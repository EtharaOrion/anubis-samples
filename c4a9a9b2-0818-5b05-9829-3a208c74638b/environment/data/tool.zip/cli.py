#!/usr/bin/env python3
"""task-ctl: local admission-control hardening compiler (BROKEN).

This tool compiles a flat hardened admission configuration for the active
enforcement class from the interacting numeric policy layers under /app/data.
It is shipped in a broken state: several derivation steps disagree with the
documented contract in README.md and schema.json. Repair it before use.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

DATA = Path("/app/data")
ADOPTED = "ADOPTED"


def load_json(path):
    return json.loads(Path(path).read_text())


def write_json(path, data):
    Path(path).write_text(json.dumps(data))


def read_lines(name):
    out = []
    for line in (DATA / name).read_text(encoding="utf-8", errors="replace").split("\n"):
        s = line.strip()
        if not s or s.startswith("#") or s.startswith(";"):
            continue
        out.append(line)
    return out


def delimited_rows(name, sep):
    lines = read_lines(name)
    if not lines:
        return []
    header = [c.strip() for c in lines[0].split(sep)]
    rows = []
    for line in lines[1:]:
        parts = [c.strip() for c in line.split(sep)]
        if len(parts) != len(header):
            continue
        rows.append(dict(zip(header, parts)))
    return rows


def round_half_up(num, den):
    return int(math.floor(num / den + 0.5))


def quantize_floor(value, step):
    return (value // step) * step


def base_inputs():
    base = load_json(DATA / "defaults.json")["base_config"]
    return int(base["max_records"]), int(base["retry_limit"]), int(base["timeout_ms"]), str(base["trailer"])


def active_class(max_records, retry_limit):
    return ((max_records // 37) + 3 * retry_limit) % 5


def first_row_value(rows, field):
    return rows[0][field]


def cmd_derive(args):
    max_records, retry_limit, timeout_ms, trailer = base_inputs()
    klass = active_class(max_records, retry_limit)

    ingress_rows = delimited_rows("ingress_rate.tsv", "\t")
    qps = int(first_row_value(ingress_rows, "ingress_qps"))
    permille = 1600
    window = 3
    rate_pre = round_half_up(qps * permille, 1000)
    rate_limit = quantize_floor(rate_pre, 25)
    burst_ceiling = round_half_up(rate_pre * window, 1)

    # scopes
    base = {r["scope"] for r in delimited_rows("scope_deny.psv", "|")}
    privilege_drop_uid = 0
    uids = []
    for line in read_lines("uid_map.env"):
        key, _, val = line.strip().partition("=")
        if key.startswith("SCOPE_") and val.strip().isdigit():
            uids.append(int(val.strip()))
    privilege_drop_uid = max(uids) if uids else 0

    # hardening fold
    rows = [r for r in delimited_rows("baseline_controls.scsv", ";") if str(r.get("class_id")).strip() == str(klass)]
    rows.sort(key=lambda r: int(r["order"]))
    score = 0
    for r in rows:
        if r.get("status") != ADOPTED:
            continue
        score += int(r["weight"])
    hardening_baseline = quantize_floor(score, 5)

    severity = 1000
    risk_index = round_half_up((100 - hardening_baseline) * severity, 1000)

    # quorum
    voters = 0
    for line in read_lines("voter_health.ndjson"):
        obj = json.loads(line)
        if str(obj.get("class_id")) == str(klass):
            voters += 1
    quorum = round_half_up(voters * 667, 1000)

    retry_backoff = quantize_floor(round_half_up(timeout_ms * (retry_limit + 1), 8), 10)

    admission = {
        "active_class": klass,
        "burst_ceiling": burst_ceiling,
        "hardening_baseline": hardening_baseline,
        "ingress_rate_limit_qps": rate_limit,
        "privilege_drop_uid": privilege_drop_uid,
        "quorum_threshold": quorum,
        "retry_backoff_base_ms": retry_backoff,
        "risk_index": risk_index,
        "trailer": trailer,
    }
    write_json(args.out, {"admission": admission})
    print("derived")


def cmd_profile(args):
    config = load_json(args.config)
    deltas = load_json(DATA / "profile_deltas.json")[args.name]
    base_ttl = 1800
    ttl = quantize_floor(base_ttl, 5)
    ttl = round_half_up(ttl * int(deltas["ttl_scale_permille"]), 1000)
    write_json(args.out, {"profile": args.name, "session_ttl_seconds": ttl})
    print("profiled")


def cmd_init(args):
    schema = load_json(args.schema)
    data = {
        "profile": schema["profile"],
        "checksum": schema["checksum"],
        "mode": schema["mode"],
    }
    write_json(args.out, data)
    print("initialized")


def cmd_set(args):
    data = load_json(args.config)
    data[args.key.upper()] = args.value
    write_json(args.config, data)
    print("set")


def cmd_validate(args):
    schema = load_json(args.schema)
    data = load_json(args.config)
    required = [k.strip() for k in schema["required_keys"].split(",") if k.strip()]
    missing = [k for k in required if k not in data]
    if missing:
        raise SystemExit("missing: " + ",".join(missing))
    bad = [k for k, v in data.items() if isinstance(v, (dict, list))]
    if bad:
        raise SystemExit("configuration must be flat: " + ",".join(sorted(bad)))
    print("ok")


def cmd_report(args):
    data = load_json(args.config)
    report = {"ok": True, "config": data, "commands": "unknown"}
    write_json(args.out, report)
    print("reported")


def main():
    parser = argparse.ArgumentParser(prog="task-ctl")
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("derive")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_derive)

    p = sub.add_parser("profile")
    p.add_argument("--name", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_profile)

    p = sub.add_parser("init")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("export-report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_report)

    args = parser.parse_args()
    if not getattr(args, "command", None):
        return
    args.func(args)


if __name__ == "__main__":
    main()
