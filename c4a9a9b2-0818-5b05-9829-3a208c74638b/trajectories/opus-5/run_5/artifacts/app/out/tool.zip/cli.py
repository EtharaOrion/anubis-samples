#!/usr/bin/env python3
"""task-ctl: local admission-control hardening compiler.

Compiles a flat hardened admission configuration for the active enforcement
class from the interacting numeric policy layers under /app/data, plus the
canary/enforce deployment profiles and the derivation sidecars.

All graded arithmetic is exact integer arithmetic with round-half-even
rounding; no floating point value ever reaches a derived scalar.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import re
import zipfile
from pathlib import Path

DATA = Path("/app/data")
ADOPTED = "ADOPTED"
DECOY_STATUSES = ("SUPERSEDED", "DRAFT", "SHADOW", "REVOKED")

PERMILLE = 1000
HARDENING_STEP = 5
TTL_STEP = 5
TLS_MIN_SCORE = 0
TLS_MAX_SCORE = 100
RETENTION_MIN_DAYS = 1
RETENTION_MAX_DAYS = 3650
SECCOMP_MIN = 0
ZIP_EPOCH = (1980, 1, 1, 0, 0, 0)


# --------------------------------------------------------------------------
# exact integer arithmetic
# --------------------------------------------------------------------------
def round_half_even(num, den):
    """Exact round-half-to-even division of two integers (den > 0)."""
    num = int(num)
    den = int(den)
    if den <= 0:
        raise ValueError("denominator must be positive")
    quo, rem = divmod(num, den)
    twice = 2 * rem
    if twice > den or (twice == den and quo % 2 != 0):
        quo += 1
    return quo


def quantize(value, step):
    """Quantize down to a multiple of step (exact integers)."""
    value = int(value)
    step = int(step)
    if step <= 0:
        raise ValueError("step must be positive")
    return (value // step) * step


def clamp(value, lo, hi):
    return max(int(lo), min(int(hi), int(value)))


# --------------------------------------------------------------------------
# io helpers
# --------------------------------------------------------------------------
def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def dumps_json(data):
    return json.dumps(data, sort_keys=True, indent=2, ensure_ascii=False) + "\n"


def write_json(path, data):
    Path(path).write_text(dumps_json(data), encoding="utf-8")


def write_text(path, text):
    if text and not text.endswith("\n"):
        text += "\n"
    Path(path).write_text(text, encoding="utf-8")


def sha256_bytes(blob):
    return hashlib.sha256(blob).hexdigest()


def sha256_file(path):
    return sha256_bytes(Path(path).read_bytes())


def read_lines(name):
    out = []
    for line in (DATA / name).read_text(encoding="utf-8", errors="replace").split("\n"):
        s = line.strip()
        if not s or s.startswith("#") or s.startswith("; ") or s == ";":
            continue
        out.append(line.rstrip("\r"))
    return out


def ini_lines(name):
    """Lines of an ini/toml style file with ';' and '#' comments removed."""
    out = []
    for line in (DATA / name).read_text(encoding="utf-8", errors="replace").split("\n"):
        s = line.strip()
        if not s or s.startswith("#") or s.startswith(";"):
            continue
        out.append(s)
    return out


def delimited_rows(name, sep):
    lines = read_lines(name)
    if not lines:
        return []
    header = [c.strip() for c in lines[0].split(sep)]
    rows = []
    for line in lines[1:]:
        parts = [c.strip() for c in line.split(sep)]
        if len(parts) != len(header):
            continue
        rows.append(dict(zip(header, parts)))
    return rows


def ws_rows(name, columns=None):
    """Whitespace-delimited rows; columns given when the header is a comment."""
    lines = read_lines(name)
    if not lines:
        return []
    if columns is None:
        columns = lines[0].split()
        lines = lines[1:]
    rows = []
    for line in lines:
        parts = line.split()
        if len(parts) != len(columns):
            continue
        rows.append(dict(zip(columns, parts)))
    return rows


def json_rows(name):
    rows = []
    for line in read_lines(name):
        s = line.strip()
        if not s.startswith("{"):
            continue
        rows.append(json.loads(s))
    return rows


def ini_sections(name):
    """Parse [section] key = value blocks; values keep their literal text."""
    sections = {}
    current = None
    for line in ini_lines(name):
        if line.startswith("[") and line.endswith("]"):
            current = line[1:-1].strip()
            sections[current] = {}
            continue
        if current is None or "=" not in line:
            continue
        key, _, val = line.partition("=")
        sections[current][key.strip()] = val.strip().strip('"').strip("'")
    return sections


def kv_lines(name, sep="="):
    out = {}
    for line in ini_lines(name):
        if sep not in line:
            continue
        key, _, val = line.partition(sep)
        out[key.strip()] = val.strip().strip('"').strip("'")
    return out


def adopted(rows, status_key="status"):
    return [r for r in rows if str(r.get(status_key, "")).strip() == ADOPTED]


def for_class(rows, klass, class_key="class_id"):
    return [r for r in rows if str(r.get(class_key, "")).strip() == str(klass)]


def bind(rows, klass, class_key="class_id", status_key="status"):
    """Authoritative binding: ADOPTED rows of the active class only."""
    return [
        r
        for r in adopted(rows, status_key)
        if str(r.get(class_key, "")).strip() == str(klass)
    ]


def only(rows, what):
    if not rows:
        raise SystemExit("no authoritative row bound for " + what)
    return rows[0]


# --------------------------------------------------------------------------
# policy layer readers
# --------------------------------------------------------------------------
def base_inputs():
    base = load_json(DATA / "defaults.json")["base_config"]
    return (
        int(base["max_records"]),
        int(base["retry_limit"]),
        int(base["timeout_ms"]),
        str(base["trailer"]),
    )


def class_index_rows():
    rows = []
    for r in delimited_rows("class_index.tsv2", "\t\t"):
        rows.append(
            {
                "class_id": int(r["class_id"]),
                "lo": int(r["selector_lo"]),
                "hi": int(r["selector_hi"]),
                "status": r["status"],
            }
        )
    return rows


def active_class(max_records):
    """Active enforcement class from the base budget via the class index."""
    index = [r for r in class_index_rows() if r["status"] == ADOPTED]
    span = max(r["hi"] for r in index) + 1
    selector = max_records % span
    for row in sorted(index, key=lambda r: r["lo"]):
        if row["lo"] <= selector <= row["hi"]:
            return row["class_id"], selector, span
    raise SystemExit("no adopted enforcement class covers selector %d" % selector)


def ingress_qps(klass):
    rows = bind(delimited_rows("ingress_rate.tsv", "\t"), klass)
    return int(only(rows, "ingress_qps")["ingress_qps"])


def burst_layer(klass):
    sections = ini_sections("burst_multiplier.ini")
    block = sections.get("class.%d" % klass, {})
    if block.get("status") != ADOPTED:
        raise SystemExit("burst multiplier block for class %d is not adopted" % klass)
    permille = int(block["burst_multiplier_permille"])
    window = int(block["window_seconds"])
    win_rows = bind(
        ws_rows("window_seconds.conf", ["class_id", "window_seconds", "status"]), klass
    )
    window_conf = int(only(win_rows, "window_seconds")["window_seconds"])
    if window_conf != window:
        raise SystemExit("window layers disagree for class %d" % klass)
    return permille, window


def rate_granularity(klass):
    rows = bind(delimited_rows("rate_gran.caret", "^"), klass)
    return int(only(rows, "rate granularity")["gran"])


def scope_sets(klass):
    base = {r["scope"] for r in bind(json_rows("scope_base.jsonl"), klass)}
    overlay = {r["scope"] for r in bind(json_rows("scope_overlay.ndjson"), klass)}
    deny = {r["scope"] for r in bind(delimited_rows("scope_deny.psv", "|"), klass)}
    effective = (base | overlay) - deny
    return base, overlay, deny, effective


def scope_uids():
    uids = {}
    for line in read_lines("uid_map.env"):
        key, _, val = line.strip().partition("=")
        key = key.strip()
        val = val.strip()
        if key.startswith("SCOPE_") and val.isdigit():
            uids[key[len("SCOPE_"):].lower()] = int(val)
    return uids


def uid_floor(klass):
    rows = bind(delimited_rows("uid_floor.hex", ":"), klass)
    return int(only(rows, "uid floor")["floor_hex"], 16)


def control_rows(klass):
    rows = for_class(delimited_rows("baseline_controls.scsv", ";"), klass)
    return sorted(rows, key=lambda r: int(r["order"]))


def hardening_fold(klass):
    """Ordered carry-aware fold of the adopted control layer.

    The carry flag of an adopted control carries one unit forward into the
    next adopted control of the ordered layer.
    """
    trace = []
    score = 0
    carry = 0
    for row in control_rows(klass):
        entry = {
            "order": int(row["order"]),
            "control_id": row["control_id"],
            "weight": int(row["weight"]),
            "carry": int(row["carry_flag"]),
            "status": row["status"],
            "adopted": row["status"] == ADOPTED,
            "running": None,
        }
        if entry["adopted"]:
            score += entry["weight"] + carry
            carry = entry["carry"]
            entry["running"] = score
        trace.append(entry)
    return score, trace


def hardening_bounds(klass):
    block = ini_sections("hardening_bounds.toml").get("class.%d" % klass, {})
    if block.get("status") != ADOPTED:
        raise SystemExit("hardening bounds for class %d are not adopted" % klass)
    return int(block["floor"]), int(block["ceil"])


def severity_permille(klass):
    for line in read_lines("severity_weight.kv"):
        parts = [p.strip() for p in line.split(":")]
        if len(parts) != 3:
            continue
        name, permille, status = parts
        if name == "class%d" % klass and status == ADOPTED:
            return int(permille)
    raise SystemExit("no adopted severity weight for class %d" % klass)


def risk_constants():
    consts = kv_lines("risk_const.env2")
    if consts.get("STATUS") != ADOPTED:
        raise SystemExit("risk constants are not adopted")
    return int(consts["BASELINE_COMPLEMENT"]), int(consts["RISK_DIVISOR"])


def healthy_voters(klass):
    count = 0
    for row in bind(json_rows("voter_health.ndjson"), klass):
        if row.get("healthy") is True:
            count += 1
    return count


def quorum_permille(klass):
    rows = bind(delimited_rows("quorum_permille.tilde", "~"), klass)
    return int(only(rows, "quorum permille")["permille"])


def tls_floor(klass):
    scores = [
        int(r["score"])
        for r in bind(delimited_rows("tls_matrix.csv", ","), klass)
        if r.get("enabled") == "true"
    ]
    if not scores:
        raise SystemExit("no adopted enabled TLS suite for class %d" % klass)
    return clamp(max(scores), TLS_MIN_SCORE, TLS_MAX_SCORE)


def seccomp_sets(klass):
    allow = {r["syscall"] for r in bind(delimited_rows("seccomp_allow.tsv", "\t"), klass)}
    deny = {r["syscall"] for r in bind(delimited_rows("seccomp_deny.psv", "|"), klass)}
    return allow, deny, allow - deny


def retention_days(klass):
    block = ini_sections("retention.ini").get("class.%d" % klass, {})
    if block.get("status") != ADOPTED:
        raise SystemExit("retention block for class %d is not adopted" % klass)
    return clamp(int(block["retention_days"]), RETENTION_MIN_DAYS, RETENTION_MAX_DAYS)


def nonce_floor(klass):
    block = ini_sections("nonce_bounds.toml2").get("class.%d" % klass, {})
    if block.get("status") != ADOPTED:
        raise SystemExit("nonce bounds for class %d are not adopted" % klass)
    return int(block["floor_ms"])


def sessions_ceiling(klass):
    rows = bind(delimited_rows("sessions_cap.csv2", ","), klass)
    return int(only(rows, "session cap ceiling")["abs_ceil"])


def retry_step(klass):
    rows = bind(delimited_rows("retry_backoff.psv2", "||"), klass)
    return int(only(rows, "retry backoff step")["step"])


PRECEDENCE_FIELDS = ("session_ttl_seconds", "nonce_window_ms", "max_concurrent_sessions")


def precedence(klass):
    """Resolve base -> overlay -> pinned (the pinned layer binds only when pinned)."""
    defaults = load_json(DATA / "defaults.json")["layer_defaults"]
    overrides = load_json(DATA / "layer_overrides.json").get("class_%d" % klass, {})
    pinned = load_json(DATA / "pinned_overrides.json").get("class_%d" % klass, {})
    resolved = {}
    detail = {}
    for field in PRECEDENCE_FIELDS:
        value = int(defaults[field])
        source = "defaults"
        if field in overrides:
            value = int(overrides[field])
            source = "layer_overrides"
        if pinned.get("pinned") is True and field in pinned:
            value = int(pinned[field])
            source = "pinned_overrides"
        resolved[field] = value
        detail[field] = {"default": int(defaults[field]), "resolved": value, "source": source}
    resolved["nonce_window_ms"] = max(resolved["nonce_window_ms"], nonce_floor(klass))
    resolved["max_concurrent_sessions"] = min(
        resolved["max_concurrent_sessions"], sessions_ceiling(klass)
    )
    for field in PRECEDENCE_FIELDS:
        detail[field]["resolved"] = resolved[field]
    return resolved, detail


# --------------------------------------------------------------------------
# derivation
# --------------------------------------------------------------------------
def derive_all():
    max_records, retry_limit, timeout_ms, trailer = base_inputs()
    klass, selector, span = active_class(max_records)

    qps = ingress_qps(klass)
    burst_permille, window = burst_layer(klass)
    gran = rate_granularity(klass)
    rate_pre = round_half_even(qps * burst_permille, PERMILLE)
    rate_limit = quantize(rate_pre, gran)
    burst_ceiling = rate_limit * window

    base_scopes, overlay_scopes, deny_scopes, effective = scope_sets(klass)
    uids = scope_uids()
    floor = uid_floor(klass)
    granted = {s: uids[s] for s in sorted(effective) if s in uids}
    if not granted:
        raise SystemExit("no uid mapping for the effective scope set")
    privilege_drop_uid = max(min(granted.values()), floor)

    fold_score, fold_trace = hardening_fold(klass)
    h_floor, h_ceil = hardening_bounds(klass)
    hardening_baseline = quantize(clamp(fold_score, h_floor, h_ceil), HARDENING_STEP)

    severity = severity_permille(klass)
    complement, divisor = risk_constants()
    risk_index = round_half_even((complement - hardening_baseline) * severity, divisor)

    voters = healthy_voters(klass)
    q_permille = quorum_permille(klass)
    quorum_threshold = clamp(round_half_even(voters * q_permille, PERMILLE), 1, voters)

    tls_score = tls_floor(klass)
    allow, deny, seccomp_effective = seccomp_sets(klass)
    seccomp_allowed = max(len(seccomp_effective), SECCOMP_MIN)
    retention = retention_days(klass)

    resolved, precedence_detail = precedence(klass)

    step = retry_step(klass)
    retry_backoff = quantize(round_half_even(timeout_ms, retry_limit + 1), step)

    return {
        "class": klass,
        "selector": selector,
        "selector_span": span,
        "max_records": max_records,
        "retry_limit": retry_limit,
        "timeout_ms": timeout_ms,
        "trailer": trailer,
        "ingress_qps": qps,
        "burst_permille": burst_permille,
        "window_seconds": window,
        "rate_granularity": gran,
        "rate_pre": rate_pre,
        "ingress_rate_limit_qps": rate_limit,
        "burst_ceiling": burst_ceiling,
        "base_scopes": sorted(base_scopes),
        "overlay_scopes": sorted(overlay_scopes),
        "deny_scopes": sorted(deny_scopes),
        "effective_scopes": sorted(effective),
        "effective_scope_count": len(effective),
        "scope_uids": granted,
        "uid_floor": floor,
        "privilege_drop_uid": privilege_drop_uid,
        "fold_score": fold_score,
        "fold_trace": fold_trace,
        "hardening_floor": h_floor,
        "hardening_ceil": h_ceil,
        "hardening_baseline": hardening_baseline,
        "severity_permille": severity,
        "baseline_complement": complement,
        "risk_divisor": divisor,
        "risk_index": risk_index,
        "healthy_voters": voters,
        "quorum_permille": q_permille,
        "quorum_threshold": quorum_threshold,
        "tls_floor_score": tls_score,
        "seccomp_allow": sorted(allow),
        "seccomp_deny": sorted(deny),
        "seccomp_effective": sorted(seccomp_effective),
        "seccomp_allowed_count": seccomp_allowed,
        "audit_retention_days": retention,
        "session_ttl_seconds": resolved["session_ttl_seconds"],
        "nonce_window_ms": resolved["nonce_window_ms"],
        "max_concurrent_sessions": resolved["max_concurrent_sessions"],
        "precedence": precedence_detail,
        "retry_step": step,
        "retry_backoff_base_ms": retry_backoff,
    }


def contract_strings(schema_path):
    schema = load_json(schema_path)
    return {
        "checksum": schema["checksum"],
        "control_plane": schema["control_plane"],
        "image_runtime": schema["image_runtime"],
        "mode": schema["mode"],
        "profile": schema["profile"],
    }


def required_keys(schema):
    keys = schema["required_keys"]
    if isinstance(keys, str):
        keys = [k.strip() for k in keys.split(",") if k.strip()]
    return list(keys)


def build_config(derived, base=None):
    config = dict(base or {})
    config.update(
        {
            "active_class": derived["class"],
            "audit_retention_days": derived["audit_retention_days"],
            "burst_ceiling": derived["burst_ceiling"],
            "effective_scope_count": derived["effective_scope_count"],
            "hardening_baseline": derived["hardening_baseline"],
            "ingress_rate_limit_qps": derived["ingress_rate_limit_qps"],
            "max_concurrent_sessions": derived["max_concurrent_sessions"],
            "nonce_window_ms": derived["nonce_window_ms"],
            "privilege_drop_uid": derived["privilege_drop_uid"],
            "quorum_threshold": derived["quorum_threshold"],
            "retry_backoff_base_ms": derived["retry_backoff_base_ms"],
            "risk_index": derived["risk_index"],
            "seccomp_allowed_count": derived["seccomp_allowed_count"],
            "session_ttl_seconds": derived["session_ttl_seconds"],
            "tls_floor_score": derived["tls_floor_score"],
            "trailer": derived["trailer"],
        }
    )
    config.setdefault("enforcement_profile", "main")
    return config


def coerce_scalar(value):
    if isinstance(value, bool) or isinstance(value, (dict, list)):
        raise SystemExit("configuration values must be scalar")
    text = str(value).strip()
    if text.startswith("{") or text.startswith("["):
        raise SystemExit("configuration values must be scalar")
    if re.fullmatch(r"[+-]?\d+", text):
        return int(text)
    return text


# --------------------------------------------------------------------------
# profiles
# --------------------------------------------------------------------------
def profile_names():
    names = []
    for line in read_lines("profile_map.kv3"):
        parts = [p.strip() for p in line.split(":")]
        if len(parts) == 3 and parts[2] == ADOPTED:
            names.append((int(parts[1]), parts[0]))
    return [n for _, n in sorted(names)]


def apply_profile(config, derived, name):
    if name not in profile_names():
        raise SystemExit("profile %s is not adopted" % name)
    deltas = load_json(DATA / "profile_deltas.json")[name]
    scaled = round_half_even(
        int(config["session_ttl_seconds"]) * int(deltas["ttl_scale_permille"]), PERMILLE
    )
    out = dict(config)
    out["session_ttl_seconds"] = quantize(scaled, TTL_STEP)
    out["quorum_threshold"] = clamp(
        int(config["quorum_threshold"]) + int(deltas["quorum_delta"]),
        1,
        derived["healthy_voters"],
    )
    out["risk_index"] = int(config["risk_index"]) + int(deltas["risk_delta"])
    out["enforcement_profile"] = name
    return out


# --------------------------------------------------------------------------
# convergence cross-checks against the mirror layers
# --------------------------------------------------------------------------
def mirror_checks(klass, derived):
    checks = []

    def add(name, primary, mirrors):
        checks.append(
            {
                "quantity": name,
                "primary": primary,
                "mirrors": mirrors,
                "converged": bool(mirrors) and all(m == primary for m in mirrors),
            }
        )

    qps_mirrors = [
        int(r["qps"]) for r in bind(delimited_rows("ingress_mirror.pipe", "|"), klass, "class")
    ]
    qps_mirrors += [
        int(r["qps"]) for r in json_rows("ingress_alt.jsonl2") if r["c"] == klass and r["s"] == ADOPTED
    ]
    add("ingress_qps", derived["ingress_qps"], qps_mirrors)

    burst_mirrors = [
        int(r["permille_hex"], 16)
        for r in bind(delimited_rows("burst_mirror.hex2", "="), klass, "class")
    ]
    props = kv_lines("burst_alt.properties")
    if props.get("burst.class%d.status" % klass) == ADOPTED:
        burst_mirrors.append(int(props["burst.class%d.permille" % klass]))
    add("burst_permille", derived["burst_permille"], burst_mirrors)

    add(
        "window_seconds",
        derived["window_seconds"],
        [
            int(r["window"])
            for r in bind(delimited_rows("window_mirror.scsv3", ";;;"), klass, "class")
        ],
    )
    add(
        "rate_granularity",
        derived["rate_granularity"],
        [int(r["gran"]) for r in bind(ws_rows("gran_mirror.fixed2"), klass, "class")],
    )
    add(
        "severity_permille",
        derived["severity_permille"],
        [
            int(r["permille"])
            for r in bind(delimited_rows("severity_mirror.caret2", "^^"), klass, "class")
        ]
        + [
            int(m.group(1))
            for m in re.finditer(
                r"\(risk \(class %d\) \(permille (\d+)\) \(status ADOPTED\)\)" % klass,
                (DATA / "risk_curve.sexp").read_text(encoding="utf-8"),
            )
        ],
    )
    add(
        "quorum_permille",
        derived["quorum_permille"],
        [
            int(r["permille"])
            for r in bind(delimited_rows("quorum_mirror.rst2", " :: "), klass, "class")
        ],
    )
    roster = len(
        re.findall(
            r'<tr data-class="%d" data-status="ADOPTED">healthy</tr>' % klass,
            (DATA / "voter_roster.html2").read_text(encoding="utf-8"),
        )
    )
    add(
        "healthy_voters",
        derived["healthy_voters"],
        [int(r["voters"]) for r in bind(delimited_rows("voters_mirror.kv4", "::"), klass, "class")]
        + [roster],
    )
    tls_mirrors = [
        int(r["score"]) for r in bind(delimited_rows("tls_mirror.tilde3", "~~~"), klass, "class")
    ]
    tls_mirrors += [
        int(m.group(1))
        for m in re.finditer(
            r":class:%d :score:(\d+) :enabled:true :status:ADOPTED" % klass,
            (DATA / "tls_suites.rst").read_text(encoding="utf-8"),
        )
    ]
    add("tls_floor_score", derived["tls_floor_score"], tls_mirrors)

    retention_mirrors = [
        int(r["days"])
        for r in bind(delimited_rows("retention_mirror.psv4", "||||"), klass, "class")
    ]
    alt = kv_lines("retention_alt.kv2")
    if alt.get("retention.class.%d.status" % klass) == ADOPTED:
        retention_mirrors.append(int(alt["retention.class.%d.days" % klass]))
    add("audit_retention_days", derived["audit_retention_days"], retention_mirrors)

    add(
        "effective_scope_count",
        derived["effective_scope_count"],
        [
            int(r["scopes"])
            for r in bind(delimited_rows("scopecount_mirror.tsv3", "\t\t\t"), klass, "class")
        ],
    )

    census = []
    for m in re.finditer(
        r'\{:class (\d+) :base (\d+) :overlay (\d+) :deny (\d+) :status "ADOPTED"\}',
        (DATA / "scope_census.edn").read_text(encoding="utf-8"),
    ):
        if int(m.group(1)) == klass:
            census.append([int(m.group(2)), int(m.group(3)), int(m.group(4))])
    add(
        "scope_layer_sizes",
        [len(derived["base_scopes"]), len(derived["overlay_scopes"]), len(derived["deny_scopes"])],
        census,
    )

    uid_mirrors = []
    for line in read_lines("privilege_bits.b64"):
        try:
            decoded = base64.b64decode(line.strip()).decode("utf-8")
        except Exception:
            continue
        m = re.fullmatch(r"class=(\d+);uid=(\d+);status=(\w+)", decoded)
        if m and int(m.group(1)) == klass and m.group(3) == ADOPTED:
            uid_mirrors.append(int(m.group(2)))
    add("privilege_drop_uid", derived["privilege_drop_uid"], uid_mirrors)

    bounds_mirrors = [
        [int(r["floor"]), int(r["ceil"])]
        for r in bind(
            ws_rows("bounds_alt.fixed", ["class", "floor", "ceil", "status"]), klass, "class"
        )
    ]
    add("hardening_bounds", [derived["hardening_floor"], derived["hardening_ceil"]], bounds_mirrors)

    alt_controls = [
        [r["control_id"], int(r["weight"]), int(r["carry"])]
        for r in bind(delimited_rows("controls_alt.psv3", "|||"), klass)
    ]
    primary_controls = [
        [e["control_id"], e["weight"], e["carry"]] for e in derived["fold_trace"] if e["adopted"]
    ]
    add("adopted_controls", primary_controls, [alt_controls])

    ledger = sorted(
        {
            r["syscall"]
            for r in bind(delimited_rows("seccomp_ledger.scsv2", ";;"), klass)
            if r["action"] == "allow"
        }
    )
    add("seccomp_allow_set", derived["seccomp_allow"], [ledger])

    add(
        "retry_step",
        derived["retry_step"],
        [int(r["step"]) for r in bind(delimited_rows("retry_backoff.psv2", "||"), klass)],
    )
    return checks


# --------------------------------------------------------------------------
# commands
# --------------------------------------------------------------------------
def cmd_init(args):
    write_json(args.out, contract_strings(args.schema))
    print("initialized")


def cmd_derive(args):
    derived = derive_all()
    base = {}
    if args.config and Path(args.config).exists():
        base = load_json(args.config)
    if args.schema:
        base.update(contract_strings(args.schema))
    write_json(args.out, build_config(derived, base))
    print("derived class=%d" % derived["class"])


def cmd_set(args):
    data = load_json(args.config)
    data[args.key] = coerce_scalar(args.value)
    write_json(args.config, data)
    print("set")


def cmd_validate(args):
    schema = load_json(args.schema)
    data = load_json(args.config)
    missing = [k for k in required_keys(schema) if k not in data]
    if missing:
        raise SystemExit("missing: " + ",".join(sorted(missing)))
    bad = [k for k, v in data.items() if isinstance(v, (dict, list))]
    if bad:
        raise SystemExit("configuration must be flat: " + ",".join(sorted(bad)))
    print("ok")


def cmd_profile(args):
    derived = derive_all()
    config = load_json(args.config)
    write_json(args.out, apply_profile(config, derived, args.name))
    print("profiled %s" % args.name)


def cmd_delta_report(args):
    main = load_json(args.config)
    report = {"base": "config.json", "profiles": {}}
    for name, path in (("canary", args.canary), ("enforce", args.enforce)):
        prof = load_json(path)
        deltas = {}
        changed = []
        for key in sorted(set(main) | set(prof)):
            mv = main.get(key)
            pv = prof.get(key)
            if mv == pv:
                continue
            changed.append(key)
            if isinstance(mv, int) and isinstance(pv, int):
                deltas[key] = {"main": mv, "profile": pv, "delta": pv - mv}
            else:
                deltas[key] = {"main": mv, "profile": pv, "delta": None}
        report["profiles"][name] = {
            "changed_keys": changed,
            "deltas": deltas,
            "trailer": prof.get("trailer"),
        }
    write_json(args.out, report)
    print("delta-report")


def cmd_sidecars(args):
    derived = derive_all()
    config = load_json(args.config)
    out = Path(args.outdir)
    klass = derived["class"]

    rows = ["field,value"]
    for key in sorted(config):
        rows.append("%s,%s" % (key, config[key]))
    write_text(out / "admission_matrix.csv", "\n".join(rows))

    write_text(
        out / "rate_limit_plan.ini",
        "\n".join(
            [
                "[rate]",
                "class = %d" % klass,
                "ingress_rate_limit_qps = %d" % derived["ingress_rate_limit_qps"],
                "burst_ceiling = %d" % derived["burst_ceiling"],
            ]
        ),
    )

    lines = ["layer\tscope\tincluded"]
    for scope in derived["base_scopes"]:
        lines.append("base\t%s\tyes" % scope)
    for scope in derived["overlay_scopes"]:
        lines.append("overlay\t%s\tyes" % scope)
    for scope in derived["deny_scopes"]:
        lines.append("deny\t%s\tno" % scope)
    for scope in derived["effective_scopes"]:
        lines.append("effective\t%s\tyes" % scope)
    write_text(out / "scope_reconciliation.tsv", "\n".join(lines))

    lines = ["order|control_id|weight|carry|status|running"]
    for entry in derived["fold_trace"]:
        running = "skip" if entry["running"] is None else str(entry["running"])
        lines.append(
            "%d|%s|%d|%d|%s|%s"
            % (
                entry["order"],
                entry["control_id"],
                entry["weight"],
                entry["carry"],
                entry["status"],
                running,
            )
        )
    write_text(out / "hardening_fold_trace.psv", "\n".join(lines))

    write_text(
        out / "quorum_plan.kv",
        "healthy_voters:%d\nquorum_threshold:%d"
        % (derived["healthy_voters"], derived["quorum_threshold"]),
    )

    write_text(
        out / "risk_ledger.env",
        "HARDENING_BASELINE=%d\nRISK_INDEX=%d\nSEVERITY_PERMILLE=%d"
        % (derived["hardening_baseline"], derived["risk_index"], derived["severity_permille"]),
    )

    lines = []
    for field in PRECEDENCE_FIELDS:
        detail = derived["precedence"][field]
        lines.append("%s.default=%d" % (field, detail["default"]))
        lines.append("%s.resolved=%d" % (field, detail["resolved"]))
    write_text(out / "precedence_resolution.properties", "\n".join(lines))

    lines = []
    for scope in derived["effective_scopes"]:
        lines.append(json.dumps({"scope": scope, "uid": derived["scope_uids"][scope]}, sort_keys=True))
    write_text(out / "privilege_map.ndjson", "\n".join(lines))

    write_text(
        out / "seccomp_summary.tsv",
        "class\tseccomp_allowed_count\n%d\t%d" % (klass, derived["seccomp_allowed_count"]),
    )

    write_text(out / "tls_floor.env", "TLS_FLOOR_SCORE=%d" % derived["tls_floor_score"])

    write_text(
        out / "retention_schedule.csv",
        "class,audit_retention_days\n%d,%d" % (klass, derived["audit_retention_days"]),
    )
    print("sidecars")


def cmd_class_ordering(args):
    rows = [
        ("main", load_json(args.config)),
        ("canary", load_json(args.canary)),
        ("enforce", load_json(args.enforce)),
    ]
    ordered = sorted(rows, key=lambda r: (int(r[1]["risk_index"]), r[0]))
    lines = ["profile\trisk_index"]
    for name, cfg in ordered:
        lines.append("%s\t%d" % (name, int(cfg["risk_index"])))
    write_text(args.out, "\n".join(lines))
    print("class-ordering")


def cmd_audit(args):
    derived = derive_all()
    config = load_json(args.config)
    lines = ['<?xml version="1.0" encoding="UTF-8"?>', "<derivation_audit>"]
    lines.append("  <active_class>%d</active_class>" % derived["class"])
    lines.append(
        '  <selector base_budget="%d" value="%d" span="%d"/>'
        % (derived["max_records"], derived["selector"], derived["selector_span"])
    )
    rules = {
        "active_class": "adopted class_index range covering max_records mod span",
        "audit_retention_days": "retention.ini class block within bounds",
        "burst_ceiling": "ingress_rate_limit_qps * window_seconds",
        "effective_scope_count": "|(base union overlay) minus deny|",
        "hardening_baseline": "quantize(clamp(carry_fold, floor, ceil), %d)" % HARDENING_STEP,
        "ingress_rate_limit_qps": "quantize(rhe(qps * burst_permille, 1000), gran)",
        "max_concurrent_sessions": "precedence(defaults, overrides, pinned) capped by abs_ceil",
        "nonce_window_ms": "precedence(defaults, overrides, pinned) floored by nonce floor",
        "privilege_drop_uid": "max(min(uid of effective scopes), uid_floor)",
        "quorum_threshold": "clamp(rhe(healthy_voters * permille, 1000), 1, healthy_voters)",
        "retry_backoff_base_ms": "quantize(rhe(timeout_ms, retry_limit + 1), step)",
        "risk_index": "rhe((complement - hardening_baseline) * severity_permille, divisor)",
        "seccomp_allowed_count": "|allow minus deny|",
        "session_ttl_seconds": "precedence(defaults, overrides, pinned)",
        "tls_floor_score": "max adopted enabled suite score within bounds",
    }
    for field in sorted(rules):
        lines.append(
            '  <field name="%s" value="%s" rule="%s"/>' % (field, config[field], rules[field])
        )
    inputs = {
        "burst_permille": derived["burst_permille"],
        "fold_score": derived["fold_score"],
        "hardening_ceil": derived["hardening_ceil"],
        "hardening_floor": derived["hardening_floor"],
        "healthy_voters": derived["healthy_voters"],
        "ingress_qps": derived["ingress_qps"],
        "quorum_permille": derived["quorum_permille"],
        "rate_granularity": derived["rate_granularity"],
        "retry_step": derived["retry_step"],
        "severity_permille": derived["severity_permille"],
        "uid_floor": derived["uid_floor"],
        "window_seconds": derived["window_seconds"],
    }
    for key in sorted(inputs):
        lines.append('  <input name="%s" value="%d"/>' % (key, inputs[key]))
    lines.append("  <trailer>%s</trailer>" % config["trailer"])
    lines.append("</derivation_audit>")
    write_text(args.out, "\n".join(lines))
    print("audit")


def cmd_convergence(args):
    derived = derive_all()
    checks = mirror_checks(derived["class"], derived)
    lines = ["convergence report for active enforcement class %d" % derived["class"], ""]
    for check in sorted(checks, key=lambda c: c["quantity"]):
        lines.append(
            "%s primary=%s mirrors=%s converged=%s"
            % (
                check["quantity"],
                json.dumps(check["primary"], sort_keys=True),
                json.dumps(check["mirrors"], sort_keys=True),
                "yes" if check["converged"] else "no",
            )
        )
    lines.append("")
    lines.append("converged_quantities=%d" % sum(1 for c in checks if c["converged"]))
    lines.append("total_quantities=%d" % len(checks))
    lines.append("all_converged=%s" % ("yes" if all(c["converged"] for c in checks) else "no"))
    write_text(args.out, "\n".join(lines))
    print("convergence")


def cmd_census(args):
    lines = []
    for path in sorted(DATA.iterdir()):
        if not path.is_file():
            continue
        blob = path.read_bytes()
        lines.append(
            json.dumps(
                {
                    "bytes": len(blob),
                    "lines": blob.count(b"\n"),
                    "path": path.name,
                    "sha256": sha256_bytes(blob),
                },
                sort_keys=True,
            )
        )
    write_text(args.out, "\n".join(lines))
    print("census")


def cmd_package(args):
    src = Path(args.src)
    names = sorted(
        p.name for p in src.iterdir() if p.is_file() and p.suffix in (".py", ".md", ".json")
    )
    with zipfile.ZipFile(args.out, "w", zipfile.ZIP_DEFLATED) as zf:
        for name in names:
            info = zipfile.ZipInfo(name, date_time=ZIP_EPOCH)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            zf.writestr(info, (src / name).read_bytes())
    print("packaged")


def cmd_validation_report(args):
    schema = load_json(args.schema)
    rules = load_json(DATA / "validation_rules.json")
    config = load_json(args.config)
    out = Path(args.outdir)
    required = required_keys(schema)
    checks = []

    missing = sorted(k for k in required if k not in config)
    checks.append(
        {"name": "required_keys_present", "status": "pass" if not missing else "fail", "detail": missing}
    )
    nested = sorted(k for k, v in config.items() if isinstance(v, (dict, list)))
    checks.append(
        {"name": "flat_scalar_config", "status": "pass" if not nested else "fail", "detail": nested}
    )
    forbidden = sorted(k for k in rules["forbidden_keys"] if k in config)
    checks.append(
        {"name": "forbidden_keys_absent", "status": "pass" if not forbidden else "fail", "detail": forbidden}
    )
    self_name = Path(args.out).name
    present = sorted(
        a for a in rules["required_artifacts"] if a == self_name or (out / a).exists()
    )
    pending = sorted(
        a for a in rules["required_artifacts"] if a != self_name and not (out / a).exists()
    )
    checks.append(
        {
            "name": "required_artifacts",
            "status": "pass",
            "detail": {"pending_by_order": pending, "present": present},
        }
    )
    oversized = sorted(
        a
        for a in present
        if (out / a).exists() and (out / a).stat().st_size > int(rules["max_artifact_bytes"])
    )
    checks.append(
        {"name": "artifact_size_bounds", "status": "pass" if not oversized else "fail", "detail": oversized}
    )
    extra = sorted(k for k in config if k not in required)
    checks.append({"name": "no_extra_keys", "status": "pass" if not extra else "fail", "detail": extra})
    trailer_ok = config.get("trailer") == base_inputs()[3]
    checks.append(
        {
            "name": "trailer_canonical",
            "status": "pass" if trailer_ok else "fail",
            "detail": config.get("trailer"),
        }
    )
    floats = sorted(k for k, v in config.items() if isinstance(v, float))
    checks.append({"name": "no_float_values", "status": "pass" if not floats else "fail", "detail": floats})

    derived = derive_all()
    converged = all(c["converged"] for c in mirror_checks(derived["class"], derived))
    checks.append(
        {
            "name": "mirror_convergence",
            "status": "pass" if converged else "fail",
            "detail": derived["class"],
        }
    )
    reproduced = build_config(derived, contract_strings(args.schema))
    reproduced["enforcement_profile"] = config.get("enforcement_profile")
    checks.append(
        {
            "name": "recomputation_stable",
            "status": "pass" if reproduced == config else "fail",
            "detail": sorted(k for k in set(reproduced) | set(config) if reproduced.get(k) != config.get(k)),
        }
    )

    ok = all(c["status"] == "pass" for c in checks)
    write_json(
        args.out,
        {
            "ok": ok,
            "checks": checks,
            "config_sha256": sha256_file(args.config),
            "required_key_count": len(required),
        },
    )
    print("ok" if ok else "validation issues")


def cmd_summary(args):
    derived = derive_all()
    config = load_json(args.config)
    canary = load_json(args.canary)
    enforce = load_json(args.enforce)
    rules = load_json(DATA / "validation_rules.json")
    out = Path(args.outdir)
    write_json(
        args.out,
        {
            "active_class": derived["class"],
            "artifacts": sorted(a for a in rules["required_artifacts"] if (out / a).exists()),
            "config": config,
            "derived_inputs": {
                "burst_permille": derived["burst_permille"],
                "fold_score": derived["fold_score"],
                "healthy_voters": derived["healthy_voters"],
                "ingress_qps": derived["ingress_qps"],
                "quorum_permille": derived["quorum_permille"],
                "rate_granularity": derived["rate_granularity"],
                "retry_step": derived["retry_step"],
                "severity_permille": derived["severity_permille"],
                "uid_floor": derived["uid_floor"],
                "window_seconds": derived["window_seconds"],
            },
            "effective_scopes": derived["effective_scopes"],
            "profiles": {"canary": canary, "enforce": enforce},
            "seccomp_effective": derived["seccomp_effective"],
            "trailer": config["trailer"],
        },
    )
    print("summary")


def cmd_manifest(args):
    rules = load_json(DATA / "validation_rules.json")
    out = Path(args.outdir)
    entries = []
    for name in sorted(rules["required_artifacts"]):
        path = out / name
        if name == Path(args.out).name or not path.exists():
            continue
        blob = path.read_bytes()
        entries.append({"bytes": len(blob), "path": name, "sha256": sha256_bytes(blob)})
    write_json(
        args.out,
        {
            "artifact_count": len(entries),
            "artifacts": entries,
            "deterministic": True,
            "inputs_sha256": sha256_bytes(
                b"".join(p.read_bytes() for p in sorted(DATA.iterdir()) if p.is_file())
            ),
            "tool_sha256": sha256_file(args.tool),
        },
    )
    print("manifest")


def cmd_report(args):
    config = load_json(args.config)
    commands = json.loads(Path(args.commands).read_text(encoding="utf-8"))
    write_json(
        args.out,
        {
            "ok": True,
            "command_count": len(commands),
            "commands": commands,
            "config": config,
            "config_sha256": args.digest,
            "tool": "task-ctl",
            "trailer": config["trailer"],
        },
    )
    print("reported")


def main():
    parser = argparse.ArgumentParser(prog="task-ctl")
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("init")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("derive")
    p.add_argument("--schema")
    p.add_argument("--config")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_derive)

    p = sub.add_parser("set")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("profile")
    p.add_argument("--name", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_profile)

    p = sub.add_parser("delta-report")
    p.add_argument("--config", required=True)
    p.add_argument("--canary", required=True)
    p.add_argument("--enforce", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_delta_report)

    p = sub.add_parser("sidecars")
    p.add_argument("--config", required=True)
    p.add_argument("--outdir", required=True)
    p.set_defaults(func=cmd_sidecars)

    p = sub.add_parser("class-ordering")
    p.add_argument("--config", required=True)
    p.add_argument("--canary", required=True)
    p.add_argument("--enforce", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_class_ordering)

    p = sub.add_parser("audit")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_audit)

    p = sub.add_parser("convergence")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_convergence)

    p = sub.add_parser("census")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_census)

    p = sub.add_parser("package")
    p.add_argument("--src", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_package)

    p = sub.add_parser("validation-report")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--outdir", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_validation_report)

    p = sub.add_parser("summary")
    p.add_argument("--config", required=True)
    p.add_argument("--canary", required=True)
    p.add_argument("--enforce", required=True)
    p.add_argument("--outdir", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_summary)

    p = sub.add_parser("manifest")
    p.add_argument("--outdir", required=True)
    p.add_argument("--tool", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_manifest)

    p = sub.add_parser("export-report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest", required=True)
    p.add_argument("--commands", required=True)
    p.set_defaults(func=cmd_report)

    args = parser.parse_args()
    if not getattr(args, "command", None):
        parser.print_help()
        return
    args.func(args)


if __name__ == "__main__":
    main()
