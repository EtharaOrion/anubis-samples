# task-ctl

An offline container-image admission-control hardening compiler for a
server-side admission broker. It reads interacting numeric policy layers from
`/app/data`, selects the active enforcement class, and derives one flat hardened
admission configuration plus two deployment profiles (canary and enforce).

This build is repaired: every derived scalar follows the documented contract
below and is cross-checked against the mirror policy layers.

## Commands

- `init --schema <schema> --out <config>`: seed the fixed contract strings.
- `derive [--schema <schema>] [--config <config>] --out <config>`: derive every
  scalar from the policy layers, merged over an optional seed configuration.
- `set --config <config> --key <key> --value <value>`: set one scalar key with
  correct case and type coercion; non-scalar values are rejected.
- `validate --schema <schema> --config <config>`: confirm every required key is
  present and the configuration is flat; print `ok`.
- `profile --name <canary|enforce> --config <config> --out <profile>`: apply the
  adopted per-profile deltas.
- `delta-report --config <config> --canary <p> --enforce <p> --out <report>`.
- `sidecars --config <config> --outdir <dir>`: the eleven derivation sidecars.
- `class-ordering --config <c> --canary <p> --enforce <p> --out <tsv>`.
- `audit --config <config> --out <xml>`, `convergence --out <txt>`,
  `census --out <ndjson>`, `manifest --outdir <dir> --tool <path> --out <json>`.
- `validation-report --schema <s> --config <c> --outdir <dir> --out <json>`.
- `summary --config <c> --canary <p> --enforce <p> --outdir <dir> --out <json>`.
- `package --src <dir> --out <zip>`: deterministic repackaging of the tool.
- `export-report --config <config> --out <report> --digest <sha256> --commands <json>`:
  emit a truthful command transcript.

## Contract

- Every value is derived with exact integer arithmetic (round-half-even); no
  floating-point value may reach a graded key.
- The configuration is flat: keys map directly to integer or string scalars.
- The required key set is authoritative in `schema.json` and mirrored by the
  field registry in the policy layers.
- Only rows whose status is `ADOPTED` for the active enforcement class bind; rows
  labelled `SUPERSEDED`, `DRAFT`, `SHADOW`, or `REVOKED` are context decoys.

### Derivation rules

- `active_class`: the adopted `class_index` range covering `max_records` modulo
  the covered selector span.
- `ingress_rate_limit_qps`: `quantize(rhe(ingress_qps * burst_permille, 1000), gran)`.
- `burst_ceiling`: resolved `ingress_rate_limit_qps * window_seconds`.
- `effective_scope_count`: `|(base union overlay) minus deny|` for the active class.
- `privilege_drop_uid`: the minimum granted uid of the reconciled scope set,
  raised to the per-class uid floor.
- `hardening_baseline`: the ordered adopted control fold, where a set carry flag
  carries one unit into the next adopted control, clamped to the per-class
  `[floor, ceil]` bounds and quantized down to a multiple of 5.
- `risk_index`: `rhe((complement - hardening_baseline) * severity_permille, divisor)`.
- `quorum_threshold`: `clamp(rhe(healthy_voters * permille, 1000), 1, healthy_voters)`.
- `tls_floor_score`, `seccomp_allowed_count`, `audit_retention_days`: the adopted
  per-class layers within their documented bounds.
- `session_ttl_seconds`, `nonce_window_ms`, `max_concurrent_sessions`: resolved
  through defaults -> layer overrides -> pinned overrides (pinned entries bind
  only when `pinned` is true), then bounded by the nonce floor and session ceiling.
- `retry_backoff_base_ms`: `quantize(rhe(timeout_ms, retry_limit + 1), step)`.
