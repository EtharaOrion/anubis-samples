# task-ctl

An offline container-image admission-control hardening compiler for a
server-side admission broker. It reads interacting numeric policy layers from
`/app/data`, selects the active enforcement class, and derives one flat hardened
admission configuration plus two deployment profiles (canary and enforce).

## Commands

- `init --schema <schema> --out <config>`: seed fixed contract strings.
- `derive --out <json>`: derive every scalar from the policy layers.
- `set --config <config> --key <key> --value <value>`: set one scalar key with
  correct case and type coercion; reject any non-scalar value.
- `validate --schema <schema> --config <config>`: confirm every required key is
  present and the configuration is flat; print `ok`.
- `profile --name <canary|enforce> --config <config> --out <profile>`: apply the
  documented per-profile deltas.
- `profile-delta --config <config> --canary <p> --enforce <p> --out <report>`:
  signed deltas of each profile versus the main configuration.
- `emit-sidecars --config <config> --out-dir <dir>`: derivation sidecars.
- `class-ordering --config <config> --canary <p> --enforce <p> --out <tsv>`.
- `emit-audit --config <config> --out-dir <dir>`: audit, convergence and input
  census artifacts.
- `emit-coverage --config <config> --schema <schema> --out-dir <dir>`:
  validation report and summary.
- `emit-manifest --config <config> --out-dir <dir> --out <json>`: reproducibility
  manifest over the emitted artifacts.
- `package --src <dir> --out <zip>`: repackage the tool deterministically.
- `export-report --config <config> --out <report> --digest <sha256> --commands <json>`:
  emit a truthful command transcript.

## Contract notes

- Every value is derived with exact integer arithmetic (round-half-even); no
  floating-point value may reach a graded key.
- The configuration is flat: keys map directly to integer or string scalars.
- The required key set is authoritative in `schema.json` and mirrored by the
  field registry in the policy layers.
- Only rows whose status is `ADOPTED` for the active enforcement class bind; rows
  labelled `SUPERSEDED`, `DRAFT`, `SHADOW`, or `REVOKED` are context decoys.

## Derivation contract

- **Active class**: the base budget `max_records` is folded into the adopted
  span of `class_index.tsv2` (`selector = max_records % span`) and looked up in
  the adopted selector ranges.
- **Ingress rate limit**: adopted per-class throughput scaled by the adopted
  burst multiplier permille, round-half-even, then floor-quantized to the
  adopted rate granularity.
- **Burst ceiling**: resolved rate limit multiplied by the adopted per-class
  window.
- **Scopes**: `(base union overlay) minus deny` over adopted rows of the active
  class; `effective_scope_count` is its size and `privilege_drop_uid` is the
  minimum granted uid raised to the adopted per-class uid floor.
- **Hardening baseline**: adopted controls folded in ascending `order`; a
  control with `carry_flag=1` carries half its weight (round-half-even) into the
  next adopted control. The fold is clamped to the per-class floor/ceiling and
  floor-quantized to 5.
- **Risk index**: `(BASELINE_COMPLEMENT - hardening_baseline) * severity_permille
  / RISK_DIVISOR`, round-half-even.
- **Quorum threshold**: healthy adopted voters * quorum permille / 1000,
  round-half-even, clamped to `[1, voters]`.
- **Precedence fields**: `layer_defaults` < `layer_overrides` < `pinned_overrides`
  (the pinned layer binds only when `pinned` is true), then bounded by the
  per-class nonce floor and session ceiling.
- **Retry backoff base**: base timeout divided by the retry budget,
  round-half-even, floor-quantized to the adopted per-class step.
