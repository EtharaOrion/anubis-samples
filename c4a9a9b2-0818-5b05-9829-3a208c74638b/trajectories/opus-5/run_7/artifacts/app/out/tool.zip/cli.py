#!/usr/bin/env python3
"""task-ctl: local admission-control hardening compiler.

Compiles a flat hardened admission configuration for the active enforcement
class from the interacting numeric policy layers under /app/data.

Contract (see README.md):
  * every graded number is produced with exact integer arithmetic and
    round-half-even rounding; no floating-point value reaches a graded key,
  * only rows whose status is ADOPTED for the active enforcement class bind,
  * the emitted configuration is flat (scalars only).
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import re
import zipfile
from pathlib import Path

DATA = Path("/app/data")
ADOPTED = "ADOPTED"
HARDENING_STEP = 5
TTL_STEP = 5

PRECEDENCE_FIELDS = ("session_ttl_seconds", "nonce_window_ms", "max_concurrent_sessions")


# --------------------------------------------------------------------------
# exact integer arithmetic
# --------------------------------------------------------------------------
def round_half_even(num: int, den: int) -> int:
    """Exact integer division of num/den with banker's rounding."""
    if den == 0:
        raise ZeroDivisionError("denominator must be non-zero")
    if den < 0:
        num, den = -num, -den
    q, r = divmod(num, den)  # 0 <= r < den
    twice = 2 * r
    if twice > den or (twice == den and q % 2 != 0):
        q += 1
    return q


def quantize_floor(value: int, step: int) -> int:
    return (value // step) * step


def clamp(value: int, low: int, high: int) -> int:
    return max(low, min(high, value))


# --------------------------------------------------------------------------
# io helpers
# --------------------------------------------------------------------------
def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def dumps(data) -> str:
    return json.dumps(data, sort_keys=True, indent=2, ensure_ascii=False) + "\n"


def write_json(path, data):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(dumps(data), encoding="utf-8")


def write_text(path, text):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(text, encoding="utf-8")


def sha256_file(path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def read_lines(name):
    out = []
    for line in (DATA / name).read_text(encoding="utf-8", errors="replace").split("\n"):
        s = line.strip()
        if not s or s.startswith("#") or s.startswith(";") or s.startswith(".."):
            continue
        out.append(line)
    return out


def delimited_rows(name, sep):
    """Rows of a delimited table; empty cells created by padded separators drop out."""
    lines = read_lines(name)
    if not lines:
        return []
    header = [c.strip() for c in lines[0].split(sep) if c.strip()]
    rows = []
    for line in lines[1:]:
        parts = [c.strip() for c in line.split(sep) if c.strip() != ""]
        if len(parts) != len(header):
            continue
        rows.append(dict(zip(header, parts)))
    return rows


def whitespace_rows(name, header):
    rows = []
    for line in read_lines(name):
        parts = line.split()
        if len(parts) != len(header):
            continue
        rows.append(dict(zip(header, parts)))
    return rows


def ini_sections(name):
    """{section: {key: value}} for simple `[section]` / `key = value` layers."""
    sections = {}
    current = None
    for line in read_lines(name):
        s = line.strip()
        if s.startswith("[") and s.endswith("]"):
            current = s[1:-1].strip()
            sections.setdefault(current, {})
            continue
        if current is None or "=" not in s:
            continue
        key, _, val = s.partition("=")
        sections[current][key.strip()] = val.strip().strip('"')
    return sections


def env_pairs(name):
    pairs = {}
    for line in read_lines(name):
        key, sep, val = line.strip().partition("=")
        if sep:
            pairs[key.strip()] = val.strip()
    return pairs


def adopted(rows, class_field, klass, status_field="status"):
    return [
        r
        for r in rows
        if str(r.get(class_field)) == str(klass) and str(r.get(status_field)) == ADOPTED
    ]


def only(values, what):
    uniq = sorted(set(values))
    if len(uniq) != 1:
        raise SystemExit("ambiguous authoritative rows for %s: %r" % (what, uniq))
    return uniq[0]


def json_rows(name):
    return [json.loads(line) for line in read_lines(name)]


# --------------------------------------------------------------------------
# policy layer readers
# --------------------------------------------------------------------------
def base_inputs():
    base = load_json(DATA / "defaults.json")["base_config"]
    return (
        int(base["max_records"]),
        int(base["retry_limit"]),
        int(base["timeout_ms"]),
        str(base["trailer"]),
    )


def active_class(max_records):
    """Active enforcement class: the base budget folded into the class-index span."""
    rows = [r for r in delimited_rows("class_index.tsv2", "\t\t") if r["status"] == ADOPTED]
    span = max(int(r["selector_hi"]) for r in rows) + 1
    selector = max_records % span
    for r in sorted(rows, key=lambda r: int(r["selector_lo"])):
        if int(r["selector_lo"]) <= selector <= int(r["selector_hi"]):
            return int(r["class_id"]), selector, span
    raise SystemExit("no adopted class covers selector %d" % selector)


def ingress_qps(klass):
    rows = adopted(delimited_rows("ingress_rate.tsv", "\t"), "class_id", klass)
    return int(only([r["ingress_qps"] for r in rows], "ingress_qps"))


def burst_permille(klass):
    sec = ini_sections("burst_multiplier.ini").get("class.%d" % klass, {})
    if sec.get("status") != ADOPTED:
        raise SystemExit("no adopted burst multiplier for class %d" % klass)
    return int(sec["burst_multiplier_permille"])


def window_seconds(klass):
    rows = whitespace_rows("window_seconds.conf", ["class_id", "window_seconds", "status"])
    vals = [r["window_seconds"] for r in adopted(rows, "class_id", klass)]
    return int(only(vals, "window_seconds"))


def rate_granularity(klass):
    rows = adopted(delimited_rows("rate_gran.caret", "^"), "class_id", klass)
    return int(only([r["gran"] for r in rows], "rate_gran"))


def scope_sets(klass):
    base = {
        r["scope"]
        for r in json_rows("scope_base.jsonl")
        if r["class_id"] == klass and r["status"] == ADOPTED
    }
    overlay = {
        r["scope"]
        for r in json_rows("scope_overlay.ndjson")
        if r["class_id"] == klass and r["status"] == ADOPTED
    }
    deny = {r["scope"] for r in adopted(delimited_rows("scope_deny.psv", "|"), "class_id", klass)}
    return base, overlay, deny, (base | overlay) - deny


def scope_uids():
    uids = {}
    for key, val in env_pairs("uid_map.env").items():
        if key.startswith("SCOPE_") and val.isdigit():
            uids[key[len("SCOPE_"):].lower()] = int(val)
    return uids


def uid_floor(klass):
    rows = adopted(delimited_rows("uid_floor.hex", ":"), "class_id", klass)
    return int(only([r["floor_hex"] for r in rows], "uid_floor"), 16)


def privilege_mirror(klass):
    for line in read_lines("privilege_bits.b64"):
        text = base64.b64decode(line.strip()).decode("ascii")
        parts = dict(p.split("=", 1) for p in text.split(";"))
        if int(parts["class"]) == klass and parts["status"] == ADOPTED:
            return int(parts["uid"])
    return None


def control_rows(klass):
    rows = [
        r
        for r in delimited_rows("baseline_controls.scsv", ";")
        if str(r.get("class_id")) == str(klass)
    ]
    rows.sort(key=lambda r: int(r["order"]))
    return rows


def hardening_bounds(klass):
    sec = ini_sections("hardening_bounds.toml").get("class.%d" % klass, {})
    if sec.get("status") != ADOPTED:
        raise SystemExit("no adopted hardening bounds for class %d" % klass)
    return int(sec["floor"]), int(sec["ceil"])


def fold_controls(rows):
    """Carry-aware fold over the ordered control layer: a control whose carry_flag
    is set carries half its weight (round-half-even) into the next adopted control."""
    running = 0
    carry = 0
    trace = []
    for r in rows:
        order, cid, weight = int(r["order"]), r["control_id"], int(r["weight"])
        flag, status = int(r["carry_flag"]), r["status"]
        if status != ADOPTED:
            trace.append((order, cid, weight, flag, status, None))
            continue
        running += weight + carry
        carry = round_half_even(weight, 2) if flag == 1 else 0
        trace.append((order, cid, weight, flag, status, running))
    return running, trace


def severity_permille(klass):
    vals = []
    for line in read_lines("severity_weight.kv"):
        parts = line.strip().split(":")
        if len(parts) == 3 and parts[0] == "class%d" % klass and parts[2] == ADOPTED:
            vals.append(parts[1])
    return int(only(vals, "severity_permille"))


def risk_constants():
    pairs = env_pairs("risk_const.env2")
    return int(pairs["BASELINE_COMPLEMENT"]), int(pairs["RISK_DIVISOR"])


def healthy_voters(klass):
    return sum(
        1
        for r in json_rows("voter_health.ndjson")
        if r["class_id"] == klass and r["status"] == ADOPTED and r["healthy"] is True
    )


def quorum_permille(klass):
    rows = adopted(delimited_rows("quorum_permille.tilde", "~"), "class_id", klass)
    return int(only([r["permille"] for r in rows], "quorum_permille"))


def tls_floor(klass):
    rows = [
        r
        for r in adopted(delimited_rows("tls_matrix.csv", ","), "class_id", klass)
        if r["enabled"] == "true"
    ]
    return int(only([r["score"] for r in rows], "tls_floor_score"))


def seccomp_allowed(klass):
    allow = {
        r["syscall"] for r in adopted(delimited_rows("seccomp_allow.tsv", "\t"), "class_id", klass)
    }
    deny = {r["syscall"] for r in adopted(delimited_rows("seccomp_deny.psv", "|"), "class_id", klass)}
    return sorted(allow - deny)


def retention_days(klass):
    sec = ini_sections("retention.ini").get("class.%d" % klass, {})
    if sec.get("status") != ADOPTED:
        raise SystemExit("no adopted retention block for class %d" % klass)
    return int(sec["retention_days"])


def retry_step(klass):
    rows = adopted(delimited_rows("retry_backoff.psv2", "||"), "class_id", klass)
    return int(only([r["step"] for r in rows], "retry_step"))


def nonce_floor(klass):
    sec = ini_sections("nonce_bounds.toml2").get("class.%d" % klass, {})
    return int(sec["floor_ms"]) if sec.get("status") == ADOPTED else 0


def sessions_ceiling(klass):
    rows = adopted(delimited_rows("sessions_cap.csv2", ","), "class_id", klass)
    return int(only([r["abs_ceil"] for r in rows], "sessions_abs_ceil"))


def resolve_precedence(klass):
    """defaults < layer_overrides < pinned_overrides (the pin binds only when pinned)."""
    defaults = load_json(DATA / "defaults.json")["layer_defaults"]
    overrides = load_json(DATA / "layer_overrides.json").get("class_%d" % klass, {})
    pinned = load_json(DATA / "pinned_overrides.json").get("class_%d" % klass, {})
    pin_active = pinned.get("pinned") is True
    resolved = {}
    for field in PRECEDENCE_FIELDS:
        value = int(defaults[field])
        source = "default"
        if field in overrides:
            value = int(overrides[field])
            source = "override"
        if pin_active and field in pinned:
            value = int(pinned[field])
            source = "pinned"
        resolved[field] = {"default": int(defaults[field]), "value": value, "source": source}
    resolved["nonce_window_ms"]["value"] = max(
        resolved["nonce_window_ms"]["value"], nonce_floor(klass)
    )
    resolved["max_concurrent_sessions"]["value"] = min(
        resolved["max_concurrent_sessions"]["value"], sessions_ceiling(klass)
    )
    resolved["pin_active"] = pin_active
    return resolved


# --------------------------------------------------------------------------
# derivation
# --------------------------------------------------------------------------
def derive_all():
    max_records, retry_limit, timeout_ms, trailer = base_inputs()
    klass, selector, span = active_class(max_records)

    qps = ingress_qps(klass)
    permille = burst_permille(klass)
    window = window_seconds(klass)
    gran = rate_granularity(klass)
    rate_pre = round_half_even(qps * permille, 1000)
    rate_limit = quantize_floor(rate_pre, gran)
    burst_ceiling = rate_limit * window

    base_scopes, overlay_scopes, deny_scopes, effective = scope_sets(klass)
    uids = scope_uids()
    floor = uid_floor(klass)
    granted = {s: uids[s] for s in effective if s in uids}
    privilege_drop_uid = max(min(granted.values()), floor)

    rows = control_rows(klass)
    fold_score, trace = fold_controls(rows)
    low, high = hardening_bounds(klass)
    hardening_baseline = quantize_floor(clamp(fold_score, low, high), HARDENING_STEP)

    severity = severity_permille(klass)
    complement, divisor = risk_constants()
    risk_index = round_half_even((complement - hardening_baseline) * severity, divisor)

    voters = healthy_voters(klass)
    qpermille = quorum_permille(klass)
    quorum_threshold = clamp(round_half_even(voters * qpermille, 1000), 1, voters)

    tls_floor_score = tls_floor(klass)
    syscalls = seccomp_allowed(klass)
    audit_retention = retention_days(klass)

    precedence = resolve_precedence(klass)
    step = retry_step(klass)
    quotient = round_half_even(timeout_ms, retry_limit)
    retry_backoff = quantize_floor(quotient, step)

    schema = load_json(DATA / "config_schema.json")
    config = {
        "active_class": klass,
        "audit_retention_days": audit_retention,
        "burst_ceiling": burst_ceiling,
        "checksum": schema["checksum"],
        "control_plane": schema["control_plane"],
        "effective_scope_count": len(effective),
        "enforcement_profile": "main",
        "hardening_baseline": hardening_baseline,
        "image_runtime": schema["image_runtime"],
        "ingress_rate_limit_qps": rate_limit,
        "max_concurrent_sessions": precedence["max_concurrent_sessions"]["value"],
        "mode": schema["mode"],
        "nonce_window_ms": precedence["nonce_window_ms"]["value"],
        "privilege_drop_uid": privilege_drop_uid,
        "profile": schema["profile"],
        "quorum_threshold": quorum_threshold,
        "retry_backoff_base_ms": retry_backoff,
        "risk_index": risk_index,
        "seccomp_allowed_count": len(syscalls),
        "session_ttl_seconds": precedence["session_ttl_seconds"]["value"],
        "tls_floor_score": tls_floor_score,
        "trailer": trailer,
    }

    detail = {
        "base": {
            "max_records": max_records,
            "retry_limit": retry_limit,
            "timeout_ms": timeout_ms,
            "selector": selector,
            "selector_span": span,
        },
        "rate": {
            "ingress_qps": qps,
            "burst_multiplier_permille": permille,
            "window_seconds": window,
            "rate_granularity": gran,
            "scaled_qps": rate_pre,
        },
        "scopes": {
            "base": sorted(base_scopes),
            "overlay": sorted(overlay_scopes),
            "deny": sorted(deny_scopes),
            "effective": sorted(effective),
            "uid_floor": floor,
            "uids": {s: granted[s] for s in sorted(granted)},
            "privilege_mirror_uid": privilege_mirror(klass),
        },
        "hardening": {
            "fold_score": fold_score,
            "floor": low,
            "ceil": high,
            "step": HARDENING_STEP,
            "trace": trace,
            "severity_permille": severity,
            "baseline_complement": complement,
            "risk_divisor": divisor,
        },
        "quorum": {"healthy_voters": voters, "permille": qpermille},
        "seccomp": {"allowed": syscalls},
        "precedence": precedence,
        "retry": {"step": step, "quotient": quotient},
        "tls": {"floor_score": tls_floor_score},
        "retention": {"days": audit_retention},
    }
    return config, detail


def profile_config(config, name):
    deltas = load_json(DATA / "profile_deltas.json")[name]
    out = dict(config)
    ttl = round_half_even(
        int(config["session_ttl_seconds"]) * int(deltas["ttl_scale_permille"]), 1000
    )
    out["session_ttl_seconds"] = quantize_floor(ttl, TTL_STEP)
    out["quorum_threshold"] = int(config["quorum_threshold"]) + int(deltas["quorum_delta"])
    out["risk_index"] = int(config["risk_index"]) + int(deltas["risk_delta"])
    out["enforcement_profile"] = name
    return out


# --------------------------------------------------------------------------
# commands
# --------------------------------------------------------------------------
def cmd_derive(args):
    config, _ = derive_all()
    write_json(args.out, config)
    print("derived")


def cmd_profile(args):
    config = load_json(args.config)
    write_json(args.out, profile_config(config, args.name))
    print("profiled")


def cmd_profile_delta(args):
    config = load_json(args.config)
    report = {"base_config": str(args.config), "profiles": {}}
    for name, path in (("canary", args.canary), ("enforce", args.enforce)):
        prof = load_json(path)
        delta = {}
        for key in sorted(set(config) | set(prof)):
            a, b = config.get(key), prof.get(key)
            if a == b:
                continue
            entry = {"main": a, "profile": b}
            if isinstance(a, int) and isinstance(b, int):
                entry["delta"] = b - a
                entry["signed_delta"] = "+%d" % (b - a) if b - a >= 0 else str(b - a)
            delta[key] = entry
        report["profiles"][name] = {
            "path": str(path),
            "changed_keys": sorted(delta),
            "deltas": delta,
            "trailer": prof.get("trailer"),
        }
    report["trailer"] = config.get("trailer")
    write_json(args.out, report)
    print("delta-reported")


def cmd_init(args):
    schema = load_json(args.schema)
    data = {
        "checksum": schema["checksum"],
        "control_plane": schema["control_plane"],
        "image_runtime": schema["image_runtime"],
        "mode": schema["mode"],
        "profile": schema["profile"],
    }
    write_json(args.out, data)
    print("initialized")


def coerce_scalar(value):
    try:
        parsed = json.loads(value)
    except ValueError:
        return value
    if isinstance(parsed, (dict, list)):
        raise SystemExit("value must be scalar: " + value)
    if isinstance(parsed, float):
        raise SystemExit("floating-point values are not permitted: " + value)
    if isinstance(parsed, int) and re.fullmatch(r"-?\d+", value.strip()):
        return parsed
    return value


def cmd_set(args):
    data = load_json(args.config)
    data[args.key] = coerce_scalar(args.value)
    write_json(args.config, data)
    print("set")


def required_keys(schema):
    keys = schema["required_keys"]
    if isinstance(keys, str):
        keys = keys.split(",")
    return [k.strip() for k in keys if k.strip()]


def cmd_validate(args):
    schema = load_json(args.schema)
    data = load_json(args.config)
    missing = [k for k in required_keys(schema) if k not in data]
    if missing:
        raise SystemExit("missing: " + ",".join(missing))
    bad = [k for k, v in data.items() if isinstance(v, (dict, list))]
    if bad:
        raise SystemExit("configuration must be flat: " + ",".join(sorted(bad)))
    floats = [k for k, v in data.items() if isinstance(v, float)]
    if floats:
        raise SystemExit("floating-point values present: " + ",".join(sorted(floats)))
    print("ok")


def cmd_report(args):
    data = load_json(args.config)
    source = Path(args.commands)
    commands = json.loads(source.read_text(encoding="utf-8")) if source.exists() else json.loads(args.commands)
    report = {
        "ok": True,
        "tool": "task-ctl",
        "command_count": len(commands),
        "commands": commands,
        "config": data,
        "config_digest": sha256_file(args.config),
        "config_path": str(args.config),
        "digest": args.digest,
        "trailer": data.get("trailer"),
    }
    write_json(args.out, report)
    print("reported")


def cmd_package(args):
    src = Path(args.src)
    names = sorted(p.name for p in src.iterdir() if p.is_file())
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.out, "w", zipfile.ZIP_DEFLATED) as zf:
        for name in names:
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.external_attr = 0o644 << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            zf.writestr(info, (src / name).read_bytes())
    print("packaged")


def require_match(config, derived):
    mismatch = [k for k in derived if config.get(k) != derived[k]]
    if mismatch:
        raise SystemExit("config disagrees with derivation: " + ",".join(sorted(mismatch)))


def cmd_sidecars(args):
    config = load_json(args.config)
    derived, detail = derive_all()
    require_match(config, derived)
    out = Path(args.out_dir)
    klass = config["active_class"]

    lines = ["field,value"]
    for key in sorted(config):
        lines.append("%s,%s" % (key, config[key]))
    write_text(out / "admission_matrix.csv", "\n".join(lines) + "\n")

    write_text(
        out / "rate_limit_plan.ini",
        "[rate]\nclass = %d\ningress_rate_limit_qps = %d\nburst_ceiling = %d\n"
        % (klass, config["ingress_rate_limit_qps"], config["burst_ceiling"]),
    )

    sc = detail["scopes"]
    every = sorted(set(sc["base"]) | set(sc["overlay"]) | set(sc["deny"]))
    rows = ["\t".join(["scope", "base", "overlay", "deny", "effective"])]
    for scope in every:
        rows.append(
            "\t".join(
                [
                    scope,
                    "1" if scope in sc["base"] else "0",
                    "1" if scope in sc["overlay"] else "0",
                    "1" if scope in sc["deny"] else "0",
                    "1" if scope in sc["effective"] else "0",
                ]
            )
        )
    write_text(out / "scope_reconciliation.tsv", "\n".join(rows) + "\n")

    rows = ["|".join(["order", "control_id", "weight", "carry", "status", "running"])]
    for order, cid, weight, carry, status, running in detail["hardening"]["trace"]:
        rows.append(
            "|".join(
                [
                    str(order),
                    cid,
                    str(weight),
                    str(carry),
                    status,
                    "skip" if running is None else str(running),
                ]
            )
        )
    write_text(out / "hardening_fold_trace.psv", "\n".join(rows) + "\n")

    write_text(
        out / "quorum_plan.kv",
        "healthy_voters:%d\nquorum_threshold:%d\n"
        % (detail["quorum"]["healthy_voters"], config["quorum_threshold"]),
    )

    write_text(
        out / "risk_ledger.env",
        "HARDENING_BASELINE=%d\nRISK_INDEX=%d\nSEVERITY_PERMILLE=%d\n"
        % (
            config["hardening_baseline"],
            config["risk_index"],
            detail["hardening"]["severity_permille"],
        ),
    )

    lines = []
    for field in PRECEDENCE_FIELDS:
        lines.append("%s.default=%d" % (field, detail["precedence"][field]["default"]))
        lines.append("%s.resolved=%d" % (field, config[field]))
    write_text(out / "precedence_resolution.properties", "\n".join(lines) + "\n")

    lines = []
    for scope in sorted(sc["effective"]):
        lines.append(json.dumps({"scope": scope, "uid": sc["uids"][scope]}, sort_keys=True))
    write_text(out / "privilege_map.ndjson", "\n".join(lines) + "\n")

    write_text(
        out / "seccomp_summary.tsv",
        "class\tseccomp_allowed_count\n%d\t%d\n" % (klass, config["seccomp_allowed_count"]),
    )

    write_text(out / "tls_floor.env", "TLS_FLOOR_SCORE=%d\n" % config["tls_floor_score"])

    write_text(
        out / "retention_schedule.csv",
        "class,audit_retention_days\n%d,%d\n" % (klass, config["audit_retention_days"]),
    )
    print("sidecars")


def cmd_class_ordering(args):
    config = load_json(args.config)
    entries = [("main", int(config["risk_index"]))]
    for name, path in (("canary", args.canary), ("enforce", args.enforce)):
        entries.append((name, int(load_json(path)["risk_index"])))
    entries.sort(key=lambda e: (e[1], e[0]))
    lines = ["profile\trisk_index"]
    for name, risk in entries:
        lines.append("%s\t%d" % (name, risk))
    write_text(args.out, "\n".join(lines) + "\n")
    print("ordered")


def cmd_audit(args):
    config = load_json(args.config)
    derived, detail = derive_all()
    require_match(config, derived)
    out = Path(args.out_dir)

    lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        "<derivation_audit>",
        "  <active_class>%d</active_class>" % config["active_class"],
        "  <fields>",
    ]
    for key in sorted(config):
        lines.append('    <field name="%s" value="%s"/>' % (key, config[key]))
    lines.append("  </fields>")
    lines.append("  <inputs>")
    inputs = [
        ("max_records", detail["base"]["max_records"]),
        ("retry_limit", detail["base"]["retry_limit"]),
        ("timeout_ms", detail["base"]["timeout_ms"]),
        ("selector", detail["base"]["selector"]),
        ("selector_span", detail["base"]["selector_span"]),
        ("ingress_qps", detail["rate"]["ingress_qps"]),
        ("burst_multiplier_permille", detail["rate"]["burst_multiplier_permille"]),
        ("window_seconds", detail["rate"]["window_seconds"]),
        ("rate_granularity", detail["rate"]["rate_granularity"]),
        ("hardening_fold_score", detail["hardening"]["fold_score"]),
        ("hardening_floor", detail["hardening"]["floor"]),
        ("hardening_ceil", detail["hardening"]["ceil"]),
        ("severity_permille", detail["hardening"]["severity_permille"]),
        ("healthy_voters", detail["quorum"]["healthy_voters"]),
        ("quorum_permille", detail["quorum"]["permille"]),
        ("uid_floor", detail["scopes"]["uid_floor"]),
        ("retry_step", detail["retry"]["step"]),
    ]
    for name, value in sorted(inputs):
        lines.append('    <input name="%s" value="%d"/>' % (name, value))
    lines.append("  </inputs>")
    lines.append("  <rounding>round-half-even</rounding>")
    lines.append("  <trailer>%s</trailer>" % config["trailer"])
    lines.append("</derivation_audit>")
    write_text(out / "derivation_audit.xml", "\n".join(lines) + "\n")

    digests = []
    for _ in range(3):
        again, _unused = derive_all()
        digests.append(sha256_text(dumps(again)))
    config_digest = sha256_text(dumps(config))
    converged = len(set(digests)) == 1 and digests[0] == config_digest
    lines = [
        "convergence report",
        "active_class=%d" % config["active_class"],
        "iterations=%d" % len(digests),
        "derivation_digest=%s" % digests[0],
        "config_digest=%s" % config_digest,
        "distinct_digests=%d" % len(set(digests)),
        "stable=%s" % ("true" if converged else "false"),
        "status=%s" % ("converged" if converged else "divergent"),
        "rounding=round-half-even",
        "float_operations_on_graded_values=0",
    ]
    write_text(out / "convergence_report.txt", "\n".join(lines) + "\n")

    lines = []
    for path in sorted(DATA.iterdir()):
        if not path.is_file():
            continue
        raw = path.read_bytes()
        text = raw.decode("utf-8", errors="replace")
        lines.append(
            json.dumps(
                {
                    "bytes": len(raw),
                    "lines": len(text.splitlines()),
                    "name": path.name,
                    "sha256": hashlib.sha256(raw).hexdigest(),
                },
                sort_keys=True,
            )
        )
    write_text(out / "input_census.ndjson", "\n".join(lines) + "\n")
    print("audited")


def cmd_coverage(args):
    config = load_json(args.config)
    schema = load_json(args.schema)
    rules = load_json(DATA / "validation_rules.json")
    out = Path(args.out_dir)
    derived, detail = derive_all()

    checks = []

    def check(name, passed, note):
        checks.append({"check": name, "detail": note, "pass": bool(passed)})

    req = required_keys(schema)
    check(
        "required_keys_present",
        all(k in config for k in req),
        "%d/%d required keys present" % (sum(1 for k in req if k in config), len(req)),
    )
    check(
        "config_flat",
        all(not isinstance(v, (dict, list)) for v in config.values()),
        "every value is a scalar",
    )
    check(
        "no_float_values",
        all(not isinstance(v, float) for v in config.values()),
        "no floating-point values reach graded keys",
    )
    check(
        "no_forbidden_keys",
        all(k not in config for k in rules["forbidden_keys"]),
        "forbidden keys absent",
    )
    check(
        "derivation_matches_config",
        all(config.get(k) == derived[k] for k in derived),
        "config equals the repaired-tool derivation",
    )
    check(
        "trailer_intact",
        config["trailer"] == load_json(DATA / "defaults.json")["base_config"]["trailer"],
        config["trailer"],
    )
    check(
        "privilege_uid_matches_mirror",
        config["privilege_drop_uid"] == detail["scopes"]["privilege_mirror_uid"],
        "privilege_drop_uid agrees with the privilege-bit mirror",
    )
    check(
        "quorum_within_bounds",
        1 <= config["quorum_threshold"] <= detail["quorum"]["healthy_voters"],
        "1 <= quorum_threshold <= healthy voters",
    )
    check(
        "hardening_within_bounds",
        detail["hardening"]["floor"] <= config["hardening_baseline"] <= detail["hardening"]["ceil"],
        "hardening baseline inside per-class bounds",
    )

    profiles = {}
    for name in rules["profiles"]:
        prof = load_json(out / ("profile_%s.json" % name))
        profiles[name] = prof
        check(
            "profile_%s_matches_deltas" % name,
            prof == profile_config(config, name),
            "profile %s follows the documented deltas" % name,
        )
        check("profile_%s_trailer" % name, prof["trailer"] == config["trailer"], "trailer carried")
        check(
            "profile_%s_flat" % name,
            all(not isinstance(v, (dict, list)) for v in prof.values()),
            "profile is flat",
        )

    present, oversized = [], []
    for artifact in rules["required_artifacts"]:
        path = out / artifact
        if path.exists():
            present.append(artifact)
            if path.stat().st_size > rules["max_artifact_bytes"]:
                oversized.append(artifact)
    check(
        "required_artifacts_present",
        len(present) == len(rules["required_artifacts"]),
        "%d/%d artifacts present" % (len(present), len(rules["required_artifacts"])),
    )
    check(
        "artifact_size_bounded",
        not oversized,
        "all artifacts within %d bytes" % rules["max_artifact_bytes"],
    )

    report = {
        "active_class": config["active_class"],
        "artifacts_present": sorted(present),
        "checks": sorted(checks, key=lambda c: c["check"]),
        "checks_failed": sum(1 for c in checks if not c["pass"]),
        "checks_passed": sum(1 for c in checks if c["pass"]),
        "ok": all(c["pass"] for c in checks),
        "trailer": config["trailer"],
    }
    write_json(out / "validation_report.json", report)

    summary = {
        "active_class": config["active_class"],
        "artifact_count": len(rules["required_artifacts"]),
        "artifacts": sorted(rules["required_artifacts"]),
        "config": dict(sorted(config.items())),
        "derivation": {
            "burst_multiplier_permille": detail["rate"]["burst_multiplier_permille"],
            "effective_scopes": detail["scopes"]["effective"],
            "hardening_fold_score": detail["hardening"]["fold_score"],
            "healthy_voters": detail["quorum"]["healthy_voters"],
            "ingress_qps": detail["rate"]["ingress_qps"],
            "quorum_permille": detail["quorum"]["permille"],
            "rate_granularity": detail["rate"]["rate_granularity"],
            "seccomp_allowed": detail["seccomp"]["allowed"],
            "selector": detail["base"]["selector"],
            "severity_permille": detail["hardening"]["severity_permille"],
            "uid_floor": detail["scopes"]["uid_floor"],
            "window_seconds": detail["rate"]["window_seconds"],
        },
        "profiles": {name: dict(sorted(p.items())) for name, p in sorted(profiles.items())},
        "rounding": "round-half-even",
        "trailer": config["trailer"],
        "validation": {
            "checks_failed": report["checks_failed"],
            "checks_passed": report["checks_passed"],
            "ok": report["ok"],
        },
    }
    write_json(out / "summary.json", summary)
    print("covered")


def cmd_manifest(args):
    out = Path(args.out_dir)
    rules = load_json(DATA / "validation_rules.json")
    self_name = Path(args.out).name
    entries = {}
    for artifact in sorted(rules["required_artifacts"]):
        if artifact == self_name:
            continue
        path = out / artifact
        if path.exists():
            entries[artifact] = {"bytes": path.stat().st_size, "sha256": sha256_file(path)}
    config = load_json(args.config)
    manifest = {
        "active_class": config["active_class"],
        "artifact_count": len(entries),
        "artifacts": entries,
        "config_digest": sha256_file(args.config),
        "deterministic": True,
        "inputs_root": str(DATA),
        "rounding": "round-half-even",
        "tool": "task-ctl",
        "trailer": config["trailer"],
    }
    write_json(args.out, manifest)
    print("manifested")


def main():
    parser = argparse.ArgumentParser(prog="task-ctl")
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("derive")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_derive)

    p = sub.add_parser("profile")
    p.add_argument("--name", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_profile)

    p = sub.add_parser("profile-delta")
    p.add_argument("--config", required=True)
    p.add_argument("--canary", required=True)
    p.add_argument("--enforce", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_profile_delta)

    p = sub.add_parser("init")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("export-report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest", required=True)
    p.add_argument("--commands", required=True)
    p.set_defaults(func=cmd_report)

    p = sub.add_parser("package")
    p.add_argument("--src", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_package)

    p = sub.add_parser("emit-sidecars")
    p.add_argument("--config", required=True)
    p.add_argument("--out-dir", required=True)
    p.set_defaults(func=cmd_sidecars)

    p = sub.add_parser("class-ordering")
    p.add_argument("--config", required=True)
    p.add_argument("--canary", required=True)
    p.add_argument("--enforce", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_class_ordering)

    p = sub.add_parser("emit-audit")
    p.add_argument("--config", required=True)
    p.add_argument("--out-dir", required=True)
    p.set_defaults(func=cmd_audit)

    p = sub.add_parser("emit-coverage")
    p.add_argument("--config", required=True)
    p.add_argument("--schema", required=True)
    p.add_argument("--out-dir", required=True)
    p.set_defaults(func=cmd_coverage)

    p = sub.add_parser("emit-manifest")
    p.add_argument("--config", required=True)
    p.add_argument("--out-dir", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_manifest)

    args = parser.parse_args()
    if not getattr(args, "command", None):
        parser.print_help()
        return
    args.func(args)


if __name__ == "__main__":
    main()
