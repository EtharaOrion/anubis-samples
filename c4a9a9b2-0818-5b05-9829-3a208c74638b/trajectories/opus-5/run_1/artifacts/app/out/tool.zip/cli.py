#!/usr/bin/env python3
"""task-ctl: local admission-control hardening compiler.

Compiles a flat hardened admission configuration for the active enforcement
class from the interacting numeric policy layers under /app/data.

All graded arithmetic is exact integer arithmetic with round-half-even
rounding; no floating-point operation touches a derived number.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import re
from pathlib import Path

DATA = Path("/app/data")
ADOPTED = "ADOPTED"


# ---------------------------------------------------------------- utilities

def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, data):
    Path(path).write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def write_text(path, text):
    Path(path).write_text(text, encoding="utf-8")


def read_lines(name):
    out = []
    for line in (DATA / name).read_text(encoding="utf-8", errors="replace").split("\n"):
        s = line.strip()
        if not s or s.startswith("#") or s.startswith(";"):
            continue
        out.append(line)
    return out


def delimited_rows(name, sep):
    lines = read_lines(name)
    if not lines:
        return []
    header = [c.strip() for c in lines[0].split(sep) if c.strip()]
    rows = []
    for line in lines[1:]:
        parts = [c.strip() for c in line.split(sep) if c.strip() != ""]
        if len(parts) != len(header):
            continue
        rows.append(dict(zip(header, parts)))
    return rows


def whitespace_rows(name, fields):
    rows = []
    for line in read_lines(name):
        parts = line.split()
        if len(parts) != len(fields):
            continue
        rows.append(dict(zip(fields, parts)))
    return rows


def ini_sections(name):
    """Parse a simple `[section]` / `key = value` file."""
    sections = {}
    current = None
    for line in read_lines(name):
        s = line.strip()
        if s.startswith("[") and s.endswith("]"):
            current = s[1:-1].strip()
            sections.setdefault(current, {})
            continue
        if current is None or "=" not in s:
            continue
        key, _, val = s.partition("=")
        sections[current][key.strip()] = val.strip().strip('"')
    return sections


def round_half_even(num, den):
    """Exact integer division of num/den rounded half to even."""
    if den == 0:
        raise ZeroDivisionError("denominator must be non-zero")
    if den < 0:
        num, den = -num, -den
    q, r = divmod(num, den)
    twice = 2 * r
    if twice > den or (twice == den and q % 2 == 1):
        q += 1
    return q


def quantize_floor(value, step):
    return (value // step) * step


def clamp(value, lo, hi):
    return lo if value < lo else (hi if value > hi else value)


def sha256_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


# ------------------------------------------------------------- policy layers

def base_inputs():
    base = load_json(DATA / "defaults.json")["base_config"]
    return int(base["max_records"]), int(base["retry_limit"]), int(base["timeout_ms"]), str(base["trailer"])


def class_bands():
    """Adopted selector bands from class_index.tsv2."""
    bands = []
    for row in delimited_rows("class_index.tsv2", "\t"):
        if row.get("status") != ADOPTED:
            continue
        bands.append((int(row["class_id"]), int(row["selector_lo"]), int(row["selector_hi"])))
    bands.sort(key=lambda b: b[1])
    return bands


def active_class(max_records):
    """Select the active enforcement class from the base budget."""
    bands = class_bands()
    width = bands[0][2] - bands[0][1] + 1
    span = bands[-1][2] + 1
    selector = max_records % span
    for class_id, lo, hi in bands:
        if lo <= selector <= hi:
            return class_id
    return (max_records // width) % len(bands)


def adopted_one(rows, class_field, class_id, value_field, extra=None):
    for row in rows:
        if row.get("status") != ADOPTED:
            continue
        if str(row.get(class_field)) != str(class_id):
            continue
        if extra and not extra(row):
            continue
        return int(row[value_field])
    raise SystemExit("no adopted row for class %s" % class_id)


def ingress_qps(class_id):
    return adopted_one(delimited_rows("ingress_rate.tsv", "\t"), "class_id", class_id, "ingress_qps")


def burst_layer(class_id):
    sec = ini_sections("burst_multiplier.ini")["class.%d" % class_id]
    if sec["status"] != ADOPTED:
        raise SystemExit("burst block not adopted")
    return int(sec["burst_multiplier_permille"]), int(sec["window_seconds"])


def window_seconds(class_id):
    rows = whitespace_rows("window_seconds.conf", ["class_id", "window_seconds", "status"])
    return adopted_one(rows, "class_id", class_id, "window_seconds")


def rate_step(class_id):
    return adopted_one(delimited_rows("rate_gran.caret", "^"), "class_id", class_id, "gran")


def scope_sets(class_id):
    base, overlay, deny = set(), set(), set()
    for line in read_lines("scope_base.jsonl"):
        obj = json.loads(line)
        if obj.get("status") == ADOPTED and int(obj["class_id"]) == class_id:
            base.add(obj["scope"])
    for line in read_lines("scope_overlay.ndjson"):
        obj = json.loads(line)
        if obj.get("status") == ADOPTED and int(obj["class_id"]) == class_id:
            overlay.add(obj["scope"])
    for row in delimited_rows("scope_deny.psv", "|"):
        if row.get("status") == ADOPTED and str(row["class_id"]) == str(class_id):
            deny.add(row["scope"])
    return base, overlay, deny


def uid_map():
    uids = {}
    for line in read_lines("uid_map.env"):
        key, _, val = line.strip().partition("=")
        key = key.strip()
        if key.startswith("SCOPE_") and val.strip().isdigit():
            uids[key[len("SCOPE_"):].lower()] = int(val.strip())
    return uids


def uid_floor(class_id):
    for row in delimited_rows("uid_floor.hex", ":"):
        if row.get("status") == ADOPTED and str(row["class_id"]) == str(class_id):
            return int(row["floor_hex"], 16)
    raise SystemExit("no adopted uid floor")


def privilege_mirror(class_id):
    for line in read_lines("privilege_bits.b64"):
        try:
            text = base64.b64decode(line.strip()).decode("ascii")
        except Exception:
            continue
        fields = dict(part.split("=", 1) for part in text.split(";") if "=" in part)
        if fields.get("status") == ADOPTED and fields.get("class") == str(class_id):
            return int(fields["uid"])
    return None


def control_rows(class_id):
    rows = [r for r in delimited_rows("baseline_controls.scsv", ";")
            if str(r.get("class_id")) == str(class_id)]
    rows.sort(key=lambda r: int(r["order"]))
    return rows


def hardening_bounds(class_id):
    sec = ini_sections("hardening_bounds.toml")["class.%d" % class_id]
    if sec["status"] != ADOPTED:
        raise SystemExit("hardening bounds not adopted")
    return int(sec["floor"]), int(sec["ceil"])


def severity_permille(class_id):
    for line in read_lines("severity_weight.kv"):
        parts = [p.strip() for p in line.split(":")]
        if len(parts) == 3 and parts[0] == "class%d" % class_id and parts[2] == ADOPTED:
            return int(parts[1])
    raise SystemExit("no adopted severity weight")


def risk_constants():
    consts = {}
    for line in read_lines("risk_const.env2"):
        key, _, val = line.strip().partition("=")
        consts[key.strip()] = val.strip()
    return int(consts["BASELINE_COMPLEMENT"]), int(consts["RISK_DIVISOR"])


def healthy_voters(class_id):
    healthy = 0
    total = 0
    for line in read_lines("voter_health.ndjson"):
        obj = json.loads(line)
        if obj.get("status") != ADOPTED or int(obj["class_id"]) != class_id:
            continue
        total += 1
        if obj.get("healthy") is True:
            healthy += 1
    return healthy, total


def quorum_permille(class_id):
    return adopted_one(delimited_rows("quorum_permille.tilde", "~"), "class_id", class_id, "permille")


def tls_floor(class_id):
    for row in delimited_rows("tls_matrix.csv", ","):
        if (row.get("status") == ADOPTED and str(row["class_id"]) == str(class_id)
                and row.get("enabled") == "true"):
            return clamp(int(row["score"]), 0, 100)
    raise SystemExit("no adopted enabled tls suite")


def seccomp_counts(class_id):
    allow, deny = [], set()
    for row in delimited_rows("seccomp_allow.tsv", "\t"):
        if row.get("status") == ADOPTED and str(row["class_id"]) == str(class_id):
            if row["syscall"] not in allow:
                allow.append(row["syscall"])
    for row in delimited_rows("seccomp_deny.psv", "|"):
        if row.get("status") == ADOPTED and str(row["class_id"]) == str(class_id):
            deny.add(row["syscall"])
    effective = [s for s in allow if s not in deny]
    return allow, sorted(deny), effective


def retention_days(class_id):
    sec = ini_sections("retention.ini")["class.%d" % class_id]
    if sec["status"] != ADOPTED:
        raise SystemExit("retention block not adopted")
    return int(sec["retention_days"])


def nonce_floor(class_id):
    sec = ini_sections("nonce_bounds.toml2")["class.%d" % class_id]
    if sec["status"] != ADOPTED:
        raise SystemExit("nonce bounds not adopted")
    return int(sec["floor_ms"])


def sessions_ceiling(class_id):
    return adopted_one(delimited_rows("sessions_cap.csv2", ","), "class_id", class_id, "abs_ceil")


def retry_step(class_id):
    return adopted_one(delimited_rows("retry_backoff.psv2", "||"), "class_id", class_id, "step")


def precedence(class_id):
    """Resolve base -> overlay -> pinned for the precedence fields."""
    defaults = load_json(DATA / "defaults.json")["layer_defaults"]
    overrides = load_json(DATA / "layer_overrides.json").get("class_%d" % class_id, {})
    pinned = load_json(DATA / "pinned_overrides.json").get("class_%d" % class_id, {})
    resolved = {}
    for field in ("session_ttl_seconds", "nonce_window_ms", "max_concurrent_sessions"):
        value = int(defaults[field])
        if field in overrides:
            value = int(overrides[field])
        if pinned.get("pinned") is True and field in pinned:
            value = int(pinned[field])
        resolved[field] = value
    return {k: int(v) for k, v in defaults.items()}, resolved


def profile_deltas(name):
    return load_json(DATA / "profile_deltas.json")[name]


def contract_strings():
    schema = load_json(DATA / "config_schema.json")
    return {
        "checksum": schema["checksum"],
        "control_plane": schema["control_plane"],
        "image_runtime": schema["image_runtime"],
        "mode": schema["mode"],
        "profile": schema["profile"],
    }


# ------------------------------------------------------------- the derivation

def derive_all():
    max_records, retry_limit, timeout_ms, trailer = base_inputs()
    klass = active_class(max_records)

    # ingress rate limit / burst ceiling
    qps = ingress_qps(klass)
    permille, burst_window = burst_layer(klass)
    win = window_seconds(klass)
    if win != burst_window:
        raise SystemExit("window layers disagree")
    step = rate_step(klass)
    scaled = round_half_even(qps * permille, 1000)
    rate_limit = quantize_floor(scaled, step)
    burst_ceiling = rate_limit * win

    # scope reconciliation and privilege drop uid
    base_scopes, overlay_scopes, deny_scopes = scope_sets(klass)
    effective = sorted((base_scopes | overlay_scopes) - deny_scopes)
    uids = uid_map()
    floor = uid_floor(klass)
    granted = {s: uids[s] for s in effective if s in uids}
    privilege_drop_uid = max(min(granted.values()), floor)

    # carry-aware hardening fold
    running = 0
    carry = 0
    trace = []
    for row in control_rows(klass):
        weight = int(row["weight"])
        flag = int(row["carry_flag"])
        if row.get("status") == ADOPTED:
            running += weight + carry
            carry = flag
            cell = str(running)
        else:
            cell = "skip"
        trace.append((int(row["order"]), row["control_id"], weight, flag, row["status"], cell))
    fold_score = running
    lo, hi = hardening_bounds(klass)
    hardening_baseline = quantize_floor(clamp(fold_score, lo, hi), 5)

    # risk index
    severity = severity_permille(klass)
    complement, divisor = risk_constants()
    risk_index = round_half_even((complement - hardening_baseline) * severity, divisor)

    # quorum
    healthy, voter_total = healthy_voters(klass)
    qpermille = quorum_permille(klass)
    quorum = clamp(round_half_even(healthy * qpermille, 1000), 1, healthy)

    # bounded per-class layers
    tls_score = tls_floor(klass)
    allow, deny_calls, effective_calls = seccomp_counts(klass)
    retention = retention_days(klass)

    # precedence fields
    defaults, resolved = precedence(klass)
    resolved["nonce_window_ms"] = max(resolved["nonce_window_ms"], nonce_floor(klass))
    resolved["max_concurrent_sessions"] = min(resolved["max_concurrent_sessions"],
                                              sessions_ceiling(klass))

    # retry backoff base
    rstep = retry_step(klass)
    retry_backoff = quantize_floor(round_half_even(timeout_ms, retry_limit + 1), rstep)

    config = dict(contract_strings())
    config.update({
        "active_class": klass,
        "audit_retention_days": retention,
        "burst_ceiling": burst_ceiling,
        "effective_scope_count": len(effective),
        "enforcement_profile": "main",
        "hardening_baseline": hardening_baseline,
        "ingress_rate_limit_qps": rate_limit,
        "max_concurrent_sessions": resolved["max_concurrent_sessions"],
        "nonce_window_ms": resolved["nonce_window_ms"],
        "privilege_drop_uid": privilege_drop_uid,
        "quorum_threshold": quorum,
        "retry_backoff_base_ms": retry_backoff,
        "risk_index": risk_index,
        "seccomp_allowed_count": len(effective_calls),
        "session_ttl_seconds": resolved["session_ttl_seconds"],
        "tls_floor_score": tls_score,
        "trailer": trailer,
    })

    detail = {
        "base": {"max_records": max_records, "retry_limit": retry_limit, "timeout_ms": timeout_ms},
        "ingress_qps": qps,
        "burst_permille": permille,
        "window_seconds": win,
        "rate_step": step,
        "scaled_rate": scaled,
        "base_scopes": sorted(base_scopes),
        "overlay_scopes": sorted(overlay_scopes),
        "deny_scopes": sorted(deny_scopes),
        "effective_scopes": effective,
        "scope_uids": granted,
        "uid_floor": floor,
        "privilege_mirror": privilege_mirror(klass),
        "fold_trace": trace,
        "fold_score": fold_score,
        "bounds": [lo, hi],
        "severity_permille": severity,
        "baseline_complement": complement,
        "risk_divisor": divisor,
        "healthy_voters": healthy,
        "voter_total": voter_total,
        "quorum_permille": qpermille,
        "seccomp_allow": allow,
        "seccomp_deny": deny_calls,
        "seccomp_effective": effective_calls,
        "precedence_defaults": defaults,
        "precedence_resolved": resolved,
        "retry_step": rstep,
        "ttl_granularity": 5,
    }
    return config, detail


def profile_config(config, detail, name):
    deltas = profile_deltas(name)
    out = dict(config)
    ttl = round_half_even(int(config["session_ttl_seconds"]) * int(deltas["ttl_scale_permille"]), 1000)
    out["session_ttl_seconds"] = quantize_floor(ttl, detail["ttl_granularity"])
    out["quorum_threshold"] = clamp(int(config["quorum_threshold"]) + int(deltas["quorum_delta"]),
                                    1, detail["healthy_voters"])
    out["risk_index"] = int(config["risk_index"]) + int(deltas["risk_delta"])
    out["enforcement_profile"] = name
    return out


# ------------------------------------------------------------------ commands

def cmd_derive(args):
    config, _ = derive_all()
    write_json(args.out, config)
    print("derived")


def cmd_profile(args):
    config = load_json(args.config)
    _, detail = derive_all()
    write_json(args.out, profile_config(config, detail, args.name))
    print("profiled")


def cmd_init(args):
    schema = load_json(args.schema)
    data = {
        "checksum": schema["checksum"],
        "control_plane": schema["control_plane"],
        "image_runtime": schema["image_runtime"],
        "mode": schema["mode"],
        "profile": schema["profile"],
    }
    write_json(args.out, data)
    print("initialized")


def coerce(value):
    text = str(value)
    if re.fullmatch(r"[+-]?\d+", text):
        return int(text)
    return text


def cmd_set(args):
    data = load_json(args.config)
    try:
        parsed = json.loads(args.value)
    except ValueError:
        parsed = args.value
    if isinstance(parsed, (dict, list)):
        raise SystemExit("value must be a scalar: " + args.key)
    data[args.key] = coerce(args.value)
    write_json(args.config, data)
    print("set")


def required_keys(schema):
    keys = schema["required_keys"]
    if isinstance(keys, str):
        keys = [k.strip() for k in keys.split(",") if k.strip()]
    return list(keys)


def cmd_validate(args):
    schema = load_json(args.schema)
    data = load_json(args.config)
    missing = [k for k in required_keys(schema) if k not in data]
    if missing:
        raise SystemExit("missing: " + ",".join(missing))
    bad = [k for k, v in data.items() if isinstance(v, (dict, list))]
    if bad:
        raise SystemExit("configuration must be flat: " + ",".join(sorted(bad)))
    floats = [k for k, v in data.items() if isinstance(v, float)]
    if floats:
        raise SystemExit("floating point value in config: " + ",".join(sorted(floats)))
    print("ok")


def cmd_report(args):
    data = load_json(args.config)
    commands_path = Path(args.commands)
    raw = commands_path.read_text(encoding="utf-8") if commands_path.exists() else args.commands
    commands = json.loads(raw)
    report = {
        "command_count": len(commands),
        "commands": commands,
        "config": data,
        "config_sha256": args.digest,
        "ok": True,
        "tool": "task-ctl",
        "trailer": data.get("trailer"),
    }
    write_json(args.out, report)
    print("reported")


# ------------------------------------------------------------------ emitters

def cmd_emit(args):
    config = load_json(args.config)
    _, detail = derive_all()
    emitter = EMITTERS.get(args.kind)
    if emitter is None:
        raise SystemExit("unknown artifact kind: " + args.kind)
    emitter(args, config, detail)
    print("emitted " + args.kind)


def emit_rate_plan(args, config, detail):
    write_text(args.out, "[rate]\n"
                         "class = %d\n"
                         "ingress_rate_limit_qps = %d\n"
                         "burst_ceiling = %d\n" % (config["active_class"],
                                                   config["ingress_rate_limit_qps"],
                                                   config["burst_ceiling"]))


def emit_fold_trace(args, config, detail):
    out = ["order|control_id|weight|carry|status|running"]
    for order, cid, weight, flag, status, running in detail["fold_trace"]:
        out.append("%d|%s|%d|%d|%s|%s" % (order, cid, weight, flag, status, running))
    write_text(args.out, "\n".join(out) + "\n")


def emit_quorum_plan(args, config, detail):
    write_text(args.out, "healthy_voters:%d\nquorum_threshold:%d\n"
                         % (detail["healthy_voters"], config["quorum_threshold"]))


def emit_risk_ledger(args, config, detail):
    write_text(args.out, "HARDENING_BASELINE=%d\nRISK_INDEX=%d\nSEVERITY_PERMILLE=%d\n"
                         % (config["hardening_baseline"], config["risk_index"],
                            detail["severity_permille"]))


def emit_precedence(args, config, detail):
    defaults = detail["precedence_defaults"]
    resolved = detail["precedence_resolved"]
    out = []
    for field in ("session_ttl_seconds", "nonce_window_ms", "max_concurrent_sessions"):
        out.append("%s.default=%d" % (field, defaults[field]))
        out.append("%s.resolved=%d" % (field, resolved[field]))
    write_text(args.out, "\n".join(out) + "\n")


def emit_privilege_map(args, config, detail):
    out = [json.dumps({"scope": scope, "uid": detail["scope_uids"][scope]}, sort_keys=True)
           for scope in detail["effective_scopes"]]
    write_text(args.out, "\n".join(out) + "\n")


def emit_seccomp_summary(args, config, detail):
    write_text(args.out, "class\tseccomp_allowed_count\n%d\t%d\n"
                         % (config["active_class"], config["seccomp_allowed_count"]))


def emit_tls_floor(args, config, detail):
    write_text(args.out, "TLS_FLOOR_SCORE=%d\n" % config["tls_floor_score"])


def emit_admission_matrix(args, config, detail):
    rows = ["field,value"]
    for key in sorted(config):
        rows.append("%s,%s" % (key, config[key]))
    write_text(args.out, "\n".join(rows) + "\n")


def emit_scope_reconciliation(args, config, detail):
    rows = ["scope\tbase\toverlay\tdeny\teffective\tuid"]
    names = sorted(set(detail["base_scopes"]) | set(detail["overlay_scopes"])
                   | set(detail["deny_scopes"]))
    for scope in names:
        effective = scope in detail["effective_scopes"]
        rows.append("%s\t%d\t%d\t%d\t%d\t%s" % (
            scope,
            1 if scope in detail["base_scopes"] else 0,
            1 if scope in detail["overlay_scopes"] else 0,
            1 if scope in detail["deny_scopes"] else 0,
            1 if effective else 0,
            detail["scope_uids"][scope] if effective else "",
        ))
    rows.append("effective_scope_count\t\t\t\t%d\t%d"
                % (config["effective_scope_count"], config["privilege_drop_uid"]))
    write_text(args.out, "\n".join(rows) + "\n")


def emit_retention_schedule(args, config, detail):
    rows = ["class,audit_retention_days,tls_floor_score,seccomp_allowed_count",
            "%d,%d,%d,%d" % (config["active_class"], config["audit_retention_days"],
                             config["tls_floor_score"], config["seccomp_allowed_count"])]
    write_text(args.out, "\n".join(rows) + "\n")


def emit_class_ordering(args, config, detail):
    entries = [("main", int(config["risk_index"]))]
    for name, path in (("canary", args.canary), ("enforce", args.enforce)):
        entries.append((name, int(load_json(path)["risk_index"])))
    entries.sort(key=lambda e: (e[1], e[0]))
    rows = ["profile\trisk_index"] + ["%s\t%d" % e for e in entries]
    write_text(args.out, "\n".join(rows) + "\n")


def emit_delta_report(args, config, detail):
    report = {"base": dict(config), "profiles": {}}
    for name, path in (("canary", args.canary), ("enforce", args.enforce)):
        prof = load_json(path)
        deltas = {k: prof[k] - config[k] for k in sorted(config)
                  if isinstance(config[k], int) and isinstance(prof.get(k), int)}
        report["profiles"][name] = {
            "changed_keys": sorted(k for k in prof if prof[k] != config.get(k)),
            "config": dict(prof),
            "delta": deltas,
        }
    write_json(args.out, report)


def emit_audit(args, config, detail):
    steps = [
        ("active_class", "max_records %d reduced over the adopted selector bands"
         % detail["base"]["max_records"], config["active_class"]),
        ("ingress_rate_limit_qps", "quantize_floor(round_half_even(%d*%d,1000),%d)"
         % (detail["ingress_qps"], detail["burst_permille"], detail["rate_step"]),
         config["ingress_rate_limit_qps"]),
        ("burst_ceiling", "%d*%d" % (config["ingress_rate_limit_qps"], detail["window_seconds"]),
         config["burst_ceiling"]),
        ("effective_scope_count", "|(base union overlay) minus deny|",
         config["effective_scope_count"]),
        ("privilege_drop_uid", "max(min(granted_uids),floor=%d)" % detail["uid_floor"],
         config["privilege_drop_uid"]),
        ("hardening_baseline", "quantize_floor(clamp(fold=%d,%d,%d),5)"
         % (detail["fold_score"], detail["bounds"][0], detail["bounds"][1]),
         config["hardening_baseline"]),
        ("risk_index", "round_half_even((%d-%d)*%d,%d)"
         % (detail["baseline_complement"], config["hardening_baseline"],
            detail["severity_permille"], detail["risk_divisor"]), config["risk_index"]),
        ("quorum_threshold", "clamp(round_half_even(%d*%d,1000),1,%d)"
         % (detail["healthy_voters"], detail["quorum_permille"], detail["healthy_voters"]),
         config["quorum_threshold"]),
        ("tls_floor_score", "adopted enabled suite score", config["tls_floor_score"]),
        ("seccomp_allowed_count", "adopted allow minus adopted deny",
         config["seccomp_allowed_count"]),
        ("audit_retention_days", "adopted retention block", config["audit_retention_days"]),
        ("session_ttl_seconds", "base then overlay then pinned", config["session_ttl_seconds"]),
        ("nonce_window_ms", "base then overlay then pinned, floor bounded",
         config["nonce_window_ms"]),
        ("max_concurrent_sessions", "base then overlay then pinned, ceiling bounded",
         config["max_concurrent_sessions"]),
        ("retry_backoff_base_ms", "quantize_floor(round_half_even(%d,%d),%d)"
         % (detail["base"]["timeout_ms"], detail["base"]["retry_limit"] + 1, detail["retry_step"]),
         config["retry_backoff_base_ms"]),
    ]
    lines = ['<?xml version="1.0" encoding="UTF-8"?>', "<derivation_audit>",
             "  <active_class>%d</active_class>" % config["active_class"],
             "  <rounding>half-even</rounding>",
             "  <trailer>%s</trailer>" % config["trailer"], "  <steps>"]
    for field, rule, value in steps:
        lines.append('    <step field="%s" value="%s"><rule>%s</rule></step>' % (field, value, rule))
    lines += ["  </steps>", "</derivation_audit>"]
    write_text(args.out, "\n".join(lines) + "\n")


def emit_convergence(args, config, detail):
    lines = [
        "convergence report",
        "==================",
        "active_class=%d" % config["active_class"],
        "fold_score=%d" % detail["fold_score"],
        "hardening_baseline=%d" % config["hardening_baseline"],
        "risk_index=%d" % config["risk_index"],
        "quorum_threshold=%d" % config["quorum_threshold"],
        "healthy_voters=%d" % detail["healthy_voters"],
        "effective_scope_count=%d" % config["effective_scope_count"],
        "privilege_drop_uid=%d" % config["privilege_drop_uid"],
        "ingress_rate_limit_qps=%d" % config["ingress_rate_limit_qps"],
        "burst_ceiling=%d" % config["burst_ceiling"],
        "tls_floor_score=%d" % config["tls_floor_score"],
        "seccomp_allowed_count=%d" % config["seccomp_allowed_count"],
        "audit_retention_days=%d" % config["audit_retention_days"],
        "session_ttl_seconds=%d" % config["session_ttl_seconds"],
        "nonce_window_ms=%d" % config["nonce_window_ms"],
        "max_concurrent_sessions=%d" % config["max_concurrent_sessions"],
        "retry_backoff_base_ms=%d" % config["retry_backoff_base_ms"],
        "iterations=1",
        "converged=true",
        "float_operations=0",
        "rounding=half-even",
        "trailer=%s" % config["trailer"],
    ]
    write_text(args.out, "\n".join(lines) + "\n")


def emit_input_census(args, config, detail):
    lines = []
    for path in sorted(DATA.iterdir()):
        if not path.is_file():
            continue
        raw = path.read_bytes()
        line_count = raw.count(b"\n") + (1 if raw and not raw.endswith(b"\n") else 0)
        lines.append(json.dumps({
            "bytes": len(raw),
            "file": path.name,
            "lines": line_count,
            "sha256": hashlib.sha256(raw).hexdigest(),
        }, sort_keys=True))
    write_text(args.out, "\n".join(lines) + "\n")


def emit_manifest(args, config, detail):
    out_dir = Path(args.out).parent
    self_name = Path(args.out).name
    artifacts = {}
    for path in sorted(out_dir.iterdir()):
        if path.is_file() and path.name != self_name:
            artifacts[path.name] = {"bytes": path.stat().st_size, "sha256": sha256_file(path)}
    manifest = {
        "artifacts": artifacts,
        "deterministic": True,
        "inputs": {p.name: sha256_file(p) for p in sorted(DATA.iterdir()) if p.is_file()},
        "rounding": "half-even",
        "tool": "task-ctl",
        "trailer": config["trailer"],
    }
    write_json(args.out, manifest)


def emit_validation_report(args, config, detail):
    schema = load_json(DATA / "config_schema.json")
    rules = load_json(DATA / "validation_rules.json")
    out_dir = Path(args.out).parent
    required = required_keys(schema)
    missing_keys = sorted(set(required) - set(config))
    present = [a for a in rules["required_artifacts"] if (out_dir / a).exists()]
    checks = {
        "all_keys_present": missing_keys == [],
        "flat": all(not isinstance(v, (dict, list)) for v in config.values()),
        "no_floats": all(not isinstance(v, float) for v in config.values()),
        "no_forbidden_keys": all(k not in config for k in rules["forbidden_keys"]),
        "trailer_intact": config["trailer"] == base_inputs()[3],
    }
    report = {
        "artifacts_expected": len(rules["required_artifacts"]),
        "artifacts_present": len(present),
        "checks": checks,
        "missing_keys": missing_keys,
        "ok": all(checks.values()),
        "required_key_count": len(required),
    }
    write_json(args.out, report)


def emit_summary(args, config, detail):
    summary = {
        "active_class": config["active_class"],
        "artifact_count": len(load_json(DATA / "validation_rules.json")["required_artifacts"]),
        "config": dict(config),
        "effective_scopes": detail["effective_scopes"],
        "fold_score": detail["fold_score"],
        "healthy_voters": detail["healthy_voters"],
        "ok": True,
        "rounding": "half-even",
        "trailer": config["trailer"],
    }
    write_json(args.out, summary)


EMITTERS = {
    "admission_matrix": emit_admission_matrix,
    "class_ordering": emit_class_ordering,
    "convergence_report": emit_convergence,
    "derivation_audit": emit_audit,
    "hardening_fold_trace": emit_fold_trace,
    "input_census": emit_input_census,
    "precedence_resolution": emit_precedence,
    "privilege_map": emit_privilege_map,
    "profile_delta_report": emit_delta_report,
    "quorum_plan": emit_quorum_plan,
    "rate_limit_plan": emit_rate_plan,
    "reproducibility_manifest": emit_manifest,
    "retention_schedule": emit_retention_schedule,
    "risk_ledger": emit_risk_ledger,
    "scope_reconciliation": emit_scope_reconciliation,
    "seccomp_summary": emit_seccomp_summary,
    "summary": emit_summary,
    "tls_floor": emit_tls_floor,
    "validation_report": emit_validation_report,
}


def main():
    parser = argparse.ArgumentParser(prog="task-ctl")
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("derive")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_derive)

    p = sub.add_parser("profile")
    p.add_argument("--name", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_profile)

    p = sub.add_parser("init")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("export-report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest", required=True)
    p.add_argument("--commands", required=True)
    p.set_defaults(func=cmd_report)

    p = sub.add_parser("emit")
    p.add_argument("--kind", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--canary")
    p.add_argument("--enforce")
    p.set_defaults(func=cmd_emit)

    args = parser.parse_args()
    if not getattr(args, "command", None):
        parser.print_help()
        return
    args.func(args)


if __name__ == "__main__":
    main()
