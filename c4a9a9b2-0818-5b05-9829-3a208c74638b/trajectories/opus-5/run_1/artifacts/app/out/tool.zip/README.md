# task-ctl

An offline container-image admission-control hardening compiler for a
server-side admission broker. It reads interacting numeric policy layers from
`/app/data`, selects the active enforcement class, and derives one flat hardened
admission configuration plus two deployment profiles (canary and enforce).

This build is repaired: the active enforcement class is selected from the base
budget over the adopted selector bands, only `ADOPTED` rows for that class bind,
the rate limit/burst ceiling, scope reconciliation and privilege-drop uid, the
carry-aware hardening fold with its per-class clamp, the risk index, the quorum
threshold, the bounded TLS/seccomp/retention layers, the base/override/pinned
precedence fields and the retry backoff base are all derived with exact integer
arithmetic and round-half-even rounding.

## Commands

- `init --schema <schema> --out <config>`: seed fixed contract strings.
- `set --config <config> --key <key> --value <value>`: set one scalar key with
  correct case and type coercion; reject any non-scalar value.
- `validate --schema <schema> --config <config>`: confirm every required key is
  present and the configuration is flat; print `ok`.
- `derive --out <config>`: derive the flat hardened configuration.
- `profile --name <canary|enforce> --config <config> --out <profile>`: apply the
  documented per-profile deltas.
- `emit --kind <artifact> --config <config> --out <path>`: emit one derivation,
  audit, provenance or coverage artifact (`--canary`/`--enforce` are required by
  the `class_ordering` and `profile_delta_report` kinds).
- `export-report --config <config> --out <report> --digest <sha256> --commands <json>`:
  emit a truthful command transcript.

## Contract notes

- Every value is derived with exact integer arithmetic (round-half-even); no
  floating-point value may reach a graded key.
- The configuration is flat: keys map directly to integer or string scalars.
- The required key set is authoritative in `schema.json` and mirrored by the
  field registry in the policy layers.
- Only rows whose status is `ADOPTED` for the active enforcement class bind; rows
  labelled `SUPERSEDED`, `DRAFT`, `SHADOW`, or `REVOKED` are context decoys.
