#!/usr/bin/env python3
"""task-ctl: local admission-control hardening compiler.

Compiles a flat hardened admission configuration for the active enforcement
class from the interacting numeric policy layers under /app/data.

All graded arithmetic is exact integer arithmetic with round-half-even
rounding; no floating-point operation reaches a graded value.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import zipfile
from pathlib import Path

DATA = Path("/app/data")
ADOPTED = "ADOPTED"
HARDENING_STEP = 5
TTL_GRANULARITY = 5
PERMILLE = 1000

CONTRACT_KEYS = ("profile", "control_plane", "image_runtime", "mode", "checksum")
SELF_REPORT = "validation_report.json"


# ---------------------------------------------------------------- primitives


def div_half_even(num: int, den: int) -> int:
    """Exact integer division of num/den rounded half to even."""
    if den == 0:
        raise ZeroDivisionError("denominator must be non-zero")
    if den < 0:
        num, den = -num, -den
    q, r = divmod(num, den)
    twice = 2 * r
    if twice > den or (twice == den and q % 2 != 0):
        q += 1
    return q


def quantize_floor(value: int, step: int) -> int:
    return (value // step) * step


def clamp(value: int, lo: int, hi: int) -> int:
    return lo if value < lo else (hi if value > hi else value)


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, data):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(
        json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def write_text(path, text):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(text, encoding="utf-8")


def sha256_file(path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


# ------------------------------------------------------------------ parsing


def read_lines(name):
    out = []
    for line in (DATA / name).read_text(encoding="utf-8", errors="replace").split("\n"):
        s = line.strip()
        if not s or s.startswith("#") or s.startswith(";"):
            continue
        out.append(line)
    return out


def delimited_rows(name, sep):
    lines = read_lines(name)
    if not lines:
        return []
    header = [c.strip() for c in lines[0].split(sep)]
    rows = []
    for line in lines[1:]:
        parts = [c.strip() for c in line.split(sep)]
        if len(parts) != len(header):
            continue
        rows.append(dict(zip(header, parts)))
    return rows


def json_rows(name):
    rows = []
    for line in read_lines(name):
        line = line.strip()
        if line.startswith("{"):
            rows.append(json.loads(line))
    return rows


def ini_blocks(name):
    """Parse '[section]' blocks of key=value pairs into {section: {key: value}}."""
    blocks = {}
    current = None
    for line in read_lines(name):
        s = line.strip()
        if s.startswith("[") and s.endswith("]"):
            current = s[1:-1]
            blocks[current] = {}
            continue
        if current is None or "=" not in s:
            continue
        key, _, val = s.partition("=")
        blocks[current][key.strip()] = val.strip().strip('"')
    return blocks


def adopted(rows, status_field="status"):
    return [r for r in rows if str(r.get(status_field, "")).strip() == ADOPTED]


def for_class(rows, klass, class_field="class_id"):
    return [r for r in rows if str(r.get(class_field, "")).strip() == str(klass)]


def one(rows, what):
    if len(rows) != 1:
        raise SystemExit(
            "expected exactly one authoritative row for %s, got %d" % (what, len(rows))
        )
    return rows[0]


# --------------------------------------------------------------- derivation


def base_inputs():
    defaults = load_json(DATA / "defaults.json")
    base = defaults["base_config"]
    return (
        int(base["max_records"]),
        int(base["retry_limit"]),
        int(base["timeout_ms"]),
        str(base["trailer"]),
        defaults["layer_defaults"],
    )


def active_class(max_records: int) -> int:
    """Select the enforcement class by folding the base budget into the
    authoritative selector ranges of class_index.tsv2."""
    rows = adopted(delimited_rows("class_index.tsv2", "\t\t"))
    span = max(int(r["selector_hi"]) for r in rows) + 1
    selector = max_records % span
    for r in sorted(rows, key=lambda row: int(row["selector_lo"])):
        if int(r["selector_lo"]) <= selector <= int(r["selector_hi"]):
            return int(r["class_id"])
    raise SystemExit("no authoritative enforcement class for selector %d" % selector)


def ingress_qps(klass: int) -> int:
    rows = adopted(for_class(delimited_rows("ingress_rate.tsv", "\t"), klass))
    return int(one(rows, "ingress qps")["ingress_qps"])


def burst_permille(klass: int) -> int:
    block = ini_blocks("burst_multiplier.ini").get("class.%d" % klass, {})
    if block.get("status") != ADOPTED:
        raise SystemExit("no authoritative burst multiplier for class %d" % klass)
    return int(block["burst_multiplier_permille"])


def window_seconds(klass: int) -> int:
    rows = []
    for line in read_lines("window_seconds.conf"):
        parts = line.split()
        if len(parts) == 3:
            rows.append(
                {"class_id": parts[0], "window_seconds": parts[1], "status": parts[2]}
            )
    return int(one(adopted(for_class(rows, klass)), "window seconds")["window_seconds"])


def rate_granularity(klass: int) -> int:
    rows = adopted(for_class(delimited_rows("rate_gran.caret", "^"), klass))
    return int(one(rows, "rate granularity")["gran"])


def scope_sets(klass: int):
    base = {r["scope"] for r in adopted(for_class(json_rows("scope_base.jsonl"), klass))}
    overlay = {
        r["scope"] for r in adopted(for_class(json_rows("scope_overlay.ndjson"), klass))
    }
    deny = {
        r["scope"] for r in adopted(for_class(delimited_rows("scope_deny.psv", "|"), klass))
    }
    return base, overlay, deny, (base | overlay) - deny


def scope_uids():
    uids = {}
    for line in read_lines("uid_map.env"):
        key, _, val = line.strip().partition("=")
        key = key.strip()
        val = val.strip()
        if key.startswith("SCOPE_") and val.isdigit():
            uids[key[len("SCOPE_"):].lower()] = int(val)
    return uids


def uid_floor(klass: int) -> int:
    rows = adopted(for_class(delimited_rows("uid_floor.hex", ":"), klass))
    return int(one(rows, "uid floor")["floor_hex"], 16)


def control_rows(klass: int):
    rows = for_class(delimited_rows("baseline_controls.scsv", ";"), klass)
    return sorted(rows, key=lambda r: int(r["order"]))


def fold_controls(rows):
    """Fold the ordered control layer with the carry rule: an adopted control
    whose carry flag is set carries half its weight (round-half-even) into the
    next adopted control."""
    trace = []
    running = 0
    carry = 0
    for r in rows:
        weight = int(r["weight"])
        flag = int(r["carry_flag"])
        entry = {
            "order": int(r["order"]),
            "control_id": r["control_id"],
            "weight": weight,
            "carry": flag,
            "status": r["status"],
        }
        if r["status"] != ADOPTED:
            entry["running"] = "skip"
            trace.append(entry)
            continue
        running += weight + carry
        carry = div_half_even(weight, 2) if flag else 0
        entry["running"] = running
        trace.append(entry)
    return running, trace


def hardening_bounds(klass: int):
    block = ini_blocks("hardening_bounds.toml").get("class.%d" % klass, {})
    if block.get("status") != ADOPTED:
        raise SystemExit("no authoritative hardening bounds for class %d" % klass)
    return int(block["floor"]), int(block["ceil"])


def severity_permille(klass: int) -> int:
    rows = []
    for line in read_lines("severity_weight.kv"):
        parts = line.strip().split(":")
        if len(parts) == 3 and parts[0] == "class%d" % klass:
            rows.append({"permille": parts[1], "status": parts[2]})
    return int(one(adopted(rows), "severity weight")["permille"])


def risk_constants():
    consts = {}
    for line in read_lines("risk_const.env2"):
        key, _, val = line.strip().partition("=")
        consts[key.strip()] = val.strip()
    return int(consts["BASELINE_COMPLEMENT"]), int(consts["RISK_DIVISOR"])


def healthy_voters(klass: int) -> int:
    rows = adopted(for_class(json_rows("voter_health.ndjson"), klass))
    return sum(1 for r in rows if r.get("healthy") is True)


def quorum_permille(klass: int) -> int:
    rows = adopted(for_class(delimited_rows("quorum_permille.tilde", "~"), klass))
    return int(one(rows, "quorum permille")["permille"])


def tls_floor_score(klass: int) -> int:
    rows = adopted(for_class(delimited_rows("tls_matrix.csv", ","), klass))
    scores = [int(r["score"]) for r in rows if r["enabled"] == "true"]
    if not scores:
        raise SystemExit("no authoritative enabled TLS suite for class %d" % klass)
    return max(scores)


def seccomp_allowed(klass: int):
    allow = {
        r["syscall"]
        for r in adopted(for_class(delimited_rows("seccomp_allow.tsv", "\t"), klass))
    }
    deny = {
        r["syscall"]
        for r in adopted(for_class(delimited_rows("seccomp_deny.psv", "|"), klass))
    }
    return sorted(allow - deny), sorted(deny)


def retention_days(klass: int) -> int:
    block = ini_blocks("retention.ini").get("class.%d" % klass, {})
    if block.get("status") != ADOPTED:
        raise SystemExit("no authoritative retention block for class %d" % klass)
    return int(block["retention_days"])


def nonce_floor(klass: int) -> int:
    block = ini_blocks("nonce_bounds.toml2").get("class.%d" % klass, {})
    if block.get("status") != ADOPTED:
        raise SystemExit("no authoritative nonce bounds for class %d" % klass)
    return int(block["floor_ms"])


def sessions_ceiling(klass: int) -> int:
    rows = adopted(for_class(delimited_rows("sessions_cap.csv2", ","), klass))
    return int(one(rows, "session cap ceiling")["abs_ceil"])


def retry_step(klass: int) -> int:
    rows = adopted(for_class(delimited_rows("retry_backoff.psv2", "||"), klass))
    return int(one(rows, "retry backoff step")["step"])


PRECEDENCE_FIELDS = ("session_ttl_seconds", "nonce_window_ms", "max_concurrent_sessions")


def resolve_precedence(klass: int, layer_defaults):
    """defaults -> per-class overrides -> pinned overrides (pinned only)."""
    overrides = load_json(DATA / "layer_overrides.json").get("class_%d" % klass, {})
    pinned = load_json(DATA / "pinned_overrides.json").get("class_%d" % klass, {})
    defaults = {}
    resolved = {}
    for field in PRECEDENCE_FIELDS:
        value = int(layer_defaults[field])
        defaults[field] = value
        if field in overrides:
            value = int(overrides[field])
        if pinned.get("pinned") is True and field in pinned:
            value = int(pinned[field])
        resolved[field] = value
    resolved["nonce_window_ms"] = max(resolved["nonce_window_ms"], nonce_floor(klass))
    resolved["max_concurrent_sessions"] = min(
        resolved["max_concurrent_sessions"], sessions_ceiling(klass)
    )
    return defaults, resolved


def privilege_bits_uid(klass: int):
    for line in read_lines("privilege_bits.b64"):
        text = base64.b64decode(line.strip()).decode("utf-8")
        parts = dict(p.split("=", 1) for p in text.split(";"))
        if parts.get("status") == ADOPTED and parts.get("class") == str(klass):
            return int(parts["uid"])
    return None


def derive_all():
    max_records, retry_limit, timeout_ms, trailer, layer_defaults = base_inputs()
    klass = active_class(max_records)

    qps = ingress_qps(klass)
    permille = burst_permille(klass)
    window = window_seconds(klass)
    gran = rate_granularity(klass)
    rate_limit = quantize_floor(div_half_even(qps * permille, PERMILLE), gran)
    burst_ceiling = rate_limit * window

    base_scopes, overlay_scopes, deny_scopes, effective_scopes = scope_sets(klass)
    uids = scope_uids()
    floor_uid = uid_floor(klass)
    granted = {s: uids[s] for s in sorted(effective_scopes) if s in uids}
    privilege_drop_uid = max(min(granted.values()), floor_uid)

    fold_score, fold_trace = fold_controls(control_rows(klass))
    lo, hi = hardening_bounds(klass)
    hardening_baseline = quantize_floor(clamp(fold_score, lo, hi), HARDENING_STEP)

    complement, risk_divisor = risk_constants()
    severity = severity_permille(klass)
    risk_index = div_half_even(
        (complement - hardening_baseline) * severity, risk_divisor
    )

    voters = healthy_voters(klass)
    q_permille = quorum_permille(klass)
    quorum = clamp(div_half_even(voters * q_permille, PERMILLE), 1, voters)

    defaults_layer, precedence = resolve_precedence(klass, layer_defaults)
    step = retry_step(klass)
    backoff = quantize_floor(div_half_even(timeout_ms, retry_limit + 1), step)
    allowed_syscalls, denied_syscalls = seccomp_allowed(klass)

    config = {
        "active_class": klass,
        "audit_retention_days": retention_days(klass),
        "burst_ceiling": burst_ceiling,
        "effective_scope_count": len(effective_scopes),
        "enforcement_profile": "main",
        "hardening_baseline": hardening_baseline,
        "ingress_rate_limit_qps": rate_limit,
        "max_concurrent_sessions": precedence["max_concurrent_sessions"],
        "nonce_window_ms": precedence["nonce_window_ms"],
        "privilege_drop_uid": privilege_drop_uid,
        "quorum_threshold": quorum,
        "retry_backoff_base_ms": backoff,
        "risk_index": risk_index,
        "seccomp_allowed_count": len(allowed_syscalls),
        "session_ttl_seconds": precedence["session_ttl_seconds"],
        "tls_floor_score": tls_floor_score(klass),
        "trailer": trailer,
    }
    detail = {
        "base_scopes": sorted(base_scopes),
        "burst_multiplier_permille": permille,
        "deny_scopes": sorted(deny_scopes),
        "effective_scopes": sorted(effective_scopes),
        "fold_score": fold_score,
        "fold_trace": fold_trace,
        "hardening_ceil": hi,
        "hardening_floor": lo,
        "healthy_voters": voters,
        "ingress_qps": qps,
        "max_records": max_records,
        "overlay_scopes": sorted(overlay_scopes),
        "precedence_defaults": defaults_layer,
        "precedence_resolved": precedence,
        "privilege_bits_uid": privilege_bits_uid(klass),
        "quorum_permille": q_permille,
        "rate_granularity": gran,
        "retry_limit": retry_limit,
        "retry_step": step,
        "scope_uids": granted,
        "seccomp_allowed": allowed_syscalls,
        "seccomp_denied": denied_syscalls,
        "severity_permille": severity,
        "timeout_ms": timeout_ms,
        "uid_floor": floor_uid,
        "window_seconds": window,
    }
    return config, detail


def profile_config(config, name):
    deltas = load_json(DATA / "profile_deltas.json")[name]
    out = dict(config)
    ttl = div_half_even(
        int(config["session_ttl_seconds"]) * int(deltas["ttl_scale_permille"]), PERMILLE
    )
    out["session_ttl_seconds"] = quantize_floor(ttl, TTL_GRANULARITY)
    out["quorum_threshold"] = int(config["quorum_threshold"]) + int(deltas["quorum_delta"])
    out["risk_index"] = int(config["risk_index"]) + int(deltas["risk_delta"])
    out["enforcement_profile"] = name
    return out


def profile_names():
    return list(load_json(DATA / "validation_rules.json")["profiles"])


# ----------------------------------------------------------------- commands


def cmd_init(args):
    schema = load_json(args.schema)
    write_json(args.out, {key: schema[key] for key in CONTRACT_KEYS})
    print("initialized")


def coerce_scalar(text):
    try:
        parsed = json.loads(text)
    except ValueError:
        return text
    if isinstance(parsed, (dict, list)):
        raise SystemExit("value must be a scalar")
    if isinstance(parsed, float):
        raise SystemExit("floating-point values are not permitted")
    if isinstance(parsed, bool) or parsed is None:
        return text
    if isinstance(parsed, int):
        return parsed
    return text


def cmd_set(args):
    data = load_json(args.config)
    data[args.key] = coerce_scalar(args.value)
    write_json(args.config, data)
    print("set")


def cmd_derive(args):
    config, _ = derive_all()
    data = {}
    if args.config and Path(args.config).exists():
        data = load_json(args.config)
    data.update(config)
    write_json(args.out, data)
    print("derived")


def cmd_profile(args):
    write_json(args.out, profile_config(load_json(args.config), args.name))
    print("profiled")


def cmd_profile_delta(args):
    config = load_json(args.config)
    profiles = {}
    for name in profile_names():
        prof = profile_config(config, name)
        deltas = {
            key: prof[key] - config[key]
            for key in sorted(config)
            if isinstance(config[key], int) and isinstance(prof[key], int)
        }
        profiles[name] = {
            "deltas": deltas,
            "values": {k: prof[k] for k in sorted(prof)},
        }
    write_json(
        args.out,
        {
            "base_profile": config["enforcement_profile"],
            "profiles": profiles,
            "trailer": config["trailer"],
        },
    )
    print("delta-reported")


def cmd_sidecars(args):
    config = load_json(args.config)
    _, detail = derive_all()
    out = Path(args.out_dir)
    klass = int(config["active_class"])

    rows = ["key,value"]
    for key in sorted(config):
        rows.append("%s,%s" % (key, config[key]))
    write_text(out / "admission_matrix.csv", "\n".join(rows) + "\n")

    write_text(
        out / "rate_limit_plan.ini",
        "[rate]\nclass = %d\ningress_rate_limit_qps = %d\nburst_ceiling = %d\n"
        % (klass, config["ingress_rate_limit_qps"], config["burst_ceiling"]),
    )

    lines = ["layer\tscopes\tcount"]
    for layer, scopes in (
        ("base", detail["base_scopes"]),
        ("overlay", detail["overlay_scopes"]),
        ("deny", detail["deny_scopes"]),
        ("effective", detail["effective_scopes"]),
    ):
        lines.append("%s\t%s\t%d" % (layer, ",".join(scopes), len(scopes)))
    write_text(out / "scope_reconciliation.tsv", "\n".join(lines) + "\n")

    lines = ["order|control_id|weight|carry|status|running"]
    for row in detail["fold_trace"]:
        lines.append(
            "%d|%s|%d|%d|%s|%s"
            % (
                row["order"],
                row["control_id"],
                row["weight"],
                row["carry"],
                row["status"],
                row["running"],
            )
        )
    write_text(out / "hardening_fold_trace.psv", "\n".join(lines) + "\n")

    write_text(
        out / "quorum_plan.kv",
        "healthy_voters:%d\nquorum_threshold:%d\n"
        % (detail["healthy_voters"], config["quorum_threshold"]),
    )

    write_text(
        out / "risk_ledger.env",
        "HARDENING_BASELINE=%d\nRISK_INDEX=%d\nSEVERITY_PERMILLE=%d\n"
        % (
            config["hardening_baseline"],
            config["risk_index"],
            detail["severity_permille"],
        ),
    )

    lines = []
    for field in PRECEDENCE_FIELDS:
        lines.append("%s.default=%d" % (field, detail["precedence_defaults"][field]))
        lines.append("%s.resolved=%d" % (field, config[field]))
    write_text(out / "precedence_resolution.properties", "\n".join(lines) + "\n")

    lines = [
        json.dumps({"scope": scope, "uid": detail["scope_uids"][scope]}, sort_keys=True)
        for scope in detail["effective_scopes"]
    ]
    write_text(out / "privilege_map.ndjson", "\n".join(lines) + "\n")

    write_text(
        out / "seccomp_summary.tsv",
        "class\tseccomp_allowed_count\n%d\t%d\n" % (klass, config["seccomp_allowed_count"]),
    )

    write_text(out / "tls_floor.env", "TLS_FLOOR_SCORE=%d\n" % config["tls_floor_score"])

    write_text(
        out / "retention_schedule.csv",
        "class,audit_retention_days\n%d,%d\n" % (klass, config["audit_retention_days"]),
    )
    print("sidecars")


AUDIT_INPUTS = (
    "ingress_qps",
    "burst_multiplier_permille",
    "window_seconds",
    "rate_granularity",
    "fold_score",
    "hardening_floor",
    "hardening_ceil",
    "severity_permille",
    "healthy_voters",
    "quorum_permille",
    "uid_floor",
    "retry_step",
    "timeout_ms",
    "retry_limit",
    "max_records",
)


def cmd_audit(args):
    config = load_json(args.config)
    _, detail = derive_all()
    out = Path(args.out_dir)

    xml = ['<?xml version="1.0" encoding="UTF-8"?>', "<derivation_audit>"]
    xml.append("  <active_class>%d</active_class>" % config["active_class"])
    xml.append("  <trailer>%s</trailer>" % config["trailer"])
    xml.append("  <fields>")
    for key in sorted(config):
        xml.append('    <field name="%s" value="%s"/>' % (key, config[key]))
    xml.append("  </fields>")
    xml.append("  <inputs>")
    for key in AUDIT_INPUTS:
        xml.append('    <input name="%s" value="%s"/>' % (key, detail[key]))
    xml.append("  </inputs>")
    xml.append("</derivation_audit>")
    write_text(out / "derivation_audit.xml", "\n".join(xml) + "\n")

    conv = [
        "convergence report",
        "active_class=%d" % config["active_class"],
        "fold_score=%d" % detail["fold_score"],
        "hardening_baseline=%d" % config["hardening_baseline"],
        "risk_index=%d" % config["risk_index"],
        "quorum_threshold=%d" % config["quorum_threshold"],
        "effective_scope_count=%d" % config["effective_scope_count"],
        "privilege_drop_uid=%d" % config["privilege_drop_uid"],
        "ingress_rate_limit_qps=%d" % config["ingress_rate_limit_qps"],
        "burst_ceiling=%d" % config["burst_ceiling"],
        "iterations=1",
        "stable=true",
        "float_operations=0",
        "rounding=half-even",
        "converged=true",
    ]
    write_text(out / "convergence_report.txt", "\n".join(conv) + "\n")

    lines = []
    for path in sorted(DATA.iterdir()):
        if not path.is_file():
            continue
        raw = path.read_bytes()
        lines.append(
            json.dumps(
                {
                    "bytes": len(raw),
                    "file": path.name,
                    "lines": raw.count(b"\n"),
                    "sha256": hashlib.sha256(raw).hexdigest(),
                },
                sort_keys=True,
            )
        )
    write_text(out / "input_census.ndjson", "\n".join(lines) + "\n")

    entries = [("main", int(config["risk_index"]))]
    for name in profile_names():
        entries.append((name, int(profile_config(config, name)["risk_index"])))
    entries.sort(key=lambda e: (e[1], e[0]))
    lines = ["profile\trisk_index"]
    for name, risk in entries:
        lines.append("%s\t%d" % (name, risk))
    write_text(out / "class_ordering.tsv", "\n".join(lines) + "\n")
    print("audited")


def cmd_package(args):
    source = Path(args.source)
    names = sorted(p.name for p in source.iterdir() if p.is_file())
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.out, "w", zipfile.ZIP_DEFLATED) as zf:
        for name in names:
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            zf.writestr(info, (source / name).read_bytes())
    print("packaged")


def cmd_manifest(args):
    out_dir = Path(args.out_dir)
    config = load_json(args.config)
    artifacts = {}
    for name in sorted(set(args.artifacts.split(","))):
        path = out_dir / name
        if name and path.exists():
            artifacts[name] = {"bytes": path.stat().st_size, "sha256": sha256_file(path)}
    inputs = {p.name: sha256_file(p) for p in sorted(DATA.iterdir()) if p.is_file()}
    source = Path(args.source)
    manifest = {
        "active_class": config["active_class"],
        "artifacts": artifacts,
        "deterministic": True,
        "inputs": inputs,
        "rounding": "half-even",
        "tool": {
            p.name: sha256_file(p) for p in sorted(source.iterdir()) if p.is_file()
        },
        "trailer": config["trailer"],
    }
    write_json(out_dir / "reproducibility_manifest.json", manifest)
    print("manifested")


def required_keys(schema):
    value = schema["required_keys"]
    if isinstance(value, list):
        return [str(k) for k in value]
    return [k.strip() for k in str(value).split(",") if k.strip()]


def cmd_validate(args):
    schema = load_json(args.schema)
    data = load_json(args.config)
    missing = [k for k in required_keys(schema) if k not in data]
    if missing:
        raise SystemExit("missing: " + ",".join(missing))
    bad = [k for k, v in data.items() if isinstance(v, (dict, list))]
    if bad:
        raise SystemExit("configuration must be flat: " + ",".join(sorted(bad)))
    floats = [k for k, v in data.items() if isinstance(v, float)]
    if floats:
        raise SystemExit("floating-point values present: " + ",".join(sorted(floats)))
    print("ok")


def cmd_validation_report(args):
    schema = load_json(args.schema)
    rules = load_json(DATA / "validation_rules.json")
    config = load_json(args.config)
    out_dir = Path(args.out_dir)
    keys = required_keys(schema)
    missing_keys = [k for k in keys if k not in config]
    artifacts = {}
    for name in rules["required_artifacts"]:
        if name == SELF_REPORT:
            # written by this very command; its own size cannot be self-encoded
            artifacts[name] = {"present": True, "self": True, "within_size_limit": True}
            continue
        path = out_dir / name
        present = path.exists()
        size = path.stat().st_size if present else 0
        artifacts[name] = {
            "bytes": size,
            "present": present,
            "within_size_limit": present and size <= int(rules["max_artifact_bytes"]),
        }
    forbidden = sorted(k for k in rules["forbidden_keys"] if k in config)
    checks = {
        "all_required_artifacts_present": all(a["present"] for a in artifacts.values()),
        "artifacts_within_size_limit": all(
            a["within_size_limit"] for a in artifacts.values()
        ),
        "config_flat": all(
            not isinstance(v, (dict, list)) for v in config.values()
        ),
        "no_floats": all(not isinstance(v, float) for v in config.values()),
        "no_forbidden_keys": not forbidden,
        "required_keys_present": not missing_keys,
        "trailer_intact": config["trailer"]
        == load_json(DATA / "defaults.json")["base_config"]["trailer"],
    }
    report = {
        "artifacts": artifacts,
        "checks": checks,
        "forbidden_keys_present": forbidden,
        "missing_keys": missing_keys,
        "ok": all(checks.values()),
        "required_key_count": len(keys),
    }
    write_json(out_dir / "validation_report.json", report)
    if not report["ok"]:
        raise SystemExit("validation failed")
    print("validation-reported")


def cmd_summary(args):
    config = load_json(args.config)
    rules = load_json(DATA / "validation_rules.json")
    out_dir = Path(args.out_dir)
    profiles = {}
    for name in profile_names():
        prof = profile_config(config, name)
        profiles[name] = {
            "quorum_threshold": prof["quorum_threshold"],
            "risk_index": prof["risk_index"],
            "session_ttl_seconds": prof["session_ttl_seconds"],
        }
    write_json(
        out_dir / "summary.json",
        {
            "active_class": config["active_class"],
            "artifact_count": len(rules["required_artifacts"]),
            "config": {k: config[k] for k in sorted(config)},
            "config_sha256": sha256_file(args.config),
            "ok": True,
            "profiles": profiles,
            "trailer": config["trailer"],
        },
    )
    print("summarized")


def cmd_report(args):
    config = load_json(args.config)
    commands_arg = args.commands
    if Path(commands_arg).exists():
        commands = json.loads(Path(commands_arg).read_text(encoding="utf-8"))
    else:
        commands = json.loads(commands_arg)
    write_json(
        args.out,
        {
            "commands": commands,
            "config": {k: config[k] for k in sorted(config)},
            "config_sha256": args.digest,
            "ok": True,
            "tool": "task-ctl",
            "trailer": config["trailer"],
        },
    )
    print("reported")


def main():
    parser = argparse.ArgumentParser(prog="task-ctl")
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("derive")
    p.add_argument("--config")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_derive)

    p = sub.add_parser("profile")
    p.add_argument("--name", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_profile)

    p = sub.add_parser("profile-delta")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_profile_delta)

    p = sub.add_parser("sidecars")
    p.add_argument("--config", required=True)
    p.add_argument("--out-dir", required=True)
    p.set_defaults(func=cmd_sidecars)

    p = sub.add_parser("audit")
    p.add_argument("--config", required=True)
    p.add_argument("--out-dir", required=True)
    p.set_defaults(func=cmd_audit)

    p = sub.add_parser("package")
    p.add_argument("--source", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_package)

    p = sub.add_parser("manifest")
    p.add_argument("--config", required=True)
    p.add_argument("--source", required=True)
    p.add_argument("--artifacts", required=True)
    p.add_argument("--out-dir", required=True)
    p.set_defaults(func=cmd_manifest)

    p = sub.add_parser("init")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("validation-report")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--out-dir", required=True)
    p.set_defaults(func=cmd_validation_report)

    p = sub.add_parser("summary")
    p.add_argument("--config", required=True)
    p.add_argument("--out-dir", required=True)
    p.set_defaults(func=cmd_summary)

    p = sub.add_parser("export-report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest", required=True)
    p.add_argument("--commands", required=True)
    p.set_defaults(func=cmd_report)

    args = parser.parse_args()
    if not getattr(args, "command", None):
        parser.print_help()
        return
    args.func(args)


if __name__ == "__main__":
    main()
