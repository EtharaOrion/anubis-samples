# task-ctl

An offline container-image admission-control hardening compiler for a
server-side admission broker. It reads interacting numeric policy layers from
`/app/data`, selects the active enforcement class, and derives one flat hardened
admission configuration plus two deployment profiles (canary and enforce).

This build is repaired: the threshold/rate-limit, privilege/scope reconciliation,
hardening-baseline, risk-scoring and quorum, and policy-precedence rules now
follow the documented contract recorded across the policy layers, and the
command surface is complete.

## Commands

- `init --schema <schema> --out <config>`: seed fixed contract strings.
- `derive --config <config> --out <config>`: derive every graded scalar for the
  active enforcement class.
- `set --config <config> --key <key> --value <value>`: set one scalar key with
  correct case and type coercion; reject any non-scalar value.
- `validate --schema <schema> --config <config>`: confirm every required key is
  present and the configuration is flat; print `ok`.
- `profile --name <canary|enforce> --config <config> --out <profile>`: apply the
  documented per-profile deltas.
- `profile-delta --config <config> --out <report>`: signed profile deltas.
- `sidecars --config <config> --out-dir <dir>`: derivation sidecars.
- `audit --config <config> --out-dir <dir>`: audit and provenance artifacts.
- `package --source <dir> --out <zip>`: deterministic repackaging of the tool.
- `manifest --config <config> --source <dir> --artifacts <csv> --out-dir <dir>`:
  reproducibility manifest.
- `validation-report --schema <schema> --config <config> --out-dir <dir>` and
  `summary --config <config> --out-dir <dir>`: coverage artifacts.
- `export-report --config <config> --out <report> --digest <sha256> --commands <json>`:
  emit a truthful command transcript.

## Derivation rules

- Active class: the base budget `max_records` is reduced modulo the authoritative
  selector span of `class_index.tsv2` and matched against its adopted ranges.
- Ingress rate limit: per-class throughput scaled by the per-class burst permille
  (round-half-even) and quantized down to the per-class rate step; the burst
  ceiling is the resolved rate limit times the per-class window.
- Scopes: `(base | overlay) - deny` for the active class; the privilege-drop uid
  is the minimum granted uid raised to the per-class uid floor.
- Hardening baseline: the ordered adopted controls are folded so that a control
  with its carry flag set carries half of its weight (round-half-even) into the
  next adopted control; the fold is clamped to the per-class bounds and
  quantized down to a multiple of 5.
- Risk index: `(BASELINE_COMPLEMENT - hardening_baseline) * severity_permille`
  divided by `RISK_DIVISOR` (round-half-even).
- Quorum: healthy adopted voters scaled by the per-class quorum permille,
  bounded below by 1 and above by the voter count.
- Precedence: `layer_defaults` -> `layer_overrides` -> `pinned_overrides` (only
  where `pinned` is true), then per-class nonce floor and session-cap ceiling.
- Retry backoff: base timeout divided by the retry budget (`retry_limit + 1`),
  quantized down to the per-class step.

## Contract notes

- Every value is derived with exact integer arithmetic (round-half-even); no
  floating-point value may reach a graded key.
- The configuration is flat: keys map directly to integer or string scalars.
- The required key set is authoritative in `schema.json` and mirrored by the
  field registry in the policy layers.
- Only rows whose status is `ADOPTED` for the active enforcement class bind; rows
  labelled `SUPERSEDED`, `DRAFT`, `SHADOW`, or `REVOKED` are context decoys.
