#!/usr/bin/env python3
"""task-ctl: local admission-control hardening compiler.

Compiles a flat hardened admission configuration for the active enforcement
class from the interacting numeric policy layers under /app/data, plus the
canary/enforce deployment profiles and the derivation sidecars.

All graded arithmetic is exact integer arithmetic with round-half-even
rounding; no floating point value reaches a graded key.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import zipfile
from pathlib import Path

DATA = Path("/app/data")
ADOPTED = "ADOPTED"
PRECEDENCE_FIELDS = ("session_ttl_seconds", "nonce_window_ms", "max_concurrent_sessions")
TTL_GRANULARITY = 5
HARDENING_GRANULARITY = 5
MAIN_PROFILE = "main"

# ---------------------------------------------------------------------------
# exact integer arithmetic helpers
# ---------------------------------------------------------------------------


def round_half_even(num, den):
    """Exact integer round-half-even of num/den."""
    num, den = int(num), int(den)
    if den == 0:
        raise ZeroDivisionError("round_half_even: zero denominator")
    if den < 0:
        num, den = -num, -den
    q, r = divmod(num, den)
    twice = 2 * r
    if twice > den or (twice == den and q % 2 != 0):
        q += 1
    return q


def quantize_floor(value, step):
    value, step = int(value), int(step)
    return (value // step) * step


def clamp(value, low, high):
    return max(int(low), min(int(high), int(value)))


# ---------------------------------------------------------------------------
# generic parsing helpers
# ---------------------------------------------------------------------------


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, data):
    Path(path).write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def write_text(path, text):
    Path(path).write_text(text, encoding="utf-8")


def read_lines(name, keep_comments=False):
    out = []
    raw = (DATA / name).read_text(encoding="utf-8", errors="replace")
    for line in raw.split("\n"):
        s = line.strip()
        if not s:
            continue
        if not keep_comments and (s.startswith("#") or s.startswith(";")):
            continue
        out.append(line)
    return out


def delimited_rows(name, sep):
    lines = read_lines(name)
    if not lines:
        return []
    header = [c.strip() for c in lines[0].split(sep)]
    rows = []
    for line in lines[1:]:
        parts = [c.strip() for c in line.split(sep)]
        if len(parts) != len(header):
            continue
        rows.append(dict(zip(header, parts)))
    return rows


def whitespace_rows(name, fields, skip_header=False):
    lines = read_lines(name)
    rows = []
    for line in lines[1:] if skip_header else lines:
        parts = line.split()
        if len(parts) != len(fields):
            continue
        rows.append(dict(zip(fields, parts)))
    return rows


def ndjson_rows(name):
    rows = []
    for line in read_lines(name):
        s = line.strip()
        if not s.startswith("{"):
            continue
        rows.append(json.loads(s))
    return rows


def ini_sections(name):
    """Parse '[section]' blocks of key = value pairs (ini/toml-ish layers)."""
    sections = {}
    current = None
    for line in read_lines(name):
        s = line.strip()
        if s.startswith("[") and s.endswith("]"):
            current = s[1:-1].strip()
            sections.setdefault(current, {})
            continue
        if current is None or "=" not in s:
            continue
        key, _, val = s.partition("=")
        sections[current][key.strip()] = val.strip().strip('"')
    return sections


def class_section(sections, klass):
    key = "class.%d" % klass
    block = sections.get(key)
    if block is None or block.get("status") != ADOPTED:
        raise SystemExit("no ADOPTED section for %s" % key)
    return block


def sole(values, what):
    uniq = sorted(set(values))
    if len(uniq) != 1:
        raise SystemExit("ambiguous authoritative value for %s: %r" % (what, uniq))
    return uniq[0]


# ---------------------------------------------------------------------------
# policy layer readers (authoritative rows only)
# ---------------------------------------------------------------------------


def base_inputs():
    base = load_json(DATA / "defaults.json")["base_config"]
    return (
        int(base["max_records"]),
        int(base["retry_limit"]),
        int(base["timeout_ms"]),
        str(base["trailer"]),
    )


def active_class(max_records):
    """Select the enforcement class by folding the base budget into the
    ADOPTED selector ranges of class_index.tsv2."""
    rows = whitespace_rows("class_index.tsv2",
                           ["class_id", "selector_lo", "selector_hi", "status"], skip_header=True)
    adopted = [r for r in rows if r["status"] == ADOPTED]
    span = max(int(r["selector_hi"]) for r in adopted) + 1
    selector = max_records % span
    for r in sorted(adopted, key=lambda r: int(r["selector_lo"])):
        if int(r["selector_lo"]) <= selector <= int(r["selector_hi"]):
            return int(r["class_id"]), selector, span
    raise SystemExit("no ADOPTED selector range covers %d" % selector)


def ingress_qps(klass):
    rows = delimited_rows("ingress_rate.tsv", "\t")
    vals = [int(r["ingress_qps"]) for r in rows
            if int(r["class_id"]) == klass and r["status"] == ADOPTED]
    return sole(vals, "ingress_qps")


def burst_permille(klass):
    block = class_section(ini_sections("burst_multiplier.ini"), klass)
    return int(block["burst_multiplier_permille"])


def window_seconds(klass):
    rows = whitespace_rows("window_seconds.conf", ["class_id", "window_seconds", "status"])
    vals = [int(r["window_seconds"]) for r in rows
            if int(r["class_id"]) == klass and r["status"] == ADOPTED]
    return sole(vals, "window_seconds")


def rate_granularity(klass):
    rows = delimited_rows("rate_gran.caret", "^")
    vals = [int(r["gran"]) for r in rows
            if int(r["class_id"]) == klass and r["status"] == ADOPTED]
    return sole(vals, "rate_gran")


def scope_layers(klass):
    base = sorted({r["scope"] for r in ndjson_rows("scope_base.jsonl")
                   if int(r["class_id"]) == klass and r["status"] == ADOPTED})
    overlay = sorted({r["scope"] for r in ndjson_rows("scope_overlay.ndjson")
                      if int(r["class_id"]) == klass and r["status"] == ADOPTED})
    deny = sorted({r["scope"] for r in delimited_rows("scope_deny.psv", "|")
                   if int(r["class_id"]) == klass and r["status"] == ADOPTED})
    effective = sorted((set(base) | set(overlay)) - set(deny))
    return base, overlay, deny, effective


def scope_uids():
    uids = {}
    for line in read_lines("uid_map.env"):
        key, _, val = line.strip().partition("=")
        key, val = key.strip(), val.strip()
        if key.startswith("SCOPE_") and val.isdigit():
            uids[key[len("SCOPE_"):].lower()] = int(val)
    return uids


def uid_floor(klass):
    rows = delimited_rows("uid_floor.hex", ":")
    vals = [int(r["floor_hex"], 16) for r in rows
            if int(r["class_id"]) == klass and r["status"] == ADOPTED]
    return sole(vals, "uid_floor")


def control_rows(klass):
    rows = [r for r in delimited_rows("baseline_controls.scsv", ";")
            if int(r["class_id"]) == klass]
    rows.sort(key=lambda r: int(r["order"]))
    return rows


def hardening_bounds(klass):
    block = class_section(ini_sections("hardening_bounds.toml"), klass)
    return int(block["floor"]), int(block["ceil"])


def severity_permille(klass):
    vals = []
    for line in read_lines("severity_weight.kv"):
        parts = line.strip().split(":")
        if len(parts) != 3:
            continue
        name, permille, status = parts
        if name == "class%d" % klass and status == ADOPTED:
            vals.append(int(permille))
    return sole(vals, "severity_permille")


def risk_constants():
    consts = {}
    for line in read_lines("risk_const.env2"):
        key, _, val = line.strip().partition("=")
        consts[key.strip()] = val.strip()
    return int(consts["BASELINE_COMPLEMENT"]), int(consts["RISK_DIVISOR"])


def voter_counts(klass):
    rows = [r for r in ndjson_rows("voter_health.ndjson") if int(r["class_id"]) == klass]
    authoritative = [r for r in rows if r["status"] == ADOPTED]
    healthy = [r for r in authoritative if r["healthy"] is True]
    return len(authoritative), len(healthy)


def quorum_permille(klass):
    rows = delimited_rows("quorum_permille.tilde", "~")
    vals = [int(r["permille"]) for r in rows
            if int(r["class_id"]) == klass and r["status"] == ADOPTED]
    return sole(vals, "quorum_permille")


def tls_floor(klass):
    rows = delimited_rows("tls_matrix.csv", ",")
    vals = [int(r["score"]) for r in rows
            if int(r["class_id"]) == klass and r["status"] == ADOPTED and r["enabled"] == "true"]
    if not vals:
        raise SystemExit("no ADOPTED enabled TLS suite for class %d" % klass)
    return max(vals)


def seccomp_sets(klass):
    allow = sorted({r["syscall"] for r in delimited_rows("seccomp_allow.tsv", "\t")
                    if int(r["class_id"]) == klass and r["status"] == ADOPTED})
    deny = sorted({r["syscall"] for r in delimited_rows("seccomp_deny.psv", "|")
                   if int(r["class_id"]) == klass and r["status"] == ADOPTED})
    return allow, deny, sorted(set(allow) - set(deny))


def retention_days(klass):
    block = class_section(ini_sections("retention.ini"), klass)
    return int(block["retention_days"])


def retry_step(klass):
    rows = delimited_rows("retry_backoff.psv2", "||")
    vals = [int(r["step"]) for r in rows
            if int(r["class_id"]) == klass and r["status"] == ADOPTED]
    return sole(vals, "retry_step")


def sessions_abs_ceil(klass):
    rows = delimited_rows("sessions_cap.csv2", ",")
    vals = [int(r["abs_ceil"]) for r in rows
            if int(r["class_id"]) == klass and r["status"] == ADOPTED]
    return sole(vals, "sessions_abs_ceil")


def nonce_floor(klass):
    block = class_section(ini_sections("nonce_bounds.toml2"), klass)
    return int(block["floor_ms"])


def privilege_bits(klass):
    for line in read_lines("privilege_bits.b64"):
        try:
            decoded = base64.b64decode(line.strip()).decode("utf-8")
        except Exception:
            continue
        fields = dict(part.split("=", 1) for part in decoded.split(";") if "=" in part)
        if fields.get("status") == ADOPTED and int(fields.get("class", -1)) == klass:
            return int(fields["uid"])
    raise SystemExit("no ADOPTED privilege bits row for class %d" % klass)


def adopted_profiles():
    names = []
    for line in read_lines("profile_map.kv3"):
        parts = line.strip().split(":")
        if len(parts) != 3:
            continue
        name, order, status = parts
        if status == ADOPTED:
            names.append((int(order), name))
    return [n for _, n in sorted(names)]


# ---------------------------------------------------------------------------
# derivation
# ---------------------------------------------------------------------------


def fold_controls(rows):
    """Fold the ordered control layer: an adopted control whose carry_flag is 1
    carries half its weight (round-half-even) into the next adopted control."""
    trace = []
    running = 0
    pending_carry = 0
    for r in rows:
        if r["status"] != ADOPTED:
            trace.append({
                "order": int(r["order"]),
                "control_id": r["control_id"],
                "weight": int(r["weight"]),
                "carry": int(r["carry_flag"]),
                "status": r["status"],
                "running": "skip",
            })
            continue
        weight = int(r["weight"])
        running += weight + pending_carry
        pending_carry = round_half_even(weight, 2) if int(r["carry_flag"]) == 1 else 0
        trace.append({
            "order": int(r["order"]),
            "control_id": r["control_id"],
            "weight": weight,
            "carry": int(r["carry_flag"]),
            "status": r["status"],
            "running": running,
        })
    return running, trace


def resolve_precedence(klass):
    defaults = load_json(DATA / "defaults.json")["layer_defaults"]
    overrides = load_json(DATA / "layer_overrides.json").get("class_%d" % klass, {})
    pinned = load_json(DATA / "pinned_overrides.json").get("class_%d" % klass, {})
    resolved = {}
    for field in PRECEDENCE_FIELDS:
        value = int(defaults[field])
        if field in overrides:
            value = int(overrides[field])
        if pinned.get("pinned") is True and field in pinned:
            value = int(pinned[field])
        resolved[field] = value
    resolved["max_concurrent_sessions"] = min(
        resolved["max_concurrent_sessions"], sessions_abs_ceil(klass))
    resolved["nonce_window_ms"] = max(resolved["nonce_window_ms"], nonce_floor(klass))
    return {f: int(defaults[f]) for f in PRECEDENCE_FIELDS}, resolved


def derive_all():
    max_records, retry_limit, timeout_ms, trailer = base_inputs()
    klass, selector, span = active_class(max_records)

    qps = ingress_qps(klass)
    permille = burst_permille(klass)
    window = window_seconds(klass)
    gran = rate_granularity(klass)
    rate_pre = round_half_even(qps * permille, 1000)
    rate_limit = quantize_floor(rate_pre, gran)
    burst_ceiling = rate_limit * window

    base_scopes, overlay_scopes, deny_scopes, effective_scopes = scope_layers(klass)
    uids = scope_uids()
    floor = uid_floor(klass)
    granted = {s: uids[s] for s in effective_scopes if s in uids}
    if not granted:
        raise SystemExit("no uid mapping for effective scopes")
    privilege_drop_uid = max(min(granted.values()), floor)

    rows = control_rows(klass)
    fold_score, fold_trace = fold_controls(rows)
    h_floor, h_ceil = hardening_bounds(klass)
    hardening_baseline = quantize_floor(clamp(fold_score, h_floor, h_ceil), HARDENING_GRANULARITY)

    severity = severity_permille(klass)
    complement, divisor = risk_constants()
    risk_index = round_half_even((complement - hardening_baseline) * severity, divisor)

    voters, healthy = voter_counts(klass)
    q_permille = quorum_permille(klass)
    quorum_threshold = clamp(round_half_even(healthy * q_permille, 1000), 1, voters)

    tls_score = tls_floor(klass)
    allow, deny, effective_syscalls = seccomp_sets(klass)
    retention = retention_days(klass)

    defaults_precedence, resolved = resolve_precedence(klass)
    step = retry_step(klass)
    retry_backoff = quantize_floor(round_half_even(timeout_ms, retry_limit + 1), step)

    contract = load_json(DATA / "defaults.json")
    config = {
        "active_class": klass,
        "audit_retention_days": retention,
        "burst_ceiling": burst_ceiling,
        "checksum": contract["checksum"],
        "control_plane": contract["control_plane"],
        "effective_scope_count": len(effective_scopes),
        "enforcement_profile": MAIN_PROFILE,
        "hardening_baseline": hardening_baseline,
        "image_runtime": contract["image_runtime"],
        "ingress_rate_limit_qps": rate_limit,
        "max_concurrent_sessions": resolved["max_concurrent_sessions"],
        "mode": contract["mode"],
        "nonce_window_ms": resolved["nonce_window_ms"],
        "privilege_drop_uid": privilege_drop_uid,
        "profile": "TASK",
        "quorum_threshold": quorum_threshold,
        "retry_backoff_base_ms": retry_backoff,
        "risk_index": risk_index,
        "seccomp_allowed_count": len(effective_syscalls),
        "session_ttl_seconds": resolved["session_ttl_seconds"],
        "tls_floor_score": tls_score,
        "trailer": trailer,
    }

    detail = {
        "base_scopes": base_scopes,
        "burst_permille": permille,
        "deny_scopes": deny_scopes,
        "effective_scopes": effective_scopes,
        "effective_syscalls": effective_syscalls,
        "fold_score": fold_score,
        "fold_trace": fold_trace,
        "granted_uids": granted,
        "hardening_ceil": h_ceil,
        "hardening_floor": h_floor,
        "healthy_voters": healthy,
        "ingress_qps": qps,
        "max_records": max_records,
        "overlay_scopes": overlay_scopes,
        "precedence_defaults": defaults_precedence,
        "precedence_resolved": resolved,
        "privilege_bits_uid": privilege_bits(klass),
        "quorum_permille": q_permille,
        "rate_granularity": gran,
        "rate_pre_quantize": rate_pre,
        "retry_limit": retry_limit,
        "retry_step": step,
        "risk_complement": complement,
        "risk_divisor": divisor,
        "seccomp_allow": allow,
        "seccomp_deny": deny,
        "selector": selector,
        "selector_span": span,
        "severity_permille": severity,
        "timeout_ms": timeout_ms,
        "uid_floor": floor,
        "voters": voters,
        "window_seconds": window,
    }
    return config, detail


def build_profile(config, detail, name):
    deltas = load_json(DATA / "profile_deltas.json")[name]
    profile = dict(config)
    ttl = round_half_even(config["session_ttl_seconds"] * int(deltas["ttl_scale_permille"]), 1000)
    profile["session_ttl_seconds"] = quantize_floor(ttl, TTL_GRANULARITY)
    profile["quorum_threshold"] = clamp(
        config["quorum_threshold"] + int(deltas["quorum_delta"]), 1, detail["voters"])
    profile["risk_index"] = max(0, config["risk_index"] + int(deltas["risk_delta"]))
    profile["enforcement_profile"] = name
    return profile


# ---------------------------------------------------------------------------
# commands
# ---------------------------------------------------------------------------


def cmd_derive(args):
    config, _ = derive_all()
    out = Path(args.out)
    if out.exists():
        seeded = load_json(out)
        seeded.update(config)
        config = seeded
    write_json(out, config)
    print("derived")


def cmd_profile(args):
    config = load_json(args.config)
    derived, detail = derive_all()
    if any(config.get(k) != v for k, v in derived.items()):
        raise SystemExit("config does not match the derived contract")
    write_json(args.out, build_profile(config, detail, args.name))
    print("profiled")


def cmd_profile_delta(args):
    config = load_json(args.config)
    report = {"base": {"enforcement_profile": config["enforcement_profile"],
                       "trailer": config["trailer"]},
              "profiles": {}}
    for name, path in (("canary", args.canary), ("enforce", args.enforce)):
        profile = load_json(path)
        numeric, strings = {}, {}
        for key in sorted(config):
            before, after = config[key], profile[key]
            if isinstance(before, bool) or not isinstance(before, int):
                if before != after:
                    strings[key] = {"from": before, "to": after}
            else:
                numeric[key] = after - before
        report["profiles"][name] = {
            "changed_keys": sorted([k for k, v in numeric.items() if v != 0] + list(strings)),
            "signed_deltas": numeric,
            "string_changes": strings,
            "trailer": profile["trailer"],
        }
    write_json(args.out, report)
    print("profile-delta")


def cmd_init(args):
    schema = load_json(args.schema)
    write_json(args.out, {
        "checksum": schema["checksum"],
        "control_plane": schema["control_plane"],
        "image_runtime": schema["image_runtime"],
        "mode": schema["mode"],
        "profile": schema["profile"],
    })
    print("initialized")


def coerce_scalar(raw):
    text = raw.strip()
    try:
        parsed = json.loads(text)
    except ValueError:
        return text
    if isinstance(parsed, (dict, list)):
        raise SystemExit("value must be scalar: " + raw)
    if isinstance(parsed, float):
        raise SystemExit("floating point values are not permitted: " + raw)
    if isinstance(parsed, bool) or parsed is None:
        return text
    return parsed


def cmd_set(args):
    data = load_json(args.config)
    data[args.key] = coerce_scalar(args.value)
    write_json(args.config, data)
    print("set")


def required_keys(schema):
    keys = schema["required_keys"]
    if isinstance(keys, str):
        keys = keys.split(",")
    return [k.strip() for k in keys if k.strip()]


def cmd_validate(args):
    schema = load_json(args.schema)
    data = load_json(args.config)
    missing = [k for k in required_keys(schema) if k not in data]
    if missing:
        raise SystemExit("missing: " + ",".join(missing))
    bad = [k for k, v in data.items() if isinstance(v, (dict, list))]
    if bad:
        raise SystemExit("configuration must be flat: " + ",".join(sorted(bad)))
    floats = [k for k, v in data.items() if isinstance(v, float)]
    if floats:
        raise SystemExit("floating point values are not permitted: " + ",".join(sorted(floats)))
    print("ok")


def cmd_report(args):
    data = load_json(args.config)
    commands_arg = Path(args.commands)
    raw = commands_arg.read_text(encoding="utf-8") if commands_arg.exists() else args.commands
    commands = json.loads(raw)
    report = {
        "commands": commands,
        "config": data,
        "config_sha256": args.digest,
        "ok": all(c.get("exit_code") == 0 for c in commands),
        "tool": "task-ctl",
        "trailer": data["trailer"],
    }
    write_json(args.out, report)
    print("reported")


# ---------------------------------------------------------------------------
# sidecar / audit emitters
# ---------------------------------------------------------------------------


def cmd_sidecars(args):
    config = load_json(args.config)
    _, detail = derive_all()
    out = Path(args.outdir)

    lines = ["key,value"]
    for key in sorted(config):
        lines.append("%s,%s" % (key, config[key]))
    write_text(out / "admission_matrix.csv", "\n".join(lines) + "\n")

    write_text(out / "rate_limit_plan.ini", "[rate]\n"
               + "class = %d\n" % config["active_class"]
               + "ingress_rate_limit_qps = %d\n" % config["ingress_rate_limit_qps"]
               + "burst_ceiling = %d\n" % config["burst_ceiling"])

    rows = ["scope\tin_base\tin_overlay\tdenied\teffective"]
    universe = sorted(set(detail["base_scopes"]) | set(detail["overlay_scopes"])
                      | set(detail["deny_scopes"]))
    for scope in universe:
        rows.append("%s\t%d\t%d\t%d\t%d" % (
            scope,
            1 if scope in detail["base_scopes"] else 0,
            1 if scope in detail["overlay_scopes"] else 0,
            1 if scope in detail["deny_scopes"] else 0,
            1 if scope in detail["effective_scopes"] else 0,
        ))
    write_text(out / "scope_reconciliation.tsv", "\n".join(rows) + "\n")

    trace = ["order|control_id|weight|carry|status|running"]
    for entry in detail["fold_trace"]:
        trace.append("%d|%s|%d|%d|%s|%s" % (
            entry["order"], entry["control_id"], entry["weight"],
            entry["carry"], entry["status"], entry["running"]))
    write_text(out / "hardening_fold_trace.psv", "\n".join(trace) + "\n")

    write_text(out / "quorum_plan.kv", "healthy_voters:%d\nquorum_threshold:%d\n"
               % (detail["healthy_voters"], config["quorum_threshold"]))

    write_text(out / "risk_ledger.env",
               "HARDENING_BASELINE=%d\nRISK_INDEX=%d\nSEVERITY_PERMILLE=%d\n"
               % (config["hardening_baseline"], config["risk_index"],
                  detail["severity_permille"]))

    props = []
    for field in sorted(PRECEDENCE_FIELDS):
        props.append("%s.default=%d" % (field, detail["precedence_defaults"][field]))
        props.append("%s.resolved=%d" % (field, detail["precedence_resolved"][field]))
    write_text(out / "precedence_resolution.properties", "\n".join(props) + "\n")

    privilege = [json.dumps({"scope": scope, "uid": detail["granted_uids"][scope]}, sort_keys=True)
                 for scope in detail["effective_scopes"]]
    write_text(out / "privilege_map.ndjson", "\n".join(privilege) + "\n")

    write_text(out / "seccomp_summary.tsv", "class\tseccomp_allowed_count\n%d\t%d\n"
               % (config["active_class"], config["seccomp_allowed_count"]))

    write_text(out / "tls_floor.env", "TLS_FLOOR_SCORE=%d\n" % config["tls_floor_score"])

    write_text(out / "retention_schedule.csv", "class,audit_retention_days\n%d,%d\n"
               % (config["active_class"], config["audit_retention_days"]))

    print("sidecars")


def escape_xml(text):
    return (text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace('"', "&quot;"))


def sha256_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def cmd_audit(args):
    config = load_json(args.config)
    _, detail = derive_all()
    out = Path(args.outdir)

    formulas = {
        "active_class": "selector=max_records(%d) mod %d=%d inside ADOPTED class_index range"
                        % (detail["max_records"], detail["selector_span"], detail["selector"]),
        "audit_retention_days": "retention.ini [class.%d].retention_days" % config["active_class"],
        "burst_ceiling": "ingress_rate_limit_qps(%d)*window_seconds(%d)"
                         % (config["ingress_rate_limit_qps"], detail["window_seconds"]),
        "effective_scope_count": "count((base union overlay) minus deny)",
        "hardening_baseline": "quantize_floor(clamp(fold(%d),%d,%d),%d)"
                              % (detail["fold_score"], detail["hardening_floor"],
                                 detail["hardening_ceil"], HARDENING_GRANULARITY),
        "ingress_rate_limit_qps": "quantize_floor(rhe(qps(%d)*permille(%d),1000),%d)"
                                  % (detail["ingress_qps"], detail["burst_permille"],
                                     detail["rate_granularity"]),
        "max_concurrent_sessions": "precedence(default,override,pinned) capped by abs_ceil",
        "nonce_window_ms": "precedence(default,override,pinned) floored by nonce floor",
        "privilege_drop_uid": "max(min(uid of effective scopes),uid_floor(%d))" % detail["uid_floor"],
        "quorum_threshold": "clamp(rhe(healthy(%d)*permille(%d),1000),1,%d)"
                            % (detail["healthy_voters"], detail["quorum_permille"],
                               detail["voters"]),
        "retry_backoff_base_ms": "quantize_floor(rhe(timeout_ms(%d),retry_limit(%d)+1),%d)"
                                 % (detail["timeout_ms"], detail["retry_limit"],
                                    detail["retry_step"]),
        "risk_index": "rhe((%d-hardening_baseline)*severity(%d),%d)"
                      % (detail["risk_complement"], detail["severity_permille"],
                         detail["risk_divisor"]),
        "seccomp_allowed_count": "count(allow minus deny) over ADOPTED rows",
        "session_ttl_seconds": "precedence(default,override,pinned)",
        "tls_floor_score": "max score of ADOPTED enabled suites",
    }
    xml = ['<?xml version="1.0" encoding="UTF-8"?>',
           '<derivation class="%d">' % config["active_class"]]
    for key in sorted(config):
        xml.append('  <field name="%s" value="%s" formula="%s"/>'
                   % (key, escape_xml(str(config[key])),
                      escape_xml(formulas.get(key, "fixed contract string"))))
    xml.append("</derivation>")
    write_text(out / "derivation_audit.xml", "\n".join(xml) + "\n")

    census = []
    for path in sorted(DATA.iterdir()):
        if not path.is_file():
            continue
        raw = path.read_bytes()
        text = raw.decode("utf-8", errors="replace")
        census.append(json.dumps({
            "adopted_mentions": text.count(ADOPTED),
            "bytes": len(raw),
            "file": path.name,
            "lines": len([ln for ln in text.split("\n") if ln.strip()]),
            "sha256": hashlib.sha256(raw).hexdigest(),
        }, sort_keys=True))
    write_text(out / "input_census.ndjson", "\n".join(census) + "\n")

    rows = [(MAIN_PROFILE, config["risk_index"])]
    for name, path in (("canary", args.canary), ("enforce", args.enforce)):
        rows.append((name, load_json(path)["risk_index"]))
    rows.sort(key=lambda r: (r[1], r[0]))
    write_text(out / "class_ordering.tsv",
               "profile\trisk_index\n" + "".join("%s\t%d\n" % r for r in rows))
    print("audit")


def cmd_converge(args):
    config = load_json(args.config)
    on_disk = json.dumps(config, sort_keys=True)
    digests = []
    payloads = []
    for _ in range(int(args.iterations)):
        derived, detail = derive_all()
        profiles = {n: build_profile(derived, detail, n) for n in adopted_profiles()}
        payload = json.dumps({"config": derived, "profiles": profiles}, sort_keys=True)
        payloads.append(json.dumps(derived, sort_keys=True))
        digests.append(hashlib.sha256(payload.encode("utf-8")).hexdigest())
    matches = payloads[0] == on_disk
    stable = len(set(digests)) == 1 and matches
    write_text(Path(args.out), "\n".join([
        "iterations: %d" % len(digests),
        "derivation_digest: %s" % digests[0],
        "matches_on_disk_config: %s" % ("true" if matches else "false"),
        "stable: %s" % ("true" if stable else "false"),
        "active_class: %d" % config["active_class"],
    ]) + "\n")
    if not stable:
        raise SystemExit("derivation is not convergent")
    print("converged")


def cmd_package(args):
    src = Path(args.src)
    names = sorted(p.name for p in src.iterdir() if p.is_file())
    with zipfile.ZipFile(args.out, "w", zipfile.ZIP_DEFLATED) as zf:
        for name in names:
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            zf.writestr(info, (src / name).read_bytes())
    print("packaged")


def cmd_validate_artifacts(args):
    rules = load_json(args.rules)
    schema = load_json(args.schema)
    config = load_json(args.config)
    out = Path(args.outdir)
    self_name = Path(args.out).name
    artifacts = {}
    oversize = []
    for name in sorted(rules["required_artifacts"]):
        path = out / name
        # this command creates its own report as its final act
        present = path.exists() or name == self_name
        artifacts[name] = {"present": present}
        if path.exists() and path.stat().st_size > rules["max_artifact_bytes"]:
            oversize.append(name)
    missing_keys = [k for k in required_keys(schema) if k not in config]
    forbidden = sorted(k for k in rules["forbidden_keys"] if k in config)
    non_scalar = sorted(k for k, v in config.items() if isinstance(v, (dict, list)))
    floats = sorted(k for k, v in config.items() if isinstance(v, float))
    report = {
        "artifacts": artifacts,
        "config_flat": not non_scalar,
        "float_keys": floats,
        "forbidden_keys_present": forbidden,
        "missing_artifacts": sorted(n for n, m in artifacts.items() if not m["present"]),
        "missing_keys": missing_keys,
        "non_scalar_keys": non_scalar,
        "ok": not (missing_keys or forbidden or non_scalar or floats or oversize
                   or any(not m["present"] for m in artifacts.values())),
        "oversize_artifacts": oversize,
        "profiles_checked": rules["profiles"],
        "size_limit_bytes": rules["max_artifact_bytes"],
        "trailer": config["trailer"],
    }
    write_json(args.out, report)
    print("validated-artifacts")


def cmd_summarize(args):
    config = load_json(args.config)
    _, detail = derive_all()
    out = Path(args.outdir)
    profiles = {}
    for name in adopted_profiles():
        profile = load_json(out / ("profile_%s.json" % name))
        profiles[name] = {
            "quorum_threshold": profile["quorum_threshold"],
            "risk_index": profile["risk_index"],
            "session_ttl_seconds": profile["session_ttl_seconds"],
        }
    write_json(args.out, {
        "active_class": config["active_class"],
        "config": config,
        "effective_scopes": detail["effective_scopes"],
        "healthy_voters": detail["healthy_voters"],
        "ok": True,
        "profiles": profiles,
        "seccomp_allowed": detail["effective_syscalls"],
        "trailer": config["trailer"],
    })
    print("summarized")


def cmd_manifest(args):
    out = Path(args.outdir)
    rules = load_json(args.rules)
    # the manifest itself and the validation report are written afterwards, so
    # they cannot be digested here without making the manifest self-referential
    excluded = sorted({Path(args.out).name, "validation_report.json"})
    artifacts = {}
    for name in sorted(rules["required_artifacts"]):
        if name in excluded:
            continue
        path = out / name
        artifacts[name] = {"bytes": path.stat().st_size, "sha256": sha256_file(path)}
    write_json(args.out, {
        "artifacts": artifacts,
        "deterministic": True,
        "excluded": excluded,
        "inputs": {p.name: sha256_file(p) for p in sorted(DATA.iterdir()) if p.is_file()},
        "tool": {p.name: sha256_file(p) for p in sorted(Path(args.src).iterdir()) if p.is_file()},
    })
    print("manifest")


def main():
    parser = argparse.ArgumentParser(prog="task-ctl")
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("derive")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_derive)

    p = sub.add_parser("profile")
    p.add_argument("--name", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_profile)

    p = sub.add_parser("profile-delta")
    p.add_argument("--config", required=True)
    p.add_argument("--canary", required=True)
    p.add_argument("--enforce", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_profile_delta)

    p = sub.add_parser("init")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("export-report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest", required=True)
    p.add_argument("--commands", required=True)
    p.set_defaults(func=cmd_report)

    p = sub.add_parser("emit-sidecars")
    p.add_argument("--config", required=True)
    p.add_argument("--outdir", required=True)
    p.set_defaults(func=cmd_sidecars)

    p = sub.add_parser("emit-audit")
    p.add_argument("--config", required=True)
    p.add_argument("--canary", required=True)
    p.add_argument("--enforce", required=True)
    p.add_argument("--outdir", required=True)
    p.set_defaults(func=cmd_audit)

    p = sub.add_parser("converge")
    p.add_argument("--config", required=True)
    p.add_argument("--iterations", default="2")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_converge)

    p = sub.add_parser("package")
    p.add_argument("--src", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_package)

    p = sub.add_parser("validate-artifacts")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--rules", required=True)
    p.add_argument("--outdir", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_validate_artifacts)

    p = sub.add_parser("summarize")
    p.add_argument("--config", required=True)
    p.add_argument("--outdir", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_summarize)

    p = sub.add_parser("manifest")
    p.add_argument("--src", required=True)
    p.add_argument("--rules", required=True)
    p.add_argument("--outdir", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_manifest)

    args = parser.parse_args()
    if not getattr(args, "command", None):
        parser.print_help()
        return
    args.func(args)


if __name__ == "__main__":
    main()
