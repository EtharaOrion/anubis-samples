# task-ctl

An offline container-image admission-control hardening compiler for a
server-side admission broker. It reads interacting numeric policy layers from
`/app/data`, selects the active enforcement class, and derives one flat hardened
admission configuration plus two deployment profiles (canary and enforce).

## Commands

- `init --schema <schema> --out <config>`: seed fixed contract strings.
- `derive --out <config>`: derive every graded scalar for the active class and
  merge it into the configuration.
- `set --config <config> --key <key> --value <value>`: set one scalar key with
  correct case and type coercion; reject any non-scalar value.
- `validate --schema <schema> --config <config>`: confirm every required key is
  present and the configuration is flat; print `ok`.
- `profile --name <canary|enforce> --config <config> --out <profile>`: apply the
  documented profile deltas to the derived configuration.
- `profile-delta --config <config> --canary <p> --enforce <p> --out <report>`:
  signed per-key deltas of both profiles versus the main configuration.
- `emit-sidecars --config <config> --outdir <dir>`: derivation sidecars.
- `emit-audit --config <config> --canary <p> --enforce <p> --outdir <dir>`:
  derivation audit, input census, class ordering.
- `converge --config <config> --iterations <n> --out <txt>`: re-derive and prove
  the derivation is a fixed point of the on-disk configuration.
- `package --src <dir> --out <zip>`: deterministic repackaging of the tool.
- `summarize`, `validate-artifacts`, `manifest`: coverage and provenance.
- `export-report --config <config> --out <report> --digest <sha256> --commands <json>`:
  emit a truthful command transcript.

## Derivation contract

- The active enforcement class is the ADOPTED `class_index` selector range that
  contains `max_records mod span`, where `span` is the width of the ADOPTED
  selector space.
- `ingress_rate_limit_qps = quantize_floor(rhe(qps * burst_permille, 1000), gran)`
  and `burst_ceiling = ingress_rate_limit_qps * window_seconds`.
- Effective scopes are `(base | overlay) - deny` for the active class only;
  `privilege_drop_uid = max(min(uid of effective scopes), uid_floor)`.
- The hardening fold walks the class controls in ascending `order`; an adopted
  control with `carry_flag == 1` carries half of its weight (round-half-even)
  into the next adopted control. The fold is clamped to the class bounds and
  quantized down to a multiple of 5.
- `risk_index = rhe((100 - hardening_baseline) * severity_permille, 1000)`.
- `quorum_threshold = clamp(rhe(healthy_voters * quorum_permille, 1000), 1, voters)`.
- Session TTL, nonce window and concurrent-session cap resolve through
  defaults -> class overrides -> pinned overrides (pinned only when `pinned`).
- `retry_backoff_base_ms = quantize_floor(rhe(timeout_ms, retry_limit + 1), step)`.

## Contract notes

- Every value is derived with exact integer arithmetic (round-half-even); no
  floating-point value may reach a graded key.
- The configuration is flat: keys map directly to integer or string scalars.
- The required key set is authoritative in `schema.json` and mirrored by the
  field registry in the policy layers.
- Only rows whose status is `ADOPTED` for the active enforcement class bind; rows
  labelled `SUPERSEDED`, `DRAFT`, `SHADOW`, or `REVOKED` are context decoys.
