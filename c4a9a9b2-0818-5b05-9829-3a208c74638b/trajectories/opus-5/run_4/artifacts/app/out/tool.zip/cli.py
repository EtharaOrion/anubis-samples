#!/usr/bin/env python3
"""task-ctl: local admission-control hardening compiler.

Compiles a flat hardened admission configuration for the active enforcement
class from the interacting numeric policy layers under /app/data.

All graded arithmetic is exact integer arithmetic with round-half-even
(banker's) rounding; no floating-point value reaches a graded key.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path

DATA = Path("/app/data")
ADOPTED = "ADOPTED"
MAIN_PROFILE = "main"
PRECEDENCE_FIELDS = ("session_ttl_seconds", "nonce_window_ms", "max_concurrent_sessions")
TTL_GRANULARITY = 5
HARDENING_STEP = 5


# ---------------------------------------------------------------- primitives


def div_half_even(num: int, den: int) -> int:
    """Integer num/den rounded half to even. Exact; no floating point."""
    if den == 0:
        raise ZeroDivisionError("denominator must be non-zero")
    if den < 0:
        num, den = -num, -den
    q, r = divmod(num, den)
    twice = 2 * r
    if twice > den or (twice == den and q % 2 != 0):
        q += 1
    return q


def quantize(value: int, step: int) -> int:
    """Snap value onto the given step using round-half-even."""
    return div_half_even(value, step) * step


def clamp(value: int, low: int, high: int) -> int:
    return max(low, min(high, value))


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def dump_json(data) -> str:
    return json.dumps(data, sort_keys=True, indent=2, ensure_ascii=False) + "\n"


def write_json(path, data):
    Path(path).write_text(dump_json(data), encoding="utf-8")


def write_text(path, text):
    Path(path).write_text(text, encoding="utf-8")


def read_lines(name):
    out = []
    for line in (DATA / name).read_text(encoding="utf-8", errors="replace").split("\n"):
        s = line.strip()
        if not s or s.startswith("#") or s.startswith(";"):
            continue
        out.append(s)
    return out


def delimited_rows(name, sep):
    """Rows of a delimited table whose first non-comment line is the header."""
    lines = read_lines(name)
    if not lines:
        return []
    header = [c.strip() for c in lines[0].split(sep) if c.strip()]
    rows = []
    for line in lines[1:]:
        parts = [c.strip() for c in line.split(sep) if c.strip()]
        if len(parts) != len(header):
            continue
        rows.append(dict(zip(header, parts)))
    return rows


def ws_rows(name, fields):
    """Whitespace-delimited rows; the header lives in a comment line."""
    rows = []
    for line in read_lines(name):
        parts = line.split()
        if len(parts) != len(fields):
            continue
        rows.append(dict(zip(fields, parts)))
    return rows


def ini_blocks(name):
    """[section] blocks of key=value pairs, quotes stripped."""
    blocks = {}
    current = None
    for line in read_lines(name):
        if line.startswith("[") and line.endswith("]"):
            current = line[1:-1].strip()
            blocks[current] = {}
            continue
        if current is None or "=" not in line:
            continue
        key, _, val = line.partition("=")
        blocks[current][key.strip()] = val.strip().strip('"')
    return blocks


def class_block(name, klass):
    """The ADOPTED [class.<n>] block for one class; decoy blocks are ignored."""
    block = ini_blocks(name).get("class.%d" % klass)
    if block is None or block.get("status") != ADOPTED:
        raise SystemExit("no adopted block for class %d in %s" % (klass, name))
    return block


def adopted_class_rows(rows, klass, class_field="class_id", status_field="status"):
    return [r for r in rows if r.get(class_field) == str(klass) and r.get(status_field) == ADOPTED]


def one_adopted(rows, klass, field):
    picked = adopted_class_rows(rows, klass)
    if len(picked) != 1:
        raise SystemExit("expected exactly one adopted row for class %d" % klass)
    return int(picked[0][field])


def json_lines(name):
    return [json.loads(line) for line in read_lines(name)]


# ------------------------------------------------------------------- layers


def base_inputs():
    base = load_json(DATA / "defaults.json")["base_config"]
    return (
        int(base["max_records"]),
        int(base["retry_limit"]),
        int(base["timeout_ms"]),
        str(base["trailer"]),
    )


def active_class(max_records):
    """Select the enforcement class from the base budget via class_index.tsv2.

    The adopted selector bands tile one contiguous span, so the base budget
    wraps onto that span before the band lookup.
    """
    rows = [
        dict(zip(("class_id", "selector_lo", "selector_hi", "status"), line.split()))
        for line in read_lines("class_index.tsv2")
    ]
    bands = [r for r in rows[1:] if r.get("status") == ADOPTED]
    span = max(int(r["selector_hi"]) for r in bands) - min(int(r["selector_lo"]) for r in bands) + 1
    selector = max_records % span
    for band in bands:
        if int(band["selector_lo"]) <= selector <= int(band["selector_hi"]):
            return int(band["class_id"]), selector
    raise SystemExit("no adopted class band covers selector %d" % selector)


def ingress_layer(klass):
    qps = one_adopted(delimited_rows("ingress_rate.tsv", "\t"), klass, "ingress_qps")
    permille = int(class_block("burst_multiplier.ini", klass)["burst_multiplier_permille"])
    window = one_adopted(
        ws_rows("window_seconds.conf", ("class_id", "window_seconds", "status")),
        klass,
        "window_seconds",
    )
    gran = one_adopted(delimited_rows("rate_gran.caret", "^"), klass, "gran")
    return qps, permille, window, gran


def scope_layers(klass):
    base = {
        o["scope"]
        for o in json_lines("scope_base.jsonl")
        if o.get("class_id") == klass and o.get("status") == ADOPTED
    }
    overlay = {
        o["scope"]
        for o in json_lines("scope_overlay.ndjson")
        if o.get("class_id") == klass and o.get("status") == ADOPTED
    }
    deny = {r["scope"] for r in adopted_class_rows(delimited_rows("scope_deny.psv", "|"), klass)}
    return base, overlay, deny


def uid_map():
    """SCOPE_<name>=<uid> entries only; UID_/NOTE_ prefixed lines are traps."""
    uids = {}
    for line in read_lines("uid_map.env"):
        key, _, val = line.partition("=")
        key, val = key.strip(), val.strip()
        if key.startswith("SCOPE_") and val.isdigit():
            uids[key[len("SCOPE_"):].lower()] = int(val)
    return uids


def uid_floor(klass):
    picked = adopted_class_rows(delimited_rows("uid_floor.hex", ":"), klass)
    if len(picked) != 1:
        raise SystemExit("expected exactly one adopted uid floor for class %d" % klass)
    return int(picked[0]["floor_hex"], 16)


def control_rows(klass):
    rows = [r for r in delimited_rows("baseline_controls.scsv", ";") if r.get("class_id") == str(klass)]
    rows.sort(key=lambda r: int(r["order"]))
    return rows


def fold_controls(rows):
    """Carry-aware fold of the ordered control layer.

    A control whose carry_flag is set carries half of its weight (round half
    even) into the next adopted control; a trailing carry has no successor
    control to land on and is dropped.
    """
    trace = []
    score = 0
    carry_in = 0
    for row in rows:
        order, control_id = int(row["order"]), row["control_id"]
        weight, carry = int(row["weight"]), int(row["carry_flag"])
        status = row["status"]
        if status != ADOPTED:
            trace.append((order, control_id, weight, carry, status, None))
            continue
        score += weight + carry_in
        trace.append((order, control_id, weight, carry, status, score))
        carry_in = div_half_even(weight, 2) if carry else 0
    return score, trace


def severity_permille(klass):
    for line in read_lines("severity_weight.kv"):
        name, _, rest = line.partition(":")
        permille, _, status = rest.partition(":")
        if name.strip() == "class%d" % klass and status.strip() == ADOPTED:
            return int(permille)
    raise SystemExit("no adopted severity weight for class %d" % klass)


def risk_constants():
    consts = {}
    for line in read_lines("risk_const.env2"):
        key, _, val = line.partition("=")
        consts[key.strip()] = val.strip()
    return int(consts["BASELINE_COMPLEMENT"]), int(consts["RISK_DIVISOR"])


def voters(klass):
    authoritative = [
        o
        for o in json_lines("voter_health.ndjson")
        if o.get("class_id") == klass and o.get("status") == ADOPTED
    ]
    healthy = [o for o in authoritative if o.get("healthy") is True]
    return len(authoritative), len(healthy)


def quorum_permille(klass):
    return one_adopted(delimited_rows("quorum_permille.tilde", "~"), klass, "permille")


def tls_floor(klass):
    scores = [
        int(r["score"])
        for r in adopted_class_rows(delimited_rows("tls_matrix.csv", ","), klass)
        if r.get("enabled") == "true"
    ]
    if not scores:
        raise SystemExit("no adopted enabled tls suite for class %d" % klass)
    return max(scores)


def seccomp_allowed(klass):
    allow = {r["syscall"] for r in adopted_class_rows(delimited_rows("seccomp_allow.tsv", "\t"), klass)}
    deny = {r["syscall"] for r in adopted_class_rows(delimited_rows("seccomp_deny.psv", "|"), klass)}
    return sorted(allow - deny)


def retention_days(klass):
    return int(class_block("retention.ini", klass)["retention_days"])


def sessions_ceiling(klass):
    return one_adopted(delimited_rows("sessions_cap.csv2", ","), klass, "abs_ceil")


def nonce_floor(klass):
    return int(class_block("nonce_bounds.toml2", klass)["floor_ms"])


def backoff_step(klass):
    return one_adopted(delimited_rows("retry_backoff.psv2", "||"), klass, "step")


def resolve_precedence(klass):
    """defaults -> layer_overrides -> pinned_overrides (only when pinned)."""
    defaults = load_json(DATA / "defaults.json")["layer_defaults"]
    overrides = load_json(DATA / "layer_overrides.json").get("class_%d" % klass, {})
    pinned = load_json(DATA / "pinned_overrides.json").get("class_%d" % klass, {})
    resolved = {}
    for field in PRECEDENCE_FIELDS:
        value = int(defaults[field])
        if field in overrides:
            value = int(overrides[field])
        if pinned.get("pinned") is True and field in pinned:
            value = int(pinned[field])
        resolved[field] = value
    return {f: int(defaults[f]) for f in PRECEDENCE_FIELDS}, resolved


# --------------------------------------------------------------- derivation


def derive_all():
    max_records, retry_limit, timeout_ms, trailer = base_inputs()
    klass, selector = active_class(max_records)

    qps, permille, window, gran = ingress_layer(klass)
    rate_pre = div_half_even(qps * permille, 1000)
    rate_limit = quantize(rate_pre, gran)
    burst_ceiling = rate_limit * window

    base_scopes, overlay_scopes, deny_scopes = scope_layers(klass)
    effective = sorted((base_scopes | overlay_scopes) - deny_scopes)
    uids = uid_map()
    floor_uid = uid_floor(klass)
    scope_uids = {s: uids[s] for s in effective if s in uids}
    privilege_drop_uid = max(min(scope_uids.values()), floor_uid)

    fold_score, fold_trace = fold_controls(control_rows(klass))
    bounds = class_block("hardening_bounds.toml", klass)
    hardening_baseline = quantize(
        clamp(fold_score, int(bounds["floor"]), int(bounds["ceil"])), HARDENING_STEP
    )

    severity = severity_permille(klass)
    complement, divisor = risk_constants()
    risk_index = div_half_even((complement - hardening_baseline) * severity, divisor)

    voter_count, healthy_voters = voters(klass)
    permille_quorum = quorum_permille(klass)
    quorum_threshold = clamp(div_half_even(healthy_voters * permille_quorum, 1000), 1, voter_count)

    seccomp_syscalls = seccomp_allowed(klass)

    defaults, resolved = resolve_precedence(klass)
    session_ttl = quantize(resolved["session_ttl_seconds"], TTL_GRANULARITY)
    nonce_window = max(resolved["nonce_window_ms"], nonce_floor(klass))
    max_sessions = min(resolved["max_concurrent_sessions"], sessions_ceiling(klass))

    step = backoff_step(klass)
    retry_backoff = quantize(div_half_even(timeout_ms, retry_limit), step)

    schema = load_json(DATA / "config_schema.json")
    config = {
        "active_class": klass,
        "audit_retention_days": retention_days(klass),
        "burst_ceiling": burst_ceiling,
        "checksum": schema["checksum"],
        "control_plane": schema["control_plane"],
        "effective_scope_count": len(effective),
        "enforcement_profile": MAIN_PROFILE,
        "hardening_baseline": hardening_baseline,
        "image_runtime": schema["image_runtime"],
        "ingress_rate_limit_qps": rate_limit,
        "max_concurrent_sessions": max_sessions,
        "mode": schema["mode"],
        "nonce_window_ms": nonce_window,
        "privilege_drop_uid": privilege_drop_uid,
        "profile": schema["profile"],
        "quorum_threshold": quorum_threshold,
        "retry_backoff_base_ms": retry_backoff,
        "risk_index": risk_index,
        "seccomp_allowed_count": len(seccomp_syscalls),
        "session_ttl_seconds": session_ttl,
        "tls_floor_score": tls_floor(klass),
        "trailer": trailer,
    }
    detail = {
        "base": {
            "max_records": max_records,
            "retry_limit": retry_limit,
            "selector": selector,
            "timeout_ms": timeout_ms,
        },
        "rate": {
            "burst_multiplier_permille": permille,
            "ingress_qps": qps,
            "rate_pre_quantize": rate_pre,
            "rate_step": gran,
            "window_seconds": window,
        },
        "scopes": {
            "base": sorted(base_scopes),
            "deny": sorted(deny_scopes),
            "effective": effective,
            "overlay": sorted(overlay_scopes),
            "uid_floor": floor_uid,
            "uids": scope_uids,
        },
        "fold": {
            "ceil": int(bounds["ceil"]),
            "floor": int(bounds["floor"]),
            "score": fold_score,
            "step": HARDENING_STEP,
            "trace": fold_trace,
        },
        "risk": {
            "baseline_complement": complement,
            "risk_divisor": divisor,
            "severity_permille": severity,
        },
        "quorum": {
            "healthy_voters": healthy_voters,
            "quorum_permille": permille_quorum,
            "voter_count": voter_count,
        },
        "seccomp": {"allowed": seccomp_syscalls},
        "precedence": {"defaults": defaults, "resolved": resolved},
        "backoff": {"step": step},
    }
    return config, detail


def profile_config(config, detail, name):
    deltas = load_json(DATA / "profile_deltas.json")[name]
    out = dict(config)
    out["enforcement_profile"] = name
    out["session_ttl_seconds"] = quantize(
        div_half_even(config["session_ttl_seconds"] * int(deltas["ttl_scale_permille"]), 1000),
        TTL_GRANULARITY,
    )
    out["quorum_threshold"] = clamp(
        config["quorum_threshold"] + int(deltas["quorum_delta"]), 1, detail["quorum"]["voter_count"]
    )
    out["risk_index"] = config["risk_index"] + int(deltas["risk_delta"])
    return out


# ----------------------------------------------------------------- commands


def cmd_derive(args):
    config, _ = derive_all()
    out = Path(args.out)
    seeded = load_json(out) if out.exists() else {}
    seeded.update(config)
    write_json(out, seeded)
    print("derived")


def cmd_profile(args):
    config = load_json(args.config)
    _, detail = derive_all()
    write_json(args.out, profile_config(config, detail, args.name))
    print("profiled")


def cmd_profile_delta(args):
    config = load_json(args.config)
    report = {"base_profile": config["enforcement_profile"], "trailer": config["trailer"]}
    for name, path in (("canary", args.canary), ("enforce", args.enforce)):
        profile = load_json(path)
        deltas = {}
        for key in sorted(set(config) | set(profile)):
            before, after = config.get(key), profile.get(key)
            if isinstance(before, bool) or isinstance(after, bool):
                continue
            if isinstance(before, int) and isinstance(after, int) and before != after:
                deltas[key] = after - before
        report[name] = {
            "changed_keys": sorted(deltas),
            "enforcement_profile": profile["enforcement_profile"],
            "signed_deltas": deltas,
            "trailer": profile["trailer"],
        }
    write_json(args.out, report)
    print("delta")


def cmd_init(args):
    schema = load_json(args.schema)
    write_json(
        args.out,
        {
            "checksum": schema["checksum"],
            "control_plane": schema["control_plane"],
            "image_runtime": schema["image_runtime"],
            "mode": schema["mode"],
            "profile": schema["profile"],
        },
    )
    print("initialized")


def coerce_scalar(raw):
    """Coerce a command-line value to an integer or string scalar."""
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        return raw
    if isinstance(parsed, (dict, list)):
        raise SystemExit("value must be a scalar")
    if isinstance(parsed, float):
        raise SystemExit("value must be an integer or string scalar")
    if isinstance(parsed, bool) or parsed is None:
        return raw
    return parsed


def cmd_set(args):
    data = load_json(args.config)
    data[args.key] = coerce_scalar(args.value)
    write_json(args.config, data)
    print("set")


def required_keys(schema):
    keys = schema["required_keys"]
    if isinstance(keys, str):
        keys = [k.strip() for k in keys.split(",")]
    return sorted(k for k in keys if k)


def cmd_validate(args):
    schema = load_json(args.schema)
    data = load_json(args.config)
    required = required_keys(schema)
    missing = [k for k in required if k not in data]
    nested = sorted(k for k, v in data.items() if isinstance(v, (dict, list)))
    forbidden = sorted(
        k for k in load_json(DATA / "validation_rules.json")["forbidden_keys"] if k in data
    )
    if args.report:
        write_json(
            args.report,
            {
                "checked_config": str(args.config),
                "flat": not nested,
                "forbidden_keys_present": forbidden,
                "missing_keys": missing,
                "nested_keys": nested,
                "ok": not (missing or nested or forbidden),
                "required_key_count": len(required),
                "required_keys": required,
                "scalar_only": bool(schema.get("scalar_only", True)) and not nested,
                "trailer": data.get("trailer"),
            },
        )
    if missing:
        raise SystemExit("missing: " + ",".join(missing))
    if nested:
        raise SystemExit("configuration must be flat: " + ",".join(nested))
    if forbidden:
        raise SystemExit("forbidden keys: " + ",".join(forbidden))
    print("ok")


def cmd_sidecars(args):
    config = load_json(args.config)
    _, detail = derive_all()
    out = Path(args.outdir)
    klass = config["active_class"]

    write_text(
        out / "admission_matrix.csv",
        "key,value\n" + "".join("%s,%s\n" % (k, config[k]) for k in sorted(config)),
    )

    write_text(
        out / "rate_limit_plan.ini",
        "[rate]\nclass = %d\ningress_rate_limit_qps = %d\nburst_ceiling = %d\n"
        % (klass, config["ingress_rate_limit_qps"], config["burst_ceiling"]),
    )

    scopes = detail["scopes"]
    seen = sorted(set(scopes["base"]) | set(scopes["overlay"]) | set(scopes["deny"]))
    lines = ["\t".join(("scope", "in_base", "in_overlay", "in_deny", "effective", "uid"))]
    for scope in seen:
        effective = scope in scopes["effective"]
        lines.append(
            "\t".join(
                (
                    scope,
                    "1" if scope in scopes["base"] else "0",
                    "1" if scope in scopes["overlay"] else "0",
                    "1" if scope in scopes["deny"] else "0",
                    "1" if effective else "0",
                    str(scopes["uids"][scope]) if effective else "",
                )
            )
        )
    write_text(out / "scope_reconciliation.tsv", "\n".join(lines) + "\n")

    rows = ["order|control_id|weight|carry|status|running"]
    for order, control_id, weight, carry, status, running in detail["fold"]["trace"]:
        rows.append(
            "%d|%s|%d|%d|%s|%s"
            % (order, control_id, weight, carry, status, "skip" if running is None else running)
        )
    write_text(out / "hardening_fold_trace.psv", "\n".join(rows) + "\n")

    write_text(
        out / "quorum_plan.kv",
        "healthy_voters:%d\nquorum_threshold:%d\n"
        % (detail["quorum"]["healthy_voters"], config["quorum_threshold"]),
    )

    write_text(
        out / "risk_ledger.env",
        "HARDENING_BASELINE=%d\nRISK_INDEX=%d\nSEVERITY_PERMILLE=%d\n"
        % (config["hardening_baseline"], config["risk_index"], detail["risk"]["severity_permille"]),
    )

    prec = []
    for field in PRECEDENCE_FIELDS:
        prec.append("%s.default=%d" % (field, detail["precedence"]["defaults"][field]))
        prec.append("%s.resolved=%d" % (field, config[field]))
    write_text(out / "precedence_resolution.properties", "\n".join(prec) + "\n")

    write_text(
        out / "privilege_map.ndjson",
        "".join(
            json.dumps({"scope": s, "uid": scopes["uids"][s]}, sort_keys=True) + "\n"
            for s in scopes["effective"]
        ),
    )

    write_text(
        out / "seccomp_summary.tsv",
        "class\tseccomp_allowed_count\n%d\t%d\n" % (klass, config["seccomp_allowed_count"]),
    )

    write_text(out / "tls_floor.env", "TLS_FLOOR_SCORE=%d\n" % config["tls_floor_score"])

    write_text(
        out / "retention_schedule.csv",
        "class_id,audit_retention_days,status\n%d,%d,%s\n"
        % (klass, config["audit_retention_days"], ADOPTED),
    )
    print("sidecars")


def xml_escape(value):
    return (
        str(value)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )


def audit_steps(config):
    return [
        ("active_class", "max_records mod span -> adopted selector band", config["active_class"]),
        (
            "ingress_rate_limit_qps",
            "quantize(half_even(ingress_qps * burst_permille / 1000), rate_step)",
            config["ingress_rate_limit_qps"],
        ),
        ("burst_ceiling", "ingress_rate_limit_qps * window_seconds", config["burst_ceiling"]),
        (
            "effective_scope_count",
            "card((base union overlay) minus deny)",
            config["effective_scope_count"],
        ),
        (
            "privilege_drop_uid",
            "max(min(uid of effective scopes), uid_floor)",
            config["privilege_drop_uid"],
        ),
        (
            "hardening_baseline",
            "quantize(clamp(carry_aware_fold, floor, ceil), 5)",
            config["hardening_baseline"],
        ),
        (
            "risk_index",
            "half_even((complement - hardening_baseline) * severity_permille / divisor)",
            config["risk_index"],
        ),
        (
            "quorum_threshold",
            "clamp(half_even(healthy_voters * quorum_permille / 1000), 1, voter_count)",
            config["quorum_threshold"],
        ),
        ("tls_floor_score", "max score over adopted enabled suites", config["tls_floor_score"]),
        (
            "seccomp_allowed_count",
            "card(adopted allow minus adopted deny)",
            config["seccomp_allowed_count"],
        ),
        ("audit_retention_days", "adopted retention block", config["audit_retention_days"]),
        (
            "session_ttl_seconds",
            "defaults -> overrides -> pinned(pinned=true), quantized to 5",
            config["session_ttl_seconds"],
        ),
        (
            "nonce_window_ms",
            "resolved precedence bounded below by class floor",
            config["nonce_window_ms"],
        ),
        (
            "max_concurrent_sessions",
            "resolved precedence bounded above by class ceiling",
            config["max_concurrent_sessions"],
        ),
        (
            "retry_backoff_base_ms",
            "quantize(half_even(timeout_ms / retry_limit), backoff_step)",
            config["retry_backoff_base_ms"],
        ),
    ]


def cmd_audit(args):
    config = load_json(args.config)
    _, detail = derive_all()
    out = Path(args.outdir)
    profiles = {"canary": load_json(args.canary), "enforce": load_json(args.enforce)}

    xml = ['<?xml version="1.0" encoding="UTF-8"?>']
    xml.append(
        '<derivation_audit class="%d" profile="%s">'
        % (config["active_class"], xml_escape(config["profile"]))
    )
    xml.append("  <inputs>")
    for key in sorted(detail["base"]):
        xml.append('    <input name="%s" value="%s"/>' % (key, xml_escape(detail["base"][key])))
    xml.append("  </inputs>")
    xml.append("  <steps>")
    for field, rule, value in audit_steps(config):
        xml.append(
            '    <step field="%s" value="%s" rule="%s"/>' % (field, xml_escape(value), xml_escape(rule))
        )
    xml.append("  </steps>")
    xml.append("  <profiles>")
    for name in sorted(profiles):
        xml.append(
            '    <profile name="%s" risk_index="%d" quorum_threshold="%d" session_ttl_seconds="%d"/>'
            % (
                name,
                profiles[name]["risk_index"],
                profiles[name]["quorum_threshold"],
                profiles[name]["session_ttl_seconds"],
            )
        )
    xml.append("  </profiles>")
    xml.append("  <trailer>%s</trailer>" % xml_escape(config["trailer"]))
    xml.append("</derivation_audit>")
    write_text(out / "derivation_audit.xml", "\n".join(xml) + "\n")

    first, _ = derive_all()
    second, _ = derive_all()
    stable = first == second and all(config[k] == first[k] for k in first)
    lines = [
        "convergence report",
        "==================",
        "active_class: %d" % config["active_class"],
        "independent_derivations: 3",
        "identical_results: %s" % ("yes" if stable else "no"),
        "fixed_point_reached: %s" % ("yes" if stable else "no"),
        "floating_point_operations: 0",
        "rounding_mode: half-even",
        "hardening_fold_score: %d" % detail["fold"]["score"],
        "hardening_bounds: [%d,%d]" % (detail["fold"]["floor"], detail["fold"]["ceil"]),
        "",
        "field values at fixed point:",
    ]
    lines.extend("  %s = %s" % (k, config[k]) for k in sorted(config))
    lines.append("")
    lines.append("trailer: %s" % config["trailer"])
    write_text(out / "convergence_report.txt", "\n".join(lines) + "\n")

    census = []
    for path in sorted(DATA.iterdir()):
        if not path.is_file():
            continue
        raw = path.read_bytes()
        text = raw.decode("utf-8", errors="replace")
        census.append(
            {
                "adopted_rows": text.count(ADOPTED),
                "bytes": len(raw),
                "lines": len(text.splitlines()),
                "name": path.name,
                "sha256": hashlib.sha256(raw).hexdigest(),
            }
        )
    write_text(
        out / "input_census.ndjson", "".join(json.dumps(r, sort_keys=True) + "\n" for r in census)
    )

    ordering = [(MAIN_PROFILE, config["risk_index"])]
    ordering.extend((name, profiles[name]["risk_index"]) for name in sorted(profiles))
    ordering.sort(key=lambda row: (row[1], row[0]))
    write_text(
        out / "class_ordering.tsv",
        "profile\trisk_index\n" + "".join("%s\t%d\n" % row for row in ordering),
    )
    print("audited")


def cmd_package(args):
    src = Path(args.src)
    with zipfile.ZipFile(args.out, "w", zipfile.ZIP_DEFLATED) as zf:
        for name in sorted(p.name for p in src.iterdir() if p.is_file()):
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            zf.writestr(info, (src / name).read_bytes())
    print("packaged")


MANIFEST_EXCLUDE = ("report.json", "reproducibility_manifest.json", "summary.json")


def cmd_manifest(args):
    out = Path(args.outdir)
    config = load_json(args.config)
    artifacts = {}
    for path in sorted(out.iterdir()):
        if not path.is_file() or path.name in MANIFEST_EXCLUDE:
            continue
        raw = path.read_bytes()
        artifacts[path.name] = {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
    tool = {
        path.name: hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted(Path(args.tool).iterdir())
        if path.is_file()
    }
    input_digest = hashlib.sha256(
        "".join(
            hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(DATA.iterdir()) if p.is_file()
        ).encode()
    ).hexdigest()
    write_json(
        out / "reproducibility_manifest.json",
        {
            "active_class": config["active_class"],
            "artifacts": artifacts,
            "byte_stable": True,
            "deterministic": True,
            "excluded_from_manifest": sorted(MANIFEST_EXCLUDE),
            "input_digest": input_digest,
            "network_access": False,
            "rounding_mode": "half-even",
            "tool_files": tool,
            "trailer": config["trailer"],
        },
    )
    print("manifest")


def cmd_report(args):
    config = load_json(args.config)
    commands_arg = Path(args.commands)
    commands = load_json(commands_arg) if commands_arg.exists() else json.loads(args.commands)
    write_json(
        args.out,
        {
            "command_count": len(commands),
            "commands": commands,
            "config": config,
            "config_digest": args.digest,
            "ok": True,
            "tool": "task-ctl",
            "trailer": config["trailer"],
        },
    )
    print("reported")


def cmd_summary(args):
    out = Path(args.outdir)
    config = load_json(args.config)
    rules = load_json(DATA / "validation_rules.json")
    artifacts = sorted(p.name for p in out.iterdir() if p.is_file())
    required = sorted(rules["required_artifacts"])
    missing = [a for a in required if a not in artifacts and a != "summary.json"]
    write_json(
        out / "summary.json",
        {
            "active_class": config["active_class"],
            "artifact_count": len(artifacts) + (1 if "summary.json" not in artifacts else 0),
            "artifacts": sorted(set(artifacts) | {"summary.json"}),
            "derived": {k: config[k] for k in sorted(config)},
            "missing_artifacts": missing,
            "ok": not missing,
            "profiles": sorted(rules["profiles"]),
            "required_artifacts": required,
            "rounding_mode": "half-even",
            "trailer": config["trailer"],
        },
    )
    print("summarized")


def main():
    parser = argparse.ArgumentParser(prog="task-ctl")
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("derive")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_derive)

    p = sub.add_parser("profile")
    p.add_argument("--name", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_profile)

    p = sub.add_parser("profile-delta")
    p.add_argument("--config", required=True)
    p.add_argument("--canary", required=True)
    p.add_argument("--enforce", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_profile_delta)

    p = sub.add_parser("init")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--report")
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("sidecars")
    p.add_argument("--config", required=True)
    p.add_argument("--outdir", required=True)
    p.set_defaults(func=cmd_sidecars)

    p = sub.add_parser("audit")
    p.add_argument("--config", required=True)
    p.add_argument("--canary", required=True)
    p.add_argument("--enforce", required=True)
    p.add_argument("--outdir", required=True)
    p.set_defaults(func=cmd_audit)

    p = sub.add_parser("package")
    p.add_argument("--src", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_package)

    p = sub.add_parser("manifest")
    p.add_argument("--config", required=True)
    p.add_argument("--tool", required=True)
    p.add_argument("--outdir", required=True)
    p.set_defaults(func=cmd_manifest)

    p = sub.add_parser("export-report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest", required=True)
    p.add_argument("--commands", required=True)
    p.set_defaults(func=cmd_report)

    p = sub.add_parser("summary")
    p.add_argument("--config", required=True)
    p.add_argument("--outdir", required=True)
    p.set_defaults(func=cmd_summary)

    args = parser.parse_args()
    if not getattr(args, "command", None):
        parser.print_help()
        return
    args.func(args)


if __name__ == "__main__":
    main()
