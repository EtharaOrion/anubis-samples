# task-ctl

An offline container-image admission-control hardening compiler for a
server-side admission broker. It reads interacting numeric policy layers from
`/app/data`, selects the active enforcement class, and derives one flat hardened
admission configuration plus two deployment profiles (canary and enforce).

## Commands

- `init --schema <schema> --out <config>`: seed fixed contract strings.
- `derive --out <config>`: derive every graded scalar for the active class.
- `set --config <config> --key <key> --value <value>`: set one scalar key with
  correct case and type coercion; reject any non-scalar value.
- `validate --schema <schema> --config <config> [--report <path>]`: confirm every
  required key is present and the configuration is flat; print `ok`.
- `profile --name <canary|enforce> --config <config> --out <profile>`: apply the
  documented per-profile deltas.
- `profile-delta --config <config> --canary <p> --enforce <p> --out <report>`:
  signed deltas versus the main configuration.
- `sidecars --config <config> --outdir <dir>`: derivation sidecars.
- `audit --config <config> --canary <p> --enforce <p> --outdir <dir>`: audit and
  provenance artifacts.
- `package --src <dir> --out <zip>`: repackage the tool deterministically.
- `manifest --config <config> --tool <dir> --outdir <dir>`: reproducibility manifest.
- `export-report --config <config> --out <report> --digest <sha256> --commands <json>`:
  emit a truthful command transcript.
- `summary --config <config> --outdir <dir>`: artifact coverage summary.

## Contract notes

- Every value is derived with exact integer arithmetic (round-half-even); no
  floating-point value may reach a graded key.
- The configuration is flat: keys map directly to integer or string scalars.
- The required key set is authoritative in `schema.json` and mirrored by the
  field registry in the policy layers.
- Only rows whose status is `ADOPTED` for the active enforcement class bind; rows
  labelled `SUPERSEDED`, `DRAFT`, `SHADOW`, or `REVOKED` are context decoys.

## Derivation contract

- Active class: the base budget wraps onto the contiguous span of adopted
  selector bands in `class_index.tsv2`, and the covering band names the class.
- Ingress: `rate = quantize(half_even(qps * burst_permille / 1000), rate_step)`
  and `burst_ceiling = rate * window_seconds`, from the resolved rate.
- Scopes: `(base union overlay) minus deny` for the active class; the
  privilege-drop uid is the smallest granted uid raised to the class uid floor.
- Hardening: the ordered adopted controls fold with a carry, where a control
  whose `carry_flag` is set carries half its weight (round half even) into the
  next adopted control; the fold is then clamped to the class bounds and
  quantized. `risk_index = half_even((100 - baseline) * severity_permille / 1000)`.
- Quorum: `clamp(half_even(healthy_voters * quorum_permille / 1000), 1, voters)`.
- Precedence: `layer_defaults` -> `layer_overrides` -> `pinned_overrides` (only
  where `pinned` is true), then per-class floors and ceilings.
- Backoff: `quantize(half_even(timeout_ms / retry_limit), backoff_step)`.
