#!/usr/bin/env python3
"""task-ctl: local admission-control hardening compiler.

Compiles one flat hardened admission configuration for the active enforcement
class from the interacting numeric policy layers under /app/data, plus the
canary/enforce deployment profiles and the derivation sidecars.

All graded arithmetic is exact integer arithmetic with round-half-even
rounding; no floating point value ever reaches a derived scalar.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import re
import zipfile
from pathlib import Path

DATA = Path("/app/data")
ADOPTED = "ADOPTED"
HARDENING_STEP = 5
TTL_GRAN = 5

# ---------------------------------------------------------------- primitives


def round_half_even(num: int, den: int) -> int:
    """Exact integer division of num/den rounded half to even."""
    if den == 0:
        raise ZeroDivisionError("denominator must be non-zero")
    if den < 0:
        num, den = -num, -den
    q, r = divmod(num, den)
    twice = 2 * r
    if twice > den or (twice == den and q % 2 != 0):
        q += 1
    return q


def quantize_floor(value: int, step: int) -> int:
    """Quantize down to the nearest multiple of step."""
    return (value // step) * step


def clamp(value: int, low: int, high: int) -> int:
    return max(low, min(high, value))


def load_json(path):
    return json.loads(Path(path).read_text())


def dumps(data) -> str:
    return json.dumps(data, sort_keys=True, indent=2) + "\n"


def write_json(path, data):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(dumps(data), encoding="utf-8")


def write_text(path, text):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(text, encoding="utf-8")


def sha256_bytes(blob: bytes) -> str:
    return hashlib.sha256(blob).hexdigest()


def sha256_file(path) -> str:
    return sha256_bytes(Path(path).read_bytes())


# ------------------------------------------------------------- layer readers


def read_lines(name):
    out = []
    for line in (DATA / name).read_text(encoding="utf-8", errors="replace").split("\n"):
        s = line.strip()
        if not s or s.startswith("#") or s.startswith(";"):
            continue
        out.append(line)
    return out


def delimited_rows(name, sep):
    lines = read_lines(name)
    if not lines:
        return []
    header = [c.strip() for c in lines[0].split(sep)]
    rows = []
    for line in lines[1:]:
        parts = [c.strip() for c in line.split(sep)]
        if len(parts) != len(header):
            continue
        rows.append(dict(zip(header, parts)))
    return rows


def adopted_rows(rows, klass, class_key="class_id", status_key="status"):
    return [r for r in rows if r.get(status_key) == ADOPTED and str(r.get(class_key)) == str(klass)]


def only(rows, what):
    if len(rows) != 1:
        raise SystemExit("expected exactly one authoritative row for %s, got %d" % (what, len(rows)))
    return rows[0]


def ini_sections(name):
    sections = {}
    current = None
    for line in read_lines(name):
        s = line.strip()
        if s.startswith("[") and s.endswith("]"):
            current = s[1:-1].strip()
            sections[current] = {}
            continue
        if current is None or "=" not in s:
            continue
        key, _, val = s.partition("=")
        sections[current][key.strip()] = val.strip().strip('"').strip("'")
    return sections


def ndjson(name):
    return [json.loads(line) for line in read_lines(name)]


def env_pairs(name):
    pairs = {}
    for line in read_lines(name):
        key, _, val = line.strip().partition("=")
        if key:
            pairs[key.strip()] = val.strip()
    return pairs


# --------------------------------------------------------------- derivation


def base_inputs():
    base = load_json(DATA / "defaults.json")["base_config"]
    return {
        "max_records": int(base["max_records"]),
        "retry_limit": int(base["retry_limit"]),
        "timeout_ms": int(base["timeout_ms"]),
        "trailer": str(base["trailer"]),
    }


def select_active_class(max_records):
    """Fold the base record budget onto the adopted class selector index."""
    rows = [r for r in delimited_rows("class_index.tsv2", "\t\t") if r.get("status") == ADOPTED]
    bins = sorted((int(r["selector_lo"]), int(r["selector_hi"]), int(r["class_id"])) for r in rows)
    span = max(hi for _, hi, _ in bins) + 1
    selector = max_records % span
    for lo, hi, klass in bins:
        if lo <= selector <= hi:
            return klass, selector, span
    raise SystemExit("no adopted class bin contains selector %d" % selector)


def ingress_layer(klass):
    row = only(adopted_rows(delimited_rows("ingress_rate.tsv", "\t"), klass), "ingress_rate")
    return int(row["ingress_qps"])


def burst_layer(klass):
    sec = ini_sections("burst_multiplier.ini").get("class.%d" % klass, {})
    if sec.get("status") != ADOPTED:
        raise SystemExit("no adopted burst block for class %d" % klass)
    return int(sec["burst_multiplier_permille"])


def window_layer(klass):
    hits = []
    for line in read_lines("window_seconds.conf"):
        parts = line.split()
        if len(parts) == 3 and parts[0] == str(klass) and parts[2] == ADOPTED:
            hits.append(int(parts[1]))
    if len(hits) != 1:
        raise SystemExit("expected one adopted window row, got %d" % len(hits))
    return hits[0]


def rate_step_layer(klass):
    row = only(adopted_rows(delimited_rows("rate_gran.caret", "^"), klass), "rate_gran")
    return int(row["gran"])


def scope_layers(klass):
    base = [o["scope"] for o in ndjson("scope_base.jsonl")
            if o.get("status") == ADOPTED and str(o.get("class_id")) == str(klass)]
    overlay = [o["scope"] for o in ndjson("scope_overlay.ndjson")
               if o.get("status") == ADOPTED and str(o.get("class_id")) == str(klass)]
    deny = [r["scope"] for r in adopted_rows(delimited_rows("scope_deny.psv", "|"), klass)]
    effective = sorted((set(base) | set(overlay)) - set(deny))
    return sorted(set(base)), sorted(set(overlay)), sorted(set(deny)), effective


def uid_map():
    uids = {}
    for key, val in env_pairs("uid_map.env").items():
        if key.startswith("SCOPE_") and val.isdigit():
            uids[key[len("SCOPE_"):].lower()] = int(val)
    return uids


def uid_floor_layer(klass):
    row = only(adopted_rows(delimited_rows("uid_floor.hex", ":"), klass), "uid_floor")
    return int(row["floor_hex"], 16)


def privilege_mirror(klass):
    for line in read_lines("privilege_bits.b64"):
        try:
            decoded = base64.b64decode(line.strip(), validate=True).decode("utf-8")
        except Exception:
            continue
        fields = dict(part.split("=", 1) for part in decoded.split(";") if "=" in part)
        if fields.get("status") == ADOPTED and fields.get("class") == str(klass):
            return int(fields["uid"])
    return None


def control_rows(klass):
    rows = [r for r in delimited_rows("baseline_controls.scsv", ";") if str(r.get("class_id")) == str(klass)]
    rows.sort(key=lambda r: int(r["order"]))
    return rows


def fold_controls(rows):
    """Carry-aware fold: a set carry flag adds one unit to the next adopted control."""
    score = 0
    carry = 0
    trace = []
    for r in rows:
        if r.get("status") != ADOPTED:
            trace.append((r, None))
            continue
        score += int(r["weight"]) + carry
        carry = 1 if int(r["carry_flag"]) else 0
        trace.append((r, score))
    return score, trace


def hardening_bounds(klass):
    sec = ini_sections("hardening_bounds.toml").get("class.%d" % klass, {})
    if sec.get("status") != ADOPTED:
        raise SystemExit("no adopted hardening bounds for class %d" % klass)
    return int(sec["floor"]), int(sec["ceil"])


def severity_layer(klass):
    hits = []
    for line in read_lines("severity_weight.kv"):
        parts = line.strip().split(":")
        if len(parts) == 3 and parts[0] == "class%d" % klass and parts[2] == ADOPTED:
            hits.append(int(parts[1]))
    if len(hits) != 1:
        raise SystemExit("expected one adopted severity row, got %d" % len(hits))
    return hits[0]


def risk_constants():
    env = env_pairs("risk_const.env2")
    return int(env["BASELINE_COMPLEMENT"]), int(env["RISK_DIVISOR"])


def voter_layer(klass):
    return sum(1 for o in ndjson("voter_health.ndjson")
               if o.get("status") == ADOPTED and str(o.get("class_id")) == str(klass)
               and o.get("healthy") is True)


def quorum_permille_layer(klass):
    row = only(adopted_rows(delimited_rows("quorum_permille.tilde", "~"), klass), "quorum_permille")
    return int(row["permille"])


def tls_layer(klass):
    rows = [r for r in adopted_rows(delimited_rows("tls_matrix.csv", ","), klass)
            if r.get("enabled") == "true"]
    return int(only(rows, "tls_matrix")["score"])


def seccomp_layer(klass):
    allow = [r["syscall"] for r in adopted_rows(delimited_rows("seccomp_allow.tsv", "\t"), klass)]
    deny = [r["syscall"] for r in adopted_rows(delimited_rows("seccomp_deny.psv", "|"), klass)]
    return sorted(set(allow) - set(deny)), sorted(set(deny))


def retention_layer(klass):
    sec = ini_sections("retention.ini").get("class.%d" % klass, {})
    if sec.get("status") != ADOPTED:
        raise SystemExit("no adopted retention block for class %d" % klass)
    return int(sec["retention_days"])


def retry_step_layer(klass):
    row = only(adopted_rows(delimited_rows("retry_backoff.psv2", "||"), klass), "retry_backoff")
    return int(row["step"])


def sessions_ceiling(klass):
    row = only(adopted_rows(delimited_rows("sessions_cap.csv2", ","), klass), "sessions_cap")
    return int(row["abs_ceil"])


def nonce_floor(klass):
    sec = ini_sections("nonce_bounds.toml2").get("class.%d" % klass, {})
    if sec.get("status") != ADOPTED:
        raise SystemExit("no adopted nonce bounds for class %d" % klass)
    return int(sec["floor_ms"])


def resolve_precedence(klass):
    """defaults < layer_overrides < pinned_overrides, the last only when pinned."""
    defaults = load_json(DATA / "defaults.json")["layer_defaults"]
    overrides = load_json(DATA / "layer_overrides.json").get("class_%d" % klass, {})
    pinned = load_json(DATA / "pinned_overrides.json").get("class_%d" % klass, {})
    resolved = {}
    for field in ("session_ttl_seconds", "nonce_window_ms", "max_concurrent_sessions"):
        value = int(defaults[field])
        source = "defaults"
        if field in overrides:
            value = int(overrides[field])
            source = "layer_overrides"
        if pinned.get("pinned") is True and field in pinned:
            value = int(pinned[field])
            source = "pinned_overrides"
        resolved[field] = {"default": int(defaults[field]), "resolved": value, "source": source}
    return resolved


def derive():
    base = base_inputs()
    klass, selector, span = select_active_class(base["max_records"])

    qps = ingress_layer(klass)
    permille = burst_layer(klass)
    window = window_layer(klass)
    rate_step = rate_step_layer(klass)
    rate_pre = round_half_even(qps * permille, 1000)
    rate_limit = quantize_floor(rate_pre, rate_step)
    burst_ceiling = rate_limit * window

    base_scopes, overlay_scopes, deny_scopes, effective = scope_layers(klass)
    uids = uid_map()
    floor_uid = uid_floor_layer(klass)
    granted = {s: uids[s] for s in effective if s in uids}
    privilege_drop_uid = max(min(granted.values()), floor_uid)

    rows = control_rows(klass)
    fold_score, trace = fold_controls(rows)
    floor_b, ceil_b = hardening_bounds(klass)
    hardening_baseline = quantize_floor(clamp(fold_score, floor_b, ceil_b), HARDENING_STEP)

    severity = severity_layer(klass)
    complement, divisor = risk_constants()
    risk_index = round_half_even((complement - hardening_baseline) * severity, divisor)

    voters = voter_layer(klass)
    quorum_permille = quorum_permille_layer(klass)
    quorum_threshold = clamp(round_half_even(voters * quorum_permille, 1000), 1, voters)

    tls_floor_score = tls_layer(klass)
    allowed, denied = seccomp_layer(klass)
    retention_days = retention_layer(klass)

    retry_step = retry_step_layer(klass)
    retry_backoff = quantize_floor(round_half_even(base["timeout_ms"], base["retry_limit"] + 1), retry_step)

    prec = resolve_precedence(klass)
    floor_nonce = nonce_floor(klass)
    ceil_sessions = sessions_ceiling(klass)
    session_ttl = prec["session_ttl_seconds"]["resolved"]
    nonce_window = max(prec["nonce_window_ms"]["resolved"], floor_nonce)
    max_sessions = min(prec["max_concurrent_sessions"]["resolved"], ceil_sessions)

    contract = load_json(DATA / "config_schema.json")

    config = {
        "active_class": klass,
        "audit_retention_days": retention_days,
        "burst_ceiling": burst_ceiling,
        "checksum": contract["checksum"],
        "control_plane": contract["control_plane"],
        "effective_scope_count": len(effective),
        "enforcement_profile": "main",
        "hardening_baseline": hardening_baseline,
        "image_runtime": contract["image_runtime"],
        "ingress_rate_limit_qps": rate_limit,
        "max_concurrent_sessions": max_sessions,
        "mode": contract["mode"],
        "nonce_window_ms": nonce_window,
        "privilege_drop_uid": privilege_drop_uid,
        "profile": contract["profile"],
        "quorum_threshold": quorum_threshold,
        "retry_backoff_base_ms": retry_backoff,
        "risk_index": risk_index,
        "seccomp_allowed_count": len(allowed),
        "session_ttl_seconds": session_ttl,
        "tls_floor_score": tls_floor_score,
        "trailer": base["trailer"],
    }

    detail = {
        "base": base,
        "selector": selector,
        "selector_span": span,
        "ingress_qps": qps,
        "burst_permille": permille,
        "window_seconds": window,
        "rate_step": rate_step,
        "rate_pre_quantize": rate_pre,
        "base_scopes": base_scopes,
        "overlay_scopes": overlay_scopes,
        "deny_scopes": deny_scopes,
        "effective_scopes": effective,
        "scope_uids": granted,
        "uid_floor": floor_uid,
        "uid_mirror": privilege_mirror(klass),
        "control_rows": rows,
        "fold_trace": trace,
        "fold_score": fold_score,
        "hardening_floor": floor_b,
        "hardening_ceil": ceil_b,
        "hardening_step": HARDENING_STEP,
        "severity_permille": severity,
        "baseline_complement": complement,
        "risk_divisor": divisor,
        "healthy_voters": voters,
        "quorum_permille": quorum_permille,
        "seccomp_allowed": allowed,
        "seccomp_denied": denied,
        "retry_step": retry_step,
        "precedence": prec,
        "nonce_floor": floor_nonce,
        "sessions_ceiling": ceil_sessions,
    }
    return config, detail


def profile_config(config, name):
    deltas = load_json(DATA / "profile_deltas.json")[name]
    _, detail = derive()
    ttl = round_half_even(int(config["session_ttl_seconds"]) * int(deltas["ttl_scale_permille"]), 1000)
    ttl = quantize_floor(ttl, TTL_GRAN)
    quorum = clamp(int(config["quorum_threshold"]) + int(deltas["quorum_delta"]), 1, detail["healthy_voters"])
    risk = max(0, int(config["risk_index"]) + int(deltas["risk_delta"]))
    out = dict(config)
    out["enforcement_profile"] = name
    out["session_ttl_seconds"] = ttl
    out["quorum_threshold"] = quorum
    out["risk_index"] = risk
    return out


# ----------------------------------------------------------------- commands


def cmd_derive(args):
    config, _ = derive()
    write_json(args.out, config)
    print("derived")


def cmd_profile(args):
    config = load_json(args.config)
    write_json(args.out, profile_config(config, args.name))
    print("profiled")


def cmd_init(args):
    schema = load_json(args.schema)
    write_json(args.out, {
        "checksum": schema["checksum"],
        "control_plane": schema["control_plane"],
        "image_runtime": schema["image_runtime"],
        "mode": schema["mode"],
        "profile": schema["profile"],
    })
    print("initialized")


def coerce(value):
    text = str(value)
    if re.fullmatch(r"[+-]?\d+", text):
        return int(text)
    return text


def cmd_set(args):
    data = load_json(args.config)
    value = coerce(args.value)
    if isinstance(value, (dict, list)):
        raise SystemExit("value must be scalar")
    data[args.key] = value
    write_json(args.config, data)
    print("set")


def required_artifacts():
    return list(load_json(DATA / "validation_rules.json")["required_artifacts"])


def manifest_artifacts():
    """Artifacts that already exist when the provenance manifest is written."""
    late = {"tool.zip", "report.json", "summary.json", "validation_report.json",
            "reproducibility_manifest.json"}
    return [name for name in required_artifacts() if name not in late]


def required_keys(schema):
    keys = schema["required_keys"]
    if isinstance(keys, str):
        keys = [k.strip() for k in keys.split(",")]
    return [k for k in keys if k]


def validate_config(schema, data):
    problems = []
    missing = [k for k in required_keys(schema) if k not in data]
    if missing:
        problems.append("missing: " + ",".join(sorted(missing)))
    nested = sorted(k for k, v in data.items() if isinstance(v, (dict, list)))
    if nested:
        problems.append("configuration must be flat: " + ",".join(nested))
    floats = sorted(k for k, v in data.items() if isinstance(v, float))
    if floats:
        problems.append("float values are forbidden: " + ",".join(floats))
    for key in ("timestamp", "generated_at", "uuid", "random_seed"):
        if key in data:
            problems.append("forbidden key: " + key)
    return problems


def cmd_validate(args):
    schema = load_json(args.schema)
    data = load_json(args.config)
    problems = validate_config(schema, data)
    if problems:
        raise SystemExit("; ".join(problems))
    print("ok")


def cmd_report(args):
    data = load_json(args.config)
    commands = json.loads(args.commands)
    if not isinstance(commands, list):
        raise SystemExit("--commands must be a JSON array")
    write_json(args.out, {
        "commands": commands,
        "config": data,
        "digest": args.digest,
        "ok": True,
        "tool": "task-ctl",
        "trailer": data.get("trailer"),
    })
    print("reported")


# ----------------------------------------------------------------- sidecars


def cmd_sidecars(args):
    config = load_json(args.config)
    _, d = derive()
    out = Path(args.outdir)
    out.mkdir(parents=True, exist_ok=True)
    klass = config["active_class"]

    sources = {
        "active_class": "class_index.tsv2",
        "audit_retention_days": "retention.ini",
        "burst_ceiling": "burst_multiplier.ini+window_seconds.conf",
        "effective_scope_count": "scope_base.jsonl+scope_overlay.ndjson+scope_deny.psv",
        "hardening_baseline": "baseline_controls.scsv+hardening_bounds.toml",
        "ingress_rate_limit_qps": "ingress_rate.tsv+burst_multiplier.ini+rate_gran.caret",
        "max_concurrent_sessions": "defaults.json+layer_overrides.json+pinned_overrides.json",
        "nonce_window_ms": "defaults.json+layer_overrides.json+pinned_overrides.json",
        "privilege_drop_uid": "uid_map.env+uid_floor.hex",
        "quorum_threshold": "voter_health.ndjson+quorum_permille.tilde",
        "retry_backoff_base_ms": "defaults.json+retry_backoff.psv2",
        "risk_index": "risk_const.env2+severity_weight.kv",
        "seccomp_allowed_count": "seccomp_allow.tsv+seccomp_deny.psv",
        "session_ttl_seconds": "defaults.json+layer_overrides.json+pinned_overrides.json",
        "tls_floor_score": "tls_matrix.csv",
    }
    rows = ["field,class,value,source"]
    for field in sorted(sources):
        rows.append("%s,%d,%s,%s" % (field, klass, config[field], sources[field]))
    write_text(out / "admission_matrix.csv", "\n".join(rows) + "\n")

    write_text(out / "rate_limit_plan.ini",
               "[rate]\nclass = %d\ningress_rate_limit_qps = %d\nburst_ceiling = %d\n"
               % (klass, config["ingress_rate_limit_qps"], config["burst_ceiling"]))

    uids = uid_map()
    every = sorted(set(d["base_scopes"]) | set(d["overlay_scopes"]) | set(d["deny_scopes"]))
    lines = ["scope\tin_base\tin_overlay\tin_deny\teffective\tuid"]
    for scope in every:
        lines.append("%s\t%s\t%s\t%s\t%s\t%s" % (
            scope,
            "yes" if scope in d["base_scopes"] else "no",
            "yes" if scope in d["overlay_scopes"] else "no",
            "yes" if scope in d["deny_scopes"] else "no",
            "yes" if scope in d["effective_scopes"] else "no",
            uids.get(scope, ""),
        ))
    write_text(out / "scope_reconciliation.tsv", "\n".join(lines) + "\n")

    lines = ["order|control_id|weight|carry|status|running"]
    for row, running in d["fold_trace"]:
        lines.append("%s|%s|%s|%s|%s|%s" % (
            row["order"], row["control_id"], row["weight"], row["carry_flag"], row["status"],
            "skip" if running is None else running))
    write_text(out / "hardening_fold_trace.psv", "\n".join(lines) + "\n")

    write_text(out / "quorum_plan.kv", "healthy_voters:%d\nquorum_threshold:%d\n"
               % (d["healthy_voters"], config["quorum_threshold"]))

    write_text(out / "risk_ledger.env", "HARDENING_BASELINE=%d\nRISK_INDEX=%d\nSEVERITY_PERMILLE=%d\n"
               % (config["hardening_baseline"], config["risk_index"], d["severity_permille"]))

    lines = []
    for field in ("session_ttl_seconds", "nonce_window_ms", "max_concurrent_sessions"):
        lines.append("%s.default=%d" % (field, d["precedence"][field]["default"]))
        lines.append("%s.resolved=%d" % (field, config[field]))
    write_text(out / "precedence_resolution.properties", "\n".join(lines) + "\n")

    lines = [json.dumps({"scope": s, "uid": uids[s]}, sort_keys=True) for s in d["effective_scopes"]]
    write_text(out / "privilege_map.ndjson", "\n".join(lines) + "\n")

    write_text(out / "seccomp_summary.tsv", "class\tseccomp_allowed_count\n%d\t%d\n"
               % (klass, config["seccomp_allowed_count"]))

    write_text(out / "tls_floor.env", "TLS_FLOOR_SCORE=%d\n" % config["tls_floor_score"])

    lines = ["profile,class,audit_retention_days"]
    for name in ("canary", "enforce", "main"):
        lines.append("%s,%d,%d" % (name, klass, config["audit_retention_days"]))
    write_text(out / "retention_schedule.csv", "\n".join(lines) + "\n")
    print("sidecars")


def cmd_delta_report(args):
    config = load_json(args.config)
    canary = load_json(args.canary)
    enforce = load_json(args.enforce)
    fields = ("max_concurrent_sessions", "nonce_window_ms", "quorum_threshold", "risk_index",
              "session_ttl_seconds")
    report = {"main": {f: config[f] for f in fields}, "trailer": config["trailer"]}
    for name, prof in (("canary", canary), ("enforce", enforce)):
        report[name] = {
            "deltas": {f: prof[f] - config[f] for f in fields},
            "values": {f: prof[f] for f in fields},
        }
    write_json(args.out, report)
    print("delta-report")


def cmd_audit(args):
    config = load_json(args.config)
    canary = load_json(args.canary)
    enforce = load_json(args.enforce)
    _, d = derive()
    out = Path(args.outdir)
    out.mkdir(parents=True, exist_ok=True)

    formulas = {
        "active_class": "selector = max_records mod %d resolved through class_index.tsv2" % d["selector_span"],
        "audit_retention_days": "retention.ini [class.%d] retention_days" % config["active_class"],
        "burst_ceiling": "ingress_rate_limit_qps * window_seconds(%d)" % d["window_seconds"],
        "effective_scope_count": "count((base union overlay) minus deny)",
        "hardening_baseline": "quantize_floor(clamp(carry_fold=%d,%d,%d),%d)" % (
            d["fold_score"], d["hardening_floor"], d["hardening_ceil"], d["hardening_step"]),
        "ingress_rate_limit_qps": "quantize_floor(round_half_even(%d*%d,1000),%d)" % (
            d["ingress_qps"], d["burst_permille"], d["rate_step"]),
        "max_concurrent_sessions": "precedence(%s) capped at %d" % (
            d["precedence"]["max_concurrent_sessions"]["source"], d["sessions_ceiling"]),
        "nonce_window_ms": "precedence(%s) floored at %d" % (
            d["precedence"]["nonce_window_ms"]["source"], d["nonce_floor"]),
        "privilege_drop_uid": "max(min(effective scope uids),uid_floor=%d)" % d["uid_floor"],
        "quorum_threshold": "clamp(round_half_even(%d*%d,1000),1,%d)" % (
            d["healthy_voters"], d["quorum_permille"], d["healthy_voters"]),
        "retry_backoff_base_ms": "quantize_floor(round_half_even(%d,%d),%d)" % (
            d["base"]["timeout_ms"], d["base"]["retry_limit"] + 1, d["retry_step"]),
        "risk_index": "round_half_even((%d-hardening_baseline)*%d,%d)" % (
            d["baseline_complement"], d["severity_permille"], d["risk_divisor"]),
        "seccomp_allowed_count": "count(allow minus deny)",
        "session_ttl_seconds": "precedence(%s)" % d["precedence"]["session_ttl_seconds"]["source"],
        "tls_floor_score": "tls_matrix.csv adopted enabled suite score",
    }

    def esc(text):
        return (str(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace('"', "&quot;"))

    xml = ['<?xml version="1.0" encoding="UTF-8"?>',
           '<derivation_audit tool="task-ctl">',
           "  <active_class>%d</active_class>" % config["active_class"],
           '  <selector span="%d">%d</selector>' % (d["selector_span"], d["selector"]),
           "  <trailer>%s</trailer>" % esc(config["trailer"]),
           "  <fields>"]
    for field in sorted(formulas):
        xml.append('    <field name="%s" value="%s" formula="%s"/>'
                   % (field, esc(config[field]), esc(formulas[field])))
    xml.append("  </fields>")
    xml.append("  <profiles>")
    for name, prof in (("canary", canary), ("enforce", enforce)):
        xml.append('    <profile name="%s" session_ttl_seconds="%d" quorum_threshold="%d" risk_index="%d"/>'
                   % (name, prof["session_ttl_seconds"], prof["quorum_threshold"], prof["risk_index"]))
    xml.append("  </profiles>")
    xml.append("</derivation_audit>")
    write_text(out / "derivation_audit.xml", "\n".join(xml) + "\n")

    runs = [derive()[0] for _ in range(3)]
    identical = sum(1 for r in runs if r == config)
    lines = [
        "active_class: %d" % config["active_class"],
        "convergence: %s" % ("stable" if identical == len(runs) else "unstable"),
        "float_operations_on_graded_values: 0",
        "hardening_baseline: %d" % config["hardening_baseline"],
        "identical_rederivations: %d" % identical,
        "ingress_rate_limit_qps: %d" % config["ingress_rate_limit_qps"],
        "quorum_threshold: %d" % config["quorum_threshold"],
        "rederivation_runs: %d" % len(runs),
        "risk_index: %d" % config["risk_index"],
        "rounding_mode: round-half-even",
        "trailer: %s" % config["trailer"],
    ]
    write_text(out / "convergence_report.txt", "\n".join(lines) + "\n")

    census = []
    for path in sorted(DATA.iterdir()):
        if not path.is_file():
            continue
        blob = path.read_bytes()
        census.append(json.dumps({
            "bytes": len(blob),
            "lines": blob.count(b"\n"),
            "name": path.name,
            "sha256": sha256_bytes(blob),
        }, sort_keys=True))
    write_text(out / "input_census.ndjson", "\n".join(census) + "\n")

    ordering = sorted([("main", config["risk_index"]), ("canary", canary["risk_index"]),
                       ("enforce", enforce["risk_index"])], key=lambda p: (p[1], p[0]))
    write_text(out / "class_ordering.tsv",
               "profile\trisk_index\n" + "".join("%s\t%d\n" % (n, r) for n, r in ordering))

    # Hash a fixed artifact list so the manifest stays byte-stable regardless of
    # which artifacts a previous run left behind in the output directory.
    artifacts = {}
    for name in sorted(manifest_artifacts()):
        path = out / name
        if path.is_file():
            artifacts[name] = {"bytes": path.stat().st_size, "sha256": sha256_file(path)}
    tool_dir = Path(__file__).resolve().parent
    write_json(out / "reproducibility_manifest.json", {
        "algorithm": "sha256",
        "artifacts": artifacts,
        "deterministic": True,
        "inputs": {p.name: sha256_file(p) for p in sorted(DATA.iterdir()) if p.is_file()},
        "rounding_mode": "round-half-even",
        "tool": "task-ctl",
        "tool_sources": {p.name: sha256_file(p) for p in sorted(tool_dir.iterdir())
                         if p.is_file() and p.suffix in (".py", ".md", ".json")},
        "trailer": config["trailer"],
    })
    print("audit")


def cmd_validation_report(args):
    schema = load_json(args.schema)
    config = load_json(args.config)
    canary = load_json(args.canary)
    enforce = load_json(args.enforce)
    _, d = derive()
    checks = []

    def check(name, ok, detail):
        checks.append({"check": name, "detail": detail, "ok": bool(ok)})

    keys = required_keys(schema)
    check("required_keys_present", all(k in config for k in keys),
          "%d/%d keys present" % (sum(1 for k in keys if k in config), len(keys)))
    check("flat_scalars", all(not isinstance(v, (dict, list)) for v in config.values()),
          "no nested containers")
    check("no_floats", all(not isinstance(v, float) for v in config.values()),
          "integer arithmetic only")
    check("trailer_intact", config["trailer"] == d["base"]["trailer"], config["trailer"])
    check("active_class_from_budget",
          config["active_class"] == select_active_class(d["base"]["max_records"])[0],
          "selector %d of span %d -> class %d" % (d["selector"], d["selector_span"], config["active_class"]))
    check("hardening_within_bounds",
          d["hardening_floor"] <= config["hardening_baseline"] <= d["hardening_ceil"],
          "%d in [%d,%d]" % (config["hardening_baseline"], d["hardening_floor"], d["hardening_ceil"]))
    check("hardening_quantized", config["hardening_baseline"] % d["hardening_step"] == 0,
          "step %d" % d["hardening_step"])
    check("rate_quantized", config["ingress_rate_limit_qps"] % d["rate_step"] == 0,
          "step %d" % d["rate_step"])
    check("burst_from_rate_and_window",
          config["burst_ceiling"] == config["ingress_rate_limit_qps"] * d["window_seconds"],
          "%d = %d * %d" % (config["burst_ceiling"], config["ingress_rate_limit_qps"], d["window_seconds"]))
    check("quorum_bounded", 1 <= config["quorum_threshold"] <= d["healthy_voters"],
          "%d of %d healthy voters" % (config["quorum_threshold"], d["healthy_voters"]))
    check("scope_count_matches", config["effective_scope_count"] == len(d["effective_scopes"]),
          ",".join(d["effective_scopes"]))
    check("privilege_uid_mirror", config["privilege_drop_uid"] == d["uid_mirror"],
          "uid %s agrees with privilege_bits.b64" % config["privilege_drop_uid"])
    check("uid_above_floor", config["privilege_drop_uid"] >= d["uid_floor"], "floor %d" % d["uid_floor"])
    check("nonce_above_floor", config["nonce_window_ms"] >= d["nonce_floor"], "floor %d" % d["nonce_floor"])
    check("sessions_below_ceiling", config["max_concurrent_sessions"] <= d["sessions_ceiling"],
          "ceiling %d" % d["sessions_ceiling"])
    check("retry_quantized", config["retry_backoff_base_ms"] % d["retry_step"] == 0,
          "step %d" % d["retry_step"])
    check("risk_index_matches_baseline",
          config["risk_index"] == round_half_even(
              (d["baseline_complement"] - config["hardening_baseline"]) * d["severity_permille"],
              d["risk_divisor"]),
          "severity %d permille" % d["severity_permille"])
    for name, prof in (("canary", canary), ("enforce", enforce)):
        check("profile_%s_trailer" % name, prof["trailer"] == config["trailer"], prof["trailer"])
        check("profile_%s_keys" % name, all(k in prof for k in keys), "%d required keys" % len(keys))
        check("profile_%s_flat" % name,
              all(not isinstance(v, (dict, list)) for v in prof.values()), "flat scalars")
    out_dir = Path(args.config).parent
    emitted = [n for n in manifest_artifacts() if (out_dir / n).is_file()]
    check("derivation_artifacts_present", len(emitted) == len(manifest_artifacts()),
          "%d/%d emitted" % (len(emitted), len(manifest_artifacts())))
    oversized = [n for n in required_artifacts()
                 if (out_dir / n).is_file()
                 and (out_dir / n).stat().st_size > load_json(DATA / "validation_rules.json")["max_artifact_bytes"]]
    check("artifact_size_bounded", not oversized, ",".join(oversized) if oversized else "within limit")
    problems = validate_config(schema, config)
    check("schema_validation", not problems, "; ".join(problems) if problems else "ok")

    write_json(args.out, {
        "checks": checks,
        "failed": sum(1 for c in checks if not c["ok"]),
        "ok": all(c["ok"] for c in checks),
        "passed": sum(1 for c in checks if c["ok"]),
        "total": len(checks),
    })
    print("validation-report")


def cmd_summary(args):
    config = load_json(args.config)
    canary = load_json(args.canary)
    enforce = load_json(args.enforce)
    validation = load_json(args.validation)
    _, d = derive()
    write_json(args.out, {
        "active_class": config["active_class"],
        "artifacts": sorted(required_artifacts()),
        "config_digest": sha256_file(args.config),
        "derived": dict(config),
        "effective_scopes": d["effective_scopes"],
        "healthy_voters": d["healthy_voters"],
        "ok": bool(validation["ok"]),
        "profiles": {
            "canary": {"quorum_threshold": canary["quorum_threshold"],
                       "risk_index": canary["risk_index"],
                       "session_ttl_seconds": canary["session_ttl_seconds"]},
            "enforce": {"quorum_threshold": enforce["quorum_threshold"],
                        "risk_index": enforce["risk_index"],
                        "session_ttl_seconds": enforce["session_ttl_seconds"]},
        },
        "rounding_mode": "round-half-even",
        "trailer": config["trailer"],
        "validation": {"failed": validation["failed"], "passed": validation["passed"],
                       "total": validation["total"]},
    })
    print("summary")


def cmd_package(args):
    src = Path(args.src)
    names = sorted(p.name for p in src.iterdir() if p.is_file() and p.suffix in (".py", ".md", ".json"))
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.out, "w", zipfile.ZIP_DEFLATED) as zf:
        for name in names:
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            zf.writestr(info, (src / name).read_bytes())
    print("packaged")


def main():
    parser = argparse.ArgumentParser(prog="task-ctl")
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("derive")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_derive)

    p = sub.add_parser("profile")
    p.add_argument("--name", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_profile)

    p = sub.add_parser("init")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("export-report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest", required=True)
    p.add_argument("--commands", required=True)
    p.set_defaults(func=cmd_report)

    p = sub.add_parser("sidecars")
    p.add_argument("--config", required=True)
    p.add_argument("--outdir", required=True)
    p.set_defaults(func=cmd_sidecars)

    p = sub.add_parser("delta-report")
    p.add_argument("--config", required=True)
    p.add_argument("--canary", required=True)
    p.add_argument("--enforce", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_delta_report)

    p = sub.add_parser("audit")
    p.add_argument("--config", required=True)
    p.add_argument("--canary", required=True)
    p.add_argument("--enforce", required=True)
    p.add_argument("--outdir", required=True)
    p.set_defaults(func=cmd_audit)

    p = sub.add_parser("validation-report")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--canary", required=True)
    p.add_argument("--enforce", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_validation_report)

    p = sub.add_parser("summary")
    p.add_argument("--config", required=True)
    p.add_argument("--canary", required=True)
    p.add_argument("--enforce", required=True)
    p.add_argument("--validation", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_summary)

    p = sub.add_parser("package")
    p.add_argument("--src", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_package)

    args = parser.parse_args()
    if not getattr(args, "command", None):
        parser.print_help()
        return
    args.func(args)


if __name__ == "__main__":
    main()
