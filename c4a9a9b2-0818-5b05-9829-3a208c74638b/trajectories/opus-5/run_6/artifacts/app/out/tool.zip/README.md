# task-ctl

An offline container-image admission-control hardening compiler for a
server-side admission broker. It reads interacting numeric policy layers from
`/app/data`, selects the active enforcement class, and derives one flat hardened
admission configuration plus two deployment profiles (canary and enforce).

This build is repaired: every derived scalar follows the documented contract
recorded across the policy layers.

## Commands

- `init --schema <schema> --out <config>`: seed fixed contract strings.
- `derive --out <config>`: compile the flat hardened configuration.
- `set --config <config> --key <key> --value <value>`: set one scalar key with
  correct case and type coercion; reject any non-scalar value.
- `validate --schema <schema> --config <config>`: confirm every required key is
  present and the configuration is flat; print `ok`.
- `profile --name <canary|enforce> --config <config> --out <profile>`: apply the
  documented per-profile deltas.
- `sidecars --config <config> --outdir <dir>`: emit the derivation sidecars.
- `delta-report --config <config> --canary <p> --enforce <p> --out <report>`.
- `audit --config <config> --canary <p> --enforce <p> --outdir <dir>`: emit the
  audit and provenance artifacts.
- `validation-report --schema <s> --config <c> --canary <p> --enforce <p> --out <r>`.
- `summary --config <c> --canary <p> --enforce <p> --validation <v> --out <s>`.
- `export-report --config <config> --out <report> --digest <sha256> --commands <json>`:
  emit a truthful command transcript.
- `package --src <dir> --out <zip>`: repackage the tool deterministically.

## Contract notes

- Every value is derived with exact integer arithmetic (round-half-even); no
  floating-point value may reach a graded key.
- The configuration is flat: keys map directly to integer or string scalars.
- The required key set is authoritative in `schema.json` and mirrored by the
  field registry in the policy layers.
- Only rows whose status is `ADOPTED` for the active enforcement class bind; rows
  labelled `SUPERSEDED`, `DRAFT`, `SHADOW`, or `REVOKED` are context decoys.

## Derivation contract

- active class: `selector = base_config.max_records mod span`, where `span` is
  one past the highest adopted selector bound in `class_index.tsv2`; the class
  owning the bin containing `selector` is active.
- ingress rate limit: `quantize_floor(round_half_even(ingress_qps *
  burst_multiplier_permille, 1000), rate_gran)`.
- burst ceiling: `ingress_rate_limit_qps * window_seconds`.
- effective scopes: `(base union overlay) minus deny` for the active class;
  `privilege_drop_uid = max(min(uid of each effective scope), uid_floor)`.
- hardening baseline: ordered carry-aware fold of the adopted controls (a set
  carry flag adds one unit to the next adopted control), clamped to the per-class
  floor/ceiling and quantized down to a multiple of 5.
- risk index: `round_half_even((BASELINE_COMPLEMENT - hardening_baseline) *
  severity_permille, RISK_DIVISOR)`.
- quorum threshold: `clamp(round_half_even(healthy_voters * quorum_permille,
  1000), 1, healthy_voters)`.
- retry backoff base: `quantize_floor(round_half_even(timeout_ms,
  retry_limit + 1), step)`.
- precedence fields: `defaults < layer_overrides < pinned_overrides`, the pinned
  layer binding only when `pinned` is true; the nonce window is floored and the
  session cap is capped by their per-class bounds.
- profiles: the canary/enforce deltas scale the resolved session TTL before
  granularity quantization and apply signed quorum and risk adjustments.
