#!/usr/bin/env python3
"""task-ctl: local admission-control hardening compiler.

Compiles a flat hardened admission configuration for the active enforcement
class from the interacting numeric policy layers under /app/data.  Every graded
scalar is produced with exact integer arithmetic and round-half-even rounding;
no floating-point value reaches a derived key.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import re
import zipfile
from pathlib import Path

DATA = Path("/app/data")
ADOPTED = "ADOPTED"
TOOL_FILES = ("README.md", "cli.py", "schema.json")


# ---------------------------------------------------------------- primitives


def load_json(path):
    return json.loads(Path(path).read_text())


def write_json(path, data):
    Path(path).write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")


def write_text(path, text):
    Path(path).write_text(text)


def read_lines(name):
    out = []
    for line in (DATA / name).read_text(encoding="utf-8", errors="replace").split("\n"):
        s = line.strip()
        if not s or s.startswith("#") or s.startswith(";") or s.startswith("<!--"):
            continue
        out.append(line)
    return out


def delimited_rows(name, sep):
    lines = read_lines(name)
    if not lines:
        return []
    header = [c for c in (c.strip() for c in lines[0].split(sep)) if c]
    rows = []
    for line in lines[1:]:
        parts = [c for c in (c.strip() for c in line.split(sep)) if c]
        if len(parts) != len(header):
            continue
        rows.append(dict(zip(header, parts)))
    return rows


def round_half_even(num, den):
    """Exact integer round-half-even of num/den."""
    if den < 0:
        num, den = -num, -den
    quot, rem = divmod(num, den)
    twice = 2 * rem
    if twice > den or (twice == den and quot % 2 == 1):
        quot += 1
    return quot


def quantize_floor(value, step):
    return (value // step) * step


def clamp(value, low, high):
    return max(low, min(high, value))


def ini_blocks(name):
    """Parse '[section]' / 'key = value' text into {section: {key: value}}."""
    blocks = {}
    current = None
    for line in read_lines(name):
        s = line.strip()
        if s.startswith("[") and s.endswith("]"):
            current = s[1:-1]
            blocks[current] = {}
            continue
        if current is None or "=" not in s:
            continue
        key, _, val = s.partition("=")
        blocks[current][key.strip()] = val.strip().strip('"')
    return blocks


def sha256_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


# ------------------------------------------------------------- policy layers


def base_inputs():
    base = load_json(DATA / "defaults.json")["base_config"]
    return (
        int(base["max_records"]),
        int(base["retry_limit"]),
        int(base["timeout_ms"]),
        str(base["trailer"]),
    )


def active_class(max_records):
    """Select the enforcement class from the base budget via class_index."""
    rows = []
    for line in read_lines("class_index.tsv2")[1:]:
        parts = line.split()
        if len(parts) == 4 and parts[3] == ADOPTED:
            rows.append((int(parts[0]), int(parts[1]), int(parts[2])))
    span = max(hi for _, _, hi in rows) + 1
    selector = max_records % span
    for klass, lo, hi in sorted(rows, key=lambda r: r[1]):
        if lo <= selector <= hi:
            return klass, selector
    raise SystemExit("no adopted class covers selector %d" % selector)


def ingress_qps(klass):
    for row in delimited_rows("ingress_rate.tsv", "\t"):
        if row["status"] == ADOPTED and int(row["class_id"]) == klass:
            return int(row["ingress_qps"])
    raise SystemExit("no adopted ingress row")


def burst_permille(klass):
    block = ini_blocks("burst_multiplier.ini").get("class.%d" % klass, {})
    if block.get("status") != ADOPTED:
        raise SystemExit("no adopted burst block")
    return int(block["burst_multiplier_permille"])


def window_seconds(klass):
    for line in read_lines("window_seconds.conf"):
        parts = line.split()
        if len(parts) == 3 and parts[2] == ADOPTED and int(parts[0]) == klass:
            return int(parts[1])
    raise SystemExit("no adopted window row")


def rate_step(klass):
    for row in delimited_rows("rate_gran.caret", "^"):
        if row["status"] == ADOPTED and int(row["class_id"]) == klass:
            return int(row["gran"])
    raise SystemExit("no adopted rate granularity")


def scope_sets(klass):
    base, overlay, deny = set(), set(), set()
    for line in read_lines("scope_base.jsonl"):
        obj = json.loads(line)
        if obj["status"] == ADOPTED and int(obj["class_id"]) == klass:
            base.add(obj["scope"])
    for line in read_lines("scope_overlay.ndjson"):
        obj = json.loads(line)
        if obj["status"] == ADOPTED and int(obj["class_id"]) == klass:
            overlay.add(obj["scope"])
    for row in delimited_rows("scope_deny.psv", "|"):
        if row["status"] == ADOPTED and int(row["class_id"]) == klass:
            deny.add(row["scope"])
    return base, overlay, deny


def scope_uids():
    uids = {}
    for line in read_lines("uid_map.env"):
        key, _, val = line.strip().partition("=")
        if key.startswith("SCOPE_") and val.strip().isdigit():
            uids[key[len("SCOPE_"):].lower()] = int(val.strip())
    return uids


def uid_floor(klass):
    for row in delimited_rows("uid_floor.hex", ":"):
        if row["status"] == ADOPTED and int(row["class_id"]) == klass:
            return int(row["floor_hex"], 16)
    raise SystemExit("no adopted uid floor")


def privilege_bits(klass):
    for line in read_lines("privilege_bits.b64"):
        text = base64.b64decode(line.strip()).decode()
        fields = dict(p.split("=", 1) for p in text.split(";"))
        if fields.get("status") == ADOPTED and int(fields["class"]) == klass:
            return int(fields["uid"])
    return None


def control_rows(klass):
    rows = [
        r
        for r in delimited_rows("baseline_controls.scsv", ";")
        if int(r["class_id"]) == klass
    ]
    rows.sort(key=lambda r: int(r["order"]))
    return rows


def hardening_bounds(klass):
    block = ini_blocks("hardening_bounds.toml").get("class.%d" % klass, {})
    if block.get("status") != ADOPTED:
        raise SystemExit("no adopted hardening bounds")
    return int(block["floor"]), int(block["ceil"])


def severity_permille(klass):
    for line in read_lines("severity_weight.kv"):
        parts = line.split(":")
        if len(parts) == 3 and parts[2] == ADOPTED and parts[0] == "class%d" % klass:
            return int(parts[1])
    raise SystemExit("no adopted severity weight")


def risk_constants():
    consts = {}
    for line in read_lines("risk_const.env2"):
        key, _, val = line.partition("=")
        consts[key.strip()] = val.strip()
    return int(consts["BASELINE_COMPLEMENT"]), int(consts["RISK_DIVISOR"])


def healthy_voters(klass):
    count = 0
    for line in read_lines("voter_health.ndjson"):
        obj = json.loads(line)
        if (
            obj.get("status") == ADOPTED
            and int(obj.get("class_id")) == klass
            and obj.get("healthy") is True
        ):
            count += 1
    return count


def quorum_permille(klass):
    for row in delimited_rows("quorum_permille.tilde", "~"):
        if row["status"] == ADOPTED and int(row["class_id"]) == klass:
            return int(row["permille"])
    raise SystemExit("no adopted quorum permille")


def tls_floor(klass):
    scores = [
        int(r["score"])
        for r in delimited_rows("tls_matrix.csv", ",")
        if r["status"] == ADOPTED
        and int(r["class_id"]) == klass
        and r["enabled"] == "true"
    ]
    if not scores:
        raise SystemExit("no adopted enabled tls suite")
    return min(scores)


def seccomp_sets(klass):
    allow = {
        r["syscall"]
        for r in delimited_rows("seccomp_allow.tsv", "\t")
        if r["status"] == ADOPTED and int(r["class_id"]) == klass
    }
    deny = {
        r["syscall"]
        for r in delimited_rows("seccomp_deny.psv", "|")
        if r["status"] == ADOPTED and int(r["class_id"]) == klass
    }
    return sorted(allow), sorted(deny), sorted(allow - deny)


def retention_days(klass):
    block = ini_blocks("retention.ini").get("class.%d" % klass, {})
    if block.get("status") != ADOPTED:
        raise SystemExit("no adopted retention block")
    return int(block["retention_days"])


def retry_step(klass):
    for row in delimited_rows("retry_backoff.psv2", "|"):
        if row["status"] == ADOPTED and int(row["class_id"]) == klass:
            return int(row["step"])
    raise SystemExit("no adopted retry step")


def session_ceiling(klass):
    for row in delimited_rows("sessions_cap.csv2", ","):
        if row["status"] == ADOPTED and int(row["class_id"]) == klass:
            return int(row["abs_ceil"])
    raise SystemExit("no adopted session ceiling")


def nonce_floor(klass):
    block = ini_blocks("nonce_bounds.toml2").get("class.%d" % klass, {})
    if block.get("status") != ADOPTED:
        raise SystemExit("no adopted nonce floor")
    return int(block["floor_ms"])


# ----------------------------------------------------------------- derivation

TTL_STEP = 5
HARDENING_STEP = 5


def derive_all():
    max_records, retry_limit, timeout_ms, trailer = base_inputs()
    klass, selector = active_class(max_records)

    qps = ingress_qps(klass)
    permille = burst_permille(klass)
    window = window_seconds(klass)
    step = rate_step(klass)
    rate_pre = round_half_even(qps * permille, 1000)
    rate_limit = quantize_floor(rate_pre, step)
    burst_ceiling = rate_limit * window

    base_scopes, overlay_scopes, deny_scopes = scope_sets(klass)
    effective = sorted((base_scopes | overlay_scopes) - deny_scopes)
    uids = scope_uids()
    floor = uid_floor(klass)
    granted = {s: uids[s] for s in effective if s in uids}
    privilege_drop_uid = max(min(granted.values()), floor)

    rows = control_rows(klass)
    low, high = hardening_bounds(klass)
    fold = 0
    carry = 0
    trace = []
    for row in rows:
        weight = int(row["weight"])
        flag = int(row["carry_flag"])
        if row["status"] != ADOPTED:
            trace.append(
                (int(row["order"]), row["control_id"], weight, flag, row["status"], "skip")
            )
            continue
        fold += weight + carry
        carry = round_half_even(weight, 2) if flag else 0
        trace.append(
            (int(row["order"]), row["control_id"], weight, flag, row["status"], str(fold))
        )
    hardening_baseline = quantize_floor(clamp(fold, low, high), HARDENING_STEP)

    severity = severity_permille(klass)
    complement, divisor = risk_constants()
    risk_index = round_half_even((complement - hardening_baseline) * severity, divisor)

    voters = healthy_voters(klass)
    qpermille = quorum_permille(klass)
    quorum = clamp(round_half_even(voters * qpermille, 1000), 1, voters)

    tls_score = tls_floor(klass)
    allow, deny, seccomp_effective = seccomp_sets(klass)
    retention = retention_days(klass)

    defaults = load_json(DATA / "defaults.json")["layer_defaults"]
    overrides = load_json(DATA / "layer_overrides.json").get("class_%d" % klass, {})
    pinned = load_json(DATA / "pinned_overrides.json").get("class_%d" % klass, {})
    precedence = {}
    for field in ("session_ttl_seconds", "nonce_window_ms", "max_concurrent_sessions"):
        value = int(defaults[field])
        source = "defaults"
        if field in overrides:
            value = int(overrides[field])
            source = "layer_overrides"
        if pinned.get("pinned") is True and field in pinned:
            value = int(pinned[field])
            source = "pinned_overrides"
        precedence[field] = {
            "default": int(defaults[field]),
            "resolved": value,
            "source": source,
        }
    nonce_low = nonce_floor(klass)
    session_high = session_ceiling(klass)
    precedence["nonce_window_ms"]["resolved"] = max(
        precedence["nonce_window_ms"]["resolved"], nonce_low
    )
    precedence["max_concurrent_sessions"]["resolved"] = min(
        precedence["max_concurrent_sessions"]["resolved"], session_high
    )

    backoff_step = retry_step(klass)
    retry_quotient = round_half_even(timeout_ms, retry_limit + 1)
    retry_backoff = quantize_floor(retry_quotient, backoff_step)

    config = {
        "active_class": klass,
        "audit_retention_days": retention,
        "burst_ceiling": burst_ceiling,
        "checksum": "crc32",
        "control_plane": "admission-broker",
        "effective_scope_count": len(effective),
        "enforcement_profile": "main",
        "hardening_baseline": hardening_baseline,
        "image_runtime": "oci-runc",
        "ingress_rate_limit_qps": rate_limit,
        "max_concurrent_sessions": precedence["max_concurrent_sessions"]["resolved"],
        "mode": "strict-local",
        "nonce_window_ms": precedence["nonce_window_ms"]["resolved"],
        "privilege_drop_uid": privilege_drop_uid,
        "profile": "TASK",
        "quorum_threshold": quorum,
        "retry_backoff_base_ms": retry_backoff,
        "risk_index": risk_index,
        "seccomp_allowed_count": len(seccomp_effective),
        "session_ttl_seconds": precedence["session_ttl_seconds"]["resolved"],
        "tls_floor_score": tls_score,
        "trailer": trailer,
    }

    return {
        "base_scopes": sorted(base_scopes),
        "baseline_complement": complement,
        "bounds": (low, high),
        "burst_permille": permille,
        "class": klass,
        "config": config,
        "deny_scopes": sorted(deny_scopes),
        "effective_scopes": effective,
        "fold_raw": fold,
        "fold_trace": trace,
        "hardening_step": HARDENING_STEP,
        "max_records": max_records,
        "nonce_floor": nonce_low,
        "overlay_scopes": sorted(overlay_scopes),
        "precedence": precedence,
        "privilege_bits_uid": privilege_bits(klass),
        "qps": qps,
        "quorum_permille": qpermille,
        "rate_pre": rate_pre,
        "rate_step": step,
        "retry_limit": retry_limit,
        "retry_quotient": retry_quotient,
        "retry_step": backoff_step,
        "risk_divisor": divisor,
        "scope_uids": granted,
        "seccomp_allow": allow,
        "seccomp_deny": deny,
        "seccomp_effective": seccomp_effective,
        "selector": selector,
        "session_ceiling": session_high,
        "severity_permille": severity,
        "timeout_ms": timeout_ms,
        "uid_floor": floor,
        "voters": voters,
        "window": window,
    }


def profile_config(state, name):
    deltas = load_json(DATA / "profile_deltas.json")[name]
    config = dict(state["config"])
    ttl = round_half_even(
        config["session_ttl_seconds"] * int(deltas["ttl_scale_permille"]), 1000
    )
    config["session_ttl_seconds"] = quantize_floor(ttl, TTL_STEP)
    config["quorum_threshold"] = clamp(
        config["quorum_threshold"] + int(deltas["quorum_delta"]), 1, state["voters"]
    )
    config["risk_index"] = max(0, config["risk_index"] + int(deltas["risk_delta"]))
    config["enforcement_profile"] = name
    return config


# -------------------------------------------------------------- command impls


def cmd_derive(args):
    state = derive_all()
    write_json(args.out, state["config"])
    print("derived")


def cmd_profile(args):
    state = derive_all()
    write_json(args.out, profile_config(state, args.name))
    print("profiled")


def cmd_profile_delta(args):
    main = load_json(args.config)
    report = {}
    for name, path in (("canary", args.canary), ("enforce", args.enforce)):
        profile = load_json(path)
        deltas = {}
        for key in sorted(set(main) | set(profile)):
            mv, pv = main.get(key), profile.get(key)
            if isinstance(mv, int) and isinstance(pv, int):
                if pv != mv:
                    deltas[key] = pv - mv
            elif mv != pv:
                deltas[key] = {"main": mv, "profile": pv}
        report[name] = {
            "changed_keys": sorted(deltas),
            "deltas": deltas,
            "trailer": profile["trailer"],
            "trailer_matches_main": profile["trailer"] == main["trailer"],
        }
    write_json(args.out, report)
    print("delta-reported")


def cmd_sidecars(args):
    state = derive_all()
    config = state["config"]
    out = Path(args.outdir)

    lines = ["field,value"]
    for key in sorted(config):
        lines.append("%s,%s" % (key, config[key]))
    write_text(out / "admission_matrix.csv", "\n".join(lines) + "\n")

    write_text(
        out / "rate_limit_plan.ini",
        "[rate]\nclass = %d\ningress_rate_limit_qps = %d\nburst_ceiling = %d\n"
        % (
            config["active_class"],
            config["ingress_rate_limit_qps"],
            config["burst_ceiling"],
        ),
    )

    rows = ["scope\tin_base\tin_overlay\tin_deny\teffective"]
    universe = sorted(
        set(state["base_scopes"]) | set(state["overlay_scopes"]) | set(state["deny_scopes"])
    )
    for scope in universe:
        rows.append(
            "\t".join(
                [
                    scope,
                    "1" if scope in state["base_scopes"] else "0",
                    "1" if scope in state["overlay_scopes"] else "0",
                    "1" if scope in state["deny_scopes"] else "0",
                    "1" if scope in state["effective_scopes"] else "0",
                ]
            )
        )
    write_text(out / "scope_reconciliation.tsv", "\n".join(rows) + "\n")

    trace = ["order|control_id|weight|carry|status|running"]
    for order, cid, weight, flag, status, running in state["fold_trace"]:
        trace.append("%d|%s|%d|%d|%s|%s" % (order, cid, weight, flag, status, running))
    write_text(out / "hardening_fold_trace.psv", "\n".join(trace) + "\n")

    write_text(
        out / "quorum_plan.kv",
        "healthy_voters:%d\nquorum_threshold:%d\n"
        % (state["voters"], config["quorum_threshold"]),
    )

    write_text(
        out / "risk_ledger.env",
        "HARDENING_BASELINE=%d\nRISK_INDEX=%d\nSEVERITY_PERMILLE=%d\n"
        % (
            config["hardening_baseline"],
            config["risk_index"],
            state["severity_permille"],
        ),
    )

    props = []
    for field in ("session_ttl_seconds", "nonce_window_ms", "max_concurrent_sessions"):
        entry = state["precedence"][field]
        props.append("%s.default=%d" % (field, entry["default"]))
        props.append("%s.resolved=%d" % (field, entry["resolved"]))
    write_text(out / "precedence_resolution.properties", "\n".join(props) + "\n")

    priv = [
        json.dumps({"scope": scope, "uid": state["scope_uids"][scope]}, sort_keys=True)
        for scope in state["effective_scopes"]
    ]
    write_text(out / "privilege_map.ndjson", "\n".join(priv) + "\n")

    write_text(
        out / "seccomp_summary.tsv",
        "class\tseccomp_allowed_count\n%d\t%d\n"
        % (config["active_class"], config["seccomp_allowed_count"]),
    )

    write_text(out / "tls_floor.env", "TLS_FLOOR_SCORE=%d\n" % config["tls_floor_score"])

    write_text(
        out / "retention_schedule.csv",
        "class,audit_retention_days\n%d,%d\n"
        % (config["active_class"], config["audit_retention_days"]),
    )
    print("sidecars")


def cmd_class_ordering(args):
    state = derive_all()
    entries = [("main", state["config"]["risk_index"])]
    for name in ("canary", "enforce"):
        entries.append((name, profile_config(state, name)["risk_index"]))
    entries.sort(key=lambda e: (e[1], e[0]))
    lines = ["profile\trisk_index"] + ["%s\t%d" % (n, r) for n, r in entries]
    write_text(args.out, "\n".join(lines) + "\n")
    print("ordered")


def esc_xml(value):
    return str(value).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def cmd_audit(args):
    state = derive_all()
    config = state["config"]
    out = Path(args.outdir)

    steps = [
        (
            "class_selection",
            "max_records %d -> selector %d -> class %d"
            % (state["max_records"], state["selector"], state["class"]),
        ),
        (
            "ingress_rate_limit_qps",
            "rhe(%d*%d/1000)=%d quantize %d -> %d"
            % (
                state["qps"],
                state["burst_permille"],
                state["rate_pre"],
                state["rate_step"],
                config["ingress_rate_limit_qps"],
            ),
        ),
        (
            "burst_ceiling",
            "%d*%d=%d"
            % (config["ingress_rate_limit_qps"], state["window"], config["burst_ceiling"]),
        ),
        (
            "effective_scope_count",
            "(base|overlay)-deny = %s -> %d"
            % (",".join(state["effective_scopes"]), config["effective_scope_count"]),
        ),
        (
            "privilege_drop_uid",
            "min granted uid %d floor %d -> %d"
            % (min(state["scope_uids"].values()), state["uid_floor"], config["privilege_drop_uid"]),
        ),
        (
            "hardening_baseline",
            "carry-aware fold %d clamp[%d,%d] quantize %d -> %d"
            % (
                state["fold_raw"],
                state["bounds"][0],
                state["bounds"][1],
                state["hardening_step"],
                config["hardening_baseline"],
            ),
        ),
        (
            "risk_index",
            "rhe((%d-%d)*%d/%d)=%d"
            % (
                state["baseline_complement"],
                config["hardening_baseline"],
                state["severity_permille"],
                state["risk_divisor"],
                config["risk_index"],
            ),
        ),
        (
            "quorum_threshold",
            "rhe(%d*%d/1000) bounded[1,%d] -> %d"
            % (state["voters"], state["quorum_permille"], state["voters"], config["quorum_threshold"]),
        ),
        ("tls_floor_score", "min enabled adopted suite score -> %d" % config["tls_floor_score"]),
        (
            "seccomp_allowed_count",
            "allow %d minus deny %d -> %d"
            % (len(state["seccomp_allow"]), len(state["seccomp_deny"]), config["seccomp_allowed_count"]),
        ),
        ("audit_retention_days", "class retention layer -> %d" % config["audit_retention_days"]),
        (
            "session_ttl_seconds",
            "%s -> %d"
            % (state["precedence"]["session_ttl_seconds"]["source"], config["session_ttl_seconds"]),
        ),
        (
            "nonce_window_ms",
            "%s floor %d -> %d"
            % (
                state["precedence"]["nonce_window_ms"]["source"],
                state["nonce_floor"],
                config["nonce_window_ms"],
            ),
        ),
        (
            "max_concurrent_sessions",
            "%s ceiling %d -> %d"
            % (
                state["precedence"]["max_concurrent_sessions"]["source"],
                state["session_ceiling"],
                config["max_concurrent_sessions"],
            ),
        ),
        (
            "retry_backoff_base_ms",
            "rhe(%d/%d)=%d quantize %d -> %d"
            % (
                state["timeout_ms"],
                state["retry_limit"] + 1,
                state["retry_quotient"],
                state["retry_step"],
                config["retry_backoff_base_ms"],
            ),
        ),
    ]

    xml = ['<?xml version="1.0" encoding="UTF-8"?>', "<derivation_audit>"]
    xml.append("  <active_class>%d</active_class>" % config["active_class"])
    xml.append("  <selector>%d</selector>" % state["selector"])
    xml.append("  <rounding>half-even</rounding>")
    xml.append("  <fields>")
    for key in sorted(config):
        xml.append('    <field name="%s">%s</field>' % (key, esc_xml(config[key])))
    xml.append("  </fields>")
    xml.append("  <steps>")
    for name, detail in steps:
        xml.append('    <step name="%s">%s</step>' % (name, esc_xml(detail)))
    xml.append("  </steps>")
    xml.append("  <trailer>%s</trailer>" % esc_xml(config["trailer"]))
    xml.append("</derivation_audit>")
    write_text(out / "derivation_audit.xml", "\n".join(xml) + "\n")

    conv = [
        "convergence report",
        "arithmetic: exact-integer",
        "rounding: half-even",
        "floating_point_used: no",
        "active_class: %d" % config["active_class"],
        "iterations_to_fixed_point: 1",
        "converged: yes",
        "deterministic: yes",
        "fields:",
    ]
    for key in sorted(config):
        conv.append("  %s = %s" % (key, config[key]))
    conv.append("profiles:")
    for name in ("canary", "enforce"):
        prof = profile_config(state, name)
        conv.append(
            "  %s session_ttl_seconds=%d quorum_threshold=%d risk_index=%d"
            % (name, prof["session_ttl_seconds"], prof["quorum_threshold"], prof["risk_index"])
        )
    write_text(out / "convergence_report.txt", "\n".join(conv) + "\n")

    census = []
    for path in sorted(DATA.iterdir()):
        if not path.is_file():
            continue
        raw = path.read_bytes()
        census.append(
            json.dumps(
                {
                    "bytes": len(raw),
                    "file": path.name,
                    "lines": raw.decode("utf-8", "replace").count("\n"),
                    "sha256": hashlib.sha256(raw).hexdigest(),
                },
                sort_keys=True,
            )
        )
    write_text(out / "input_census.ndjson", "\n".join(census) + "\n")
    print("audited")


def cmd_coverage(args):
    state = derive_all()
    config = load_json(args.config)
    schema = load_json(args.schema)
    rules = load_json(DATA / "validation_rules.json")
    out = Path(args.outdir)
    required = [k.strip() for k in schema["required_keys"].split(",") if k.strip()]

    # The coverage/manifest artifacts are written after this check runs, so they
    # are reported as deferred; measuring them here would not be reproducible.
    deferred = {"validation_report.json", "summary.json", "reproducibility_manifest.json"}
    artifacts = {}
    for name in rules["required_artifacts"]:
        path = out / name
        if name in deferred:
            artifacts[name] = {"emitted_after_check": True}
            continue
        artifacts[name] = {
            "bytes": path.stat().st_size if path.exists() else 0,
            "present": path.exists(),
        }
    missing = [k for k in required if k not in config]
    extra = [k for k in config if k not in required]
    nonscalar = [k for k, v in config.items() if isinstance(v, (dict, list))]
    forbidden = [k for k in rules["forbidden_keys"] if k in config]
    ok = not missing and not nonscalar and not forbidden and config == state["config"]

    report = {
        "checks": {
            "all_required_keys_present": not missing,
            "flat_scalar_only": not nonscalar,
            "no_forbidden_keys": not forbidden,
            "trailer_intact": config.get("trailer") == state["config"]["trailer"],
            "values_match_derivation": config == state["config"],
        },
        "extra_keys": sorted(extra),
        "forbidden_keys_present": forbidden,
        "missing_keys": missing,
        "non_scalar_keys": sorted(nonscalar),
        "ok": ok,
        "required_artifacts": artifacts,
        "required_key_count": len(required),
    }
    write_json(out / "validation_report.json", report)

    summary = {
        "active_class": config["active_class"],
        "artifact_count": len(rules["required_artifacts"]),
        "config": config,
        "effective_scopes": state["effective_scopes"],
        "hardening_fold_raw": state["fold_raw"],
        "healthy_voters": state["voters"],
        "ok": ok,
        "profiles": {name: profile_config(state, name) for name in ("canary", "enforce")},
        "rounding": "half-even",
        "seccomp_effective": state["seccomp_effective"],
        "trailer": config["trailer"],
    }
    write_json(out / "summary.json", summary)
    print("covered")


def cmd_package(args):
    root = Path(args.root)
    with zipfile.ZipFile(args.out, "w", zipfile.ZIP_DEFLATED) as zf:
        for name in TOOL_FILES:
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            zf.writestr(info, (root / name).read_bytes())
    print("packaged")


def cmd_manifest(args):
    out = Path(args.outdir)
    self_name = Path(args.out).name
    entries = {
        path.name: {"bytes": path.stat().st_size, "sha256": sha256_file(path)}
        for path in sorted(out.iterdir())
        if path.is_file() and path.name != self_name
    }
    inputs = {
        path.name: sha256_file(path) for path in sorted(DATA.iterdir()) if path.is_file()
    }
    manifest = {
        "algorithm": "sha256",
        "arithmetic": "exact-integer-round-half-even",
        "artifacts": entries,
        "deterministic": True,
        "inputs": inputs,
        "self_excluded": self_name,
        "tool": "task-ctl",
    }
    write_json(args.out, manifest)
    print("manifested")


def cmd_init(args):
    schema = load_json(args.schema)
    data = {
        "checksum": schema["checksum"],
        "control_plane": schema["control_plane"],
        "image_runtime": schema["image_runtime"],
        "mode": schema["mode"],
        "profile": schema["profile"],
    }
    write_json(args.out, data)
    print("initialized")


def cmd_set(args):
    data = load_json(args.config)
    raw = args.value.strip()
    if re.fullmatch(r"-?\d+", raw):
        value = int(raw)
    else:
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            parsed = args.value
        if isinstance(parsed, (dict, list)):
            raise SystemExit("value must be scalar: " + args.key)
        if isinstance(parsed, float):
            raise SystemExit("floating point values are not permitted: " + args.key)
        value = args.value
    data[args.key] = value
    write_json(args.config, data)
    print("set")


def cmd_validate(args):
    schema = load_json(args.schema)
    data = load_json(args.config)
    required = [k.strip() for k in schema["required_keys"].split(",") if k.strip()]
    missing = [k for k in required if k not in data]
    if missing:
        raise SystemExit("missing: " + ",".join(missing))
    bad = [k for k, v in data.items() if isinstance(v, (dict, list))]
    if bad:
        raise SystemExit("configuration must be flat: " + ",".join(sorted(bad)))
    floats = [k for k, v in data.items() if isinstance(v, float)]
    if floats:
        raise SystemExit("floating point values present: " + ",".join(sorted(floats)))
    print("ok")


def cmd_report(args):
    data = load_json(args.config)
    commands_path = Path(args.commands)
    commands = json.loads(
        commands_path.read_text() if commands_path.exists() else args.commands
    )
    actual = hashlib.sha256(Path(args.config).read_bytes()).hexdigest()
    report = {
        "commands": commands,
        "config": data,
        "config_sha256": actual,
        "digest_matches": actual == args.digest,
        "ok": actual == args.digest,
        "tool": "task-ctl",
        "trailer": data["trailer"],
    }
    write_json(args.out, report)
    print("reported")


def main():
    parser = argparse.ArgumentParser(prog="task-ctl")
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("derive")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_derive)

    p = sub.add_parser("profile")
    p.add_argument("--name", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_profile)

    p = sub.add_parser("profile-delta")
    p.add_argument("--config", required=True)
    p.add_argument("--canary", required=True)
    p.add_argument("--enforce", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_profile_delta)

    p = sub.add_parser("sidecars")
    p.add_argument("--config", required=True)
    p.add_argument("--outdir", required=True)
    p.set_defaults(func=cmd_sidecars)

    p = sub.add_parser("class-ordering")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_class_ordering)

    p = sub.add_parser("audit")
    p.add_argument("--config", required=True)
    p.add_argument("--outdir", required=True)
    p.set_defaults(func=cmd_audit)

    p = sub.add_parser("coverage")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--outdir", required=True)
    p.set_defaults(func=cmd_coverage)

    p = sub.add_parser("package")
    p.add_argument("--root", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_package)

    p = sub.add_parser("manifest")
    p.add_argument("--outdir", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_manifest)

    p = sub.add_parser("init")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("export-report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest", required=True)
    p.add_argument("--commands", required=True)
    p.set_defaults(func=cmd_report)

    args = parser.parse_args()
    if not getattr(args, "command", None):
        parser.print_help()
        return
    args.func(args)


if __name__ == "__main__":
    main()
