# task-ctl

An offline container-image admission-control hardening compiler for a
server-side admission broker. It reads interacting numeric policy layers from
`/app/data`, selects the active enforcement class, and derives one flat hardened
admission configuration plus two deployment profiles (canary and enforce).

This build is repaired: the class selection, threshold/rate-limit, privilege/scope
reconciliation, hardening-baseline fold, risk-scoring and quorum, and
policy-precedence steps now agree with the documented contract recorded across the
policy layers, and the command surface is complete.

## Repaired derivation rules

- Active class: the base budget `max_records` is reduced into the adopted
  selector span of `class_index.tsv2` and mapped to the covering class row.
- Ingress rate limit: adopted per-class qps scaled by the adopted burst permille
  (round-half-even) and quantized down to the adopted rate granularity; the burst
  ceiling is the resolved rate limit times the adopted class window.
- Scopes: (base ∪ overlay) − deny over adopted rows of the active class; the
  privilege-drop uid is the minimum granted scope uid raised to the class floor.
- Hardening: adopted controls are folded in ascending order; a control whose
  `carry_flag` is set carries half its weight (round-half-even) into the next
  adopted control.  The fold is clamped to the class bounds and quantized.
- Risk index: `(BASELINE_COMPLEMENT - hardening_baseline) * severity_permille /
  RISK_DIVISOR`, round-half-even.
- Quorum: healthy adopted voters scaled by the adopted quorum permille,
  round-half-even, bounded to `[1, voters]`.
- Precedence: `layer_defaults` < `layer_overrides` < `pinned_overrides`
  (only when `pinned` is true), then the nonce floor and session ceiling bounds.
- Retry backoff: `timeout_ms / (retry_limit + 1)` round-half-even, quantized down
  to the adopted retry step.

## Commands

- `init --schema <schema> --out <config>`: seed fixed contract strings.
- `set --config <config> --key <key> --value <value>`: set one scalar key with
  correct case and type coercion; reject any non-scalar value.
- `validate --schema <schema> --config <config>`: confirm every required key is
  present and the configuration is flat; print `ok`.
- `export-report --config <config> --out <report> --digest <sha256> --commands <json>`:
  emit a truthful command transcript.
- `derive --out <config>`: compile the flat hardened configuration.
- `profile --name <canary|enforce> --config <config> --out <profile>`: apply the
  documented per-profile deltas.
- `profile-delta --config <config> --canary <p> --enforce <p> --out <report>`:
  emit the signed deltas versus the main configuration.
- `sidecars --config <config> --outdir <dir>`: emit the derivation sidecars.
- `class-ordering --config <config> --out <tsv>`: rank profiles by risk index.
- `audit --config <config> --outdir <dir>`: emit audit and provenance artifacts.
- `coverage --schema <schema> --config <config> --outdir <dir>`: emit the
  validation and summary coverage artifacts.
- `package --root <dir> --out <zip>`: repackage the tool deterministically.
- `manifest --outdir <dir> --out <json>`: emit the reproducibility manifest.

## Contract notes

- Every value is derived with exact integer arithmetic (round-half-even); no
  floating-point value may reach a graded key.
- The configuration is flat: keys map directly to integer or string scalars.
- The required key set is authoritative in `schema.json` and mirrored by the
  field registry in the policy layers.
- Only rows whose status is `ADOPTED` for the active enforcement class bind; rows
  labelled `SUPERSEDED`, `DRAFT`, `SHADOW`, or `REVOKED` are context decoys.
