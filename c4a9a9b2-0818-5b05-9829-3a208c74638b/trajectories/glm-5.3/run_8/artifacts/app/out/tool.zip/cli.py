#!/usr/bin/env python3
"""task-ctl: local admission-control hardening compiler (repaired).

Compiles one flat hardened admission configuration for the active enforcement
class from the interacting numeric policy layers under /app/data, plus the
canary/enforce deployment profiles and the derivation/audit/coverage sidecars.

All arithmetic on graded values is exact integer arithmetic; rounding is
round-half-even (banker's) and no floating-point value ever touches a graded
key.  Only rows whose status is ADOPTED for the active class bind; every other
status label (SUPERSEDED, DRAFT, SHADOW, REVOKED) is a decoy.
"""
from __future__ import annotations

import argparse
import configparser
import hashlib
import json
import re
from pathlib import Path

DATA = Path("/app/data")
ADOPTED = "ADOPTED"
PRECEDENCE_FIELDS = ("session_ttl_seconds", "nonce_window_ms", "max_concurrent_sessions")
HARDENING_QUANT = 5


# ---------------------------------------------------------------- helpers ---

def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def dump_json(path, obj):
    """Deterministic JSON: sorted keys, stable separators, trailing newline."""
    Path(path).write_text(
        json.dumps(obj, sort_keys=True, separators=(",", ":")) + "\n", encoding="utf-8"
    )


def write_text(path, text):
    if not text.endswith("\n"):
        text += "\n"
    Path(path).write_text(text, encoding="utf-8")


def read_lines(name):
    out = []
    for line in (DATA / name).read_text(encoding="utf-8", errors="replace").split("\n"):
        s = line.strip()
        if not s or s.startswith("#") or s.startswith(";"):
            continue
        out.append(line)
    return out


def delimited_rows(name, sep):
    lines = read_lines(name)
    if not lines:
        return []
    header = [c.strip() for c in lines[0].split(sep) if c.strip()]
    rows = []
    for line in lines[1:]:
        parts = [c.strip() for c in line.split(sep) if c.strip()]
        if len(parts) != len(header):
            continue
        rows.append(dict(zip(header, parts)))
    return rows


def round_half_even(num, den):
    """Exact integer round-half-even of num/den (den > 0). No floats."""
    if den <= 0:
        raise ValueError("denominator must be positive")
    neg = num < 0
    n = -num if neg else num
    q, r = divmod(n, den)
    twice = 2 * r
    if twice > den or (twice == den and q % 2 == 1):
        q += 1
    return -q if neg else q


def quantize_floor(value, step):
    return (value // step) * step


def clamp(value, lo, hi):
    return max(lo, min(hi, value))


def sha256_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


# ------------------------------------------------------------ INI / TOML ----

def ini_sections(name):
    """Parse a flat INI/TOML-lite file into {section: {key: value}}."""
    cp = configparser.ConfigParser(interpolation=None, strict=False)
    cp.optionxform = str
    cp.read_string((DATA / name).read_text(encoding="utf-8", errors="replace"))
    return {sect: {k: v.strip().strip('"') for k, v in cp.items(sect)}
            for sect in cp.sections()}


def adopted_class_section(sections, klass):
    """Return the ADOPTED [class.<k>] block (shadow/draft blocks are decoys)."""
    key = "class.%d" % klass
    if key not in sections:
        raise SystemExit("no class section for %r" % key)
    return sections[key]


# -------------------------------------------------------------- selectors ---

def base_inputs():
    base = load_json(DATA / "defaults.json")["base_config"]
    return (
        int(base["max_records"]),
        int(base["retry_limit"]),
        int(base["timeout_ms"]),
        str(base["trailer"]),
    )


def layer_defaults():
    return dict(load_json(DATA / "defaults.json")["layer_defaults"])


def active_class(max_records, retry_limit):
    """Active class from the documented base budget rule.

    class = ((max_records // 37) + 3 * retry_limit) % 5, taken from the base
    budget in defaults.json -- never from the first row of any table.  The
    class_index.tsv2 selector bands are then consulted (ADOPTED rows only) as
    a consistency gate: the selected class must be one the index marks
    ADOPTED.
    """
    klass = ((max_records // 37) + 3 * retry_limit) % 5
    adopted_classes = {
        int(row["class_id"])
        for row in delimited_rows("class_index.tsv2", "\t")
        if row.get("status") == ADOPTED
    }
    if klass not in adopted_classes:
        raise SystemExit("class %d is not ADOPTED in class_index.tsv2" % klass)
    return klass


# ---------------------------------------------------------------- ingress ---

def ingress_layers(klass):
    """Per-class throughput, burst factor, window and rate step (ADOPTED only)."""
    qps = None
    for row in delimited_rows("ingress_rate.tsv", "\t"):
        if row.get("status") != ADOPTED or int(row["class_id"]) != klass:
            continue
        qps = int(row["ingress_qps"])
        break
    if qps is None:
        raise SystemExit("no ADOPTED ingress row for class %d" % klass)

    burst = adopted_class_section(ini_sections("burst_multiplier.ini"), klass)
    permille = int(burst["burst_multiplier_permille"])
    window = int(burst["window_seconds"])

    step = None
    for row in delimited_rows("rate_gran.caret", "^"):
        if row.get("status") != ADOPTED or int(row["class_id"]) != klass:
            continue
        step = int(row["gran"])
        break
    if step is None:
        raise SystemExit("no ADOPTED rate step for class %d" % klass)
    return qps, permille, window, step


def derive_rate_limits(qps, permille, window, step):
    """rate = quantize(qps * burst_permille / 1000, step); burst = rate * window."""
    rate_pre = round_half_even(qps * permille, 1000)
    rate_limit = quantize_floor(rate_pre, step)
    burst_ceiling = rate_limit * window
    return rate_pre, rate_limit, burst_ceiling


# ----------------------------------------------------------------- scopes ---

def scope_layers(klass):
    base, overlay, deny = set(), set(), set()
    for line in read_lines("scope_base.jsonl"):
        obj = json.loads(line)
        if obj.get("status") == ADOPTED and int(obj["class_id"]) == klass:
            base.add(str(obj["scope"]))
    for line in read_lines("scope_overlay.ndjson"):
        obj = json.loads(line)
        if obj.get("status") == ADOPTED and int(obj["class_id"]) == klass:
            overlay.add(str(obj["scope"]))
    for row in delimited_rows("scope_deny.psv", "|"):
        if row.get("status") != ADOPTED or int(row["class_id"]) != klass:
            continue
        deny.add(str(row["scope"]))
    return base, overlay, deny


def scope_uid_map():
    """SCOPE_<NAME>=<uid> pairs only; UID_DECOY_* and NOTE_* lines are traps."""
    out = {}
    for line in read_lines("uid_map.env"):
        key, _, val = line.strip().partition("=")
        if key.startswith("SCOPE_") and val.strip().isdigit():
            out[key[len("SCOPE_"):].lower()] = int(val.strip())
    return out


def uid_floor(klass):
    for row in delimited_rows("uid_floor.hex", ":"):
        if row.get("status") != ADOPTED or int(row["class_id"]) != klass:
            continue
        return int(row["floor_hex"], 16)
    raise SystemExit("no ADOPTED uid floor for class %d" % klass)


def reconcile_scopes(klass):
    """effective = (base UNION overlay) MINUS deny, for the active class only."""
    base, overlay, deny = scope_layers(klass)
    effective = sorted((base | overlay) - deny)
    uids = scope_uid_map()
    floor = uid_floor(klass)
    granted = [(s, uids[s]) for s in effective if s in uids and uids[s] >= floor]
    if not granted:
        raise SystemExit("no granted uid >= floor %d for class %d" % (floor, klass))
    return {
        "base": sorted(base),
        "overlay": sorted(overlay),
        "deny": sorted(deny),
        "effective": effective,
        "effective_scope_count": len(effective),
        "uid_floor": floor,
        "privilege_drop_uid": min(uid for _, uid in granted),
        "scope_uids": {s: uids.get(s) for s in effective},
        "granted": granted,
    }


# -------------------------------------------------------------- hardening ---

def adopted_controls(klass):
    rows = [
        r for r in delimited_rows("baseline_controls.scsv", ";")
        if r.get("status") == ADOPTED and str(r.get("class_id")).strip() == str(klass)
    ]
    rows.sort(key=lambda r: int(r["order"]))
    return rows


def fold_controls(rows):
    """Carry-aware fold over consecutive adopted controls.

    A carry flag on a control adds half of the previous adopted control's
    contribution (exact integer halving, truncated toward zero) on top of the
    control's own weight.
    """
    trace = []
    running = 0
    prev_inc = 0
    for r in rows:
        weight = int(r["weight"])
        carry = int(r["carry_flag"])
        inc = weight + (prev_inc // 2 if carry else 0)
        running += inc
        prev_inc = inc
        trace.append({
            "order": int(r["order"]),
            "control_id": r["control_id"],
            "weight": weight,
            "carry": carry,
            "status": r["status"],
            "running": running,
        })
    return trace, running


def hardening_bounds(klass):
    sect = adopted_class_section(ini_sections("hardening_bounds.toml"), klass)
    return int(sect["floor"]), int(sect["ceil"])


def derive_hardening(klass):
    trace, raw = fold_controls(adopted_controls(klass))
    floor, ceil = hardening_bounds(klass)
    clamped = clamp(raw, floor, ceil)
    return {
        "trace": trace,
        "raw": raw,
        "floor": floor,
        "ceil": ceil,
        "clamped": clamped,
        "baseline": quantize_floor(clamped, HARDENING_QUANT),
    }


def risk_constants():
    consts = {}
    for line in read_lines("risk_const.env2"):
        key, _, val = line.strip().partition("=")
        if val.strip().isdigit():
            consts[key] = int(val.strip())
    return consts


def severity_permille(klass):
    """ADOPTED severity weight; rows are `class<N>:<permille>:<status>`."""
    for line in read_lines("severity_weight.kv"):
        parts = [p.strip() for p in line.strip().split(":")]
        if len(parts) != 3 or parts[2] != ADOPTED:
            continue
        if parts[0] != "class%d" % klass:
            continue
        return int(parts[1])
    raise SystemExit("no ADOPTED severity weight for class %d" % klass)


def derive_risk(baseline, severity, complement, divisor):
    return round_half_even((complement - baseline) * severity, divisor)


# ----------------------------------------------------------------- quorum ---

def quorum_permille(klass):
    for row in delimited_rows("quorum_permille.tilde", "~"):
        if row.get("status") != ADOPTED or int(row["class_id"]) != klass:
            continue
        return int(row["permille"])
    raise SystemExit("no ADOPTED quorum permille for class %d" % klass)


def healthy_voters(klass):
    voters = []
    for line in read_lines("voter_health.ndjson"):
        obj = json.loads(line)
        if str(obj.get("class_id")) != str(klass):
            continue
        if obj.get("status") != ADOPTED or obj.get("healthy") is not True:
            continue
        voters.append(str(obj["voter_id"]))
    return sorted(voters)


def derive_quorum(klass):
    voters = healthy_voters(klass)
    permille = quorum_permille(klass)
    count = len(voters)
    return {
        "voters": voters,
        "count": count,
        "permille": permille,
        "quorum": clamp(round_half_even(count * permille, 1000), 1, count),
    }


# -------------------------------------------------- tls / seccomp / audit ---

def tls_floor_score(klass):
    """Floor score among ADOPTED *enabled* suites for the active class."""
    scores = [
        int(row["score"])
        for row in delimited_rows("tls_matrix.csv", ",")
        if row.get("status") == ADOPTED
        and int(row["class_id"]) == klass
        and str(row.get("enabled", "true")).strip().lower() == "true"
    ]
    if not scores:
        raise SystemExit("no ADOPTED enabled TLS suite for class %d" % klass)
    return min(scores)


def seccomp_layers(klass):
    allowed, denied = set(), set()
    for row in delimited_rows("seccomp_allow.tsv", "\t"):
        if row.get("status") == ADOPTED and int(row["class_id"]) == klass:
            allowed.add(row["syscall"])
    for row in delimited_rows("seccomp_deny.psv", "|"):
        if row.get("status") == ADOPTED and int(row["class_id"]) == klass:
            denied.add(row["syscall"])
    return allowed, denied


def ledger_allows(klass):
    allows, denies = set(), set()
    for row in delimited_rows("seccomp_ledger.scsv2", ";;"):
        if row.get("status") != ADOPTED or int(row["class_id"]) != klass:
            continue
        if row["action"] == "allow":
            allows.add(row["syscall"])
        elif row["action"] == "deny":
            denies.add(row["syscall"])
    return allows, denies


def seccomp_allowed(klass):
    """ADOPTED allow entries reduced by ADOPTED deny entries (both sources)."""
    allowed, denied = seccomp_layers(klass)
    la, ld = ledger_allows(klass)
    return sorted((allowed | la) - (denied | ld))


def audit_retention_days(klass):
    return int(adopted_class_section(ini_sections("retention.ini"), klass)["retention_days"])


# ------------------------------------------------------------- precedence ---

def session_cap_ceil(klass):
    for row in delimited_rows("sessions_cap.csv2", ","):
        if row.get("status") == ADOPTED and int(row["class_id"]) == klass:
            return int(row["abs_ceil"])
    raise SystemExit("no ADOPTED session cap ceiling for class %d" % klass)


def nonce_floor_ms(klass):
    return int(adopted_class_section(ini_sections("nonce_bounds.toml2"), klass)["floor_ms"])


def resolve_precedence(klass):
    """base defaults < class override layer < pinned layer (only when pinned)."""
    defaults = layer_defaults()
    overrides = load_json(DATA / "layer_overrides.json").get("class_%d" % klass, {})
    pinned_entry = load_json(DATA / "pinned_overrides.json").get("class_%d" % klass, {})
    pinned = pinned_entry.get("pinned") is True
    resolution = {}
    for field in PRECEDENCE_FIELDS:
        value = int(defaults[field])
        if field in overrides:
            value = int(overrides[field])
        if pinned and field in pinned_entry:
            value = int(pinned_entry[field])
        resolution[field] = {
            "default": int(defaults[field]),
            "override": int(overrides.get(field, defaults[field])),
            "pinned_applied": pinned,
            "resolved": value,
        }
    cap_ceil = session_cap_ceil(klass)
    nonce_floor = nonce_floor_ms(klass)
    resolution["max_concurrent_sessions"]["abs_ceil"] = cap_ceil
    resolution["max_concurrent_sessions"]["resolved"] = min(
        resolution["max_concurrent_sessions"]["resolved"], cap_ceil)
    resolution["nonce_window_ms"]["floor_ms"] = nonce_floor
    resolution["nonce_window_ms"]["resolved"] = max(
        resolution["nonce_window_ms"]["resolved"], nonce_floor)
    return resolution


def retry_backoff_base(timeout_ms, retry_limit, klass):
    step = None
    for row in delimited_rows("retry_backoff.psv2", "||"):
        if row.get("status") != ADOPTED or int(row["class_id"]) != klass:
            continue
        step = int(row["step"])
        break
    if step is None:
        raise SystemExit("no ADOPTED retry step for class %d" % klass)
    raw = timeout_ms * (retry_limit + 1)
    return raw, step, quantize_floor(raw, step)


# ------------------------------------------------------------- derivation ---

def derive():
    max_records, retry_limit, timeout_ms, trailer = base_inputs()
    klass = active_class(max_records, retry_limit)

    qps, permille, window, step = ingress_layers(klass)
    rate_pre, rate_limit, burst_ceiling = derive_rate_limits(qps, permille, window, step)

    scopes = reconcile_scopes(klass)
    hard = derive_hardening(klass)
    consts = risk_constants()
    complement = int(consts["BASELINE_COMPLEMENT"])
    divisor = int(consts["RISK_DIVISOR"])
    severity = severity_permille(klass)

    quorum = derive_quorum(klass)
    tls = tls_floor_score(klass)
    seccomp = seccomp_allowed(klass)
    retention = audit_retention_days(klass)
    precedence = resolve_precedence(klass)
    retry_raw, retry_step, retry_backoff = retry_backoff_base(timeout_ms, retry_limit, klass)

    schema = load_json(DATA / "config_schema.json")
    config = {
        "active_class": klass,
        "audit_retention_days": retention,
        "burst_ceiling": burst_ceiling,
        "checksum": schema["checksum"],
        "control_plane": schema["control_plane"],
        "effective_scope_count": scopes["effective_scope_count"],
        "enforcement_profile": "main",
        "hardening_baseline": hard["baseline"],
        "image_runtime": schema["image_runtime"],
        "ingress_rate_limit_qps": rate_limit,
        "max_concurrent_sessions": precedence["max_concurrent_sessions"]["resolved"],
        "mode": schema["mode"],
        "nonce_window_ms": precedence["nonce_window_ms"]["resolved"],
        "privilege_drop_uid": scopes["privilege_drop_uid"],
        "profile": schema["profile"],
        "quorum_threshold": quorum["quorum"],
        "retry_backoff_base_ms": retry_backoff,
        "risk_index": derive_risk(hard["baseline"], severity, complement, divisor),
        "seccomp_allowed_count": len(seccomp),
        "session_ttl_seconds": precedence["session_ttl_seconds"]["resolved"],
        "tls_floor_score": tls,
        "trailer": trailer,
    }
    config["risk_index"] = derive_risk(hard["baseline"], severity, complement, divisor)
    return {
        "config": config,
        "klass": klass,
        "selector": max_records * retry_limit,
        "max_records": max_records,
        "retry_limit": retry_limit,
        "timeout_ms": timeout_ms,
        "qps": qps,
        "burst_permille": permille,
        "window_seconds": window,
        "rate_step": step,
        "rate_pre_quantized": rate_pre,
        "scopes": scopes,
        "hardening": hard,
        "risk": {
            "complement": complement,
            "divisor": divisor,
            "severity": severity,
            "risk_index": config["risk_index"],
        },
        "quorum": quorum,
        "tls_floor_score": tls,
        "seccomp": seccomp,
        "retention": retention,
        "precedence": precedence,
        "retry": {"raw": retry_raw, "step": retry_step, "backoff": retry_backoff},
    }


# -------------------------------------------------------------- profiles ----

def profile_deltas():
    raw = load_json(DATA / "profile_deltas.json")
    return {k: v for k, v in raw.items() if not k.startswith("_")}


def apply_profile(name, deltas, ctx):
    base = ctx["config"]
    ttl_scale = int(deltas["ttl_scale_permille"])
    quorum_delta = int(deltas["quorum_delta"])
    risk_delta = int(deltas["risk_delta"])
    ttl = round_half_even(base["session_ttl_seconds"] * ttl_scale, 1000)
    quorum = clamp(base["quorum_threshold"] + quorum_delta, 1, ctx["quorum"]["count"])
    cfg = dict(base)
    cfg["profile"] = name
    cfg["enforcement_profile"] = name
    cfg["session_ttl_seconds"] = ttl
    cfg["quorum_threshold"] = quorum
    cfg["risk_index"] = base["risk_index"] + risk_delta
    delta = {
        "profile": name,
        "quorum_threshold": {
            "base": base["quorum_threshold"],
            "delta": quorum_delta,
            "resolved": quorum,
        },
        "risk_index": {
            "base": base["risk_index"],
            "delta": risk_delta,
            "resolved": cfg["risk_index"],
        },
        "session_ttl_seconds": {
            "base": base["session_ttl_seconds"],
            "scale_permille": ttl_scale,
            "resolved": ttl,
        },
    }
    return cfg, delta


# -------------------------------------------------------------- sidecars ----

def emit_rate_limit_plan(out, ctx):
    cfg = ctx["config"]
    write_text(out, "\n".join([
        "[rate]",
        "class = %s" % cfg["active_class"],
        "ingress_rate_limit_qps = %d" % cfg["ingress_rate_limit_qps"],
        "burst_ceiling = %d" % cfg["burst_ceiling"],
    ]))


def emit_hardening_fold_trace(out, ctx):
    lines = ["order|control_id|weight|carry|status|running"]
    for row in ctx["hardening"]["trace"]:
        lines.append("%d|%s|%d|%d|%s|%d" % (
            row["order"], row["control_id"], row["weight"],
            row["carry"], row["status"], row["running"]))
    write_text(out, "\n".join(lines))


def emit_quorum_plan(out, ctx):
    q = ctx["quorum"]
    write_text(out, "healthy_voters:%d\nquorum_threshold:%d" % (q["count"], q["quorum"]))


def emit_risk_ledger(out, ctx):
    cfg = ctx["config"]
    write_text(out, "\n".join([
        "HARDENING_BASELINE=%d" % cfg["hardening_baseline"],
        "RISK_INDEX=%d" % cfg["risk_index"],
        "SEVERITY_PERMILLE=%d" % ctx["risk"]["severity"],
    ]))


def emit_precedence_resolution(out, ctx):
    prec = ctx["precedence"]
    lines = []
    for field in PRECEDENCE_FIELDS:
        lines.append("%s.default=%d" % (field, prec[field]["default"]))
        lines.append("%s.resolved=%d" % (field, prec[field]["resolved"]))
    write_text(out, "\n".join(lines))


def emit_privilege_map(out, ctx):
    lines = [
        json.dumps({"scope": s, "uid": ctx["scopes"]["scope_uids"][s]}, sort_keys=True)
        for s in ctx["scopes"]["effective"]
    ]
    write_text(out, "\n".join(lines))


def emit_seccomp_summary(out, ctx):
    cfg = ctx["config"]
    write_text(out, "class\tseccomp_allowed_count\n%d\t%d"
               % (cfg["active_class"], cfg["seccomp_allowed_count"]))


def emit_tls_floor(out, ctx):
    write_text(out, "TLS_FLOOR_SCORE=%d" % ctx["config"]["tls_floor_score"])


def emit_scope_reconciliation(out, ctx):
    sc = ctx["scopes"]
    k = ctx["klass"]
    lines = ["class\tlayer\tscope\tstatus"]
    for s in sc["base"]:
        lines.append("%d\tbase\t%s\t%s" % (k, s, ADOPTED))
    for s in sc["overlay"]:
        lines.append("%d\toverlay\t%s\t%s" % (k, s, ADOPTED))
    for s in sc["deny"]:
        lines.append("%d\tdeny\t%s\t%s" % (k, s, ADOPTED))
    for s in sc["effective"]:
        lines.append("%d\teffective\t%s\t%s" % (k, s, ADOPTED))
    lines.append("%d\teffective_scope_count\t%d\t%s" % (k, sc["effective_scope_count"], ADOPTED))
    lines.append("%d\tprivilege_drop_uid\t%d\t%s" % (k, sc["privilege_drop_uid"], ADOPTED))
    write_text(out, "\n".join(lines))


def emit_admission_matrix(out, ctx):
    cfg = ctx["config"]
    lines = ["class,field,value"]
    for key in sorted(cfg):
        lines.append("%d,%s,%s" % (cfg["active_class"], key, cfg[key]))
    write_text(out, "\n".join(lines))


def emit_retention_schedule(out, ctx):
    cfg = ctx["config"]
    write_text(out, "class,audit_retention_days\n%d,%d"
               % (cfg["active_class"], cfg["audit_retention_days"]))


# -------------------------------------------------------- audit artifacts ---

def xml_escape(v):
    return (str(v).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


def emit_derivation_audit(out, ctx):
    cfg = ctx["config"]
    sc = ctx["scopes"]
    hard = ctx["hardening"]
    q = ctx["quorum"]
    prec = ctx["precedence"]
    r = ctx["risk"]
    retry = ctx["retry"]
    lines = ['<?xml version="1.0" encoding="UTF-8"?>', "<derivationAudit>"]
    lines.append("  <activeClass>%d</activeClass>" % cfg["active_class"])
    lines.append('  <selector value="%d" formula="max_records * retry_limit" '
                 'maxRecords="%d" retryLimit="%d" source="class_index.tsv2" binding="ADOPTED"/>'
                 % (ctx["selector"], ctx["max_records"], ctx["retry_limit"]))
    lines.append('  <ingressRate qps="%d" burstPermille="%d" preQuantized="%d" '
                 'rateStep="%d" rateLimit="%d" windowSeconds="%d" burstCeiling="%d"/>'
                 % (ctx["qps"], ctx["burst_permille"], ctx["rate_pre_quantized"],
                    ctx["rate_step"], cfg["ingress_rate_limit_qps"], ctx["window_seconds"],
                    cfg["burst_ceiling"]))
    lines.append('  <scopeReconciliation base="%d" overlay="%d" deny="%d" effective="%d" '
                 'privilegeDropUid="%d" uidFloor="%d">'
                 % (len(sc["base"]), len(sc["overlay"]), len(sc["deny"]),
                    sc["effective_scope_count"], cfg["privilege_drop_uid"], sc["uid_floor"]))
    for s in sc["effective"]:
        lines.append('    <effectiveScope name="%s" uid="%d" granted="true"/>'
                     % (xml_escape(s), sc["scope_uids"][s]))
    lines.append("  </scopeReconciliation>")
    lines.append('  <hardeningFold raw="%d" floor="%d" ceil="%d" clamped="%d" quantum="%d" '
                 'baseline="%d">' % (hard["raw"], hard["floor"], hard["ceil"],
                                     hard["clamped"], HARDENING_QUANT, hard["baseline"]))
    for row in hard["trace"]:
        lines.append('    <control order="%d" id="%s" weight="%d" carry="%d" status="%s" '
                     'running="%d"/>' % (row["order"], xml_escape(row["control_id"]),
                                         row["weight"], row["carry"], row["status"],
                                         row["running"]))
    lines.append("  </hardeningFold>")
    lines.append('  <risk baselineComplement="%d" severityPermille="%d" divisor="%d" '
                 'riskIndex="%d"/>' % (r["complement"], r["severity"], r["divisor"], r["risk_index"]))
    lines.append('  <quorum healthyVoters="%d" permille="%d" threshold="%d" lowerBound="1" '
                 'upperBound="%d"/>' % (q["count"], q["permille"], q["quorum"], q["count"]))
    lines.append('  <tlsFloor score="%d" binding="enabled+ADOPTED"/>' % cfg["tls_floor_score"])
    lines.append('  <seccomp allowedCount="%d"/>' % cfg["seccomp_allowed_count"])
    lines.append('  <auditRetention days="%d"/>' % cfg["audit_retention_days"])
    for field in PRECEDENCE_FIELDS:
        e = prec[field]
        lines.append('  <precedence field="%s" default="%d" override="%d" pinnedApplied="%s" '
                     'resolved="%d"/>' % (field, e["default"], e["override"],
                                          str(e["pinned_applied"]).lower(), e["resolved"]))
    lines.append('  <retryBackoff timeoutMs="%d" retryLimit="%d" raw="%d" step="%d" base="%d"/>'
                 % (ctx["timeout_ms"], ctx["retry_limit"], retry["raw"], retry["step"],
                    retry["backoff"]))
    lines.append("  <trailer>%s</trailer>" % xml_escape(cfg["trailer"]))
    lines.append("</derivationAudit>")
    write_text(out, "\n".join(lines))


def emit_convergence_report(out, ctx):
    cfg = ctx["config"]
    write_text(out, "\n".join([
        "convergence report",
        "==================",
        "active_class=%d" % cfg["active_class"],
        "selector=%d" % ctx["selector"],
        "ingress_rate_limit_qps=%d" % cfg["ingress_rate_limit_qps"],
        "burst_ceiling=%d" % cfg["burst_ceiling"],
        "effective_scope_count=%d" % cfg["effective_scope_count"],
        "privilege_drop_uid=%d" % cfg["privilege_drop_uid"],
        "hardening_baseline=%d" % cfg["hardening_baseline"],
        "risk_index=%d" % cfg["risk_index"],
        "quorum_threshold=%d" % cfg["quorum_threshold"],
        "tls_floor_score=%d" % cfg["tls_floor_score"],
        "seccomp_allowed_count=%d" % cfg["seccomp_allowed_count"],
        "audit_retention_days=%d" % cfg["audit_retention_days"],
        "session_ttl_seconds=%d" % cfg["session_ttl_seconds"],
        "nonce_window_ms=%d" % cfg["nonce_window_ms"],
        "max_concurrent_sessions=%d" % cfg["max_concurrent_sessions"],
        "retry_backoff_base_ms=%d" % cfg["retry_backoff_base_ms"],
        "trailer=%s" % cfg["trailer"],
        "status=converged",
    ]))


def input_digests():
    return [{"file": p.name, "sha256": sha256_file(p)}
            for p in sorted(DATA.iterdir(), key=lambda p: p.name)
            if p.is_file() and p.name != "tool.zip"]


def emit_reproducibility_manifest(out, outdir):
    entries = [
        {"artifact": p.name, "sha256": sha256_file(p)}
        for p in sorted(Path(outdir).iterdir(), key=lambda p: p.name)
        if p.is_file() and p.name != Path(out).name
    ]
    dump_json(out, {
        "digest_algorithm": "sha256",
        "rounding": "round-half-even (integer arithmetic only)",
        "artifacts": entries,
        "inputs": input_digests(),
    })


def emit_input_census(out, ctx):
    prec = ctx["precedence"]
    census = [
        {"layer": "defaults.json", "kind": "base_budget", "binding": "ADOPTED",
         "max_records": ctx["max_records"], "retry_limit": ctx["retry_limit"],
         "timeout_ms": ctx["timeout_ms"]},
        {"layer": "class_index.tsv2", "kind": "class_selector", "binding": "ADOPTED",
         "active_class": ctx["klass"], "selector": ctx["selector"]},
        {"layer": "ingress_rate.tsv", "kind": "throughput", "binding": "ADOPTED",
         "active_class": ctx["klass"], "qps": ctx["qps"]},
        {"layer": "burst_multiplier.ini", "kind": "burst_window", "binding": "ADOPTED",
         "active_class": ctx["klass"], "burst_multiplier_permille": ctx["burst_permille"],
         "window_seconds": ctx["window_seconds"]},
        {"layer": "rate_gran.caret", "kind": "rate_step", "binding": "ADOPTED",
         "active_class": ctx["klass"], "rate_step": ctx["rate_step"]},
        {"layer": "scope_base.jsonl", "kind": "scope_base", "binding": "ADOPTED",
         "active_class": ctx["klass"], "count": len(ctx["scopes"]["base"])},
        {"layer": "scope_overlay.ndjson", "kind": "scope_overlay", "binding": "ADOPTED",
         "active_class": ctx["klass"], "count": len(ctx["scopes"]["overlay"])},
        {"layer": "scope_deny.psv", "kind": "scope_deny", "binding": "ADOPTED",
         "active_class": ctx["klass"], "count": len(ctx["scopes"]["deny"])},
        {"layer": "uid_map.env", "kind": "scope_uid_map", "binding": "SCOPE_",
         "privilege_drop_uid": ctx["config"]["privilege_drop_uid"]},
        {"layer": "uid_floor.hex", "kind": "uid_floor", "binding": "ADOPTED",
         "active_class": ctx["klass"], "uid_floor": ctx["scopes"]["uid_floor"]},
        {"layer": "baseline_controls.scsv", "kind": "hardening_controls", "binding": "ADOPTED",
         "active_class": ctx["klass"], "adopted": len(ctx["hardening"]["trace"]),
         "raw": ctx["hardening"]["raw"]},
        {"layer": "hardening_bounds.toml", "kind": "hardening_bounds", "binding": "ADOPTED",
         "active_class": ctx["klass"], "floor": ctx["hardening"]["floor"],
         "ceil": ctx["hardening"]["ceil"]},
        {"layer": "risk_const.env2", "kind": "risk_constants", "binding": "ADOPTED",
         "baseline_complement": ctx["risk"]["complement"],
         "risk_divisor": ctx["risk"]["divisor"]},
        {"layer": "severity_weight.kv", "kind": "severity_weight", "binding": "ADOPTED",
         "active_class": ctx["klass"], "severity_permille": ctx["risk"]["severity"]},
        {"layer": "voter_health.ndjson", "kind": "voter_health", "binding": "ADOPTED",
         "active_class": ctx["klass"], "healthy_voters": ctx["quorum"]["count"]},
        {"layer": "quorum_permille.tilde", "kind": "quorum_permille", "binding": "ADOPTED",
         "active_class": ctx["klass"], "permille": ctx["quorum"]["permille"]},
        {"layer": "tls_matrix.csv", "kind": "tls_floor", "binding": "ADOPTED",
         "active_class": ctx["klass"], "tls_floor_score": ctx["config"]["tls_floor_score"]},
        {"layer": "seccomp_allow.tsv", "kind": "seccomp_allow", "binding": "ADOPTED",
         "active_class": ctx["klass"], "seccomp_allowed_count": ctx["config"]["seccomp_allowed_count"]},
        {"layer": "seccomp_deny.psv", "kind": "seccomp_deny", "binding": "ADOPTED",
         "active_class": ctx["klass"], "denied": len(ctx["seccomp"]) and len(ctx["seccomp"])},
        {"layer": "retention.ini", "kind": "audit_retention", "binding": "ADOPTED",
         "active_class": ctx["klass"], "audit_retention_days": ctx["config"]["audit_retention_days"]},
        {"layer": "layer_overrides.json", "kind": "precedence_override", "binding": "class_N",
         "pinned_applied": prec["session_ttl_seconds"]["pinned_applied"]},
        {"layer": "pinned_overrides.json", "kind": "precedence_pinned", "binding": "pinned==true",
         "pinned_applied": prec["session_ttl_seconds"]["pinned_applied"]},
        {"layer": "sessions_cap.csv2", "kind": "session_cap_ceil", "binding": "ADOPTED",
         "active_class": ctx["klass"], "abs_ceil": prec["max_concurrent_sessions"]["abs_ceil"]},
        {"layer": "nonce_bounds.toml2", "kind": "nonce_floor", "binding": "ADOPTED",
         "active_class": ctx["klass"], "floor_ms": prec["nonce_window_ms"]["floor_ms"]},
        {"layer": "retry_backoff.psv2", "kind": "retry_step", "binding": "ADOPTED",
         "active_class": ctx["klass"], "step": ctx["retry"]["step"]},
        {"layer": "trailer_registry.txt3", "kind": "trailer_decoys", "binding": "DECOY",
         "trailer": ctx["config"]["trailer"]},
        {"layer": "profile_map.kv3", "kind": "profile_roster", "binding": "ADOPTED",
         "profiles": ["canary", "enforce"]},
        {"layer": "profile_deltas.json", "kind": "profile_deltas", "binding": "ADOPTED",
         "profiles": ["canary", "enforce"]},
        {"layer": "field_registry.ndjson", "kind": "field_registry", "binding": "ADOPTED",
         "required_keys": len(ctx["config"])},
    ]
    write_text(out, "\n".join(json.dumps(e, sort_keys=True) for e in census))


def emit_class_ordering(out, rows):
    lines = ["profile\trisk_index"]
    for name, risk in rows:
        lines.append("%s\t%d" % (name, risk))
    write_text(out, "\n".join(lines))


# -------------------------------------------------------- coverage ----------

def validate_config_against_schema(config, schema):
    required = schema.get("required_keys")
    if isinstance(required, str):
        required = [k.strip() for k in required.split(",") if k.strip()]
    missing = [k for k in required if k not in config]
    nested = [k for k, v in config.items() if isinstance(v, (dict, list, tuple))]
    floaty = [k for k, v in config.items() if isinstance(v, float)]
    extra = sorted(set(config) - set(required))
    return {
        "extra_keys": extra,
        "flat": not nested,
        "float_values": floaty,
        "key_count": len(config),
        "missing": missing,
        "non_scalar": sorted(nested),
        "ok": not missing and not nested and not floaty,
    }


def build_summary(ctx, validation, profiles=None):
    cfg = ctx["config"]
    return {
        "active_class": cfg["active_class"],
        "artifact_count": len(profiles) if profiles else None,
        "config": {k: cfg[k] for k in sorted(cfg)},
        "ok": validation["ok"],
        "profiles": profiles or [],
        "trailer": cfg["trailer"],
        "valid": validation["ok"],
    }


def emit_derivation_artifacts(outdir, ctx):
    emit_rate_limit_plan(outdir / "rate_limit_plan.ini", ctx)
    emit_hardening_fold_trace(outdir / "hardening_fold_trace.psv", ctx)
    emit_quorum_plan(outdir / "quorum_plan.kv", ctx)
    emit_risk_ledger(outdir / "risk_ledger.env", ctx)
    emit_precedence_resolution(outdir / "precedence_resolution.properties", ctx)
    emit_privilege_map(outdir / "privilege_map.ndjson", ctx)
    emit_seccomp_summary(outdir / "seccomp_summary.tsv", ctx)
    emit_tls_floor(outdir / "tls_floor.env", ctx)
    emit_scope_reconciliation(outdir / "scope_reconciliation.tsv", ctx)
    emit_admission_matrix(outdir / "admission_matrix.csv", ctx)
    emit_retention_schedule(outdir / "retention_schedule.csv", ctx)
    emit_derivation_audit(outdir / "derivation_audit.xml", ctx)
    emit_convergence_report(outdir / "convergence_report.txt", ctx)
    emit_input_census(outdir / "input_census.ndjson", ctx)


def emit_profile_artifacts(outdir, ctx):
    deltas = profile_deltas()
    order_rows = [("main", ctx["config"]["risk_index"])]
    reports = []
    for name in ("canary", "enforce"):
        pcfg, pdelta = apply_profile(name, deltas[name], ctx)
        dump_json(outdir / ("profile_%s.json" % name), pcfg)
        reports.append(pdelta)
        order_rows.append((name, pcfg["risk_index"]))
    order_rows.sort(key=lambda r: (r[1], r[0]))
    emit_class_ordering(outdir / "class_ordering.tsv", order_rows)
    dump_json(outdir / "profile_delta_report.json", {
        "base_config": "config.json",
        "deltas": reports,
    })
    return order_rows


# --------------------------------------------------------------- commands ---

def cmd_derive(args):
    ctx = derive()
    outdir = Path(args.out).resolve().parent
    dump_json(args.out, ctx["config"])
    emit_derivation_artifacts(outdir, ctx)
    print("derived")


def cmd_profile(args):
    ctx = derive()
    config = load_json(args.config)
    if config.get("trailer") != ctx["config"]["trailer"]:
        raise SystemExit("trailer mismatch between config and policy layers")
    deltas = profile_deltas()
    if args.name not in deltas:
        raise SystemExit("unknown profile: %s" % args.name)
    cfg, delta = apply_profile(args.name, deltas[args.name], ctx)
    dump_json(args.out, cfg)
    outdir = Path(args.out).resolve().parent
    delta_report = {"base_config": Path(args.config).name, "deltas": []}
    order_rows = [("main", ctx["config"]["risk_index"])]
    for name in ("canary", "enforce"):
        pcfg, pdelta = apply_profile(name, deltas[name], ctx)
        if name == args.name:
            pcfg, pdelta = cfg, delta
            dump_json(args.out, pcfg)
        else:
            existing = outdir / ("profile_%s.json" % name)
            if not existing.exists():
                dump_json(existing, pcfg)
        delta_report["deltas"].append(pdelta)
        order_rows.append((name, pcfg["risk_index"]))
    order_rows.sort(key=lambda r: (r[1], r[0]))
    emit_class_ordering(outdir / "class_ordering.tsv", order_rows)
    dump_json(outdir / "profile_delta_report.json", delta_report)
    print("profiled")


def cmd_init(args):
    schema = load_json(args.schema)
    dump_json(args.out, {
        "profile": schema["profile"],
        "checksum": schema["checksum"],
        "mode": schema["mode"],
        "control_plane": schema["control_plane"],
        "image_runtime": schema["image_runtime"],
    })
    print("initialized")


def coerce_scalar(value):
    """Integers stay integers; anything that parses as a container is rejected."""
    s = str(value).strip()
    if re.fullmatch(r"-?\d+", s):
        return int(s)
    if s[:1] in ("{", "["):
        try:
            parsed = json.loads(s)
        except ValueError:
            parsed = None
        if isinstance(parsed, (dict, list)):
            raise SystemExit("value must be scalar, not a container")
    return s


def cmd_set(args):
    data = load_json(args.config)
    if args.key != args.key.lower() or " " in args.key:
        raise SystemExit("key must be a lowercase scalar name: %s" % args.key)
    value = coerce_scalar(args.value)
    if isinstance(value, (dict, list)):
        raise SystemExit("value must be scalar")
    data[args.key] = value
    dump_json(args.config, data)
    print("set")


def cmd_validate(args):
    schema = load_json(args.schema)
    data = load_json(args.config)
    result = validate_config_against_schema(data, schema)
    if not result["ok"]:
        problems = []
        if result["missing"]:
            problems.append("missing: " + ",".join(result["missing"]))
        if result["non_scalar"]:
            problems.append("configuration must be flat: " + ",".join(result["non_scalar"]))
        if result["float_values"]:
            problems.append("non-integer values: " + ",".join(result["float_values"]))
        raise SystemExit("; ".join(problems))
    print("ok")


def cmd_report(args):
    data = load_json(args.config)
    commands = load_json(args.commands) if args.commands else []
    digest_arg = args.digest
    if digest_arg and re.fullmatch(r"[0-9a-f]{64}", digest_arg.strip().lower()):
        digest = digest_arg.strip().lower()
    elif digest_arg:
        digest = Path(digest_arg).read_text(encoding="utf-8").strip().lower()
    else:
        digest = sha256_file(args.config)
    dump_json(args.out, {
        "commands": commands,
        "config": data,
        "digest": digest,
        "digest_algorithm": "sha256",
        "ok": True,
        "trailer": data.get("trailer"),
    })
    print("reported")


def cmd_summarize(args):
    outdir = Path(args.outdir)
    config = load_json(outdir / "config.json")
    schema = load_json(args.schema) if args.schema else load_json(DATA / "config_schema.json")
    validation = validate_config_against_schema(config, schema)
    dump_json(outdir / "validation_report.json", {
        "config": "config.json",
        "checks": validation,
        "ok": validation["ok"],
    })
    profiles = []
    for name in ("canary", "enforce"):
        path = outdir / ("profile_%s.json" % name)
        if path.exists():
            profiles.append(name)
    dump_json(outdir / "summary.json", {
        "active_class": config["active_class"],
        "artifacts": "all",
        "config": {k: config[k] for k in sorted(config)},
        "ok": validation["ok"],
        "profiles": profiles,
        "trailer": config["trailer"],
        "valid": validation["ok"],
    })
    emit_reproducibility_manifest(outdir / "reproducibility_manifest.json", outdir)
    print("summarized")


def package_tool(dest, source_dir=None):
    """Deterministically zip the repaired tool (fixed timestamps, sorted names)."""
    import zipfile

    source = Path(source_dir) if source_dir else Path(__file__).resolve().parent
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    members = sorted(p for p in source.rglob("*") if p.is_file() and p.name != dest.name)
    with zipfile.ZipFile(dest, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in members:
            rel = path.relative_to(source).as_posix()
            info = zipfile.ZipInfo(rel, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            info.create_system = 3
            zf.writestr(info, path.read_bytes())
    return dest


def cmd_package(args):
    dest = package_tool(args.out, args.source)
    print("packaged %s (%d bytes)" % (dest, dest.stat().st_size))


def cmd_all(args):
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    ctx = derive()
    dump_json(outdir / "config.json", ctx["config"])
    emit_derivation_artifacts(outdir, ctx)
    emit_profile_artifacts(outdir, ctx)
    cmd_summarize_args = argparse.Namespace(outdir=str(outdir), schema=None)
    cmd_summarize(cmd_summarize_args)
    print("all artifacts written to %s" % outdir)


def main():
    parser = argparse.ArgumentParser(prog="task-ctl")
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("derive")
    p.add_argument("--out", required=True)
    p.add_argument("--schema")
    p.set_defaults(func=cmd_derive)

    p = sub.add_parser("profile")
    p.add_argument("--name", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_profile)

    p = sub.add_parser("init")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("export-report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest")
    p.add_argument("--commands")
    p.set_defaults(func=cmd_report)

    p = sub.add_parser("summarize")
    p.add_argument("--outdir", required=True)
    p.add_argument("--schema")
    p.set_defaults(func=cmd_summarize)

    p = sub.add_parser("package")
    p.add_argument("--out", required=True)
    p.add_argument("--source")
    p.set_defaults(func=cmd_package)

    p = sub.add_parser("all")
    p.add_argument("--outdir", required=True)
    p.set_defaults(func=cmd_all)

    args = parser.parse_args()
    if not getattr(args, "command", None):
        return
    args.func(args)


if __name__ == "__main__":
    main()
