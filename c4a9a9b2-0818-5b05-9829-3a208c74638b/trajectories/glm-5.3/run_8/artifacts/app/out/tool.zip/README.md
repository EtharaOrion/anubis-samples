# task-ctl

An offline container-image admission-control hardening compiler for a
server-side admission broker. It reads interacting numeric policy layers from
`/app/data`, selects the active enforcement class, and derives one flat hardened
admission configuration plus two deployment profiles (canary and enforce).

## Expected repaired commands

- `init --schema <schema> --out <config>`: seed fixed contract strings.
- `derive --schema <schema> --out <config>`: compile the flat hardened
  configuration for the active enforcement class and emit every derivation
  sidecar plus the audit/provenance artifacts next to the config.
- `set --config <config> --key <key> --value <value>`: set one scalar key with
  correct case and type coercion; reject any non-scalar value.
- `validate --schema <schema> --config <config>`: confirm every required key is
  present and the configuration is flat; print `ok`.
- `profile --name <canary|enforce> --config <config> --out <profile>`: apply
  the documented per-profile deltas, refresh both profiles, the signed delta
  report and the class-ordering artifact.
- `export-report --config <config> --out <report> --digest <sha256> --commands <json>`:
  emit a truthful command transcript.
- `summarize --schema <schema> --outdir <dir>`: emit `validation_report.json`,
  `summary.json` and the byte-stable `reproducibility_manifest.json`.
- `package --out <tool.zip>`: deterministically repackage the repaired tool.
- `all --outdir <dir>`: one-shot equivalent of the full pipeline.

## Derivation contract

- Active class: `((max_records // 37) + 3 * retry_limit) % 5` from
  `defaults.base_config`, cross-checked against the ADOPTED rows of
  `class_index.tsv2`; never taken from a first table row.
- Ingress rate limit: `quantize(qps * burst_multiplier_permille / 1000, rate
  step)` from the ADOPTED throughput, burst and granularity rows for the
  active class; burst ceiling: `rate limit * window_seconds`.
- Effective scopes: `(base UNION overlay) MINUS deny` for the active class;
  `privilege_drop_uid` is the minimum granted uid at or above the ADOPTED
  uid floor.
- Hardening baseline: carry-aware ordered fold of ADOPTED controls, clamped to
  the ADOPTED per-class bounds and quantized to 5.
- Risk index: `(100 - baseline) * severity_permille / 1000`.
- Quorum: `round_half_even(healthy ADOPTED voters * 667 / 1000)` clamped to
  `[1, voter count]`.
- TLS floor: lowest score among ADOPTED *enabled* suites; seccomp allowance:
  ADOPTED allow entries minus ADOPTED deny entries; retention: the ADOPTED
  `[class.N]` retention block.
- Precedence: `defaults.layer_defaults` < `layer_overrides.class_N` <
  `pinned_overrides.class_N` (only when `pinned == true`), honouring the
  session-cap ceiling and nonce-window floor.
- Retry backoff base: `quantize(timeout_ms * (retry_limit + 1), retry step)`.

## Contract notes

- Every value is derived with exact integer arithmetic (round-half-even); no
  floating-point value may reach a graded key.
- The configuration is flat: keys map directly to integer or string scalars.
- The required key set is authoritative in `schema.json` and mirrored by the
  field registry in the policy layers.
- Only rows whose status is `ADOPTED` for the active enforcement class bind; rows
  labelled `SUPERSEDED`, `DRAFT`, `SHADOW`, or `REVOKED` are context decoys.
