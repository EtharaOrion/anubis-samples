# task-ctl

An offline container-image admission-control hardening compiler for a
server-side admission broker. It reads interacting numeric policy layers from
`/app/data`, selects the active enforcement class, and derives one flat hardened
admission configuration plus two deployment profiles (canary and enforce).

## Repaired commands

- `init --schema <schema> --out <config>`: seed fixed contract strings.
- `derive --schema <schema> --out <config>`: derive the hardened configuration.
- `profile --name <canary|enforce> --config <config> --out <profile>`: apply the
  documented per-profile deltas to a derived configuration.
- `set --config <config> --key <key> --value <value>`: set one scalar key with
  correct case and type coercion; reject any non-scalar value.
- `validate --schema <schema> --config <config>`: confirm every required key is
  present and the configuration is flat; print `ok`.
- `export-report --config <config> --out <report> --digest <sha256> --commands <json>`:
  emit a truthful command transcript.
- `build --schema <schema> --outdir <dir>`: run the whole derivation and emit
  every graded artifact, including the repackaged tool.

## Contract notes

- Every value is derived with exact integer arithmetic (round-half-even); no
  floating-point value may reach a graded key.
- The configuration is flat: keys map directly to integer or string scalars.
- The required key set is authoritative in `schema.json` and mirrored by the
  field registry in the policy layers.
- Only rows whose status is `ADOPTED` for the active enforcement class bind; rows
  labelled `SUPERSEDED`, `DRAFT`, `SHADOW`, or `REVOKED` are context decoys.

## Derivation contract

- Active class: `selector = (max_records // 37) + 3 * retry_limit`, matched
  against the `ADOPTED` selector ranges of `class_index.tsv2` (never a first row).
- Ingress rate limit: per-class `ingress_qps` scaled by the class burst
  multiplier permille (banker's rounding), then quantized down to the class rate
  step. Burst ceiling: resolved rate limit times the per-class window.
- Effective scopes: class `ADOPTED` base scopes unioned with the class
  `ADOPTED` overlay scopes, reduced by the class `ADOPTED` deny scopes.
  `privilege_drop_uid` is the minimum granted uid of that set, floored at the
  class uid floor.
- Hardening baseline: carry-aware fold over the class's ordered controls, where
  a control whose carry flag is set passes its weight forward to the next
  adopted control; the folded score is clamped to the class bounds and
  quantized. Risk index: `(complement - baseline) * severity permille /
  risk divisor`, banker's rounded.
- Quorum threshold: healthy `ADOPTED` voters for the class scaled by the class
  quorum permille (banker's rounding), clamped to `[1, voters]`.
- TLS floor score: minimum score among `ADOPTED` and enabled suites of the class.
  Seccomp allowed count: class allow-list reduced by the class deny-list.
  Audit retention: the class `ADOPTED` retention days.
- Precedence: base `layer_defaults` -> `layer_overrides` -> `pinned_overrides`
  (only when `pinned == true`), with the nonce floor and session ceiling applied
  as bounds.
- Retry backoff base: `timeout_ms * (retry_limit + 1)` quantized to the class
  retry step.
- Profiles: `ttl_scale_permille` scales the resolved session TTL (banker's
  rounding, then granularity quantization); `quorum_delta` and `risk_delta` are
  signed adjustments applied after the main derivation.

