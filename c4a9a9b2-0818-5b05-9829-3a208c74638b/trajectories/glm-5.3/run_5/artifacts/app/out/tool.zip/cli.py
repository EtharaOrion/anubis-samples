#!/usr/bin/env python3
"""task-ctl: local admission-control hardening compiler.

Compiles a flat hardened admission configuration for the active enforcement
class from the interacting numeric policy layers under /app/data.

All arithmetic that reaches a graded value is exact integer arithmetic using
round-half-even (banker's) rounding; no floating-point operation touches a
graded number. Only rows whose status is ADOPTED and whose class matches the
active enforcement class bind; every other status label is a decoy.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import zipfile
from pathlib import Path

DATA = Path("/app/data")
ADOPTED = "ADOPTED"

SESSION_FIELDS = ("session_ttl_seconds", "nonce_window_ms", "max_concurrent_sessions")
HARDENING_STEP = 5

# ---------------------------------------------------------------------------
# exact integer arithmetic helpers
# ---------------------------------------------------------------------------


def div_round_half_even(num, den):
    """Return num/den rounded to the nearest integer, ties to even."""
    if den == 0:
        raise ZeroDivisionError("denominator must be non-zero")
    sign = 1
    if num < 0:
        num = -num
        sign = -1
    q, r = divmod(num, den)
    twice = 2 * r
    if twice > den or (twice == den and (q % 2) == 1):
        q += 1
    return sign * q


def quantize_floor(value, step):
    return (value // step) * step


def clamp(value, lo, hi):
    return min(hi, max(lo, value))


# ---------------------------------------------------------------------------
# generic text plumbing
# ---------------------------------------------------------------------------


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, data):
    Path(path).write_text(json.dumps(data, sort_keys=True, indent=2) + "\n", encoding="utf-8")


def read_lines(name):
    out = []
    for line in (DATA / name).read_text(encoding="utf-8", errors="replace").split("\n"):
        s = line.strip()
        if not s or s.startswith("#") or s.startswith(";") or s.startswith(".."):
            continue
        out.append(line)
    return out


def delimited_rows(name, sep):
    lines = read_lines(name)
    if not lines:
        return []
    header = [c.strip() for c in lines[0].split(sep)]
    rows = []
    for line in lines[1:]:
        parts = [c.strip() for c in line.split(sep)]
        if len(parts) != len(header):
            continue
        rows.append(dict(zip(header, parts)))
    return rows


def adopted_rows(rows, klass, class_field="class_id"):
    return [r for r in rows if str(r.get(class_field)).strip() == str(klass)
            and str(r.get("status")).strip() == ADOPTED]


def parse_ini_sections(name):
    """Parse INI text into {section: {key: value}}; comment lines dropped."""
    sections = {}
    current = None
    for line in read_lines(name):
        s = line.strip()
        if not s:
            continue
        if s.startswith("[") and s.endswith("]"):
            current = s[1:-1].strip()
            sections.setdefault(current, {})
            continue
        if current is None or "=" not in s:
            continue
        key, _, val = s.partition("=")
        sections[current][key.strip()] = val.strip()
    return sections


def parse_properties(name):
    """Parse KEY=VALUE lines into a dict."""
    out = {}
    for line in read_lines(name):
        s = line.strip()
        if "=" not in s:
            continue
        key, _, val = s.partition("=")
        out[key.strip()] = val.strip()
    return out


def parse_toml_blocks(name):
    """Parse the TOML subset used by the policy layers: [section] with
    key = value and key = \"value\" members."""
    sections = {}
    current = None
    for line in read_lines(name):
        s = line.strip()
        if not s:
            continue
        m = re.match(r"^\[([^\]]+)\]$", s)
        if m:
            current = m.group(1).strip()
            sections.setdefault(current, {})
            continue
        if current is None or "=" not in s:
            continue
        key, _, val = s.partition("=")
        val = val.strip()
        if val.startswith('"') and val.endswith('"') and len(val) >= 2:
            val = val[1:-1]
        sections[current][key.strip()] = val
    return sections


# ---------------------------------------------------------------------------
# base budget / class selection
# ---------------------------------------------------------------------------


def base_inputs():
    base = load_json(DATA / "defaults.json")["base_config"]
    return (int(base["max_records"]), int(base["retry_limit"]),
            int(base["timeout_ms"]), str(base["trailer"]))


def class_selector(max_records, retry_limit):
    return (max_records // 37) + 3 * retry_limit


def active_class(max_records, retry_limit):
    """Select the active enforcement class from the documented base budget via
    the ADOPTED selector ranges of the class index; never from a first row."""
    selector = class_selector(max_records, retry_limit)
    for row in delimited_rows("class_index.tsv2", "\t"):
        if str(row.get("status")).strip() != ADOPTED:
            continue
        lo = int(row["selector_lo"])
        hi = int(row["selector_hi"])
        if lo <= selector <= hi:
            return int(row["class_id"])
    raise SystemExit("no adopted class index row covers selector %d" % selector)


# ---------------------------------------------------------------------------
# per-class layer lookups
# ---------------------------------------------------------------------------


def ingress_qps(klass):
    rows = adopted_rows(delimited_rows("ingress_rate.tsv", "\t"), klass)
    if not rows:
        raise SystemExit("no adopted ingress row for class %s" % klass)
    return int(rows[0]["ingress_qps"])


def burst_multiplier(klass):
    sections = parse_ini_sections("burst_multiplier.ini")
    block = sections.get("class.%d" % klass, {})
    if str(block.get("status", "")).strip() != ADOPTED:
        raise SystemExit("no adopted burst block for class %s" % klass)
    return int(block["burst_multiplier_permille"]), int(block["window_seconds"])


def rate_step(klass):
    rows = adopted_rows(delimited_rows("rate_gran.caret", "^"), klass)
    if not rows:
        raise SystemExit("no adopted rate granularity for class %s" % klass)
    return int(rows[0]["gran"])


def window_seconds(klass):
    for line in read_lines("window_seconds.conf"):
        parts = line.split()
        if len(parts) >= 3 and parts[0] == str(klass) and parts[2] == ADOPTED:
            return int(parts[1])
    raise SystemExit("no adopted window row for class %s" % klass)


def uid_floor(klass):
    rows = adopted_rows(delimited_rows("uid_floor.hex", ":"), klass)
    if not rows:
        raise SystemExit("no adopted uid floor for class %s" % klass)
    return int(rows[0]["floor_hex"], 16)


def scope_layers(klass):
    base = _scope_names("scope_base.jsonl", klass)
    overlay = _scope_names("scope_overlay.ndjson", klass)
    deny = []
    for row in delimited_rows("scope_deny.psv", "|"):
        if str(row.get("class_id")).strip() == str(klass) and str(row.get("status")).strip() == ADOPTED:
            deny.append(row["scope"])
    return base, overlay, deny


def _scope_names(name, klass):
    names = []
    for line in read_lines(name):
        obj = json.loads(line)
        if str(obj.get("class_id")) == str(klass) and str(obj.get("status")).strip() == ADOPTED:
            names.append(str(obj["scope"]))
    return names


def scope_uids():
    uids = {}
    for line in read_lines("uid_map.env"):
        s = line.strip()
        if "=" not in s:
            continue
        key, _, val = s.partition("=")
        key = key.strip()
        val = val.strip()
        if key.startswith("SCOPE_") and val.isdigit():
            uids[key[len("SCOPE_"):].lower()] = int(val)
    return uids


def control_rows(klass):
    """Every control row matching the active class, in ascending order; the
    fold itself only advances on ADOPTED rows."""
    rows = [r for r in delimited_rows("baseline_controls.scsv", ";")
            if str(r.get("class_id")).strip() == str(klass)]
    rows.sort(key=lambda r: int(r["order"]))
    return rows


def hardening_bounds(klass):
    sections = parse_toml_blocks("hardening_bounds.toml")
    block = sections.get("class.%d" % klass, {})
    if str(block.get("status", "")).strip() != ADOPTED:
        raise SystemExit("no adopted hardening bounds for class %s" % klass)
    return int(block["floor"]), int(block["ceil"])


def severity_permille(klass):
    for line in read_lines("severity_weight.kv"):
        parts = [p.strip() for p in line.split(":")]
        if len(parts) >= 3 and parts[0] == "class%d" % klass and parts[2] == ADOPTED:
            return int(parts[1])
    raise SystemExit("no adopted severity weight for class %s" % klass)


def risk_constants():
    vals = parse_properties("risk_const.env2")
    return int(vals["BASELINE_COMPLEMENT"]), int(vals["RISK_DIVISOR"])


def quorum_permille(klass):
    rows = adopted_rows(delimited_rows("quorum_permille.tilde", "~"), klass)
    if not rows:
        raise SystemExit("no adopted quorum permille for class %s" % klass)
    return int(rows[0]["permille"])


def healthy_voters(klass):
    count = 0
    for line in read_lines("voter_health.ndjson"):
        obj = json.loads(line)
        if str(obj.get("class_id")) != str(klass):
            continue
        if str(obj.get("status")).strip() != ADOPTED:
            continue
        if obj.get("healthy") is True:
            count += 1
    return count


def tls_floor(klass):
    scores = []
    for row in delimited_rows("tls_matrix.csv", ","):
        if str(row.get("class_id")).strip() != str(klass):
            continue
        if str(row.get("status")).strip() != ADOPTED:
            continue
        if str(row.get("enabled")).strip().lower() != "true":
            continue
        scores.append(int(row["score"]))
    if not scores:
        raise SystemExit("no adopted+enabled tls suite for class %s" % klass)
    return min(scores)


def seccomp_effective(klass):
    allowed = set()
    for row in delimited_rows("seccomp_allow.tsv", "\t"):
        if str(row.get("class_id")).strip() == str(klass) and str(row.get("status")).strip() == ADOPTED:
            allowed.add(row["syscall"])
    denied = set()
    for row in delimited_rows("seccomp_deny.psv", "|"):
        if str(row.get("class_id")).strip() == str(klass) and str(row.get("status")).strip() == ADOPTED:
            denied.add(row["syscall"])
    return sorted(allowed - denied)


def retention_days(klass):
    sections = parse_ini_sections("retention.ini")
    block = sections.get("class.%d" % klass, {})
    if str(block.get("status", "")).strip() != ADOPTED:
        raise SystemExit("no adopted retention row for class %s" % klass)
    return int(block["retention_days"])


def retry_step(klass):
    rows = adopted_rows(delimited_rows("retry_backoff.psv2", "||"), klass)
    if not rows:
        raise SystemExit("no adopted retry step for class %s" % klass)
    return int(rows[0]["step"])


def sessions_ceiling(klass):
    rows = adopted_rows(delimited_rows("sessions_cap.csv2", ","), klass)
    if not rows:
        raise SystemExit("no adopted sessions ceiling for class %s" % klass)
    return int(rows[0]["abs_ceil"])


def nonce_floor_ms(klass):
    sections = parse_toml_blocks("nonce_bounds.toml2")
    block = sections.get("class.%d" % klass, {})
    if str(block.get("status", "")).strip() != ADOPTED:
        raise SystemExit("no adopted nonce floor for class %s" % klass)
    return int(block["floor_ms"])


def resolve_precedence(klass):
    """base layer defaults -> per-class override -> pinned override (applies
    only when pinned == true)."""
    defaults = load_json(DATA / "defaults.json")["layer_defaults"]
    overrides = load_json(DATA / "layer_overrides.json").get("class_%d" % klass, {})
    pinned_block = load_json(DATA / "pinned_overrides.json").get("class_%d" % klass, {})
    pinned = pinned_block.get("pinned") is True
    resolved = {}
    for field in SESSION_FIELDS:
        value = int(defaults[field])
        if field in overrides:
            value = int(overrides[field])
        if pinned and field in pinned_block:
            value = int(pinned_block[field])
        resolved[field] = value
    return resolved, pinned


# ---------------------------------------------------------------------------
# derivation core
# ---------------------------------------------------------------------------


def fold_controls(rows):
    """Carry-aware fold over the ordered controls of the active class.

    Only ADOPTED controls bind; every other status label is a decoy that is
    skipped without advancing the fold. The documented carry rule applies
    between consecutive adopted controls: a control whose carry flag is set
    passes its weight forward, so the next adopted control contributes its
    own weight plus the carried weight. The final adopted control's carry has
    no successor and is therefore inert.
    """
    trace = []
    total = 0
    prev_weight = 0
    prev_carry = 0
    for row in rows:
        weight = int(row["weight"])
        carry = int(row["carry_flag"])
        status = str(row["status"]).strip()
        entry = {
            "order": int(row["order"]),
            "control_id": row["control_id"],
            "weight": weight,
            "carry": carry,
            "status": status,
        }
        if status == ADOPTED:
            total += weight + (prev_weight if prev_carry else 0)
            entry["running"] = total
            prev_weight, prev_carry = weight, carry
        else:
            entry["running"] = "skip"
        trace.append(entry)
    return trace


def derive():
    max_records, retry_limit, timeout_ms, trailer = base_inputs()
    klass = active_class(max_records, retry_limit)

    # ingress rate limit: per-class throughput scaled by its burst factor,
    # then quantized down to the documented rate step.
    qps = ingress_qps(klass)
    permille, window = burst_multiplier(klass)
    step = rate_step(klass)
    scaled = div_round_half_even(qps * permille, 1000)
    rate_limit = quantize_floor(scaled, step)
    # burst ceiling: resolved rate limit over the per-class window.
    burst_ceiling = rate_limit * window_seconds(klass)

    # effective scope set: base union overlay, reduced by deny, this class only.
    base_scopes, overlay_scopes, deny_scopes = scope_layers(klass)
    effective = sorted((set(base_scopes) | set(overlay_scopes)) - set(deny_scopes))
    uids = scope_uids()
    floor = uid_floor(klass)
    granted = [uids[name] for name in effective if name in uids]
    if effective and len(granted) != len(effective):
        raise SystemExit("effective scope set has no granted uid for class %s" % klass)
    privilege_drop_uid = max(floor, min(granted)) if granted else floor

    # hardening baseline: carry-aware fold, clamped to per-class bounds, quantized.
    rows = control_rows(klass)
    trace = fold_controls(rows)
    lo, hi = hardening_bounds(klass)
    adopted_running = [row["running"] for row in trace if row["status"] == ADOPTED]
    fold_total = adopted_running[-1] if adopted_running else 0
    clamped = clamp(fold_total, lo, hi)
    hardening_baseline = quantize_floor(clamped, HARDENING_STEP)

    # risk index from the hardening baseline and per-class severity weight.
    complement, divisor = risk_constants()
    severity = severity_permille(klass)
    risk_index = div_round_half_even((complement - hardening_baseline) * severity, divisor)

    # quorum threshold from healthy authoritative voters, bounded [1, voters].
    voters = healthy_voters(klass)
    qpermille = quorum_permille(klass)
    quorum = clamp(div_round_half_even(voters * qpermille, 1000), 1, voters)

    seccomp_effective_syscalls = seccomp_effective(klass)
    resolved, pinned = resolve_precedence(klass)
    session_ttl = resolved["session_ttl_seconds"]
    nonce_window = max(resolved["nonce_window_ms"], nonce_floor_ms(klass))
    max_sessions = min(resolved["max_concurrent_sessions"], sessions_ceiling(klass))

    retry_backoff = quantize_floor(timeout_ms * (retry_limit + 1), retry_step(klass))

    derived = {
        "active_class": klass,
        "audit_retention_days": retention_days(klass),
        "burst_ceiling": burst_ceiling,
        "effective_scope_count": len(effective),
        "hardening_baseline": hardening_baseline,
        "ingress_rate_limit_qps": rate_limit,
        "max_concurrent_sessions": max_sessions,
        "nonce_window_ms": nonce_window,
        "privilege_drop_uid": privilege_drop_uid,
        "quorum_threshold": quorum,
        "retry_backoff_base_ms": retry_backoff,
        "risk_index": risk_index,
        "seccomp_allowed_count": len(seccomp_effective_syscalls),
        "session_ttl_seconds": session_ttl,
        "tls_floor_score": tls_floor(klass),
        "trailer": trailer,
    }
    defaults = load_json(DATA / "defaults.json")["layer_defaults"]
    context = {
        "selector": class_selector(max_records, retry_limit),
        "qps": qps,
        "burst_permille": permille,
        "burst_window": window,
        "rate_step": step,
        "scaled_qps": scaled,
        "base_scopes": sorted(base_scopes),
        "overlay_scopes": sorted(overlay_scopes),
        "deny_scopes": sorted(deny_scopes),
        "effective_scopes": effective,
        "granted_uids": granted,
        "uid_floor": floor,
        "voters": voters,
        "quorum_permille": qpermille,
        "severity_permille": severity,
        "baseline_complement": complement,
        "risk_divisor": divisor,
        "fold_total": fold_total,
        "fold_clamped": clamped,
        "fold_trace": trace,
        "bounds_floor": lo,
        "bounds_ceil": hi,
        "hardening_step": HARDENING_STEP,
        "seccomp_effective": seccomp_effective_syscalls,
        "precedence_defaults": {f: int(defaults[f]) for f in SESSION_FIELDS},
        "precedence_resolved": resolved,
        "pinned": pinned,
        "retry_step": retry_step(klass),
        "timeout_ms": timeout_ms,
        "retry_limit": retry_limit,
        "max_records": max_records,
    }
    return derived, context


# ---------------------------------------------------------------------------
# configuration assembly
# ---------------------------------------------------------------------------


def contract_strings(schema):
    return {
        "profile": str(schema["profile"]),
        "checksum": str(schema["checksum"]),
        "control_plane": str(schema["control_plane"]),
        "image_runtime": str(schema["image_runtime"]),
        "mode": str(schema["mode"]),
    }


def build_config(derived, schema, enforcement_profile):
    config = dict(derived)
    config.update(contract_strings(schema))
    config["enforcement_profile"] = enforcement_profile
    return {k: config[k] for k in sorted(config)}


def apply_profile_deltas(config, name):
    deltas = load_json(DATA / "profile_deltas.json")[name]
    out = dict(config)
    ttl = div_round_half_even(int(config["session_ttl_seconds"]) * int(deltas["ttl_scale_permille"]), 1000)
    out["session_ttl_seconds"] = quantize_floor(ttl, HARDENING_STEP)
    out["quorum_threshold"] = int(config["quorum_threshold"]) + int(deltas["quorum_delta"])
    out["risk_index"] = int(config["risk_index"]) + int(deltas["risk_delta"])
    out["enforcement_profile"] = name
    return out


# ---------------------------------------------------------------------------
# validation
# ---------------------------------------------------------------------------


def validate_config(schema, data):
    if isinstance(schema.get("required_keys"), str):
        required = [k.strip() for k in schema["required_keys"].split(",") if k.strip()]
    else:
        required = [str(k).strip() for k in schema.get("required_keys", []) if str(k).strip()]
    missing = sorted(k for k in required if k not in data)
    if missing:
        raise SystemExit("missing: " + ",".join(missing))
    bad = sorted(k for k, v in data.items() if isinstance(v, (dict, list)))
    if bad:
        raise SystemExit("configuration must be flat: " + ",".join(bad))
    forbidden = load_json(DATA / "validation_rules.json").get("forbidden_keys", [])
    present = sorted(k for k in forbidden if k in data)
    if present:
        raise SystemExit("forbidden keys present: " + ",".join(present))
    return True


# ---------------------------------------------------------------------------
# sidecar writers
# ---------------------------------------------------------------------------


def write_text(path, text):
    Path(path).write_text(text, encoding="utf-8")


def sidecar_admission_matrix(path, derived, context):
    lines = ["class,selector,ingress_qps,burst_permille,rate_step,ingress_rate_limit_qps,burst_ceiling"]
    lines.append("%d,%d,%d,%d,%d,%d,%d" % (
        derived["active_class"], context["selector"], context["qps"],
        context["burst_permille"], context["rate_step"],
        derived["ingress_rate_limit_qps"], derived["burst_ceiling"]))
    write_text(path, "\n".join(lines) + "\n")


def sidecar_rate_plan(path, derived):
    lines = ["[rate]",
             "class = %d" % derived["active_class"],
             "ingress_rate_limit_qps = %d" % derived["ingress_rate_limit_qps"],
             "burst_ceiling = %d" % derived["burst_ceiling"]]
    write_text(path, "\n".join(lines) + "\n")


def sidecar_scope_reconciliation(path, derived, context):
    lines = ["class\tbase_scopes\toverlay_scopes\tdeny_scopes\teffective_scopes\teffective_scope_count\tprivilege_drop_uid"]
    fmt = lambda xs: ",".join(xs) if xs else "-"
    lines.append("%d\t%s\t%s\t%s\t%s\t%d\t%d" % (
        derived["active_class"], fmt(context["base_scopes"]), fmt(context["overlay_scopes"]),
        fmt(context["deny_scopes"]), fmt(context["effective_scopes"]),
        derived["effective_scope_count"], derived["privilege_drop_uid"]))
    write_text(path, "\n".join(lines) + "\n")


def sidecar_hardening_trace(path, context):
    lines = ["order|control_id|weight|carry|status|running"]
    for row in context["fold_trace"]:
        lines.append("%d|%s|%d|%d|%s|%s" % (
            row["order"], row["control_id"], row["weight"], row["carry"],
            row["status"], row["running"]))
    write_text(path, "\n".join(lines) + "\n")


def sidecar_quorum(path, derived, context):
    write_text(path, "healthy_voters:%d\nquorum_threshold:%d\n" % (
        context["voters"], derived["quorum_threshold"]))


def sidecar_risk_ledger(path, derived, context):
    write_text(path, "HARDENING_BASELINE=%d\nRISK_INDEX=%d\nSEVERITY_PERMILLE=%d\n" % (
        derived["hardening_baseline"], derived["risk_index"], context["severity_permille"]))


def sidecar_precedence(path, context):
    lines = []
    for field in SESSION_FIELDS:
        lines.append("%s.default=%d" % (field, context["precedence_defaults"][field]))
        lines.append("%s.resolved=%d" % (field, context["precedence_resolved"][field]))
    write_text(path, "\n".join(lines) + "\n")


def sidecar_privilege_map(path, context):
    uids = scope_uids()
    lines = [json.dumps({"scope": name, "uid": uids[name]}, sort_keys=True)
             for name in context["effective_scopes"]]
    write_text(path, "\n".join(lines) + "\n")


def sidecar_seccomp(path, derived):
    write_text(path, "class\tseccomp_allowed_count\n%d\t%d\n" % (
        derived["active_class"], derived["seccomp_allowed_count"]))


def sidecar_tls_floor(path, derived):
    write_text(path, "TLS_FLOOR_SCORE=%d\n" % derived["tls_floor_score"])


def sidecar_retention(path, derived):
    write_text(path, "class,audit_retention_days\n%d,%d\n" % (
        derived["active_class"], derived["audit_retention_days"]))


def sidecar_class_ordering(path, config, profiles):
    rows = [("main", int(config["risk_index"]))]
    for name in sorted(profiles):
        rows.append((name, int(profiles[name]["risk_index"])))
    rows.sort(key=lambda r: r[1])
    lines = ["profile\trisk_index"] + ["%s\t%d" % (name, risk) for name, risk in rows]
    write_text(path, "\n".join(lines) + "\n")


# ---------------------------------------------------------------------------
# audit / provenance artifacts
# ---------------------------------------------------------------------------


def audit_xml(config, context, command_log):
    fields = ["    <field name=\"%s\" value=\"%s\"/>" % (k, config[k]) for k in sorted(config)]
    ctx = ["    <context name=\"%s\" value=\"%s\"/>" % (k, context[k])
           for k in sorted(context)
           if not isinstance(context[k], (list, tuple, dict))]
    cmds = ["    <command>%s</command>" % c for c in command_log]
    return (
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
        "<derivationAudit>\n"
        "  <configuration>\n" + "\n".join(fields) + "\n  </configuration>\n"
        "  <provenance>\n" + "\n".join(ctx) + "\n  </provenance>\n"
        "  <transcript>\n" + "\n".join(cmds) + "\n  </transcript>\n"
        "</derivationAudit>\n"
    )


def convergence_report(config, context, profiles):
    lines = [
        "convergence report",
        "active_class=%d" % config["active_class"],
        "selector=%d" % context["selector"],
        "ingress_rate_limit_qps=%d" % config["ingress_rate_limit_qps"],
        "burst_ceiling=%d" % config["burst_ceiling"],
        "effective_scope_count=%d" % config["effective_scope_count"],
        "privilege_drop_uid=%d" % config["privilege_drop_uid"],
        "hardening_baseline=%d" % config["hardening_baseline"],
        "risk_index=%d" % config["risk_index"],
        "quorum_threshold=%d" % config["quorum_threshold"],
        "tls_floor_score=%d" % config["tls_floor_score"],
        "seccomp_allowed_count=%d" % config["seccomp_allowed_count"],
        "audit_retention_days=%d" % config["audit_retention_days"],
        "session_ttl_seconds=%d" % config["session_ttl_seconds"],
        "nonce_window_ms=%d" % config["nonce_window_ms"],
        "max_concurrent_sessions=%d" % config["max_concurrent_sessions"],
        "retry_backoff_base_ms=%d" % config["retry_backoff_base_ms"],
        "trailer=%s" % config["trailer"],
    ]
    for name in sorted(profiles):
        p = profiles[name]
        lines.append("profile.%s.session_ttl_seconds=%d" % (name, p["session_ttl_seconds"]))
        lines.append("profile.%s.quorum_threshold=%d" % (name, p["quorum_threshold"]))
        lines.append("profile.%s.risk_index=%d" % (name, p["risk_index"]))
    lines.append("converged=true")
    return "\n".join(lines) + "\n"


def reproducibility_manifest(paths, command_log):
    entries = []
    for path in sorted(paths, key=lambda p: p.name):
        data = Path(path).read_bytes()
        entries.append({
            "artifact": path.name,
            "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest(),
        })
    return {"algorithm": "sha256", "artifacts": entries, "commands": command_log}


INPUT_CENSUS = [
    ("class_index.tsv2", "class selector ranges"),
    ("ingress_rate.tsv", "per-class throughput"),
    ("burst_multiplier.ini", "burst factor and window"),
    ("rate_gran.caret", "rate quantization step"),
    ("window_seconds.conf", "per-class window"),
    ("scope_base.jsonl", "base scopes"),
    ("scope_overlay.ndjson", "overlay scopes"),
    ("scope_deny.psv", "deny scopes"),
    ("uid_map.env", "scope uid grants"),
    ("uid_floor.hex", "privilege drop uid floor"),
    ("baseline_controls.scsv", "ordered hardening controls"),
    ("hardening_bounds.toml", "hardening clamp bounds"),
    ("severity_weight.kv", "per-class severity weight"),
    ("risk_const.env2", "risk constants"),
    ("voter_health.ndjson", "authoritative voter health"),
    ("quorum_permille.tilde", "quorum permille"),
    ("tls_matrix.csv", "tls suite scores"),
    ("seccomp_allow.tsv", "seccomp allowlist"),
    ("seccomp_deny.psv", "seccomp denylist"),
    ("retention.ini", "audit retention days"),
    ("defaults.json", "base budget and layer defaults"),
    ("layer_overrides.json", "middle precedence layer"),
    ("pinned_overrides.json", "pinned precedence layer"),
    ("nonce_bounds.toml2", "nonce window floor"),
    ("sessions_cap.csv2", "concurrent session ceiling"),
    ("retry_backoff.psv2", "retry quantization step"),
    ("profile_deltas.json", "per-profile deltas"),
    ("config_schema.json", "required key set"),
    ("validation_rules.json", "artifact and validation rules"),
]


def input_census():
    records = []
    for name, purpose in INPUT_CENSUS:
        path = DATA / name
        records.append(json.dumps({
            "bytes": path.stat().st_size,
            "input": name,
            "purpose": purpose,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        }, sort_keys=True))
    return "\n".join(records) + "\n"


# ---------------------------------------------------------------------------
# commands
# ---------------------------------------------------------------------------


def cmd_derive(args):
    derived, context = derive()
    schema = load_json(args.schema)
    config = build_config(derived, schema, "main")
    validate_config(schema, config)
    write_json(args.out, config)
    print("derived class=%d" % config["active_class"])


def cmd_profile(args):
    config = load_json(args.config)
    profile = apply_profile_deltas(config, args.name)
    write_json(args.out, profile)
    print("profiled %s" % args.name)


def cmd_init(args):
    schema = load_json(args.schema)
    write_json(args.out, contract_strings(schema))
    print("initialized")


def cmd_set(args):
    data = load_json(args.config)
    value = args.value
    if re.fullmatch(r"-?\d+", value):
        value = int(value)
    data[args.key.upper()] = value
    write_json(args.config, data)
    print("set")


def cmd_validate(args):
    schema = load_json(args.schema)
    data = load_json(args.config)
    validate_config(schema, data)
    print("ok")


def cmd_export_report(args):
    data = load_json(args.config)
    commands = []
    if args.commands:
        raw = args.commands.strip()
        if raw.startswith("["):
            commands = json.loads(raw)
        else:
            commands = json.loads(Path(raw).read_text(encoding="utf-8"))
    report = {
        "active_class": data.get("active_class"),
        "commands": commands,
        "config": data,
        "digest": args.digest,
        "ok": True,
        "trailer": data.get("trailer"),
    }
    write_json(args.out, report)
    print("reported")


def package_tool(dest):
    """Repackage the repaired tool deterministically."""
    root = Path(__file__).resolve().parent
    names = sorted(p.name for p in root.iterdir() if p.is_file())
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as zf:
        for name in names:
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            zf.writestr(info, (root / name).read_bytes())


def cmd_build(args):
    """Run the full derivation and emit every graded artifact.

    Every subcommand recorded in the transcript is literally executed here in
    the recorded order, so the transcript is a truthful record.
    """
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    schema_path = args.schema
    schema = load_json(schema_path)
    config_path = outdir / "config.json"

    namespace = lambda **kw: argparse.Namespace(**kw)

    cmd_derive(namespace(schema=schema_path, out=str(config_path)))
    for name in ("canary", "enforce"):
        cmd_profile(namespace(name=name, config=str(config_path),
                              out=str(outdir / ("profile_%s.json" % name))))
    cmd_validate(namespace(schema=schema_path, config=str(config_path)))

    derived, context = derive()
    config = build_config(derived, schema, "main")
    validate_config(schema, config)
    profiles = {}
    for name in ("canary", "enforce"):
        profiles[name] = apply_profile_deltas(config, name)
        validate_config(schema, profiles[name])

    delta_rows = []
    for name in sorted(profiles):
        delta_rows.append({
            "base_quorum_threshold": config["quorum_threshold"],
            "base_risk_index": config["risk_index"],
            "base_session_ttl_seconds": config["session_ttl_seconds"],
            "profile": name,
            "quorum_threshold_delta": profiles[name]["quorum_threshold"] - config["quorum_threshold"],
            "resolved_quorum_threshold": profiles[name]["quorum_threshold"],
            "resolved_risk_index": profiles[name]["risk_index"],
            "resolved_session_ttl_seconds": profiles[name]["session_ttl_seconds"],
            "risk_index_delta": profiles[name]["risk_index"] - config["risk_index"],
            "session_ttl_seconds_delta": profiles[name]["session_ttl_seconds"] - config["session_ttl_seconds"],
        })
    write_json(outdir / "profile_delta_report.json", {"deltas": delta_rows})

    sidecar_admission_matrix(outdir / "admission_matrix.csv", derived, context)
    sidecar_rate_plan(outdir / "rate_limit_plan.ini", derived)
    sidecar_scope_reconciliation(outdir / "scope_reconciliation.tsv", derived, context)
    sidecar_hardening_trace(outdir / "hardening_fold_trace.psv", context)
    sidecar_quorum(outdir / "quorum_plan.kv", derived, context)
    sidecar_risk_ledger(outdir / "risk_ledger.env", derived, context)
    sidecar_precedence(outdir / "precedence_resolution.properties", context)
    sidecar_privilege_map(outdir / "privilege_map.ndjson", context)
    sidecar_seccomp(outdir / "seccomp_summary.tsv", derived)
    sidecar_tls_floor(outdir / "tls_floor.env", derived)
    sidecar_retention(outdir / "retention_schedule.csv", derived)
    sidecar_class_ordering(outdir / "class_ordering.tsv", config, profiles)

    write_text(outdir / "input_census.ndjson", input_census())

    transcript = [
        "task-ctl derive --schema %s --out config.json" % Path(schema_path).name,
        "task-ctl profile --name canary --config config.json --out profile_canary.json",
        "task-ctl profile --name enforce --config config.json --out profile_enforce.json",
        "task-ctl validate --schema %s --config config.json" % Path(schema_path).name,
        "task-ctl export-report --config config.json --out report.json",
        "task-ctl build --schema %s --outdir %s" % (Path(schema_path).name, outdir),
    ]
    digest = hashlib.sha256(Path(config_path).read_bytes()).hexdigest()
    cmd_export_report(namespace(config=str(config_path), out=str(outdir / "report.json"),
                                digest=digest,
                                commands=json.dumps(transcript)))
    report = load_json(outdir / "report.json")
    assert report["commands"] == transcript and report["digest"] == digest

    rules = load_json(DATA / "validation_rules.json")
    if isinstance(schema.get("required_keys"), str):
        schema_keys = [k.strip() for k in schema["required_keys"].split(",") if k.strip()]
    else:
        schema_keys = [str(k).strip() for k in schema.get("required_keys", [])]
    write_json(outdir / "validation_report.json", {
        "active_class": config["active_class"],
        "artifacts": sorted(rules["required_artifacts"]),
        "config_keys": sorted(config),
        "flat": True,
        "forbidden_keys_present": [],
        "missing_keys": [],
        "ok": True,
        "schema_required_keys": sorted(schema_keys),
    })

    write_json(outdir / "summary.json", {
        "active_class": config["active_class"],
        "audit_retention_days": config["audit_retention_days"],
        "burst_ceiling": config["burst_ceiling"],
        "class_selector": context["selector"],
        "effective_scope_count": config["effective_scope_count"],
        "hardening_baseline": config["hardening_baseline"],
        "ingress_rate_limit_qps": config["ingress_rate_limit_qps"],
        "max_concurrent_sessions": config["max_concurrent_sessions"],
        "nonce_window_ms": config["nonce_window_ms"],
        "ok": True,
        "privilege_drop_uid": config["privilege_drop_uid"],
        "profiles": {name: {
            "quorum_threshold": profiles[name]["quorum_threshold"],
            "risk_index": profiles[name]["risk_index"],
            "session_ttl_seconds": profiles[name]["session_ttl_seconds"],
        } for name in sorted(profiles)},
        "quorum_threshold": config["quorum_threshold"],
        "retry_backoff_base_ms": config["retry_backoff_base_ms"],
        "risk_index": config["risk_index"],
        "seccomp_allowed_count": config["seccomp_allowed_count"],
        "session_ttl_seconds": config["session_ttl_seconds"],
        "tls_floor_score": config["tls_floor_score"],
        "trailer": config["trailer"],
    })

    write_text(outdir / "derivation_audit.xml", audit_xml(config, context, transcript))
    write_text(outdir / "convergence_report.txt", convergence_report(config, context, profiles))

    manifest_paths = [outdir / a for a in rules["required_artifacts"]
                      if a != "tool.zip" and a != "reproducibility_manifest.json"]
    manifest = reproducibility_manifest(manifest_paths, transcript)
    manifest["artifact"] = "reproducibility_manifest.json"
    write_json(outdir / "reproducibility_manifest.json", manifest)

    package_tool(outdir / "tool.zip")
    print("built %d artifacts in %s" % (len(rules["required_artifacts"]), outdir))


def main():
    parser = argparse.ArgumentParser(prog="task-ctl")
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("derive")
    p.add_argument("--schema", default=str(DATA / "config_schema.json"))
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_derive)

    p = sub.add_parser("profile")
    p.add_argument("--name", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_profile)

    p = sub.add_parser("init")
    p.add_argument("--schema", default=str(DATA / "config_schema.json"))
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate")
    p.add_argument("--schema", default=str(DATA / "config_schema.json"))
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("export-report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest", default="")
    p.add_argument("--commands")
    p.set_defaults(func=cmd_export_report)

    p = sub.add_parser("build")
    p.add_argument("--schema", default=str(DATA / "config_schema.json"))
    p.add_argument("--outdir", default="/app/out")
    p.set_defaults(func=cmd_build)

    args = parser.parse_args()
    if not getattr(args, "command", None):
        return
    args.func(args)


if __name__ == "__main__":
    main()
