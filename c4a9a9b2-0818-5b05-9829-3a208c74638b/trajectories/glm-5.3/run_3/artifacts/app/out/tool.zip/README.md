# task-ctl

An offline container-image admission-control hardening compiler for a
server-side admission broker. It reads the interacting numeric policy layers
from `/app/data`, selects the active enforcement class, and derives one flat
hardened admission configuration plus the two deployment profiles (canary and
enforce) and every derivation sidecar.

This build has been **repaired**; the derivation now matches the documented
contract recorded across the policy layers.

## Commands

- `init --schema <schema> --out <config>`: seed fixed contract strings.
- `set --config <config> --key <key> --value <value>`: set one scalar key with
  correct case and type coercion; reject any non-scalar value.
- `derive --schema <schema> --out <config>`: derive the hardened configuration.
- `profile --name canary|enforce --config <config> --out <profile>`: apply the
  documented per-profile deltas.
- `validate --schema <schema> --config <config>`: confirm every required key is
  present and the configuration is flat; print `ok`.
- `export-report --config <config> --out <report> --digest <sha256> --commands <json>`:
  emit a truthful command transcript.
- `artifacts --outdir <dir> --commands <json>`: emit every graded artifact.

`run_pipeline.py` drives the full run and repackages the tool deterministically.

## Derivation contract

- Only rows whose status is `ADOPTED` bind for the active enforcement class;
  rows labelled `SUPERSEDED`, `DRAFT`, `SHADOW` or `REVOKED` are decoys.
- Active class: base-budget selector `(max_records // 37) + 3 * retry_limit`
  resolved through the `ADOPTED` selector ranges of `class_index.tsv2`.
- `ingress_rate_limit_qps`: throughput * burst factor (permille), quantized to
  the per-class rate step. `burst_ceiling`: resolved rate limit * class window.
- Scopes: base union overlay minus deny for the active class.
  `effective_scope_count` is that set's cardinality; `privilege_drop_uid` is
  the minimum granted uid subject to the per-class uid floor.
- `hardening_baseline`: ordered carry-aware fold (a control with `carry=1`
  carries its weight into the next adopted control), clamped to the per-class
  bounds and quantized to the hardening step.
- `risk_index`: (baseline complement - baseline) * severity permille / divisor.
- `quorum_threshold`: healthy `ADOPTED` voters * quorum permille, bounded to
  `[1, voters]`.
- `tls_floor_score`, `seccomp_allowed_count`, `audit_retention_days`: from their
  per-class layers within the documented bounds.
- `session_ttl_seconds`, `nonce_window_ms`, `max_concurrent_sessions`:
  defaults, then class override, then pinned override (only `pinned == true`).
- `retry_backoff_base_ms`: timeout * (retry budget) / 8, quantized to the
  per-class step.

## Arithmetic

Every value is derived with exact integer arithmetic (round-half-even); no
floating-point value ever reaches a graded key. Artifacts are byte-stable:
sorted keys wherever the format admits ordering, LF newlines, trailing newline.

## Layout

- `cli.py` - command surface
- `taskctl/policy.py` - policy layer loaders (ADOPTED rows only)
- `taskctl/derive.py` - derivation and profile deltas
- `taskctl/artifacts.py` - deterministic artifact emission
- `schema.json` - required key set for the flat configuration
