#!/usr/bin/env python3
"""task-ctl command line (repaired).

Commands
--------
init            --schema <schema> --out <config>        seed fixed contract strings
set             --config <config> --key k --value v    set one scalar key
derive          --schema <schema> --out <config>       derive the hardened configuration
profile         --name canary|enforce ...              apply the documented profile deltas
validate        --schema <schema> --config <config>    confirm keys and flatness, print ok
export-report   --config <config> --out <report> ...   emit a truthful command transcript
artifacts       --outdir <dir> [--commands <json>]     emit every graded artifact
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from taskctl.artifacts import (  # noqa: E402
    class_ordering_rows,
    emit_audit,
    emit_manifest,
    emit_report,
    emit_sidecars,
    emit_validation,
    write_json,
)
from taskctl.derive import apply_profile, derive  # noqa: E402
from taskctl.policy import load_json  # noqa: E402

DATA = Path("/app/data")
PROFILE_NAMES = ("canary", "enforce")


def required_keys(schema):
    raw = schema["required_keys"]
    return raw if isinstance(raw, list) else [k.strip() for k in raw.split(",") if k.strip()]


def coerce_scalar(value):
    text = str(value).strip()
    return int(text) if re.fullmatch(r"-?\d+", text) else text


# ----------------------------------------------------------------- commands

def cmd_init(args):
    schema = load_json(args.schema)
    data = {k: schema[k] for k in ("profile", "control_plane", "image_runtime", "mode", "checksum")
            if k in schema}
    write_json(args.out, data)
    print("initialized")


def cmd_set(args):
    data = load_json(args.config)
    value = coerce_scalar(args.value)
    if isinstance(value, (dict, list)):
        raise SystemExit("non-scalar value rejected: %s" % args.value)
    data[args.key.strip().lower()] = value
    write_json(args.config, data)
    print("set")


def cmd_derive(args):
    config, _ = derive()
    write_json(args.out, config)
    print("derived")


def cmd_profile(args):
    config = load_json(args.config)
    deltas = load_json(DATA / "profile_deltas.json")
    if args.name not in deltas:
        raise SystemExit("unknown profile: %s" % args.name)
    write_json(args.out, apply_profile(config, args.name))
    print("profiled")


def cmd_validate(args):
    schema = load_json(args.schema)
    data = load_json(args.config)
    missing = [k for k in required_keys(schema) if k not in data]
    if missing:
        raise SystemExit("missing: " + ",".join(missing))
    bad = [k for k, v in data.items() if isinstance(v, (dict, list))]
    if bad:
        raise SystemExit("configuration must be flat: " + ",".join(sorted(bad)))
    print("ok")


def cmd_report(args):
    data = load_json(args.config)
    commands = load_json(args.commands) if args.commands else []
    digest = args.digest or hashlib.sha256(
        json.dumps(data, sort_keys=True).encode("utf-8")).hexdigest()
    report = {
        "ok": True,
        "config": data,
        "config_sha256": digest,
        "commands": commands,
        "trailer": data.get("trailer"),
        "rounding": "round-half-even exact integer arithmetic",
    }
    write_json(args.out, report)
    print("reported")


def cmd_artifacts(args):
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    config, facts = derive()
    profiles = {name: apply_profile(config, name) for name in PROFILE_NAMES}

    write_json(outdir / "config.json", config)
    for name, prof in profiles.items():
        write_json(outdir / ("profile_%s.json" % name), prof)

    deltas = {}
    for name in sorted(profiles):
        diff = {}
        for key in sorted(set(config) | set(profiles[name])):
            if config.get(key) != profiles[name].get(key):
                if isinstance(config.get(key), int) and isinstance(profiles[name].get(key), int):
                    diff[key] = profiles[name][key] - config[key]
                else:
                    diff[key] = "%s -> %s" % (config.get(key), profiles[name].get(key))
        deltas[name] = diff
    write_json(outdir / "profile_delta_report.json", deltas)

    emit_sidecars(outdir, config, facts)
    commands = load_json(args.commands) if args.commands else []
    census = emit_audit(outdir, config, facts, profiles, DATA)
    emit_report(outdir, config, commands)
    validation = emit_validation(outdir, config, facts, profiles, census, commands, outdir)

    summary = {
        "active_class": config["active_class"],
        "selector": facts["selector"],
        "enforcement_profile": config["enforcement_profile"],
        "profiles": {name: {k: profiles[name][k] for k in
                            ("enforcement_profile", "risk_index", "quorum_threshold",
                             "session_ttl_seconds")}
                     for name in sorted(profiles)},
        "risk_ordering": [{"profile": n, "risk_index": r}
                          for n, r in class_ordering_rows(config, profiles)],
        "config_sha256": validation["config_sha256"],
        "validation_ok": validation["ok"],
        "rounding": "round-half-even exact integer arithmetic",
        "trailer": config["trailer"],
        "artifacts": sorted({p.name for p in outdir.iterdir()}
                            | {"summary.json", "reproducibility_manifest.json", "tool.zip"}),
        "inputs": len(census),
        "commands": len(commands),
    }
    write_json(outdir / "summary.json", summary)
    emit_manifest(outdir, commands)
    print("artifacts")


def build_parser():
    parser = argparse.ArgumentParser(prog="task-ctl")
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("init")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("derive")
    p.add_argument("--schema", default=str(DATA / "config_schema.json"))
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_derive)

    p = sub.add_parser("profile")
    p.add_argument("--name", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_profile)

    p = sub.add_parser("validate")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("export-report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest", default=None)
    p.add_argument("--commands", default=None)
    p.set_defaults(func=cmd_report)

    p = sub.add_parser("artifacts")
    p.add_argument("--outdir", required=True)
    p.add_argument("--commands", default=None)
    p.set_defaults(func=cmd_artifacts)
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    if not getattr(args, "command", None):
        parser.print_help()
        return
    args.func(args)


if __name__ == "__main__":
    main()
