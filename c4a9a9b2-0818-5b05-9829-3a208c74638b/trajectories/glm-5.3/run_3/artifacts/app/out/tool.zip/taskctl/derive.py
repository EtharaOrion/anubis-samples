"""Derivation of the hardened admission configuration (repaired logic)."""
from __future__ import annotations

from .policy import (
    ADOPTED,
    DECOY_STATUS,
    HARDENING_STEP,
    PRECEDENCE_FIELDS,
    audit_retention_days,
    base_inputs,
    burst_factor,
    clamp,
    class_selector,
    healthy_voters,
    hardening_bounds,
    hardening_controls,
    load_json,
    nonce_floor_ms,
    privilege_witness,
    quorum_permille,
    quantize,
    rate_step,
    resolve_precedence,
    retry_step,
    risk_constants,
    round_half_even,
    scope_sets,
    scope_uids,
    seccomp_allowed,
    select_active_class,
    session_ceiling,
    severity_permille,
    throughput_qps,
    tls_floor_score,
    uid_floor,
    window_seconds,
)

DATA_SCHEMAS = ("config_schema.json",)

# session TTL granularity applied after the profile permille scaling
PROFILE_TTL_STEP = 5


def hardening_fold(rows):
    """Carry-aware fold over the ordered class-matched controls.

    A control whose carry flag is set carries its weight into the next adopted
    control, so the fold score after control i is the cumulative sum of
    weight_i plus the carried weight of control i-1. Non-adopted controls are
    recorded as skipped and do not disturb the carry chain.
    """
    trace = []
    running = 0
    prev_weight = 0
    prev_carry = 0
    for r in rows:
        weight = int(r["weight"])
        carry = int(r["carry_flag"])
        if r.get("status") == ADOPTED:
            running += weight + (prev_weight if prev_carry else 0)
            cell = str(running)
            prev_weight, prev_carry = weight, carry
        else:
            cell = "skip"
        trace.append({"order": int(r["order"]), "control_id": r["control_id"],
                      "weight": weight, "carry": carry, "status": r["status"], "running": cell})
    return trace, running


def derive():
    max_records, retry_limit, timeout_ms, trailer = base_inputs()
    selector = class_selector(max_records, retry_limit)
    klass = select_active_class(selector)

    # ingress rate limit and burst ceiling
    qps = throughput_qps(klass)
    permille, ini_window = burst_factor(klass)
    step = rate_step(klass)
    window = window_seconds(klass)
    if window != ini_window:
        raise SystemExit("window disagreement between layers for class %d" % klass)
    rate_pre = round_half_even(qps * permille, 1000)
    rate_limit = quantize(rate_pre, step)
    burst_ceiling = rate_limit * window

    # scope reconciliation and privilege drop
    base_set, overlay_set, deny_set = scope_sets(klass)
    effective = (base_set | overlay_set) - deny_set
    uids = scope_uids()
    floor = uid_floor(klass)
    granted = sorted((s, uids[s]) for s in effective if s in uids)
    if not granted:
        raise SystemExit("no granted uid for class %d scopes" % klass)
    min_granted = min(u for _, u in granted)
    privilege_drop_uid = max(min_granted, floor)

    # hardening baseline
    controls = hardening_controls(klass)
    trace, folded = hardening_fold(controls)
    lo, hi = hardening_bounds(klass)
    hardening_baseline = quantize(clamp(folded, lo, hi), HARDENING_STEP)

    # risk index
    complement, divisor = risk_constants()
    severity = severity_permille(klass)
    risk_index = round_half_even((complement - hardening_baseline) * severity, divisor)

    # quorum
    voters = healthy_voters(klass)
    quorum = clamp(round_half_even(voters * quorum_permille(klass), 1000), 1, voters)

    # bounded per-class layers
    tls_score = tls_floor_score(klass)
    seccomp = seccomp_allowed(klass)
    retention = audit_retention_days(klass)

    # precedence-resolved fields
    prec = resolve_precedence(klass)
    if prec["resolved"]["nonce_window_ms"] < nonce_floor_ms(klass):
        raise SystemExit("resolved nonce window below the class floor")
    if prec["resolved"]["max_concurrent_sessions"] > session_ceiling(klass):
        raise SystemExit("resolved session cap above the class ceiling")

    # retry backoff
    backoff = quantize(round_half_even(timeout_ms * (retry_limit + 1), 8), retry_step(klass))

    schema = load_json("/app/data/config_schema.json")
    config = {
        "active_class": klass,
        "audit_retention_days": retention,
        "burst_ceiling": burst_ceiling,
        "checksum": schema["checksum"],
        "control_plane": schema["control_plane"],
        "effective_scope_count": len(effective),
        "enforcement_profile": "main",
        "hardening_baseline": hardening_baseline,
        "image_runtime": schema["image_runtime"],
        "ingress_rate_limit_qps": rate_limit,
        "max_concurrent_sessions": prec["resolved"]["max_concurrent_sessions"],
        "mode": schema["mode"],
        "nonce_window_ms": prec["resolved"]["nonce_window_ms"],
        "privilege_drop_uid": privilege_drop_uid,
        "profile": schema["profile"],
        "quorum_threshold": quorum,
        "retry_backoff_base_ms": backoff,
        "risk_index": risk_index,
        "seccomp_allowed_count": len(seccomp),
        "session_ttl_seconds": prec["resolved"]["session_ttl_seconds"],
        "tls_floor_score": tls_score,
        "trailer": trailer,
    }
    facts = {
        "selector": selector,
        "class": klass,
        "qps": qps,
        "burst_permille": permille,
        "window_seconds": window,
        "rate_step": step,
        "rate_pre": rate_pre,
        "base_scopes": sorted(base_set),
        "overlay_scopes": sorted(overlay_set),
        "deny_scopes": sorted(deny_set),
        "effective_scopes": sorted(effective),
        "granted": granted,
        "uid_floor": floor,
        "min_granted_uid": min_granted,
        "privilege_witness": privilege_witness(klass),
        "controls": trace,
        "folded": folded,
        "bounds": [lo, hi],
        "severity_permille": severity,
        "baseline_complement": complement,
        "risk_divisor": divisor,
        "healthy_voters": voters,
        "quorum_permille": quorum_permille(klass),
        "seccomp_allowed": seccomp,
        "precedence": prec,
        "max_records": max_records,
        "retry_limit": retry_limit,
        "timeout_ms": timeout_ms,
        "hardening_step": HARDENING_STEP,
    }
    return config, facts


def apply_profile(config, name):
    """Apply a documented per-profile delta on top of the main configuration.

    ttl_scale_permille scales the resolved session_ttl_seconds before
    granularity quantization; quorum_delta and risk_delta are signed integer
    adjustments applied after the main derivation.
    """
    deltas = load_json("/app/data/profile_deltas.json")[name]
    out = dict(config)
    out["enforcement_profile"] = name
    out["session_ttl_seconds"] = quantize(
        round_half_even(config["session_ttl_seconds"] * int(deltas["ttl_scale_permille"]), 1000),
        PROFILE_TTL_STEP)
    out["quorum_threshold"] = config["quorum_threshold"] + int(deltas["quorum_delta"])
    out["risk_index"] = config["risk_index"] + int(deltas["risk_delta"])
    return out
