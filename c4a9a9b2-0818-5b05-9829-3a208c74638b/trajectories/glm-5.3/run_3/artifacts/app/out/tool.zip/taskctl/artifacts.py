"""Artifact emission for the repaired task-ctl compiler.

Every artifact is written deterministically: sorted keys where the format
admits ordering, fixed field order elsewhere, LF newlines, trailing newline.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from .policy import (
    ADOPTED,
    DECOY_STATUS,
    PRECEDENCE_FIELDS,
    base_inputs,
    load_json,
    sha256_file,
)


def write_text(path, text):
    Path(path).write_text(text, encoding="utf-8")


def dump_json(obj):
    return json.dumps(obj, sort_keys=True, indent=2, ensure_ascii=False) + "\n"


def write_json(path, data):
    Path(path).write_text(dump_json(data), encoding="utf-8")


# ------------------------------------------------------- derivation sidecars

def emit_rate_limit_plan(outdir, config, facts):
    write_text(outdir / "rate_limit_plan.ini",
               "[rate]\n"
               "class = %d\n" % config["active_class"]
               + "ingress_rate_limit_qps = %d\n" % config["ingress_rate_limit_qps"]
               + "burst_ceiling = %d\n" % config["burst_ceiling"])


def emit_hardening_trace(outdir, config, facts):
    lines = ["order|control_id|weight|carry|status|running"]
    for row in facts["controls"]:
        lines.append("%d|%s|%d|%d|%s|%s" % (row["order"], row["control_id"], row["weight"],
                                            row["carry"], row["status"], row["running"]))
    write_text(outdir / "hardening_fold_trace.psv", "\n".join(lines) + "\n")


def emit_quorum_plan(outdir, config, facts):
    write_text(outdir / "quorum_plan.kv",
               "healthy_voters:%d\nquorum_threshold:%d\n"
               % (facts["healthy_voters"], config["quorum_threshold"]))


def emit_risk_ledger(outdir, config, facts):
    write_text(outdir / "risk_ledger.env",
               "HARDENING_BASELINE=%d\nRISK_INDEX=%d\nSEVERITY_PERMILLE=%d\n"
               % (config["hardening_baseline"], config["risk_index"], facts["severity_permille"]))


def emit_precedence_resolution(outdir, config, facts):
    lines = []
    for field in PRECEDENCE_FIELDS:
        lines.append("%s.default=%d" % (field, facts["precedence"]["defaults"][field]))
        lines.append("%s.resolved=%d" % (field, facts["precedence"]["resolved"][field]))
    write_text(outdir / "precedence_resolution.properties", "\n".join(lines) + "\n")


def emit_privilege_map(outdir, config, facts):
    lines = [json.dumps({"scope": s, "uid": u}, sort_keys=True) for s, u in facts["granted"]]
    write_text(outdir / "privilege_map.ndjson", "\n".join(lines) + "\n")


def emit_seccomp_summary(outdir, config, facts):
    write_text(outdir / "seccomp_summary.tsv",
               "class\tseccomp_allowed_count\n%d\t%d\n"
               % (config["active_class"], config["seccomp_allowed_count"]))


def emit_tls_floor(outdir, config, facts):
    write_text(outdir / "tls_floor.env", "TLS_FLOOR_SCORE=%d\n" % config["tls_floor_score"])


def emit_admission_matrix(outdir, config, facts):
    header = ("class,ingress_qps,burst_permille,window_seconds,rate_step,"
              "ingress_rate_limit_qps,burst_ceiling,healthy_voters,quorum_threshold,"
              "hardening_baseline,risk_index,effective_scope_count,privilege_drop_uid,"
              "seccomp_allowed_count,tls_floor_score,audit_retention_days,session_ttl_seconds,"
              "nonce_window_ms,max_concurrent_sessions,retry_backoff_base_ms")
    row = "%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d" % (
        config["active_class"], facts["qps"], facts["burst_permille"], facts["window_seconds"],
        facts["rate_step"], config["ingress_rate_limit_qps"], config["burst_ceiling"],
        facts["healthy_voters"], config["quorum_threshold"], config["hardening_baseline"],
        config["risk_index"], config["effective_scope_count"], config["privilege_drop_uid"],
        config["seccomp_allowed_count"], config["tls_floor_score"], config["audit_retention_days"],
        config["session_ttl_seconds"], config["nonce_window_ms"], config["max_concurrent_sessions"],
        config["retry_backoff_base_ms"])
    write_text(outdir / "admission_matrix.csv", "\n".join([header, row]) + "\n")


def emit_scope_reconciliation(outdir, config, facts):
    klass = config["active_class"]
    lines = ["layer\tclass\tscopes\tcount"]
    for layer, key, count in (("base", "base_scopes", None),
                              ("overlay", "overlay_scopes", None),
                              ("deny", "deny_scopes", None)):
        scopes = facts[key]
        lines.append("%s\t%d\t%s\t%d" % (layer, klass, " ".join(scopes), len(scopes)))
    lines.append("effective\t%d\t%s\t%d" % (klass, " ".join(facts["effective_scopes"]),
                                            config["effective_scope_count"]))
    write_text(outdir / "scope_reconciliation.tsv", "\n".join(lines) + "\n")


def emit_retention_schedule(outdir, config, facts):
    write_text(outdir / "retention_schedule.csv",
               "class,audit_retention_days\n%d,%d\n"
               % (config["active_class"], config["audit_retention_days"]))


def emit_sidecars(outdir, config, facts):
    emit_rate_limit_plan(outdir, config, facts)
    emit_hardening_trace(outdir, config, facts)
    emit_quorum_plan(outdir, config, facts)
    emit_risk_ledger(outdir, config, facts)
    emit_precedence_resolution(outdir, config, facts)
    emit_privilege_map(outdir, config, facts)
    emit_seccomp_summary(outdir, config, facts)
    emit_tls_floor(outdir, config, facts)
    emit_admission_matrix(outdir, config, facts)
    emit_scope_reconciliation(outdir, config, facts)
    emit_retention_schedule(outdir, config, facts)


# ------------------------------------------------------------- ordering/audit

def class_ordering_rows(config, profiles):
    rows = [("main", config["risk_index"])]
    for name in sorted(profiles):
        rows.append((name, profiles[name]["risk_index"]))
    return sorted(rows, key=lambda r: (r[1], r[0]))


def emit_class_ordering(outdir, config, profiles):
    lines = ["profile\trisk_index"]
    for name, risk in class_ordering_rows(config, profiles):
        lines.append("%s\t%d" % (name, risk))
    write_text(outdir / "class_ordering.tsv", "\n".join(lines) + "\n")


def audit_steps(config, facts):
    return [
        ("selector", "base budget selector (max_records // 37) + 3 * retry_limit", facts["selector"]),
        ("active_class", "ADOPTED selector range lookup in class_index.tsv2", config["active_class"]),
        ("throughput_qps", "ADOPTED ingress throughput for the active class", facts["qps"]),
        ("burst_permille", "ADOPTED burst factor permille", facts["burst_permille"]),
        ("window_seconds", "ADOPTED per-class window", facts["window_seconds"]),
        ("rate_step", "ADOPTED rate quantization step", facts["rate_step"]),
        ("scaled_rate", "throughput * burst factor, round-half-even", facts["rate_pre"]),
        ("ingress_rate_limit_qps", "scaled rate quantized to the class rate step", config["ingress_rate_limit_qps"]),
        ("burst_ceiling", "resolved rate limit * class window", config["burst_ceiling"]),
        ("scope_base", "base scopes unioned", " ".join(facts["base_scopes"])),
        ("scope_overlay", "overlay scopes unioned", " ".join(facts["overlay_scopes"])),
        ("scope_deny", "deny scopes removed", " ".join(facts["deny_scopes"])),
        ("scope_effective", "reconciled effective scope set", " ".join(facts["effective_scopes"])),
        ("effective_scope_count", "cardinality of the effective scope set", config["effective_scope_count"]),
        ("uid_floor", "ADOPTED privilege uid floor", facts["uid_floor"]),
        ("min_granted_uid", "minimum uid granted over the effective scope set", facts["min_granted_uid"]),
        ("privilege_drop_uid", "minimum granted uid subject to the floor", config["privilege_drop_uid"]),
        ("hardening_fold", "carry-aware fold over ADOPTED controls", facts["folded"]),
        ("hardening_bounds", "ADOPTED per-class clamp bounds", "%d..%d" % tuple(facts["bounds"])),
        ("hardening_baseline", "clamped fold quantized to the hardening step", config["hardening_baseline"]),
        ("severity_permille", "ADOPTED severity weight permille", facts["severity_permille"]),
        ("risk_index", "(complement - baseline) * severity / divisor", config["risk_index"]),
        ("healthy_voters", "healthy ADOPTED voters for the class", facts["healthy_voters"]),
        ("quorum_permille", "ADOPTED quorum permille", facts["quorum_permille"]),
        ("quorum_threshold", "voters * quorum permille clamped to [1, voters]", config["quorum_threshold"]),
        ("tls_floor_score", "enabled ADOPTED TLS suite score", config["tls_floor_score"]),
        ("seccomp_allowed_count", "ADOPTED allowed syscalls minus ADOPTED denied", config["seccomp_allowed_count"]),
        ("audit_retention_days", "ADOPTED retention days", config["audit_retention_days"]),
        ("session_ttl_seconds", "precedence-resolved session TTL", config["session_ttl_seconds"]),
        ("nonce_window_ms", "precedence-resolved nonce window", config["nonce_window_ms"]),
        ("max_concurrent_sessions", "precedence-resolved session cap", config["max_concurrent_sessions"]),
        ("retry_backoff_base_ms", "timeout * (retry_limit + 1) / 8 quantized to the class step",
         config["retry_backoff_base_ms"]),
    ]


def emit_derivation_audit(outdir, config, facts, profiles):
    ordering = class_ordering_rows(config, profiles)
    xml = ['<?xml version="1.0" encoding="UTF-8"?>', "<derivationAudit>"]
    xml.append("  <activeClass>%d</activeClass>" % config["active_class"])
    xml.append("  <selector>%d</selector>" % facts["selector"])
    xml.append("  <rounding>round-half-even (banker's), exact integer arithmetic</rounding>")
    xml.append("  <bindingRule>only rows with status %s bind; %s are decoys</bindingRule>"
               % (ADOPTED, ", ".join(DECOY_STATUS)))
    xml.append("  <steps>")
    for name, rule, value in audit_steps(config, facts):
        xml.append('    <step name="%s" rule="%s" value="%s"/>' % (name, rule, value))
    xml.append("  </steps>")
    xml.append("  <profiles>")
    for name, risk in ordering:
        xml.append('    <profile name="%s" riskIndex="%d"/>' % (name, risk))
    xml.append("  </profiles>")
    xml.append("</derivationAudit>")
    write_text(outdir / "derivation_audit.xml", "\n".join(xml) + "\n")


def emit_convergence_report(outdir, config, facts, profiles):
    klass = config["active_class"]
    ordering = class_ordering_rows(config, profiles)
    lines = [
        "task-ctl convergence report",
        "active class: %d (selector %d)" % (klass, facts["selector"]),
        "rounding: exact integer arithmetic, round-half-even",
        "binding rows: status == %s for the active class" % ADOPTED,
        "",
        "layer agreements:",
        "  ingress throughput: %d qps (ingress_rate.tsv == ingress_mirror.pipe == ingress_alt.jsonl2)" % facts["qps"],
        "  burst factor: %d permille (burst_multiplier.ini == burst_alt.properties == burst_mirror.hex2)"
        % facts["burst_permille"],
        "  window seconds: %d (window_seconds.conf == window_mirror.scsv3 == burst_multiplier.ini)"
        % facts["window_seconds"],
        "  rate step: %d (rate_gran.caret == gran_mirror.fixed2)" % facts["rate_step"],
        "  scope count: %d (reconciliation == scopecount_mirror.tsv3)" % config["effective_scope_count"],
        "  severity: %d permille (severity_weight.kv == severity_mirror.caret2 == risk_curve.sexp)"
        % facts["severity_permille"],
        "  quorum permille: %d (quorum_permille.tilde == quorum_mirror.rst2)" % facts["quorum_permille"],
        "  healthy voters: %d (voter_health.ndjson == voters_mirror.kv4)" % facts["healthy_voters"],
        "  tls floor: %d (tls_matrix.csv == tls_mirror.tilde3 == tls_suites.rst)" % config["tls_floor_score"],
        "  privilege uid: %d (uid_map.env minimum == privilege_bits.b64 ADOPTED witness)"
        % config["privilege_drop_uid"],
        "  retention: %d days (retention.ini == retention_alt.kv2 == retention_mirror.psv4)"
        % config["audit_retention_days"],
        "",
        "hardening fold trace:",
    ]
    for row in facts["controls"]:
        lines.append("  order=%d control=%s weight=%d carry=%d status=%s running=%s"
                     % (row["order"], row["control_id"], row["weight"], row["carry"],
                        row["status"], row["running"]))
    lines += [
        "",
        "folded=%d bounds=%d..%d hardening_baseline=%d" % (
            facts["folded"], facts["bounds"][0], facts["bounds"][1], config["hardening_baseline"]),
        "precedence resolution: " + ", ".join(
            "%s %d->%d" % (f, facts["precedence"]["defaults"][f], facts["precedence"]["resolved"][f])
            for f in PRECEDENCE_FIELDS),
        "profile ordering (ascending risk index): " + ", ".join("%s=%d" % r for r in ordering),
        "status: converged",
    ]
    write_text(outdir / "convergence_report.txt", "\n".join(lines) + "\n")


def emit_input_census(outdir, data_dir):
    rows = [{"file": p.name, "sha256": sha256_file(p), "bytes": p.stat().st_size}
            for p in sorted(data_dir.iterdir()) if p.is_file()]
    with (outdir / "input_census.ndjson").open("w", encoding="utf-8") as fh:
        for row in rows:
            fh.write(json.dumps(row, sort_keys=True) + "\n")
    return rows


def emit_audit(outdir, config, facts, profiles, data_dir):
    emit_class_ordering(outdir, config, profiles)
    emit_derivation_audit(outdir, config, facts, profiles)
    emit_convergence_report(outdir, config, facts, profiles)
    return emit_input_census(outdir, data_dir)


# ------------------------------------------------------- validation/summary

def validation_checks(config, facts, profiles, census, commands, outdir, pending=()):
    rules = load_json("/app/data/validation_rules.json")
    schema = load_json("/app/data/config_schema.json")
    required = schema["required_keys"] if isinstance(schema["required_keys"], list) else \
        [k.strip() for k in schema["required_keys"].split(",") if k.strip()]
    missing = [k for k in required if k not in config]
    forbidden = [k for k in rules["forbidden_keys"] if k in config]
    lo, hi = facts["bounds"]
    names = sorted({p.name for p in outdir.iterdir()} | set(pending) | {"tool.zip"})
    return [
        {"check": "required_keys_present", "ok": not missing, "detail": missing},
        {"check": "configuration_flat",
         "ok": all(not isinstance(v, (dict, list)) for v in config.values()), "detail": []},
        {"check": "no_forbidden_keys", "ok": not forbidden, "detail": forbidden},
        {"check": "trailer_canonical", "ok": config["trailer"] == base_inputs()[3], "detail": []},
        {"check": "trailer_in_profiles",
         "ok": all(profiles[n]["trailer"] == config["trailer"] for n in profiles), "detail": []},
        {"check": "scope_count_matches_reconciliation",
         "ok": config["effective_scope_count"] == len(facts["effective_scopes"]), "detail": []},
        {"check": "privilege_map_line_count",
         "ok": len(facts["granted"]) == config["effective_scope_count"], "detail": []},
        {"check": "privilege_uid_at_or_above_floor",
         "ok": config["privilege_drop_uid"] >= facts["uid_floor"], "detail": []},
        {"check": "privilege_uid_is_floored_minimum",
         "ok": config["privilege_drop_uid"] == max(facts["min_granted_uid"], facts["uid_floor"]), "detail": []},
        {"check": "privilege_uid_witness_agrees",
         "ok": facts["privilege_witness"] in (None, config["privilege_drop_uid"]), "detail": []},
        {"check": "hardening_within_bounds", "ok": lo <= config["hardening_baseline"] <= hi, "detail": []},
        {"check": "quorum_bounded",
         "ok": 1 <= config["quorum_threshold"] <= facts["healthy_voters"], "detail": []},
        {"check": "profiles_present", "ok": sorted(profiles) == sorted(rules["profiles"]), "detail": []},
        {"check": "profiles_keep_flat",
         "ok": all(not isinstance(v, (dict, list)) for p in profiles.values() for v in p.values()), "detail": []},
        {"check": "class_ordering_sorted",
         "ok": [r[1] for r in class_ordering_rows(config, profiles)]
         == sorted(r[1] for r in class_ordering_rows(config, profiles)), "detail": []},
        {"check": "required_artifacts_written",
         "ok": set(rules["required_artifacts"]) <= set(names),
         "detail": sorted(set(rules["required_artifacts"]) - set(names))},
        {"check": "artifacts_within_size_limit",
         "ok": all(((outdir / n).stat().st_size if (outdir / n).exists() else 0)
                   <= rules["max_artifact_bytes"] for n in names),
         "detail": []},
    ]


def emit_validation(outdir, config, facts, profiles, census, commands, outdir_path):
    pending = ("validation_report.json", "summary.json", "reproducibility_manifest.json")
    checks = validation_checks(config, facts, profiles, census, commands, outdir_path, pending)
    report = {
        "ok": all(c["ok"] for c in checks),
        "checks": checks,
        "config_sha256": hashlib.sha256(dump_json(config).encode("utf-8")).hexdigest(),
        "inputs_hashed": len(census),
        "commands": len(commands),
    }
    write_json(outdir / "validation_report.json", report)
    return report


# ----------------------------------------------------------- report/manifest

def emit_report(outdir, config, commands):
    digest = hashlib.sha256(json.dumps(config, sort_keys=True).encode("utf-8")).hexdigest()
    report = {
        "ok": True,
        "config": config,
        "config_sha256": digest,
        "commands": commands,
        "trailer": config.get("trailer"),
        "rounding": "round-half-even exact integer arithmetic",
    }
    write_json(outdir / "report.json", report)
    return report


def emit_manifest(outdir, commands):
    """Reproducibility manifest: hashes of every emitted artifact (but itself)."""
    entries = []
    for path in sorted(outdir.iterdir()):
        if path.is_file() and path.name != "reproducibility_manifest.json":
            entries.append({"artifact": path.name, "bytes": path.stat().st_size,
                            "sha256": sha256_file(path)})
    manifest = {
        "artifacts": entries,
        "artifact_count": len(entries),
        "command_count": len(commands),
        "deterministic": True,
        "hash": "sha256",
        "key_order": "sorted",
        "newlines": "LF",
        "rounding": "round-half-even exact integer arithmetic",
        "tool": "task-ctl",
    }
    write_json(outdir / "reproducibility_manifest.json", manifest)
    return manifest

