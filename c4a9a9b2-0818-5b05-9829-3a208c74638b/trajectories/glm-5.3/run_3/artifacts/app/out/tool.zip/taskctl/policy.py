"""Policy layer loaders for the repaired task-ctl compiler.

Every loader binds only rows whose status is ADOPTED for the requested
enforcement class; SUPERSEDED, DRAFT, SHADOW and REVOKED rows are decoys.
"""
from __future__ import annotations

import base64
import configparser
import hashlib
import json
import re
from pathlib import Path

DATA = Path("/app/data")
ADOPTED = "ADOPTED"
DECOY_STATUS = ("SUPERSEDED", "DRAFT", "SHADOW", "REVOKED")

PRECEDENCE_FIELDS = ("session_ttl_seconds", "nonce_window_ms", "max_concurrent_sessions")
HARDENING_STEP = 5


# ---------------------------------------------------------------- utilities

def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def round_half_even(num, den):
    """Exact round-half-even of num/den for integers (den > 0). No floats."""
    if den <= 0:
        raise ValueError("denominator must be positive")
    sign = 1
    if num < 0:
        sign, num = -1, -num
    q, r = divmod(num, den)
    twice = 2 * r
    if twice > den or (twice == den and q % 2 == 1):
        q += 1
    return sign * q


def quantize(value, step):
    """Quantize value to a multiple of step using round-half-even."""
    return round_half_even(value, step) * step


def clamp(value, lo, hi):
    return max(lo, min(hi, value))


def read_lines(name):
    out = []
    for line in (DATA / name).read_text(encoding="utf-8", errors="replace").split("\n"):
        s = line.strip()
        if not s or s.startswith("#") or s.startswith(";"):
            continue
        out.append(line)
    return out


def delimited_rows(name, sep):
    """Delimited rows: first non-comment line is the header, cells stripped."""
    lines = [[c.strip() for c in line.strip().split(sep)] for line in read_lines(name)]
    if not lines:
        return []
    header = lines[0]
    rows = []
    for parts in lines[1:]:
        if len(parts) != len(header):
            continue
        rows.append(dict(zip(header, parts)))
    return rows


def adopted(rows, klass, key="class_id"):
    return [r for r in rows if str(r.get(key)) == str(klass) and r.get("status") == ADOPTED]


def ndjson_rows(name):
    out = []
    for line in (DATA / name).read_text(encoding="utf-8", errors="replace").split("\n"):
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        try:
            out.append(json.loads(s))
        except ValueError:
            continue
    return out


def ini_sections(name):
    cp = configparser.ConfigParser()
    cp.optionxform = str
    cp.read(DATA / name)
    return cp


def kv_pairs(name, sep):
    out = []
    for line in read_lines(name):
        key, _, val = line.strip().partition(sep)
        out.append((key.strip(), val.strip()))
    return out


def toml_blocks(name):
    """Minimal [section] key = value parser (quoted or bare values)."""
    blocks = {}
    current = None
    for raw in (DATA / name).read_text(encoding="utf-8").split("\n"):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        m = re.match(r"^\[([^\]]+)\]$", line)
        if m:
            current = m.group(1)
            blocks[current] = {}
            continue
        m = re.match(r"^([A-Za-z0-9_]+)\s*=\s*(.+?)\s*$", line)
        if m and current is not None:
            val = m.group(2)
            if len(val) >= 2 and val[0] == val[-1] and val[0] in "\"'":
                val = val[1:-1]
            blocks[current][m.group(1)] = val
    return blocks


def colon_triples(name):
    out = []
    for line in read_lines(name):
        parts = [p.strip() for p in line.split(":")]
        if len(parts) == 3:
            out.append(tuple(parts))
    return out


def sha256_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


# ------------------------------------------------------------- policy layers

def base_inputs():
    base = load_json(DATA / "defaults.json")["base_config"]
    return int(base["max_records"]), int(base["retry_limit"]), int(base["timeout_ms"]), str(base["trailer"])


def class_selector(max_records, retry_limit):
    """Documented base-budget selector: (max_records // 37) + 3 * retry_limit."""
    return (max_records // 37) + 3 * retry_limit


def select_active_class(selector):
    """Resolve the selector through the ADOPTED selector ranges."""
    for row in delimited_rows("class_index.tsv2", "\t"):
        try:
            lo, hi = int(row["selector_lo"]), int(row["selector_hi"])
        except (KeyError, ValueError):
            continue
        if row.get("status") == ADOPTED and lo <= selector <= hi:
            return int(row["class_id"])
    raise SystemExit("no ADOPTED selector range covers %d" % selector)


def throughput_qps(klass):
    rows = adopted(delimited_rows("ingress_rate.tsv", "\t"), klass)
    if not rows:
        raise SystemExit("no ADOPTED throughput row for class %s" % klass)
    return int(rows[0]["ingress_qps"])


def burst_factor(klass):
    section = "class.%d" % klass
    cp = ini_sections("burst_multiplier.ini")
    if not cp.has_section(section) or cp.get(section, "status") != ADOPTED:
        raise SystemExit("no ADOPTED burst block for class %s" % klass)
    return int(cp.get(section, "burst_multiplier_permille")), int(cp.get(section, "window_seconds"))


def rate_step(klass):
    rows = adopted(delimited_rows("rate_gran.caret", "^"), klass)
    return int(rows[0]["gran"])


def window_seconds(klass):
    rows = []
    for line in read_lines("window_seconds.conf"):
        parts = line.split()
        if len(parts) == 3:
            rows.append({"class_id": parts[0], "window": parts[1], "status": parts[2]})
    hit = adopted(rows, klass)
    if not hit:
        raise SystemExit("no ADOPTED window row for class %s" % klass)
    return int(hit[0]["window"])


def scope_sets(klass):
    base_rows = adopted(ndjson_rows("scope_base.jsonl"), klass)
    overlay_rows = adopted(ndjson_rows("scope_overlay.ndjson"), klass)
    deny_rows = adopted(delimited_rows("scope_deny.psv", "|"), klass)
    return ({r["scope"] for r in base_rows},
            {r["scope"] for r in overlay_rows},
            {r["scope"] for r in deny_rows})


def scope_uids():
    uids = {}
    for key, val in kv_pairs("uid_map.env", "="):
        if key.startswith("SCOPE_") and val.lstrip("-").isdigit():
            uids[key[len("SCOPE_"):].lower()] = int(val)
    return uids


def uid_floor(klass):
    lines = [[c.strip() for c in line.strip().split(":")] for line in read_lines("uid_floor.hex")]
    header, rows = lines[0], lines[1:]
    for parts in rows:
        if len(parts) != len(header):
            continue
        row = dict(zip(header, parts))
        if row["class_id"] == str(klass) and row["status"] == ADOPTED:
            return int(row["floor_hex"], 16)
    raise SystemExit("no ADOPTED uid floor for class %s" % klass)


def hardening_controls(klass):
    rows = [r for r in delimited_rows("baseline_controls.scsv", ";")
            if str(r.get("class_id")) == str(klass)]
    rows.sort(key=lambda r: int(r["order"]))
    return rows


def hardening_bounds(klass):
    blk = toml_blocks("hardening_bounds.toml").get("class.%d" % klass)
    if not blk or blk.get("status") != ADOPTED:
        raise SystemExit("no ADOPTED hardening bounds for class %s" % klass)
    return int(blk["floor"]), int(blk["ceil"])


def severity_permille(klass):
    for key, val, status in colon_triples("severity_weight.kv"):
        if key == "class%d" % klass and status == ADOPTED:
            return int(val)
    raise SystemExit("no ADOPTED severity for class %s" % klass)


def quorum_permille(klass):
    rows = adopted(delimited_rows("quorum_permille.tilde", "~"), klass)
    if not rows:
        raise SystemExit("no ADOPTED quorum permille for class %s" % klass)
    return int(rows[0]["permille"])


def healthy_voters(klass):
    return sum(1 for r in ndjson_rows("voter_health.ndjson")
               if str(r.get("class_id")) == str(klass)
               and r.get("status") == ADOPTED and r.get("healthy") is True)


def tls_floor_score(klass):
    for r in adopted(delimited_rows("tls_matrix.csv", ","), klass):
        if r.get("enabled") == "true":
            return int(r["score"])
    raise SystemExit("no enabled ADOPTED TLS suite for class %s" % klass)


def seccomp_allowed(klass):
    allow = {r["syscall"] for r in adopted(delimited_rows("seccomp_allow.tsv", "\t"), klass)}
    deny = {r["syscall"] for r in adopted(delimited_rows("seccomp_deny.psv", "|"), klass)}
    return sorted(allow - deny)


def audit_retention_days(klass):
    section = "class.%d" % klass
    cp = ini_sections("retention.ini")
    if not cp.has_section(section) or cp.get(section, "status") != ADOPTED:
        raise SystemExit("no ADOPTED retention block for class %s" % klass)
    return int(cp.get(section, "retention_days"))


def retry_step(klass):
    rows = adopted(delimited_rows("retry_backoff.psv2", "||"), klass)
    if not rows:
        raise SystemExit("no ADOPTED retry step for class %s" % klass)
    return int(rows[0]["step"])


def session_ceiling(klass):
    rows = adopted(delimited_rows("sessions_cap.csv2", ","), klass)
    return int(rows[0]["abs_ceil"])


def nonce_floor_ms(klass):
    blk = toml_blocks("nonce_bounds.toml2").get("class.%d" % klass)
    if not blk or blk.get("status") != ADOPTED:
        raise SystemExit("no ADOPTED nonce bounds for class %s" % klass)
    return int(blk["floor_ms"])


def risk_constants():
    vals = {}
    for key, val in kv_pairs("risk_const.env2", "="):
        if key in ("BASELINE_COMPLEMENT", "RISK_DIVISOR") and val.lstrip("-").isdigit():
            vals[key] = int(val)
    return vals["BASELINE_COMPLEMENT"], vals["RISK_DIVISOR"]


def privilege_witness(klass):
    """Cross-check witness row (base64 of 'class=k;uid=<min>;status=S')."""
    for line in read_lines("privilege_bits.b64"):
        try:
            text = base64.b64decode(line.strip()).decode("utf-8")
        except ValueError:
            continue
        fields = dict(p.split("=", 1) for p in text.split(";") if "=" in p)
        if fields.get("class") == str(klass) and fields.get("status") == ADOPTED:
            return int(fields["uid"])
    return None


def resolve_precedence(klass):
    """defaults -> class override -> pinned override (only when pinned==true)."""
    defaults = load_json(DATA / "defaults.json")["layer_defaults"]
    overrides = load_json(DATA / "layer_overrides.json").get("class_%d" % klass, {})
    pinned_block = load_json(DATA / "pinned_overrides.json").get("class_%d" % klass, {})
    pinned = pinned_block.get("pinned") is True
    resolved = {}
    for field in PRECEDENCE_FIELDS:
        value = int(defaults[field])
        if field in overrides:
            value = int(overrides[field])
        if pinned and field in pinned_block:
            value = int(pinned_block[field])
        resolved[field] = value
    return {
        "defaults": {f: int(defaults[f]) for f in PRECEDENCE_FIELDS},
        "overrides": {f: int(overrides[f]) for f in PRECEDENCE_FIELDS if f in overrides},
        "pinned": pinned,
        "pinned_values": {f: int(pinned_block[f]) for f in PRECEDENCE_FIELDS if f in pinned_block},
        "resolved": resolved,
    }
