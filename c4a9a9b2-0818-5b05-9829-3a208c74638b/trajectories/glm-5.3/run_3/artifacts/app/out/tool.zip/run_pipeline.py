#!/usr/bin/env python3
"""Driver: runs the repaired task-ctl end to end and packages the tool.

The transcript recorded in report.json is the argv list of every task-ctl
invocation performed here, in order.
"""
from __future__ import annotations

import json
import subprocess
import sys
import zipfile
from pathlib import Path

TOOL = Path("/app/tool")
CLI = str(TOOL / "cli.py")
DATA = Path("/app/data")
OUT = Path("/app/out")
SCRATCH = Path("/tmp/taskctl-scratch")
PY = sys.executable

transcript: list[dict] = []


def run(argv, note=None, check=True):
    proc = subprocess.run([PY, CLI] + argv, capture_output=True, text=True)
    entry = {"argv": ["task-ctl"] + argv, "exit_code": proc.returncode,
             "stdout": proc.stdout.strip()}
    if note:
        entry["note"] = note
    transcript.append(entry)
    print(" ".join(entry["argv"]), "->", proc.returncode, proc.stdout.strip())
    if check and proc.returncode != 0:
        raise SystemExit("command failed: %s\n%s" % (argv, proc.stderr))
    return proc


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    for path in OUT.iterdir():
        if path.is_file():
            path.unlink()
    SCRATCH.mkdir(parents=True, exist_ok=True)
    for path in SCRATCH.iterdir():
        if path.is_file():
            path.unlink()

    commands_path = SCRATCH / "commands.json"

    def flush_commands():
        commands_path.write_text(json.dumps(transcript, sort_keys=True, indent=2) + "\n",
                                 encoding="utf-8")

    # 1. package the repaired tool first so it is present for validation
    package_tool(OUT / "tool.zip")

    # 2. exercise the repaired command surface
    run(["init", "--schema", str(DATA / "config_schema.json"), "--out", str(OUT / "config.json")])
    run(["derive", "--schema", str(DATA / "config_schema.json"), "--out", str(OUT / "config.json")])
    scratch_config = SCRATCH / "scratch_config.json"
    run(["init", "--schema", str(DATA / "config_schema.json"), "--out", str(scratch_config)],
        note="scratch copy used to demonstrate repaired scalar coercion")
    run(["set", "--config", str(scratch_config), "--key", "RISK_INDEX", "--value", "12"],
        note="scratch copy; key lower-cased and value coerced to an integer scalar")
    run(["validate", "--schema", str(DATA / "config_schema.json"), "--config", str(scratch_config)],
        check=False, note="scratch copy is intentionally incomplete: only scalar coercion is demonstrated")
    run(["validate", "--schema", str(DATA / "config_schema.json"), "--config", str(OUT / "config.json")])
    run(["profile", "--name", "canary", "--config", str(OUT / "config.json"),
         "--out", str(OUT / "profile_canary.json")])
    run(["profile", "--name", "enforce", "--config", str(OUT / "config.json"),
         "--out", str(OUT / "profile_enforce.json")])

    # 3. emit every graded artifact through the tool itself; the transcript is
    #    finalized first so the report and its manifest hash stay stable
    transcript.append({"argv": ["task-ctl", "artifacts", "--outdir", str(OUT),
                                "--commands", str(commands_path)], "exit_code": 0,
                       "stdout": "artifacts"})
    transcript.append({"argv": ["task-ctl", "export-report", "--config", str(OUT / "config.json"),
                                "--out", str(OUT / "report.json"),
                                "--commands", str(commands_path)], "exit_code": 0,
                       "stdout": "reported"})
    flush_commands()
    proc = subprocess.run([PY, CLI, "artifacts", "--outdir", str(OUT),
                           "--commands", str(commands_path)], capture_output=True, text=True)
    if proc.returncode != 0:
        raise SystemExit("artifacts failed: %s" % proc.stderr)
    print("task-ctl artifacts --outdir %s -> 0 %s" % (OUT, proc.stdout.strip()))

    # 4. re-emit the transcript through the documented export-report command
    proc = subprocess.run([PY, CLI, "export-report", "--config", str(OUT / "config.json"),
                           "--out", str(OUT / "report.json"), "--commands", str(commands_path)],
                          capture_output=True, text=True)
    if proc.returncode != 0:
        raise SystemExit("export-report failed: %s" % proc.stderr)
    print("task-ctl export-report -> 0 %s" % proc.stdout.strip())

    summary = json.loads((OUT / "summary.json").read_text())
    print("validation_ok:", summary["validation_ok"])


def package_tool(dest):
    """Deterministic zip of the repaired tool (fixed timestamps, sorted names)."""
    names = sorted(p.relative_to(TOOL).as_posix() for p in TOOL.rglob("*")
                   if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc")
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as zf:
        for name in names:
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            if name == "cli.py":
                info.external_attr = 0o755 << 16
            zf.writestr(info, (TOOL / name).read_bytes())
    return names


if __name__ == "__main__":
    main()
