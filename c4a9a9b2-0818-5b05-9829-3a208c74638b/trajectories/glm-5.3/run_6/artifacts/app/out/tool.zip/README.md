# task-ctl

An offline container-image admission-control hardening compiler for a
server-side admission broker. It reads interacting numeric policy layers from
`/app/data`, selects the active enforcement class, and derives one flat hardened
admission configuration plus two deployment profiles (canary and enforce).

This build is repaired: every derivation step now follows the documented
contract recorded across the policy layers, and the command surface is complete.

## Commands

- `init --schema <schema> --out <config>`: seed fixed contract strings.
- `set --config <config> --key <key> --value <value>`: set one scalar key with
  correct case and type coercion; reject any non-scalar value.
- `derive --out <config>`: derive the flat hardened admission configuration for
  the active enforcement class.
- `profile --name <canary|enforce> --config <config> --out <profile>`: apply the
  documented per-profile deltas on top of the derived configuration.
- `validate --schema <schema> --config <config>`: confirm every required key is
  present, the configuration is flat, and no unexpected key is present; print `ok`.
- `export-report --config <config> --out <report> --digest <sha256> --commands <json>`:
  emit a truthful command transcript.
- `compile --outdir <dir>`: run the whole pipeline and emit every configuration,
  profile, derivation sidecar, audit and coverage artifact in one deterministic pass.

## Contract notes

- Every value is derived with exact integer arithmetic (round-half-even); no
  floating-point value may reach a graded key.
- The configuration is flat: keys map directly to integer or string scalars.
- The required key set is authoritative in `schema.json` and mirrored by the
  field registry in the policy layers.
- Only rows whose status is `ADOPTED` for the active enforcement class bind; rows
  labelled `SUPERSEDED`, `DRAFT`, `SHADOW`, or `REVOKED` are context decoys.
- The active class is the single `ADOPTED` selector range of `class_index.tsv2`
  containing the base budget folded into the selector span; never the first row.
- Ingress rate = per-class throughput x burst factor, round-half-even, quantised
  to the per-class rate step; burst ceiling = resolved rate x per-class window.
- Effective scopes = base union overlay minus deny for the active class; the
  privilege-drop uid is the minimum granted uid, bounded below by the class floor.
- Hardening baseline = ordered carry-aware fold of the adopted controls, clamped
  to the per-class bounds and quantised; risk index follows from the baseline and
  the per-class severity permille.
- Quorum = healthy authoritative voters x quorum permille, round-half-even,
  bounded to [1, voter count].
- Precedence fields resolve default -> class override -> pinned (only when the
  pin flag is true).

