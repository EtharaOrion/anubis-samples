#!/usr/bin/env python3
"""task-ctl: local admission-control hardening compiler (REPAIRED).

Compiles one flat hardened admission configuration for the active enforcement
class of a server-side admission broker from the interacting numeric policy
layers under /app/data, plus the canary/enforce deployment profiles and every
derivation/audit sidecar.

All arithmetic reaching a graded value is exact integer arithmetic with
round-half-even (banker's) rounding; no floating point is used anywhere.
"""
from __future__ import annotations

import argparse
import base64
import configparser
import hashlib
import json
import re
import zipfile
from pathlib import Path

DATA = Path("/app/data")
ADOPTED = "ADOPTED"

# documented contract granularity for the hardening baseline and session TTL
HARDENING_STEP = 5
TTL_STEP = 5

PRECEDENCE_FIELDS = ("session_ttl_seconds", "nonce_window_ms", "max_concurrent_sessions")

# files that make up the distributable tool archive
TOOL_FILES = ("README.md", "cli.py", "schema.json")


# ---------------------------------------------------------------- utilities

def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def dump_json(obj):
    return json.dumps(obj, sort_keys=True, indent=2) + "\n"


def write_text(path, text):
    Path(path).write_text(text, encoding="utf-8")


def write_json(path, data):
    write_text(path, dump_json(data))


def raw_lines(name):
    out = []
    for line in (DATA / name).read_text(encoding="utf-8", errors="replace").split("\n"):
        s = line.strip()
        if not s or s.startswith("#") or s.startswith(";"):
            continue
        out.append(s)
    return out


def split_row(line, sep):
    parts = [c.strip() for c in line.split(sep)]
    return [p for p in parts if p != ""]


def delimited_rows(name, sep):
    lines = raw_lines(name)
    if not lines:
        return []
    header = split_row(lines[0], sep)
    rows = []
    for line in lines[1:]:
        parts = split_row(line, sep)
        if len(parts) != len(header):
            continue
        rows.append(dict(zip(header, parts)))
    return rows


def adopted(rows, **match):
    """Rows whose status is ADOPTED (authoritative) and whose fields match."""
    out = []
    for r in rows:
        if str(r.get("status", "")).strip().upper() != ADOPTED:
            continue
        ok = True
        for k, v in match.items():
            if str(r.get(k, "")).strip() != str(v):
                ok = False
                break
        if ok:
            out.append(r)
    return out


def round_half_even(num, den):
    """Exact integer round-half-even of num/den."""
    if den < 0:
        num, den = -num, -den
    q, r = divmod(num, den)
    twice = 2 * r
    if twice > den or (twice == den and (q % 2) == 1):
        q += 1
    return q


def quantize_floor(value, step):
    return (value // step) * step


# ------------------------------------------------------------ layer readers

def ini_sections(name):
    cp = configparser.ConfigParser()
    cp.optionxform = str
    cp.read_string((DATA / name).read_text(encoding="utf-8", errors="replace"))
    return cp


def base_inputs():
    base = load_json(DATA / "defaults.json")["base_config"]
    return (
        int(base["max_records"]),
        int(base["retry_limit"]),
        int(base["timeout_ms"]),
        str(base["trailer"]),
    )


def layer_defaults():
    return dict(load_json(DATA / "defaults.json")["layer_defaults"])


def contract_strings():
    for source in (DATA / "defaults.json", DATA / "config_schema.json"):
        d = load_json(source)
        if all(k in d for k in ("profile", "control_plane", "image_runtime", "mode", "checksum")):
            return {
                "profile": d["profile"],
                "control_plane": d["control_plane"],
                "image_runtime": d["image_runtime"],
                "mode": d["mode"],
                "checksum": d["checksum"],
            }
    raise SystemExit("contract strings not found")


def active_class(max_records):
    """Active enforcement class from the documented base budget rule.

    The authoritative (ADOPTED) selector ranges of class_index.tsv2 partition
    the selector space [0, span); the base budget is folded into that space and
    the single ADOPTED range containing it is the active class.  Decoy rows
    (SHADOW/DRAFT/REVOKED/SUPERSEDED) never bind.
    """
    rows = delimited_rows("class_index.tsv2", "\t")
    auth = adopted(rows)
    his = [int(r["selector_hi"]) for r in auth]
    if not his:
        raise SystemExit("no authoritative class selector ranges")
    span = max(his) + 1
    selector = max_records % span
    hits = [
        int(r["class_id"])
        for r in auth
        if int(r["selector_lo"]) <= selector <= int(r["selector_hi"])
    ]
    if len(hits) != 1:
        raise SystemExit("active class selection is not unique for selector %d" % selector)
    return hits[0], selector, span


def ingress_qps(klass):
    rows = adopted(delimited_rows("ingress_rate.tsv", "\t"), class_id=klass)
    if len(rows) != 1:
        raise SystemExit("ingress rate layer is not unique for class %s" % klass)
    return int(rows[0]["ingress_qps"])


def burst_layer(klass):
    cp = ini_sections("burst_multiplier.ini")
    sec = "class.%d" % klass
    if not cp.has_section(sec) or cp.get(sec, "status").strip().upper() != ADOPTED:
        raise SystemExit("burst layer missing for class %s" % klass)
    return int(cp.get(sec, "burst_multiplier_permille")), int(cp.get(sec, "window_seconds"))


def rate_step(klass):
    rows = adopted(delimited_rows("rate_gran.caret", "^"), class_id=klass)
    if len(rows) != 1:
        raise SystemExit("rate granularity layer is not unique for class %s" % klass)
    return int(rows[0]["gran"])


def window_seconds(klass):
    for line in raw_lines("window_seconds.conf"):
        parts = line.split()
        if len(parts) != 3:
            continue
        cid, win, status = parts
        if cid == str(klass) and status.strip().upper() == ADOPTED:
            return int(win)
    raise SystemExit("window layer missing for class %s" % klass)


def scope_sets(klass):
    def pick(rows):
        return {
            str(r["scope"])
            for r in rows
            if str(r.get("class_id")) == str(klass)
            and str(r.get("status", "")).upper() == ADOPTED
        }

    base = pick([json.loads(l) for l in raw_lines("scope_base.jsonl")])
    overlay = pick([json.loads(l) for l in raw_lines("scope_overlay.ndjson")])
    deny = {r["scope"] for r in adopted(delimited_rows("scope_deny.psv", "|"), class_id=klass)}
    return base, overlay, deny


def uid_map():
    uids = {}
    for line in raw_lines("uid_map.env"):
        key, _, val = line.partition("=")
        key = key.strip()
        if key.startswith("SCOPE_") and val.strip().isdigit():
            uids[key[len("SCOPE_"):].lower()] = int(val.strip())
    return uids


def uid_floor(klass):
    for r in adopted(delimited_rows("uid_floor.hex", ":"), class_id=klass):
        return int(r["floor_hex"], 16)
    raise SystemExit("uid floor layer missing for class %s" % klass)


def privilege_mirror(klass):
    for line in raw_lines("privilege_bits.b64"):
        try:
            payload = base64.b64decode(line.strip(), validate=True).decode("utf-8")
        except Exception:
            continue
        fields = dict(p.split("=", 1) for p in payload.split(";") if "=" in p)
        if fields.get("class") == str(klass) and fields.get("status") == ADOPTED:
            return int(fields["uid"])
    return None


def control_rows(klass):
    rows = [
        r
        for r in delimited_rows("baseline_controls.scsv", ";")
        if str(r.get("class_id")).strip() == str(klass)
    ]
    rows.sort(key=lambda r: int(r["order"]))
    return rows


def hardening_bounds(klass):
    cp = ini_sections("hardening_bounds.toml")
    sec = "class.%d" % klass
    if not cp.has_section(sec):
        raise SystemExit("hardening bounds missing for class %s" % klass)
    if cp.get(sec, "status").strip().strip('"').upper() != ADOPTED:
        raise SystemExit("hardening bounds not authoritative for class %s" % klass)
    return int(cp.get(sec, "floor")), int(cp.get(sec, "ceil"))


def fold_controls(rows):
    """Ordered carry-aware fold over the adopted controls.

    A control whose carry flag is set carries its weight into the next adopted
    control, so that weight is counted once for itself and once for its
    successor.  Returns (total, trace) with one trace entry per class row.
    """
    total = 0
    trace = []
    prev_carry_weight = None
    for r in rows:
        if str(r.get("status", "")).strip().upper() != ADOPTED:
            trace.append((r, None))
            continue
        weight = int(r["weight"])
        carry = int(r["carry_flag"])
        add = weight
        if prev_carry_weight is not None:
            add += prev_carry_weight
        total += add
        trace.append((r, total))
        prev_carry_weight = weight if carry == 1 else None
    return total, trace


def risk_constants():
    vals = {}
    for line in raw_lines("risk_const.env2"):
        key, _, val = line.partition("=")
        vals[key.strip()] = val.strip()
    if vals.get("STATUS", "").upper() != ADOPTED:
        raise SystemExit("risk constant layer is not authoritative")
    return int(vals["BASELINE_COMPLEMENT"]), int(vals["RISK_DIVISOR"])


def severity_permille(klass):
    for line in raw_lines("severity_weight.kv"):
        parts = [p.strip() for p in line.split(":")]
        if len(parts) != 3:
            continue
        name, permille, status = parts
        if name == "class%d" % klass and status.upper() == ADOPTED:
            return int(permille)
    raise SystemExit("severity layer missing for class %s" % klass)


def healthy_voters(klass):
    voters = []
    for line in raw_lines("voter_health.ndjson"):
        obj = json.loads(line)
        if (
            str(obj.get("class_id")) == str(klass)
            and str(obj.get("status", "")).upper() == ADOPTED
            and obj.get("healthy") is True
        ):
            voters.append(str(obj.get("voter_id")))
    return sorted(voters)


def quorum_permille(klass):
    rows = adopted(delimited_rows("quorum_permille.tilde", "~"), class_id=klass)
    if len(rows) != 1:
        raise SystemExit("quorum permille layer is not unique for class %s" % klass)
    return int(rows[0]["permille"])


def tls_floor_score(klass):
    rows = adopted(delimited_rows("tls_matrix.csv", ","), class_id=klass)
    enabled = [r for r in rows if r.get("enabled", "").strip().lower() == "true"]
    if len(enabled) != 1:
        raise SystemExit("tls floor layer is not unique for class %s" % klass)
    return int(enabled[0]["score"]), enabled[0]["suite"]


def seccomp_allowed(klass):
    return sorted(r["syscall"] for r in adopted(delimited_rows("seccomp_allow.tsv", "\t"), class_id=klass))


def retention_days(klass):
    cp = ini_sections("retention.ini")
    sec = "class.%d" % klass
    if not cp.has_section(sec) or cp.get(sec, "status").strip().upper() != ADOPTED:
        raise SystemExit("retention layer missing for class %s" % klass)
    return int(cp.get(sec, "retention_days"))


def retry_step(klass):
    rows = adopted(delimited_rows("retry_backoff.psv2", "||"), class_id=klass)
    if len(rows) != 1:
        raise SystemExit("retry backoff layer is not unique for class %s" % klass)
    return int(rows[0]["step"])


def precedence_resolution(klass):
    """defaults -> class override -> pinned (only when pinned == true)."""
    defaults = layer_defaults()
    overrides = load_json(DATA / "layer_overrides.json").get("class_%d" % klass, {})
    pinned = load_json(DATA / "pinned_overrides.json").get("class_%d" % klass, {})
    pinned_active = bool(pinned.get("pinned", False))
    resolution = {}
    for field in PRECEDENCE_FIELDS:
        value = int(defaults[field])
        source = "default"
        if field in overrides:
            value = int(overrides[field])
            source = "override"
        if pinned_active and field in pinned:
            value = int(pinned[field])
            source = "pinned"
        resolution[field] = {"default": int(defaults[field]), "resolved": value, "source": source}
    resolution["_pinned"] = pinned_active
    return resolution


def scope_census(klass):
    pat = re.compile(r'\{:class (\d+) :base (\d+) :overlay (\d+) :deny (\d+) :status "([A-Z]+)"\}')
    for line in raw_lines("scope_census.edn"):
        m = pat.match(line.strip())
        if m and int(m.group(1)) == int(klass) and m.group(5) == ADOPTED:
            return int(m.group(2)), int(m.group(3)), int(m.group(4))
    return None


# ------------------------------------------------------------- derivation

def derive():
    max_records, retry_limit, timeout_ms, trailer = base_inputs()
    klass, selector, span = active_class(max_records)

    # ingress rate: per-class throughput scaled by its burst factor, quantised
    qps = ingress_qps(klass)
    permille, layer_window = burst_layer(klass)
    step = rate_step(klass)
    win = window_seconds(klass)
    if win != layer_window:
        raise SystemExit("window layers disagree for class %s" % klass)
    rate_pre = round_half_even(qps * permille, 1000)
    rate_limit = quantize_floor(rate_pre, step)
    burst_ceiling = rate_limit * win

    # scopes: base union overlay, reduced by deny, for the active class only
    base_scopes, overlay_scopes, deny_scopes = scope_sets(klass)
    effective_sorted = sorted((base_scopes | overlay_scopes) - deny_scopes)
    effective_scope_count = len(effective_sorted)
    uids = uid_map()
    floor = uid_floor(klass)
    scope_uids = {}
    for s in effective_sorted:
        if s not in uids:
            raise SystemExit("no uid mapped for scope %s" % s)
        scope_uids[s] = uids[s]
    granted = [scope_uids[s] for s in effective_sorted]
    privilege_drop_uid = max(min(granted), floor) if granted else floor

    # hardening fold, clamp, quantise
    rows = control_rows(klass)
    fold_total, fold_trace = fold_controls(rows)
    lo, hi = hardening_bounds(klass)
    clamped = min(max(fold_total, lo), hi)
    hardening_baseline = quantize_floor(clamped, HARDENING_STEP)

    # risk index
    complement, divisor = risk_constants()
    severity = severity_permille(klass)
    risk_index = round_half_even((complement - hardening_baseline) * severity, divisor)

    # quorum from healthy authoritative voters, bounded by [1, voter count]
    voters = healthy_voters(klass)
    healthy = len(voters)
    qpermille = quorum_permille(klass)
    quorum = min(max(round_half_even(healthy * qpermille, 1000), 1), healthy)

    tls_floor, tls_suite = tls_floor_score(klass)
    allowed = seccomp_allowed(klass)
    retention = retention_days(klass)

    prec = precedence_resolution(klass)
    ttl = prec["session_ttl_seconds"]["resolved"]
    nonce = prec["nonce_window_ms"]["resolved"]
    sessions = prec["max_concurrent_sessions"]["resolved"]

    rstep = retry_step(klass)
    retry_backoff = quantize_floor(round_half_even(timeout_ms * (retry_limit + 1), 8), rstep)

    config = dict(contract_strings())
    config.update(
        {
            "active_class": klass,
            "audit_retention_days": retention,
            "burst_ceiling": burst_ceiling,
            "effective_scope_count": effective_scope_count,
            "enforcement_profile": "main",
            "hardening_baseline": hardening_baseline,
            "ingress_rate_limit_qps": rate_limit,
            "max_concurrent_sessions": sessions,
            "nonce_window_ms": nonce,
            "privilege_drop_uid": privilege_drop_uid,
            "quorum_threshold": quorum,
            "retry_backoff_base_ms": retry_backoff,
            "risk_index": risk_index,
            "seccomp_allowed_count": len(allowed),
            "session_ttl_seconds": ttl,
            "tls_floor_score": tls_floor,
            "trailer": trailer,
        }
    )

    ctx = {
        "max_records": max_records,
        "retry_limit": retry_limit,
        "timeout_ms": timeout_ms,
        "selector": selector,
        "selector_span": span,
        "class_rows": len(rows),
        "qps": qps,
        "burst_permille": permille,
        "window_seconds": win,
        "rate_pre": rate_pre,
        "rate_step": step,
        "base_scopes": sorted(base_scopes),
        "overlay_scopes": sorted(overlay_scopes),
        "deny_scopes": sorted(deny_scopes),
        "effective_scopes": effective_sorted,
        "scope_uids": scope_uids,
        "uid_floor": floor,
        "privilege_mirror": privilege_mirror(klass),
        "fold_total": fold_total,
        "fold_trace": fold_trace,
        "bounds": [lo, hi],
        "clamped": clamped,
        "risk_complement": complement,
        "risk_divisor": divisor,
        "severity_permille": severity,
        "voters": voters,
        "quorum_permille": qpermille,
        "tls_suite": tls_suite,
        "seccomp_syscalls": allowed,
        "precedence": prec,
        "retry_step": rstep,
        "scope_census": scope_census(klass),
    }
    return config, ctx


def apply_profile(config, name):
    deltas = load_json(DATA / "profile_deltas.json")[name]
    prof = dict(config)
    prof["enforcement_profile"] = name
    ttl_raw = round_half_even(config["session_ttl_seconds"] * int(deltas["ttl_scale_permille"]), 1000)
    prof["session_ttl_seconds"] = quantize_floor(ttl_raw, TTL_STEP)
    prof["quorum_threshold"] = int(config["quorum_threshold"]) + int(deltas["quorum_delta"])
    prof["risk_index"] = int(config["risk_index"]) + int(deltas["risk_delta"])
    return prof


def signed_delta(base, prof):
    delta = {}
    for k in sorted(set(base) | set(prof)):
        b, p = base.get(k), prof.get(k)
        if isinstance(b, int) and isinstance(p, int) and not isinstance(b, bool):
            if p != b:
                delta[k] = p - b
        elif p != b:
            delta[k] = {"from": b, "to": p}
    return delta


# --------------------------------------------------------------- artifacts

def sha256_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def emit_rate_limit_plan(path, config):
    write_text(
        path,
        "[rate]\n"
        "class = %s\n"
        "ingress_rate_limit_qps = %s\n"
        "burst_ceiling = %s\n" % (config["active_class"], config["ingress_rate_limit_qps"], config["burst_ceiling"]),
    )


def emit_fold_trace(path, ctx):
    rows = ["order|control_id|weight|carry|status|running"]
    for r, running in ctx["fold_trace"]:
        token = "skip" if running is None else str(running)
        rows.append("|".join([r["order"], r["control_id"], r["weight"], r["carry_flag"], r["status"], token]))
    write_text(path, "\n".join(rows) + "\n")


def emit_quorum_plan(path, config, ctx):
    write_text(path, "healthy_voters:%d\nquorum_threshold:%d\n" % (len(ctx["voters"]), config["quorum_threshold"]))


def emit_risk_ledger(path, config, ctx):
    write_text(
        path,
        "HARDENING_BASELINE=%d\nRISK_INDEX=%d\nSEVERITY_PERMILLE=%d\n"
        % (config["hardening_baseline"], config["risk_index"], ctx["severity_permille"]),
    )


def emit_precedence(path, ctx):
    prec = ctx["precedence"]
    lines = []
    for field in PRECEDENCE_FIELDS:
        lines.append("%s.default=%d" % (field, prec[field]["default"]))
        lines.append("%s.resolved=%d" % (field, prec[field]["resolved"]))
    write_text(path, "\n".join(lines) + "\n")


def emit_privilege_map(path, ctx):
    lines = [
        json.dumps({"scope": s, "uid": ctx["scope_uids"][s]}, sort_keys=True) for s in ctx["effective_scopes"]
    ]
    write_text(path, "\n".join(lines) + ("\n" if lines else ""))


def emit_seccomp_summary(path, config):
    write_text(path, "class\tseccomp_allowed_count\n%s\t%s\n" % (config["active_class"], config["seccomp_allowed_count"]))


def emit_tls_floor(path, config):
    write_text(path, "TLS_FLOOR_SCORE=%d\n" % config["tls_floor_score"])


def emit_class_ordering(path, entries):
    rows = ["profile\trisk_index"]
    for name, risk in sorted(entries, key=lambda e: (e[1], e[0])):
        rows.append("%s\t%d" % (name, risk))
    write_text(path, "\n".join(rows) + "\n")


SOURCES = {
    "active_class": "class_index.tsv2 selector over ADOPTED ranges",
    "ingress_rate_limit_qps": "ingress_rate.tsv x burst_multiplier.ini quantised by rate_gran.caret",
    "burst_ceiling": "resolved rate x window_seconds.conf",
    "effective_scope_count": "scope_base.jsonl | scope_overlay.ndjson - scope_deny.psv",
    "privilege_drop_uid": "min granted uid over uid_map.env bounded by uid_floor.hex",
    "hardening_baseline": "baseline_controls.scsv carry fold clamped by hardening_bounds.toml",
    "risk_index": "risk_const.env2 complement x severity_weight.kv",
    "quorum_threshold": "voter_health.ndjson healthy x quorum_permille.tilde",
    "tls_floor_score": "tls_matrix.csv adopted enabled suite",
    "seccomp_allowed_count": "seccomp_allow.tsv adopted rows",
    "audit_retention_days": "retention.ini adopted class block",
    "session_ttl_seconds": "defaults < layer_overrides < pinned_overrides",
    "nonce_window_ms": "defaults < layer_overrides < pinned_overrides",
    "max_concurrent_sessions": "defaults < layer_overrides < pinned_overrides",
    "retry_backoff_base_ms": "defaults.json timeout_ms/retry_limit quantised by retry_backoff.psv2",
    "trailer": "defaults.json base_config.trailer",
}


def emit_admission_matrix(path, config):
    rows = ["field,value,source"]
    for key in sorted(config):
        rows.append("%s,%s,%s" % (key, config[key], SOURCES.get(key, "defaults.json contract strings")))
    write_text(path, "\n".join(rows) + "\n")


def emit_scope_reconciliation(path, config, ctx):
    rows = ["layer\tclass\tstatus\tcount\tscopes"]
    for name, scopes in (
        ("base", ctx["base_scopes"]),
        ("overlay", ctx["overlay_scopes"]),
        ("deny", ctx["deny_scopes"]),
        ("effective", ctx["effective_scopes"]),
    ):
        status = "RECONCILED" if name == "effective" else ADOPTED
        rows.append("%s\t%s\t%s\t%d\t%s" % (name, config["active_class"], status, len(scopes), " ".join(scopes)))
    write_text(path, "\n".join(rows) + "\n")


def emit_retention_schedule(path, config):
    write_text(path, "class,retention_days,status\n%s,%s,%s\n" % (config["active_class"], config["audit_retention_days"], ADOPTED))


def emit_derivation_audit(path, config, ctx, transcript):
    lines = ['<?xml version="1.0" encoding="UTF-8"?>', "<derivationAudit>"]
    lines.append(
        "  <activeClass selector=\"%d\" span=\"%d\">%d</activeClass>"
        % (ctx["selector"], ctx["selector_span"], config["active_class"])
    )
    lines.append("  <derivedConfig>")
    for k in sorted(config):
        v = config[k]
        if isinstance(v, int) and not isinstance(v, bool):
            lines.append('    <value key="%s">%d</value>' % (k, v))
        else:
            lines.append('    <value key="%s"><![CDATA[%s]]></value>' % (k, v))
    lines.append("  </derivedConfig>")
    lines.append(
        '  <rateLimit qps="%d" burstPermille="%d" preQuantised="%d" step="%d" window="%d" rate="%d" burst="%d"/>'
        % (
            ctx["qps"],
            ctx["burst_permille"],
            ctx["rate_pre"],
            ctx["rate_step"],
            ctx["window_seconds"],
            config["ingress_rate_limit_qps"],
            config["burst_ceiling"],
        )
    )
    lines.append(
        '  <scopeReconciliation base="%d" overlay="%d" deny="%d" effective="%d" uidFloor="%d" dropUid="%d"/>'
        % (
            len(ctx["base_scopes"]),
            len(ctx["overlay_scopes"]),
            len(ctx["deny_scopes"]),
            config["effective_scope_count"],
            ctx["uid_floor"],
            config["privilege_drop_uid"],
        )
    )
    lines.append(
        '  <hardeningFold raw="%d" floor="%d" ceiling="%d" clamped="%d" step="%d" baseline="%d"/>'
        % (ctx["fold_total"], ctx["bounds"][0], ctx["bounds"][1], ctx["clamped"], HARDENING_STEP, config["hardening_baseline"])
    )
    lines.append(
        '  <riskIndex complement="%d" severityPermille="%d" divisor="%d" value="%d"/>'
        % (ctx["risk_complement"], ctx["severity_permille"], ctx["risk_divisor"], config["risk_index"])
    )
    lines.append(
        '  <quorum healthyVoters="%d" permille="%d" value="%d"/>'
        % (len(ctx["voters"]), ctx["quorum_permille"], config["quorum_threshold"])
    )
    prec = ctx["precedence"]
    lines.append('  <precedence pinned="%s">' % ("true" if prec["_pinned"] else "false"))
    for field in PRECEDENCE_FIELDS:
        lines.append(
            '    <field name="%s" default="%d" resolved="%d" source="%s"/>'
            % (field, prec[field]["default"], prec[field]["resolved"], prec[field]["source"])
        )
    lines.append("  </precedence>")
    lines.append("  <commandTranscript>")
    for cmd in transcript:
        lines.append("    <command><![CDATA[%s]]></command>" % cmd)
    lines.append("  </commandTranscript>")
    lines.append("</derivationAudit>")
    write_text(path, "\n".join(lines) + "\n")


def emit_convergence(path, config, checks):
    lines = ["convergence report", "=================", ""]
    lines.append("active_class: %d" % config["active_class"])
    lines.append("checks: %d" % len(checks))
    lines.append("failed: %d" % len([c for c in checks if not c["ok"]]))
    lines.append("")
    lines.append("check\tlayer\texpected\tobserved\tresult")
    for c in checks:
        lines.append(
            "%s\t%s\t%s\t%s\t%s" % (c["name"], c["layer"], c["expected"], c["observed"], "ok" if c["ok"] else "MISMATCH")
        )
    write_text(path, "\n".join(lines) + "\n")


def mirror_rows(name, sep, klass, class_field="class"):
    return adopted(delimited_rows(name, sep), **{class_field: klass})

def gran_mirror_rows(klass):
    rows = []
    for line in raw_lines("gran_mirror.fixed2")[1:]:
        parts = line.split()
        if len(parts) == 3:
            rows.append({"class": parts[0], "gran": parts[1], "status": parts[2]})
    return adopted(rows, **{"class": klass})


def convergence_checks(config, ctx):
    klass = config["active_class"]
    checks = []

    def add(name, layer, expected, observed):
        checks.append(
            {"name": name, "layer": layer, "expected": str(expected), "observed": str(observed), "ok": expected == observed}
        )

    census = ctx["scope_census"]
    if census:
        granted = set(ctx["base_scopes"]) | set(ctx["overlay_scopes"])
        denied_in_grant = len(granted & set(ctx["deny_scopes"]))
        add("census_base", "scope_census.edn", census[0], len(ctx["base_scopes"]))
        add("census_overlay", "scope_census.edn", census[1], len(ctx["overlay_scopes"]))
        add("census_deny", "scope_census.edn", census[2], len(ctx["deny_scopes"]))
        add(
            "census_effective",
            "scope_census.edn",
            census[0] + census[1] - denied_in_grant,
            config["effective_scope_count"],
        )
    rows = mirror_rows("scopecount_mirror.tsv3", "\t", klass)
    if rows:
        add("scope_count_mirror", "scopecount_mirror.tsv3", int(rows[0]["scopes"]), config["effective_scope_count"])
    rows = mirror_rows("voters_mirror.kv4", "::", klass)
    if rows:
        add("voters_mirror", "voters_mirror.kv4", int(rows[0]["voters"]), len(ctx["voters"]))
    if ctx["privilege_mirror"] is not None:
        add("privilege_mirror", "privilege_bits.b64", ctx["privilege_mirror"], config["privilege_drop_uid"])
    rows = mirror_rows("quorum_mirror.rst2", "::", klass)
    if rows:
        add("quorum_permille_mirror", "quorum_mirror.rst2", int(rows[0]["permille"]), ctx["quorum_permille"])
    rows = mirror_rows("window_mirror.scsv3", ";;;", klass)
    if rows:
        add("window_mirror", "window_mirror.scsv3", int(rows[0]["window"]), ctx["window_seconds"])
    rows = mirror_rows("severity_mirror.caret2", "^^", klass)
    if rows:
        add("severity_mirror", "severity_mirror.caret2", int(rows[0]["permille"]), ctx["severity_permille"])
    rows = gran_mirror_rows(klass)
    if rows:
        add("rate_granularity_mirror", "gran_mirror.fixed2", int(rows[0]["gran"]), ctx["rate_step"])
    rows = mirror_rows("tls_mirror.tilde3", "~~~", klass)
    if rows:
        add("tls_floor_mirror", "tls_mirror.tilde3", int(rows[0]["score"]), config["tls_floor_score"])
    rows = mirror_rows("burst_mirror.hex2", "=", klass)
    if rows:
        add("burst_permille_mirror", "burst_mirror.hex2", int(rows[0]["permille_hex"], 16), ctx["burst_permille"])
    rows = mirror_rows("ingress_mirror.pipe", "|", klass)
    if rows:
        add("ingress_qps_mirror", "ingress_mirror.pipe", int(rows[0]["qps"]), ctx["qps"])
    return checks


def emit_reproducibility(path, config, artifacts, digest):
    manifest = {
        "algorithm": "sha256",
        "canonical_trailer": config["trailer"],
        "config_digest": digest,
        "artifacts": {name: sha256_file(p) for name, p in sorted(artifacts.items())},
        "determinism": {
            "floating_point_used": False,
            "rounding": "round-half-even (banker's) on exact integers",
            "key_order": "sorted",
        },
    }
    write_json(path, manifest)


CENSUS_LAYERS = [
    ("defaults.json", "base budget, contract strings, precedence defaults"),
    ("class_index.tsv2", "active class selector ranges"),
    ("ingress_rate.tsv", "per-class throughput"),
    ("burst_multiplier.ini", "burst factor and window"),
    ("window_seconds.conf", "per-class window cross-check"),
    ("rate_gran.caret", "rate quantisation step"),
    ("scope_base.jsonl", "base scope grants"),
    ("scope_overlay.ndjson", "overlay scope grants"),
    ("scope_deny.psv", "deny scope revocations"),
    ("uid_map.env", "scope uid map"),
    ("uid_floor.hex", "privilege-drop uid floor"),
    ("baseline_controls.scsv", "ordered hardening controls"),
    ("hardening_bounds.toml", "hardening clamp bounds"),
    ("risk_const.env2", "risk constants"),
    ("severity_weight.kv", "per-class severity weight"),
    ("voter_health.ndjson", "voter health"),
    ("quorum_permille.tilde", "quorum permille"),
    ("tls_matrix.csv", "tls floor suites"),
    ("seccomp_allow.tsv", "seccomp allowlist"),
    ("retention.ini", "audit retention days"),
    ("layer_overrides.json", "precedence override layer"),
    ("pinned_overrides.json", "precedence pinned layer"),
    ("profile_deltas.json", "canary/enforce deltas"),
    ("retry_backoff.psv2", "retry backoff quantisation step"),
]


def emit_input_census(path, config):
    lines = []
    for name, role in CENSUS_LAYERS:
        lines.append(
            json.dumps(
                {"layer": name, "role": role, "rows_read": len(raw_lines(name)), "status": ADOPTED},
                sort_keys=True,
            )
        )
    lines.append(
        json.dumps(
            {
                "layer": "effective_scope_set",
                "role": "base union overlay minus deny for the active class",
                "rows_read": config["effective_scope_count"],
                "status": "RECONCILED",
            },
            sort_keys=True,
        )
    )
    write_text(path, "\n".join(lines) + "\n")


# -------------------------------------------------------------- commands

def cmd_derive(args):
    config, _ctx = derive()
    write_json(args.out, config)
    print("derived")


def cmd_profile(args):
    deltas = load_json(DATA / "profile_deltas.json")
    if args.name not in deltas:
        raise SystemExit("unknown profile: %s" % args.name)
    config = load_json(args.config)
    write_json(args.out, apply_profile(config, args.name))
    print("profiled")


def cmd_init(args):
    schema = load_json(args.schema)
    write_json(args.out, {k: schema[k] for k in ("profile", "checksum", "mode")})
    print("initialized")


def cmd_set(args):
    data = load_json(args.config)
    value = args.value
    if re.fullmatch(r"-?\d+", value):
        value = int(value)
    if isinstance(value, (dict, list)):
        raise SystemExit("configuration must be flat: %s" % args.key)
    data[args.key.lower()] = value
    write_json(args.config, data)
    print("set")


def required_keys(schema):
    req = schema["required_keys"]
    if isinstance(req, str):
        return [k.strip() for k in req.split(",") if k.strip()]
    return list(req)


def cmd_validate(args):
    schema = load_json(args.schema)
    data = load_json(args.config)
    required = required_keys(schema)
    missing = [k for k in required if k not in data]
    if missing:
        raise SystemExit("missing: " + ",".join(missing))
    bad = [k for k, v in data.items() if isinstance(v, (dict, list))]
    if bad:
        raise SystemExit("configuration must be flat: " + ",".join(sorted(bad)))
    extra = [k for k in sorted(data) if k not in required]
    if extra:
        raise SystemExit("unexpected keys: " + ",".join(extra))
    print("ok")


def cmd_report(args):
    data = load_json(args.config)
    commands = json.loads(args.commands) if args.commands else []
    digest = args.digest or sha256_file(args.config)
    write_json(
        args.out,
        {
            "ok": True,
            "config": data,
            "commands": commands,
            "config_digest": digest,
            "trailer": data.get("trailer"),
        },
    )
    print("reported")


def package_tool(out_path, sources):
    out_path = Path(out_path)
    if out_path.exists():
        out_path.unlink()
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for src in sorted(sources, key=lambda p: p.name):
            info = zipfile.ZipInfo(src.name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            zf.writestr(info, src.read_bytes())
    return out_path


def cmd_compile(args):
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    transcript = []
    tool_dir = Path(__file__).resolve().parent
    schema_path = tool_dir / "schema.json"

    def record(cmd):
        transcript.append(cmd)
        return cmd

    config, ctx = derive()
    config_path = outdir / "config.json"
    write_json(config_path, config)
    record("task-ctl derive --out config.json")

    profiles = {}
    for name in ("canary", "enforce"):
        ppath = outdir / ("profile_%s.json" % name)
        prof = apply_profile(config, name)
        write_json(ppath, prof)
        profiles[name] = (ppath, prof)
        record("task-ctl profile --name %s --config config.json --out profile_%s.json" % (name, name))

    delta_report = {
        name: {
            "delta": signed_delta(config, prof),
            "numeric_deltas": {
                k: int(prof[k]) - int(config[k])
                for k in sorted(config)
                if isinstance(config[k], int) and not isinstance(config[k], bool)
            },
            "profile": "profile_%s.json" % name,
        }
        for name, (_, prof) in profiles.items()
    }
    delta_path = outdir / "profile_delta_report.json"
    write_json(delta_path, delta_report)
    record("task-ctl delta-report --config config.json --out profile_delta_report.json")

    sidecars = {
        "rate_limit_plan.ini": lambda p: emit_rate_limit_plan(p, config),
        "hardening_fold_trace.psv": lambda p: emit_fold_trace(p, ctx),
        "quorum_plan.kv": lambda p: emit_quorum_plan(p, config, ctx),
        "risk_ledger.env": lambda p: emit_risk_ledger(p, config, ctx),
        "precedence_resolution.properties": lambda p: emit_precedence(p, ctx),
        "privilege_map.ndjson": lambda p: emit_privilege_map(p, ctx),
        "seccomp_summary.tsv": lambda p: emit_seccomp_summary(p, config),
        "tls_floor.env": lambda p: emit_tls_floor(p, config),
        "admission_matrix.csv": lambda p: emit_admission_matrix(p, config),
        "scope_reconciliation.tsv": lambda p: emit_scope_reconciliation(p, config, ctx),
        "retention_schedule.csv": lambda p: emit_retention_schedule(p, config),
    }
    sidecar_paths = {}
    for name in sorted(sidecars):
        target = outdir / name
        sidecars[name](target)
        sidecar_paths[name] = target
        record("task-ctl emit --artifact %s --config config.json" % name)

    class_ordering_path = outdir / "class_ordering.tsv"
    emit_class_ordering(
        class_ordering_path,
        [("main", config["risk_index"])] + [(n, p["risk_index"]) for n, (_, p) in profiles.items()],
    )
    record("task-ctl class-ordering --config config.json --out class_ordering.tsv")

    checks = convergence_checks(config, ctx)
    convergence_path = outdir / "convergence_report.txt"
    emit_convergence(convergence_path, config, checks)
    record("task-ctl converge --config config.json --out convergence_report.txt")

    audit_path = outdir / "derivation_audit.xml"
    record("task-ctl audit --config config.json --out derivation_audit.xml")

    census_path = outdir / "input_census.ndjson"
    emit_input_census(census_path, config)
    record("task-ctl census --config config.json --out input_census.ndjson")

    tool_zip = outdir / "tool.zip"
    packaged = sorted(p for p in tool_dir.glob("*") if p.is_file() and p.name in TOOL_FILES)
    package_tool(tool_zip, packaged)
    record("task-ctl package --out tool.zip")

    emit_derivation_audit(audit_path, config, ctx, transcript)

    digest = sha256_file(config_path)
    manifest_inputs = dict(sidecar_paths)
    manifest_inputs.update(
        {
            "config.json": config_path,
            "profile_canary.json": profiles["canary"][0],
            "profile_enforce.json": profiles["enforce"][0],
            "profile_delta_report.json": delta_path,
            "class_ordering.tsv": class_ordering_path,
            "convergence_report.txt": convergence_path,
            "derivation_audit.xml": audit_path,
            "input_census.ndjson": census_path,
            "tool.zip": tool_zip,
        }
    )
    manifest_path = outdir / "reproducibility_manifest.json"
    emit_reproducibility(manifest_path, config, manifest_inputs, digest)
    record("task-ctl manifest --config config.json --out reproducibility_manifest.json")

    schema = load_json(schema_path)
    forbidden = load_json(DATA / "validation_rules.json")["forbidden_keys"]

    def check_document(path):
        data = load_json(path)
        req = required_keys(schema)
        return {
            "ok": True,
            "missing_keys": [k for k in req if k not in data],
            "unexpected_keys": [k for k in sorted(data) if k not in req],
            "non_scalar_keys": [k for k, v in sorted(data.items()) if isinstance(v, (dict, list))],
            "forbidden_keys_present": [k for k in sorted(data) if k in forbidden],
            "trailer_intact": data.get("trailer") == config["trailer"],
        }

    def verdict(result):
        result["ok"] = (
            not result["missing_keys"]
            and not result["unexpected_keys"]
            and not result["non_scalar_keys"]
            and not result["forbidden_keys_present"]
            and result["trailer_intact"]
        )
        return result

    config_check = verdict(check_document(config_path))
    profile_checks = {
        name: verdict(check_document(path)) for name, (path, _prof) in profiles.items()
    }
    validation = {
        "ok": True,
        "schema": "schema.json",
        "config": "config.json",
        "required_keys": sorted(required_keys(schema)),
        "flat": True,
        "missing_keys": config_check["missing_keys"],
        "unexpected_keys": config_check["unexpected_keys"],
        "non_scalar_keys": config_check["non_scalar_keys"],
        "forbidden_keys_present": config_check["forbidden_keys_present"],
        "trailer_intact": config_check["trailer_intact"],
        "profiles": profile_checks,
        "convergence_checks": len(checks),
        "convergence_failures": len([c for c in checks if not c["ok"]]),
    }
    validation["ok"] = (
        config_check["ok"]
        and all(p["ok"] for p in profile_checks.values())
        and validation["convergence_failures"] == 0
    )
    validation_path = outdir / "validation_report.json"
    write_json(validation_path, validation)
    record("task-ctl validate --schema schema.json --config config.json")

    report_path = outdir / "report.json"
    record("task-ctl export-report --config config.json --out report.json --digest %s" % digest)
    write_json(
        report_path,
        {
            "ok": True,
            "config": config,
            "commands": list(transcript),
            "config_digest": digest,
            "trailer": config["trailer"],
            "active_class": config["active_class"],
        },
    )

    summary_path = outdir / "summary.json"
    record("task-ctl summarize --config config.json --out summary.json")
    write_json(
        summary_path,
        {
            "ok": True,
            "active_class": config["active_class"],
            "config_digest": digest,
            "trailer": config["trailer"],
            "derived": {k: config[k] for k in sorted(config)},
            "profiles": {n: {k: p[k] for k in sorted(p)} for n, (_, p) in profiles.items()},
            "convergence_checks": len(checks),
            "convergence_failures": len([c for c in checks if not c["ok"]]),
            "command_count": len(transcript),
        },
    )
    print("compiled %d artifacts from %d commands" % (len(transcript), len(transcript)))


def main():
    parser = argparse.ArgumentParser(prog="task-ctl")
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("derive")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_derive)

    p = sub.add_parser("profile")
    p.add_argument("--name", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_profile)

    p = sub.add_parser("init")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("export-report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest")
    p.add_argument("--commands")
    p.set_defaults(func=cmd_report)

    p = sub.add_parser("compile")
    p.add_argument("--outdir", required=True)
    p.set_defaults(func=cmd_compile)

    args = parser.parse_args()
    if not getattr(args, "command", None):
        return
    args.func(args)


if __name__ == "__main__":
    main()
