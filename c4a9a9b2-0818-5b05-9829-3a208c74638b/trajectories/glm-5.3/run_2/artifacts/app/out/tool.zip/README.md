# task-ctl

An offline container-image admission-control hardening compiler for a
server-side admission broker. It reads interacting numeric policy layers from
`/app/data`, selects the active enforcement class, and derives one flat hardened
admission configuration plus two deployment profiles (canary and enforce).

The shipped build is faulty: its numeric derivation logic disagrees with the
documented threshold/rate-limit, privilege/scope reconciliation, hardening-baseline,
risk-scoring and quorum, and policy-precedence rules recorded across the policy
layers, and its command surface is incomplete. It must be repaired so every
derived scalar matches the documented contract exactly.

## Expected repaired commands

- `init --schema <schema> --out <config>`: seed fixed contract strings.
- `set --config <config> --key <key> --value <value>`: set one scalar key with
  correct case and type coercion; reject any non-scalar value.
- `validate --schema <schema> --config <config>`: confirm every required key is
  present and the configuration is flat; print `ok`.
- `export-report --config <config> --out <report> --digest <sha256> --commands <json>`:
  emit a truthful command transcript.

## Contract notes

- Every value is derived with exact integer arithmetic (round-half-even); no
  floating-point value may reach a graded key.
- The configuration is flat: keys map directly to integer or string scalars.
- The required key set is authoritative in `schema.json` and mirrored by the
  field registry in the policy layers.
- Only rows whose status is `ADOPTED` for the active enforcement class bind; rows
  labelled `SUPERSEDED`, `DRAFT`, `SHADOW`, or `REVOKED` are context decoys.
