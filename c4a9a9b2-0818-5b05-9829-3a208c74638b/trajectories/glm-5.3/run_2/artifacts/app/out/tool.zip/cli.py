#!/usr/bin/env python3
"""task-ctl: local admission-control hardening compiler (repaired).

Compiles one flat hardened admission configuration for the active enforcement
class from the interacting numeric policy layers under /app/data.

Every arithmetic step that reaches a graded value uses exact integer arithmetic
with round-half-even (banker's) rounding; no floating-point operation touches a
graded number.  Only rows whose status is ADOPTED bind for the active class;
SUPERSEDED / DRAFT / SHADOW / REVOKED rows are decoys.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

DATA = Path("/app/data")
ADOPTED = "ADOPTED"

# documented quantization steps for the hardening baseline and session TTL
HARDENING_STEP = 5
TTL_STEP = 5


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def dump_json(data):
    return json.dumps(data, sort_keys=True, indent=2) + "\n"


def write_json(path, data):
    Path(path).write_text(dump_json(data), encoding="utf-8")


def read_lines(name):
    out = []
    for line in (DATA / name).read_text(encoding="utf-8", errors="replace").split("\n"):
        s = line.strip()
        if not s or s.startswith("#") or s.startswith(";"):
            continue
        out.append(line)
    return out


def delimited_rows(name, sep):
    lines = read_lines(name)
    if not lines:
        return []
    split = re.compile(re.escape(sep) + "+") if sep else None
    header = [c.strip() for c in (split.split(lines[0]) if split else [lines[0]])]
    rows = []
    for line in lines[1:]:
        parts = [c.strip() for c in (split.split(line) if split else [line])]
        if len(parts) != len(header):
            continue
        rows.append(dict(zip(header, parts)))
    return rows


def ndjson_rows(name):
    rows = []
    for line in read_lines(name):
        try:
            obj = json.loads(line)
        except ValueError:
            continue
        if isinstance(obj, dict):
            rows.append(obj)
    return rows


def round_half_even(num, den):
    """Exact integer round-half-even of num/den (den > 0); no float involved."""
    num, den = int(num), int(den)
    sign = 1
    if num < 0:
        num, sign = -num, -1
    q, r = divmod(num, den)
    if 2 * r > den or (2 * r == den and q % 2 == 1):
        q += 1
    return sign * q


def quantize_floor(value, step):
    return (int(value) // int(step)) * int(step)


def clamp(value, lo, hi):
    return min(max(int(value), int(lo)), int(hi))


def adopted_rows(rows, klass, key="class_id"):
    return [r for r in rows if str(r.get(key)).strip() == str(klass) and r.get("status") == ADOPTED]


def ini_blocks(name):
    """Parse an INI-ish layer into {section: {key: value}}."""
    sections = {}
    cur = None
    for line in read_lines(name):
        s = line.strip()
        m = re.match(r"^\[([^\]]+)\]$", s)
        if m:
            cur = m.group(1)
            sections.setdefault(cur, {})
            continue
        if "=" in s and cur is not None:
            k, _, v = s.partition("=")
            sections[cur][k.strip()] = v.strip()
    return sections


def class_sections(name):
    """Map class id -> {key: value} for canonical [class.N] blocks."""
    out = {}
    for sec, kv in ini_blocks(name).items():
        m = re.match(r"^class\.(\d+)$", sec)
        if m:
            out[m.group(1)] = kv
    return out


# ----------------------------------------------------------- base + class

def base_inputs():
    base = load_json(DATA / "defaults.json")["base_config"]
    return int(base["max_records"]), int(base["retry_limit"]), int(base["timeout_ms"]), str(base["trailer"])


def layer_defaults():
    return load_json(DATA / "defaults.json")["layer_defaults"]


def active_class(max_records):
    """Active class from the documented base budget selector table.

    The ADOPTED rows of class_index.tsv2 tile the base budget space in
    contiguous [selector_lo, selector_hi] bands; the budget is taken modulo the
    tiled span and the single ADOPTED band covering it selects the class.  Every
    other status label (SHADOW/DRAFT/REVOKED/SUPERSEDED) is a decoy band.
    """
    rows = [r for r in delimited_rows("class_index.tsv2", "\t") if r.get("status") == ADOPTED]
    rows.sort(key=lambda r: int(r["selector_lo"]))
    if not rows:
        raise SystemExit("no adopted class selector rows")
    span = sum(int(r["selector_hi"]) - int(r["selector_lo"]) + 1 for r in rows)
    selector = int(max_records) % span
    hits = [
        r for r in rows
        if int(r["selector_lo"]) <= selector <= int(r["selector_hi"])
    ]
    if len(hits) != 1:
        raise SystemExit("active class selector is ambiguous: %d rows" % len(hits))
    return int(hits[0]["class_id"])


# ------------------------------------------------------- rate-limit layer

def rate_limit_plan(klass):
    ingress = adopted_rows(delimited_rows("ingress_rate.tsv", "\t"), klass)
    if not ingress:
        raise SystemExit("no adopted ingress row for class %s" % klass)
    qps = int(ingress[0]["ingress_qps"])

    gran = adopted_rows(delimited_rows("rate_gran.caret", "^"), klass)
    step = int(gran[0]["gran"])

    burst = class_sections("burst_multiplier.ini").get(str(klass), {})
    if burst.get("status") != ADOPTED:
        raise SystemExit("no adopted burst block for class %s" % klass)
    permille = int(burst["burst_multiplier_permille"])

    window = None
    for line in read_lines("window_seconds.conf"):
        parts = line.split()
        if len(parts) == 3 and parts[0] == str(klass) and parts[2] == ADOPTED:
            window = int(parts[1])
            break
    if window is None:
        raise SystemExit("no adopted window row for class %s" % klass)

    rate_limit = quantize_floor(round_half_even(qps * permille, 1000), step)
    return {
        "qps": qps,
        "permille": permille,
        "step": step,
        "window": window,
        "rate_limit": rate_limit,
        "burst_ceiling": rate_limit * window,
    }


# ----------------------------------------------------------- scope layer

def scope_uids():
    uids = {}
    for line in read_lines("uid_map.env"):
        s = line.strip()
        if not s.startswith("SCOPE_") or "=" not in s:
            continue
        key, _, val = s.partition("=")
        val = val.strip()
        if val.isdigit():
            uids[key[len("SCOPE_"):].lower()] = int(val)
    return uids


def scope_plan(klass):
    base = {r["scope"] for r in adopted_rows(ndjson_rows("scope_base.jsonl"), klass)}
    overlay = {r["scope"] for r in adopted_rows(ndjson_rows("scope_overlay.ndjson"), klass)}
    deny = {r["scope"] for r in adopted_rows(delimited_rows("scope_deny.psv", "|"), klass)}
    effective = sorted((base | overlay) - deny)
    uids = scope_uids()
    missing = [s for s in effective if s not in uids]
    if missing:
        raise SystemExit("no granted uid for scopes: %s" % ",".join(missing))

    floor = int(adopted_rows(delimited_rows("uid_floor.hex", ":"), klass)[0]["floor_hex"], 16)
    min_granted = min(uids[s] for s in effective)
    return {
        "base": sorted(base),
        "overlay": sorted(overlay),
        "deny": sorted(deny),
        "effective": effective,
        "floor": floor,
        "min_granted": min_granted,
        "privilege_drop_uid": max(min_granted, floor),
        "uids": {s: uids[s] for s in effective},
    }


# ------------------------------------------------------ hardening layer

def hardening_plan(klass):
    rows = [r for r in delimited_rows("baseline_controls.scsv", ";")
            if str(r.get("class_id")).strip() == str(klass)]
    rows.sort(key=lambda r: int(r["order"]))

    running = 0
    previous = None
    trace = []
    for r in rows:
        weight, carry = int(r["weight"]), int(r["carry_flag"])
        entry = {
            "order": int(r["order"]),
            "control_id": r["control_id"],
            "weight": weight,
            "carry": carry,
            "status": r["status"],
        }
        if r.get("status") != ADOPTED:
            entry["running"] = "skip"
            trace.append(entry)
            continue
        running += weight
        if previous is not None and previous[1] == 1:
            running += previous[0]
        previous = (weight, carry)
        entry["running"] = running
        trace.append(entry)

    bounds = class_sections("hardening_bounds.toml")[str(klass)]
    if bounds.get("status", "").strip('"') != ADOPTED:
        raise SystemExit("no adopted hardening bounds for class %s" % klass)
    floor, ceil = int(bounds["floor"]), int(bounds["ceil"])
    clamped = clamp(running, floor, ceil)
    return {
        "trace": trace,
        "raw": running,
        "floor": floor,
        "ceil": ceil,
        "clamped": clamped,
        "baseline": quantize_floor(clamped, HARDENING_STEP),
    }


def severity_permille(klass):
    for line in read_lines("severity_weight.kv"):
        parts = [p.strip() for p in line.strip().split(":")]
        if len(parts) == 3 and parts[0] == "class%s" % klass and parts[2] == ADOPTED:
            return int(parts[1])
    raise SystemExit("no adopted severity row for class %s" % klass)


def risk_constants():
    vals = {}
    for line in read_lines("risk_const.env2"):
        s = line.strip()
        if "=" not in s:
            continue
        k, _, v = s.partition("=")
        vals[k.strip()] = v.strip()
    return vals


def risk_plan(klass, baseline):
    permille = severity_permille(klass)
    consts = risk_constants()
    if consts.get("STATUS") != ADOPTED:
        raise SystemExit("risk constants are not adopted")
    complement = int(consts["BASELINE_COMPLEMENT"])
    divisor = int(consts["RISK_DIVISOR"])
    return {
        "permille": permille,
        "complement": complement,
        "divisor": divisor,
        "risk_index": round_half_even((complement - baseline) * permille, divisor),
    }


# --------------------------------------------------------- quorum layer

def quorum_plan(klass):
    healthy = len([
        r for r in adopted_rows(ndjson_rows("voter_health.ndjson"), klass)
        if r.get("healthy") is True
    ])
    permille = int(adopted_rows(delimited_rows("quorum_permille.tilde", "~"), klass)[0]["permille"])
    raw = round_half_even(healthy * permille, 1000)
    return {
        "healthy_voters": healthy,
        "permille": permille,
        "raw": raw,
        "quorum_threshold": clamp(raw, 1, healthy),
    }


# --------------------------------------------- tls / seccomp / retention

def tls_floor_score(klass):
    best = None
    for r in delimited_rows("tls_matrix.csv", ","):
        if str(r.get("class_id")).strip() != str(klass) or r.get("status") != ADOPTED:
            continue
        if str(r.get("enabled")).strip().lower() != "true":
            continue
        score = int(r["score"])
        if best is None or score > best:
            best = score
    if best is None:
        raise SystemExit("no enabled adopted TLS suite for class %s" % klass)
    return best


def seccomp_allowed_count(klass):
    """Net allowed-syscall count: adopted allow entries minus adopted denies."""
    rows = delimited_rows("seccomp_ledger.scsv2", ";;")
    allow = {r["syscall"] for r in rows
             if str(r["class_id"]) == str(klass) and r["status"] == ADOPTED and r["action"] == "allow"}
    deny = {r["syscall"] for r in rows
            if str(r["class_id"]) == str(klass) and r["status"] == ADOPTED and r["action"] == "deny"}
    allow |= {r["syscall"] for r in adopted_rows(delimited_rows("seccomp_allow.tsv", "\t"), klass)}
    deny |= {r["syscall"] for r in adopted_rows(delimited_rows("seccomp_deny.psv", "|"), klass)}
    return len(allow - deny)


def retention_days(klass):
    kv = class_sections("retention.ini").get(str(klass), {})
    if kv.get("status") != ADOPTED:
        raise SystemExit("no adopted retention block for class %s" % klass)
    return int(kv["retention_days"])


# ---------------------------------------------------- precedence layers

PRECEDENCE_FIELDS = ("session_ttl_seconds", "nonce_window_ms", "max_concurrent_sessions")


def precedence_plan(klass):
    defaults = layer_defaults()
    overrides = load_json(DATA / "layer_overrides.json")
    pinned = load_json(DATA / "pinned_overrides.json")
    ov = overrides["class_%s" % klass]
    pin = pinned["class_%s" % klass]
    pinned_active = pin.get("pinned") is True
    plan = {}
    for field in PRECEDENCE_FIELDS:
        plan[field] = {
            "default": int(defaults[field]),
            "override": int(ov[field]),
            "pinned": int(pin[field]),
            "pinned_active": pinned_active,
            "resolved": int(pin[field]) if pinned_active else int(ov[field]),
        }
    return plan


def retry_backoff_plan(timeout_ms, retry_limit, klass):
    step = int(adopted_rows(delimited_rows("retry_backoff.psv2", "||"), klass)[0]["step"])
    raw = round_half_even(timeout_ms * (retry_limit + 1), 8)
    return {"step": step, "raw": raw, "retry_backoff_base_ms": quantize_floor(raw, step)}


# ------------------------------------------------------------- derivation

def derive():
    max_records, retry_limit, timeout_ms, trailer = base_inputs()
    klass = active_class(max_records)

    rate = rate_limit_plan(klass)
    scopes = scope_plan(klass)
    hardening = hardening_plan(klass)
    risk = risk_plan(klass, hardening["baseline"])
    quorum = quorum_plan(klass)
    tls = tls_floor_score(klass)
    seccomp = seccomp_allowed_count(klass)
    retention = retention_days(klass)
    precedence = precedence_plan(klass)
    retry = retry_backoff_plan(timeout_ms, retry_limit, klass)

    defaults = load_json(DATA / "defaults.json")
    config = {
        "active_class": klass,
        "audit_retention_days": retention,
        "burst_ceiling": rate["burst_ceiling"],
        "checksum": defaults["checksum"],
        "control_plane": defaults["control_plane"],
        "effective_scope_count": len(scopes["effective"]),
        "enforcement_profile": "main",
        "hardening_baseline": hardening["baseline"],
        "image_runtime": defaults["image_runtime"],
        "ingress_rate_limit_qps": rate["rate_limit"],
        "max_concurrent_sessions": precedence["max_concurrent_sessions"]["resolved"],
        "mode": defaults["mode"],
        "nonce_window_ms": precedence["nonce_window_ms"]["resolved"],
        "privilege_drop_uid": scopes["privilege_drop_uid"],
        "profile": load_json(DATA / "config_schema.json")["profile"],
        "quorum_threshold": quorum["quorum_threshold"],
        "retry_backoff_base_ms": retry["retry_backoff_base_ms"],
        "risk_index": risk["risk_index"],
        "seccomp_allowed_count": seccomp,
        "session_ttl_seconds": precedence["session_ttl_seconds"]["resolved"],
        "tls_floor_score": tls,
        "trailer": trailer,
    }
    ctx = {
        "class": klass,
        "base_inputs": {
            "max_records": max_records,
            "retry_limit": retry_limit,
            "timeout_ms": timeout_ms,
            "trailer": trailer,
        },
        "rate": rate,
        "scopes": scopes,
        "hardening": hardening,
        "risk": risk,
        "quorum": quorum,
        "tls_floor_score": tls,
        "seccomp_allowed_count": seccomp,
        "audit_retention_days": retention,
        "precedence": precedence,
        "retry": retry,
    }
    return config, ctx


def required_keys(schema_path):
    raw = load_json(schema_path)["required_keys"]
    if isinstance(raw, str):
        return [k.strip() for k in raw.split(",") if k.strip()]
    return list(raw)


def profile_config(config, name):
    deltas = load_json(DATA / "profile_deltas.json")[name]
    ttl = quantize_floor(
        round_half_even(config["session_ttl_seconds"] * int(deltas["ttl_scale_permille"]), 1000),
        TTL_STEP,
    )
    out = dict(config)
    out["enforcement_profile"] = name
    out["profile"] = name
    out["session_ttl_seconds"] = ttl
    out["quorum_threshold"] = clamp(
        config["quorum_threshold"] + int(deltas["quorum_delta"]),
        1,
        quorum_plan(config["active_class"])["healthy_voters"],
    )
    out["risk_index"] = config["risk_index"] + int(deltas["risk_delta"])
    return out


def profile_delta(main, prof):
    out = []
    for key in sorted(set(main) | set(prof)):
        a, b = main.get(key), prof.get(key)
        entry = {"field": key, "main": a, "profile": b}
        if isinstance(a, int) and not isinstance(a, bool) and isinstance(b, int) and not isinstance(b, bool):
            entry["delta"] = b - a
        out.append(entry)
    return out


# --------------------------------------------------------------- commands

def cmd_derive(args):
    config, ctx = derive()
    write_json(args.out, config)
    if getattr(args, "context", None):
        write_json(args.context, ctx)
    print("derived")


def cmd_profile(args):
    config = load_json(args.config)
    write_json(args.out, profile_config(config, args.name))
    print("profiled")


def cmd_delta(args):
    main = load_json(args.main)
    prof = load_json(args.profile)
    write_json(args.out, {
        "profile": prof.get("enforcement_profile"),
        "delta": profile_delta(main, prof),
    })
    print("delta")


def cmd_init(args):
    schema = load_json(args.schema)
    write_json(args.out, {
        "profile": schema["profile"],
        "checksum": schema["checksum"],
        "mode": schema["mode"],
        "control_plane": schema["control_plane"],
        "image_runtime": schema["image_runtime"],
    })
    print("initialized")


def cmd_set(args):
    data = load_json(args.config)
    key = args.key.lower()
    current = data.get(key)
    if isinstance(current, int) and not isinstance(current, bool):
        if not re.fullmatch(r"-?\d+", args.value.strip()):
            raise SystemExit("value for %s must be an integer scalar" % key)
        value = int(args.value.strip())
    else:
        value = args.value
    if isinstance(value, (dict, list)):
        raise SystemExit("configuration must be flat; refusing non-scalar value")
    data[key] = value
    write_json(args.config, data)
    print("set")


def cmd_validate(args):
    schema = load_json(args.schema)
    data = load_json(args.config)
    required = required_keys(args.schema)
    missing = [k for k in required if k not in data]
    if missing:
        raise SystemExit("missing: " + ",".join(missing))
    bad = [k for k in data if isinstance(data[k], (dict, list))]
    if bad:
        raise SystemExit("configuration must be flat: " + ",".join(sorted(bad)))
    forbidden = load_json(DATA / "validation_rules.json")["forbidden_keys"]
    present = [k for k in forbidden if k in data]
    if present:
        raise SystemExit("forbidden keys present: " + ",".join(sorted(present)))
    if getattr(args, "json", None):
        write_json(args.json, {
            "ok": True,
            "schema": str(args.schema),
            "config": str(args.config),
            "required_keys": sorted(required),
            "flat": True,
            "missing": [],
        })
    print("ok")


def cmd_report(args):
    data = load_json(args.config)
    text = dump_json(data)
    digest = args.digest or hashlib.sha256(text.encode("utf-8")).hexdigest()
    commands = load_json(args.commands) if args.commands else []
    write_json(args.out, {
        "ok": True,
        "config": data,
        "digest": digest,
        "commands": commands,
    })
    print("reported")


def main():
    parser = argparse.ArgumentParser(prog="task-ctl")
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("derive")
    p.add_argument("--out", required=True)
    p.add_argument("--context")
    p.set_defaults(func=cmd_derive)

    p = sub.add_parser("profile")
    p.add_argument("--name", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_profile)

    p = sub.add_parser("delta")
    p.add_argument("--main", required=True)
    p.add_argument("--profile", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_delta)

    p = sub.add_parser("init")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--json")
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("export-report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest")
    p.add_argument("--commands")
    p.set_defaults(func=cmd_report)

    args = parser.parse_args()
    if not getattr(args, "command", None):
        return
    args.func(args)


if __name__ == "__main__":
    main()

