"""Exact-integer policy layer readers for the admission-control hardening compiler.

Every helper here parses one documented policy layer under /app/data and returns
only the rows that are authoritative (status == ADOPTED) for a given
enforcement class.  All arithmetic that reaches a graded value is performed on
integers with round-half-even (banker's) rounding; no float is ever produced.
"""
from __future__ import annotations

import base64
import json
import re
from pathlib import Path

DATA = Path("/app/data")
ADOPTED = "ADOPTED"


# ---------------------------------------------------------------- arithmetic

def round_half_even(num, den):
    """Exact integer round-half-even of num/den (den > 0)."""
    num, den = int(num), int(den)
    if den < 0:
        num, den = -num, -den
    q, r = divmod(num, den)
    twice = 2 * r
    if twice > den or (twice == den and q % 2 != 0):
        q += 1
    return q


def quantize(value, step):
    """Quantize to a multiple of step using round-half-even arithmetic."""
    return round_half_even(int(value), int(step)) * int(step)


def clamp(value, lo, hi):
    return max(int(lo), min(int(hi), int(value)))


# ------------------------------------------------------------------- parsing

def read_lines(name):
    out = []
    for line in (DATA / name).read_text(encoding="utf-8", errors="replace").split("\n"):
        s = line.strip()
        if not s or s.startswith("#") or s.startswith(";"):
            continue
        out.append(line)
    return out


def delimited_rows(name, sep):
    lines = read_lines(name)
    if not lines:
        return []
    if not lines[0].split(sep) or lines[0].count(sep) == 0:
        # single-column header (separator absent): fall back to whitespace
        header = lines[0].split()
        rows = []
        for line in lines[1:]:
            parts = line.split()
            if len(parts) != len(header):
                continue
            rows.append(dict(zip(header, parts)))
        return rows
    header = [c.strip() for c in lines[0].split(sep)]
    rows = []
    for line in lines[1:]:
        parts = [c.strip() for c in line.split(sep)]
        if len(parts) != len(header):
            continue
        rows.append(dict(zip(header, parts)))
    return rows


def jsonl_rows(name):
    rows = []
    for line in read_lines(name):
        s = line.strip()
        if s:
            rows.append(json.loads(s))
    return rows


def ini_blocks(name):
    """Minimal INI reader: returns {section: {key: value}} preserving order."""
    sections = {}
    cur = None
    for line in read_lines(name):
        s = line.strip()
        if s.startswith("[") and s.endswith("]"):
            cur = s[1:-1].strip()
            sections.setdefault(cur, {})
            continue
        if cur is None or "=" not in s:
            continue
        key, _, val = s.partition("=")
        sections[cur][key.strip()] = val.strip()
    return sections


def toml_blocks(name):
    """Minimal TOML reader restricted to the flat [section] tables used here."""
    sections = {}
    cur = None
    for line in read_lines(name):
        s = line.strip()
        if s.startswith("[") and s.endswith("]"):
            cur = s[1:-1].strip()
            sections.setdefault(cur, {})
            continue
        if cur is None or "=" not in s:
            continue
        key, _, val = s.partition("=")
        val = val.strip()
        if val.startswith('"') and val.endswith('"'):
            val = val[1:-1]
        sections[cur][key.strip()] = val
    return sections


def properties_rows(name):
    out = {}
    for line in read_lines(name):
        s = line.strip()
        if "=" not in s:
            continue
        key, _, val = s.partition("=")
        out[key.strip()] = val.strip()
    return out


def env_rows(name):
    return properties_rows(name)


def class_rows(rows, klass, status_field="status", class_field=None):
    """Rows binding for klass (status ADOPTED)."""
    out = []
    for row in rows:
        if str(row.get(status_field, "")).strip() != ADOPTED:
            continue
        if class_field is not None and str(row.get(class_field, "")).strip() != str(klass):
            continue
        out.append(row)
    return out


# -------------------------------------------------------------- base budget

def base_inputs():
    base = json.loads((DATA / "defaults.json").read_text())
    cfg = base["base_config"]
    return {
        "max_records": int(cfg["max_records"]),
        "retry_limit": int(cfg["retry_limit"]),
        "timeout_ms": int(cfg["timeout_ms"]),
        "trailer": str(cfg["trailer"]),
        "defaults": {k: int(v) for k, v in base["layer_defaults"].items()},
        "schema_strings": {
            "profile": base.get("profile", "TASK"),
            "checksum": base.get("checksum", "crc32"),
            "control_plane": base.get("control_plane", "admission-broker"),
            "image_runtime": base.get("image_runtime", "oci-runc"),
            "mode": base.get("mode", "strict-local"),
        },
    }


def selector_table():
    """ADOPTED selector ranges from class_index.tsv2 (class_id, lo, hi)."""
    rows = delimited_rows("class_index.tsv2", "\t")
    out = []
    for r in rows:
        if str(r.get("status", "")).strip() != ADOPTED:
            continue
        out.append((int(r["class_id"]), int(r["selector_lo"]), int(r["selector_hi"])))
    return sorted(out, key=lambda t: t[1])


def active_class(max_records):
    """Select the class whose ADOPTED selector range covers the base budget.

    The ADOPTED ranges partition one selector span (0..span-1); the base budget
    is reduced into that span before the range lookup.  This replaces the
    undocumented ``% 5`` formula of the broken build.
    """
    table = selector_table()
    span = sum(hi - lo + 1 for _, lo, hi in table)
    selector = int(max_records) % span
    for klass, lo, hi in table:
        if lo <= selector <= hi:
            return klass, selector, span
    raise SystemExit("no adopted selector range covers budget")


# --------------------------------------------------------------- rate limits

def ingress_qps(klass):
    rows = class_rows(delimited_rows("ingress_rate.tsv", "\t"), klass, class_field="class_id")
    if not rows:
        raise SystemExit("no adopted ingress row for class %s" % klass)
    return int(rows[0]["ingress_qps"])


def burst_factor(klass):
    blocks = ini_blocks("burst_multiplier.ini")
    section = "class.%d" % klass
    if section not in blocks or blocks[section].get("status") != ADOPTED:
        raise SystemExit("no adopted burst block for class %s" % klass)
    return int(blocks[section]["burst_multiplier_permille"])


def window_seconds(klass):
    for line in read_lines("window_seconds.conf"):
        parts = line.split()
        if len(parts) != 3:
            continue
        cid, seconds, status = (p.strip() for p in parts)
        if cid == str(klass) and status == ADOPTED:
            return int(seconds)
    raise SystemExit("no adopted window row for class %s" % klass)


def rate_step(klass):
    rows = class_rows(delimited_rows("rate_gran.caret", "^"), klass, class_field="class_id")
    if not rows:
        raise SystemExit("no adopted rate step for class %s" % klass)
    return int(rows[0]["gran"])


def rate_limits(klass):
    """ingress_rate_limit_qps = qps * burst_permille / 1000, quantized to the
    rate step; burst_ceiling = resolved rate limit * window."""
    qps = ingress_qps(klass)
    permille = burst_factor(klass)
    step = rate_step(klass)
    window = window_seconds(klass)
    scaled = round_half_even(qps * permille, 1000)
    rate_limit = quantize(scaled, step)
    burst_ceiling = rate_limit * window
    return {
        "qps": qps,
        "burst_permille": permille,
        "rate_step": step,
        "scaled": scaled,
        "ingress_rate_limit_qps": rate_limit,
        "window_seconds": window,
        "burst_ceiling": burst_ceiling,
    }


# -------------------------------------------------------------------- scopes

def scope_base(klass):
    rows = class_rows(jsonl_rows("scope_base.jsonl"), klass, class_field="class_id")
    return sorted({str(r["scope"]) for r in rows})


def scope_overlay(klass):
    rows = class_rows(jsonl_rows("scope_overlay.ndjson"), klass, class_field="class_id")
    return sorted({str(r["scope"]) for r in rows})


def scope_deny(klass):
    rows = class_rows(delimited_rows("scope_deny.psv", "|"), klass, class_field="class_id")
    return sorted({str(r["scope"]) for r in rows})


def scope_uids():
    uids = {}
    for line in read_lines("uid_map.env"):
        key, _, val = line.strip().partition("=")
        if key.startswith("SCOPE_") and val.strip().lstrip("-").isdigit():
            uids[key[len("SCOPE_"):].lower()] = int(val.strip())
    return uids


def uid_floor(klass):
    rows = class_rows(delimited_rows("uid_floor.hex", ":"), klass, class_field="class_id")
    if not rows:
        raise SystemExit("no adopted uid floor for class %s" % klass)
    return int(rows[0]["floor_hex"], 16)


def privilege_min_uid(klass):
    """Cross-check layer: minimum granted uid for the class (ADOPTED rows)."""
    best = None
    for line in read_lines("privilege_bits.b64"):
        s = line.strip()
        if not s:
            continue
        try:
            decoded = base64.b64decode(s, validate=True).decode("utf-8")
        except Exception:
            continue
        fields = dict(p.split("=", 1) for p in decoded.split(";") if "=" in p)
        if fields.get("class") == str(klass) and fields.get("status") == ADOPTED:
            uid = int(fields["uid"])
            best = uid if best is None else min(best, uid)
    return best


def reconcile_scopes(klass):
    base = scope_base(klass)
    overlay = scope_overlay(klass)
    deny = scope_deny(klass)
    effective = sorted((set(base) | set(overlay)) - set(deny))
    uids = scope_uids()
    floor = uid_floor(klass)
    granted = {s: uids[s] for s in effective if s in uids}
    if len(granted) != len(effective):
        raise SystemExit("scope without granted uid: %s" % sorted(set(effective) - set(granted)))
    privilege_drop_uid = max(floor, min(granted.values()))
    mirror = privilege_min_uid(klass)
    return {
        "base": base,
        "overlay": overlay,
        "deny": deny,
        "effective": effective,
        "effective_scope_count": len(effective),
        "uids": granted,
        "uid_floor": floor,
        "privilege_drop_uid": privilege_drop_uid,
        "privilege_mirror": mirror,
    }


# ---------------------------------------------------------------- hardening

def hardening_controls(klass):
    """Class-matched control rows in ascending order (all statuses)."""
    rows = [
        r for r in delimited_rows("baseline_controls.scsv", ";")
        if str(r.get("class_id", "")).strip() == str(klass)
    ]
    rows.sort(key=lambda r: int(r["order"]))
    return rows


def hardening_bounds(klass):
    blocks = toml_blocks("hardening_bounds.toml")
    section = "class.%d" % klass
    if section not in blocks or blocks[section].get("status") != ADOPTED:
        raise SystemExit("no adopted hardening bounds for class %s" % klass)
    return int(blocks[section]["floor"]), int(blocks[section]["ceil"])


HARDENING_STEP = 5


def fold_hardening(klass):
    """Carry-aware ordered fold of the adopted hardening controls.

    A control whose ``carry_flag`` is 1 carries one increment into the next
    adopted control; a carry on the final adopted control is inert because it
    has no successor.  The folded score is clamped to the per-class bounds and
    then quantized to the hardening step with round-half-even arithmetic.
    """
    floor, ceil = hardening_bounds(klass)
    rows = hardening_controls(klass)
    trace = []
    running = 0
    carry_in = 0
    for row in rows:
        if str(row.get("status", "")).strip() != ADOPTED:
            trace.append({
                "order": int(row["order"]),
                "control_id": row["control_id"],
                "weight": int(row["weight"]),
                "carry": int(row["carry_flag"]),
                "status": row["status"],
                "running": None,
            })
            continue
        running += int(row["weight"]) + carry_in
        trace.append({
            "order": int(row["order"]),
            "control_id": row["control_id"],
            "weight": int(row["weight"]),
            "carry": int(row["carry_flag"]),
            "status": row["status"],
            "running": running,
        })
        carry_in = int(row["carry_flag"])
    clamped = clamp(running, floor, ceil)
    baseline = quantize(clamped, HARDENING_STEP)
    return {
        "trace": trace,
        "folded": running,
        "floor": floor,
        "ceil": ceil,
        "clamped": clamped,
        "step": HARDENING_STEP,
        "hardening_baseline": baseline,
    }


# --------------------------------------------------------------------- risk

def risk_constants():
    rows = env_rows("risk_const.env2")
    return int(rows["BASELINE_COMPLEMENT"]), int(rows["RISK_DIVISOR"])


def severity_permille(klass):
    for line in read_lines("severity_weight.kv"):
        parts = [p.strip() for p in line.strip().split(":")]
        if len(parts) != 3:
            continue
        cid, permille, status = parts
        if cid == "class%d" % klass and status == ADOPTED:
            return int(permille)
    raise SystemExit("no adopted severity for class %s" % klass)


def risk_index(klass, hardening_baseline):
    complement, divisor = risk_constants()
    severity = severity_permille(klass)
    return {
        "baseline_complement": complement,
        "risk_divisor": divisor,
        "severity_permille": severity,
        "risk_index": round_half_even((complement - hardening_baseline) * severity, divisor),
    }


# ------------------------------------------------------------------- quorum

def quorum_permille(klass):
    rows = class_rows(delimited_rows("quorum_permille.tilde", "~"), klass, class_field="class_id")
    if not rows:
        raise SystemExit("no adopted quorum permille for class %s" % klass)
    return int(rows[0]["permille"])


def healthy_voters(klass):
    rows = class_rows(jsonl_rows("voter_health.ndjson"), klass, class_field="class_id")
    healthy = [r for r in rows if bool(r.get("healthy"))]
    return int(len(healthy)), int(len(rows))


def quorum(klass):
    permille = quorum_permille(klass)
    healthy, total = healthy_voters(klass)
    threshold = clamp(round_half_even(healthy * permille, 1000), 1, healthy)
    return {
        "quorum_permille": permille,
        "healthy_voters": healthy,
        "class_voters": total,
        "quorum_threshold": threshold,
        "unclamped": round_half_even(healthy * permille, 1000),
    }


# ------------------------------------------------------- tls / seccomp / audit

def tls_floor(klass):
    best = None
    for row in delimited_rows("tls_matrix.csv", ","):
        if str(row.get("status", "")).strip() != ADOPTED:
            continue
        if str(row.get("class_id", "")).strip() != str(klass):
            continue
        if str(row.get("enabled", "")).strip().lower() != "true":
            continue
        score = int(row["score"])
        best = score if best is None else max(best, score)
    if best is None:
        raise SystemExit("no adopted enabled tls suite for class %s" % klass)
    return best


def seccomp_allow(klass):
    rows = class_rows(delimited_rows("seccomp_allow.tsv", "\t"), klass, class_field="class_id")
    return sorted({str(r["syscall"]) for r in rows})


def seccomp_deny(klass):
    rows = class_rows(delimited_rows("seccomp_deny.psv", "|"), klass, class_field="class_id")
    return sorted({str(r["syscall"]) for r in rows})


def seccomp_allowed_count(klass):
    allowed = set(seccomp_allow(klass)) - set(seccomp_deny(klass))
    return {
        "allowed_syscalls": sorted(allowed),
        "raw_allow": seccomp_allow(klass),
        "denied_syscalls": seccomp_deny(klass),
        "seccomp_allowed_count": len(allowed),
    }


def audit_retention_days(klass):
    blocks = ini_blocks("retention.ini")
    section = "class.%d" % klass
    if section not in blocks or blocks[section].get("status") != ADOPTED:
        raise SystemExit("no adopted retention block for class %s" % klass)
    return int(blocks[section]["retention_days"])


# --------------------------------------------------------------- precedence

PRECEDENCE_FIELDS = ("session_ttl_seconds", "nonce_window_ms", "max_concurrent_sessions")


def precedence_resolution(klass):
    """Resolve each precedence field as default <- class override <- pinned.

    A pinned entry binds only when ``pinned`` is true; pinned==false entries are
    inert.  ``max_concurrent_sessions`` is bounded above by the absolute ceiling
    layer and ``nonce_window_ms`` is bounded below by the absolute floor layer.
    """
    base = base_inputs()["defaults"]
    overrides = json.loads((DATA / "layer_overrides.json").read_text())
    pinned = json.loads((DATA / "pinned_overrides.json").read_text())
    caps = {int(r["class_id"]): int(r["abs_ceil"]) for r in
            class_rows(delimited_rows("sessions_cap.csv2", ","), klass, class_field="class_id")}
    nonce_blocks = toml_blocks("nonce_bounds.toml2")

    override = overrides.get("class_%d" % klass, {})
    pinned_row = pinned.get("class_%d" % klass, {})
    pinned_active = bool(pinned_row.get("pinned"))

    resolved = {}
    for field in PRECEDENCE_FIELDS:
        default = int(base[field])
        layer = int(override.get(field, default))
        pin = int(pinned_row.get(field, layer)) if pinned_active else layer
        value = pin
        if field == "max_concurrent_sessions":
            ceiling = caps.get(klass)
            if ceiling is not None:
                value = min(value, ceiling)
        if field == "nonce_window_ms":
            section = nonce_blocks.get("class.%d" % klass, {})
            if section.get("status") == ADOPTED:
                value = max(value, int(section["floor_ms"]))
        resolved[field] = {
            "default": default,
            "override": layer,
            "pinned": pin if pinned_active else None,
            "pinned_active": pinned_active,
            "value": value,
        }
    return resolved


# ------------------------------------------------------------ retry backoff

def retry_step(klass):
    rows = class_rows(delimited_rows("retry_backoff.psv2", "||"), klass, class_field="class_id")
    if not rows:
        raise SystemExit("no adopted retry step for class %s" % klass)
    return int(rows[0]["step"])


def retry_backoff(klass, timeout_ms, retry_limit):
    step = retry_step(klass)
    budget = round_half_even(timeout_ms * (retry_limit + 1), 8)
    return {
        "retry_step": step,
        "backoff_pre_quantize": budget,
        "retry_backoff_base_ms": quantize(budget, step),
    }


# ----------------------------------------------------------------- profiles

def profile_deltas():
    raw = json.loads((DATA / "profile_deltas.json").read_text())
    return {k: v for k, v in raw.items() if not k.startswith("_")}


def profile_roster():
    rows = class_rows(
        [{"name": p[0], "order": p[1], "status": p[2]} for p in
         [[c.strip() for c in line.strip().split(":")] for line in read_lines("profile_map.kv3")]
         if len(p) == 3],
        None,
    )
    return sorted((r["name"] for r in rows))


def required_keys():
    schema = json.loads((DATA / "config_schema.json").read_text())
    return list(schema["required_keys"])


def field_registry():
    rows = jsonl_rows("field_registry.ndjson")
    return [r for r in rows if str(r.get("status")) == ADOPTED and r.get("in_config") is True]
