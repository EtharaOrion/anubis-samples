# task-ctl

An offline container-image admission-control hardening compiler for a
server-side admission broker. It reads interacting numeric policy layers from
`/app/data`, selects the active enforcement class, and derives one flat hardened
admission configuration plus two deployment profiles (canary and enforce).

This is the repaired build. The shipped build derived several values with the
wrong formula or from the wrong layer; every defect is fixed in place:

| derivation | defect in the broken build | repair |
| --- | --- | --- |
| active class | undocumented `((max_records // 37) + 3 * retry_limit) % 5` formula | base budget reduced into the ADOPTED selector span of `class_index.tsv2` and looked up in the ADOPTED `selector_lo..selector_hi` range |
| ingress rate limit | first row of the throughput table and a hardcoded permille/window | ADOPTED row for the active class, scaled by the class burst permille, quantized to the class rate step |
| burst ceiling | raw pre-quantization throughput times window | resolved rate limit times the class window |
| scope reconciliation | deny layer read as the base layer; uid taken as the maximum over every mapped scope | base union overlay minus deny for the active class; uid is the minimum granted uid subject to the per-class uid floor |
| hardening baseline | weights summed without the carry rule, no clamp | ordered carry-aware fold over adopted controls, clamped to the per-class bounds, then quantized |
| risk index | hardcoded severity | per-class severity permille with the canonical complement and divisor |
| quorum threshold | all class rows counted, no bounds | healthy authoritative voters only, bounded below by 1 and above by the voter count |
| tls / seccomp / retention | absent | read from their per-class layers, ADOPTED rows only |
| precedence fields | absent, hardcoded 1800 | default, then class override, then pinned (only when `pinned == true`), honouring the absolute nonce floor and session ceiling |
| retry backoff | unquantized budget | timeout times retry budget, rounded half-even, quantized to the class step |
| rounding | floor-half-up on floats | exact integer arithmetic with round-half-even (banker's) rounding; no float touches a graded value |

## Commands

- `init --schema <schema> --out <config>`: seed fixed contract strings.
- `set --config <config> --key <key> --value <value>`: set one scalar key with
  correct case and type coercion; reject any non-scalar value.
- `validate --schema <schema> --config <config>`: confirm every required key is
  present and the configuration is flat; print `ok`.
- `derive --out <config>`: derive the hardened admission configuration.
- `profile --name <canary|enforce> --config <config> --out <profile>`: apply the
  documented per-profile deltas to a derived configuration.
- `package --out <archive>`: repackage the repaired tool deterministically.
- `export-report --config <config> --out <report> --digest <sha256> --commands <json>`:
  emit a truthful command transcript.
- `build --out-dir <dir>`: run the whole workflow and emit every artifact
  (configuration, profiles, delta report, sidecars, audit and coverage
  artifacts, and the repackaged tool archive) into one directory.

## Contract notes

- Every value is derived with exact integer arithmetic (round-half-even); no
  floating-point value may reach a graded key.
- The configuration is flat: keys map directly to integer or string scalars.
- The required key set is authoritative in `schema.json` and mirrored by the
  field registry in the policy layers.
- Only rows whose status is `ADOPTED` for the active enforcement class bind; rows
  labelled `SUPERSEDED`, `DRAFT`, `SHADOW`, or `REVOKED` are context decoys.
- All artifacts are pure functions of `/app/data` and are byte-stable across
  repeated runs; JSON keys are sorted wherever the format admits ordering.
