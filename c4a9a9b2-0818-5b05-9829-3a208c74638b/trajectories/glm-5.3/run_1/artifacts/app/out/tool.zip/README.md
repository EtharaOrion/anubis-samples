# task-ctl

An offline container-image admission-control hardening compiler for a
server-side admission broker. It reads interacting numeric policy layers from
`/app/data`, selects the active enforcement class, and derives one flat hardened
admission configuration plus two deployment profiles (canary and enforce).

The shipped build was faulty: its numeric derivation logic disagreed with the
documented threshold/rate-limit, privilege/scope reconciliation,
hardening-baseline, risk-scoring and quorum, and policy-precedence rules
recorded across the policy layers, and its command surface was incomplete. It
has been repaired in place so every derived scalar matches the documented
contract exactly.

## Repaired commands

- `init --schema <schema> --out <config>`: seed fixed contract strings plus the
  canonical trailer from `defaults.base_config.trailer`.
- `derive --schema <schema> --config <config> --out <config> --outdir <dir> --trace <json>`:
  compile the hardened configuration, the derivation sidecars and the audit
  artifacts from the policy layers.
- `profile --name <canary|enforce> --config <config> --trace <json> --out <config>`:
  apply the documented per-profile deltas on top of the main configuration.
- `finalize --schema <schema> --config <config> --outdir <dir> --trace <json>`:
  emit the profile delta report, class ordering, reproducibility manifest,
  validation report and summary.
- `export-report --config <config> --out <report> --digest <sha256> --commands <json>`:
  emit a truthful command transcript.
- `validate --schema <schema> --config <config>`: confirm every required key is
  present, the configuration is flat, and the trailer is the canonical one;
  print `ok`.
- `package --src <dir> --out <zip>`: repackage the repaired tool deterministically.
- `run.sh`: the full reproducible end-to-end pipeline.

## Defects repaired

- Class selection used an ad-hoc formula and ignored the class index. Now the
  base budget (`base_config.max_records`) is reduced into the span tiled by the
  ADOPTED selector bands of `class_index.tsv2` (five 37-wide bands tiling
  `[0,184]`, so mod 185) and the containing band selects the class.
- Rounding used `math.floor(x + 0.5)` (float, round-half-up). Now every
  arithmetic step is exact integer arithmetic with round-half-even (banker's)
  rounding; no float touches a graded value.
- Ingress rate limit read the first table row, hard-coded the burst factor,
  quantized with floor and derived the burst ceiling from the raw throughput.
  Now the per-class ADOPTED throughput is scaled by the ADOPTED burst permille,
  quantized (round-half-even) to the ADOPTED rate step, and the burst ceiling is
  the resolved rate limit times the ADOPTED per-class window.
- Scope reconciliation read the deny file as if it were the base layer and took
  `max` of all uids (including `UID_DECOY_*` traps). Now the effective set is
  base union overlay minus deny for the active class, and the privilege-drop uid
  is the minimum granted uid for that reconciled set subject to the ADOPTED uid
  floor (read from hex).
- Hardening baseline ignored the carry flags and the class bounds. Now the
  ordered ADOPTED controls are folded carry-aware (a flagged control also
  carries half, round-half-even, of the running score that preceded it), the
  result is clamped to the ADOPTED per-class floor/ceiling and quantized.
- Risk index hard-coded the severity. Now it uses the ADOPTED per-class severity
  permille and the canonical complement/divisor constants.
- Quorum counted every row regardless of health/status and never bounded the
  threshold. Now it counts healthy ADOPTED voters for the active class, applies
  the ADOPTED quorum permille, and clamps to [1, voter count].
- Precedence ignored the override and pinned layers entirely. Now
  defaults < class override < pinned (pinned==false entries are inert).
- Profiles scaled a hard-coded TTL. Now the resolved TTL is scaled by the
  profile permille before granularity quantization, and quorum/risk deltas are
  applied after the main derivation with the quorum bounded by the voter count.
- Emissions wrote a nested `{"admission": {...}}` object. Now the configuration
  is one flat object of scalar values with sorted keys, and every required
  artifact is emitted by the tool itself.

## Contract notes

- Every value is derived with exact integer arithmetic (round-half-even); no
  floating-point value may reach a graded key.
- The configuration is flat: keys map directly to integer or string scalars.
- The required key set is authoritative in `schema.json` and mirrored by the
  field registry in the policy layers.
- Only rows whose status is `ADOPTED` for the active enforcement class bind;
  rows labelled `SUPERSEDED`, `DRAFT`, `SHADOW`, or `REVOKED` are context
  decoys.
- The canonical trailer is `defaults.base_config.trailer`
  (`harbor:cli-config:TASK:000000002e552977`) and is carried through the
  configuration, the report and both profiles; the decoy trailers in
  `trailer_registry.txt3` are never emitted.
