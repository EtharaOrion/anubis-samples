#!/bin/sh
# Reproducible end-to-end run of the repaired task-ctl compiler.
# Every graded artifact is produced by the repaired tool itself.
set -e
cd /app/tool
rm -rf /app/out /app/run
mkdir -p /app/out /app/run

python3 cli.py derive --schema /app/tool/schema.json --config /app/run/work.json \
  --out /app/out/config.json --outdir /app/out --trace /app/run/trace.json

python3 cli.py profile --name canary --config /app/out/config.json \
  --trace /app/run/trace.json --out /app/out/profile_canary.json

python3 cli.py profile --name enforce --config /app/out/config.json \
  --trace /app/run/trace.json --out /app/out/profile_enforce.json

python3 cli.py package --src /app/tool --out /app/out/tool.zip

DIGEST=$(python3 - <<'PY'
import hashlib
print(hashlib.sha256(open('/app/out/config.json', 'rb').read()).hexdigest())
PY
)
python3 cli.py export-report --config /app/out/config.json --out /app/out/report.json \
  --digest "$DIGEST" --commands /app/tool/commands.json

python3 cli.py finalize --schema /app/tool/schema.json --config /app/out/config.json \
  --outdir /app/out --trace /app/run/trace.json

python3 cli.py validate --schema /app/tool/schema.json --config /app/out/config.json
python3 cli.py validate --schema /app/tool/schema.json --config /app/out/profile_canary.json
python3 cli.py validate --schema /app/tool/schema.json --config /app/out/profile_enforce.json
