#!/usr/bin/env python3
"""task-ctl: local admission-control hardening compiler (repaired).

Compiles one flat hardened admission configuration for the active enforcement
class of a server-side admission broker, plus the canary/enforce deployment
profiles and the derivation/audit sidecars, from the interacting policy layers
under /app/data.

Repairs applied to the shipped broken build:

* class selection now uses the documented selector-range lookup over the base
  budget instead of the undocumented ``% 5`` formula;
* the ingress rate limit is taken from the ADOPTED per-class throughput row,
  scaled by the class burst factor and quantized to the class rate step, and
  the burst ceiling is derived from the resolved rate limit and the class
  window instead of the raw throughput;
* the effective scope set is reconciled as base | overlay - deny for the active
  class and the privilege-drop uid is the minimum granted uid subject to the
  per-class uid floor (the broken build read the deny layer as the base layer
  and took the maximum uid of every mapped scope);
* the hardening baseline folds the ordered control layer with the carry rule
  between consecutive adopted controls, clamps to the per-class bounds and
  quantizes;
* risk index, quorum threshold, tls/seccomp/retention, precedence resolution
  and retry backoff all read their own documented layers;
* every arithmetic step is exact integer arithmetic with round-half-even
  (banker's) rounding; no float ever reaches a graded value.

Only the Python standard library is used and no network access is performed.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import zlib
from pathlib import Path

import policy
from policy import (
    active_class,
    audit_retention_days,
    base_inputs,
    clamp,
    fold_hardening,
    precedence_resolution,
    profile_deltas,
    quantize,
    quorum,
    rate_limits,
    reconcile_scopes,
    required_keys,
    retry_backoff,
    risk_index,
    round_half_even,
    seccomp_allowed_count,
    tls_floor,
)

TRAILER_KEY = "trailer"
MAIN_PROFILE = "main"
HARDENING_STEP = policy.HARDENING_STEP


# ------------------------------------------------------------- serialization

def dump_json(obj):
    return json.dumps(obj, sort_keys=True, indent=2, ensure_ascii=False) + "\n"


def write_text(path, text):
    Path(path).write_text(text, encoding="utf-8", newline="\n")


def write_json(path, obj):
    write_text(path, dump_json(obj))


def sha256_hex(data):
    if isinstance(data, str):
        data = data.encode("utf-8")
    return hashlib.sha256(data).hexdigest()


# ------------------------------------------------------------------ helpers

def coerce_scalar(value):
    """Coerce a CLI scalar to int when it is an exact integer literal."""
    text = str(value).strip()
    if text.lstrip("+-").isdigit():
        return int(text)
    lowered = text.lower()
    if lowered in ("true", "false"):
        return lowered == "true"
    if text[:1] in "[{":
        # a container literal is never a scalar
        raise SystemExit("configuration is scalar-only: refusing non-scalar value " + text)
    return text


def flat_scalar_config(config):
    return sorted(k for k, v in config.items() if isinstance(v, (dict, list, tuple)))


def config_digest(config):
    if isinstance(config, str):
        data = config.encode("utf-8")
    elif isinstance(config, bytes):
        data = config
    else:
        data = dump_json(config).encode("utf-8")
    return hashlib.sha256(data).hexdigest()


# ---------------------------------------------------------------- derivation

def derive_state():
    """Derive every graded value for the active enforcement class."""
    base = base_inputs()
    max_records = base["max_records"]
    retry_limit = base["retry_limit"]
    timeout_ms = base["timeout_ms"]
    trailer = base["trailer"]

    klass, selector, span = active_class(max_records)

    rate = rate_limits(klass)
    scopes = reconcile_scopes(klass)
    hardening = fold_hardening(klass)
    risk = risk_index(klass, hardening["hardening_baseline"])
    vote = quorum(klass)
    tls = tls_floor(klass)
    seccomp = seccomp_allowed_count(klass)
    retention = audit_retention_days(klass)
    precedence = precedence_resolution(klass)
    backoff = retry_backoff(klass, timeout_ms, retry_limit)

    strings = base["schema_strings"]
    config = {
        "active_class": klass,
        "audit_retention_days": retention,
        "burst_ceiling": rate["burst_ceiling"],
        "checksum": strings["checksum"],
        "control_plane": strings["control_plane"],
        "effective_scope_count": scopes["effective_scope_count"],
        "enforcement_profile": MAIN_PROFILE,
        "hardening_baseline": hardening["hardening_baseline"],
        "image_runtime": strings["image_runtime"],
        "ingress_rate_limit_qps": rate["ingress_rate_limit_qps"],
        "max_concurrent_sessions": precedence["max_concurrent_sessions"]["value"],
        "mode": strings["mode"],
        "nonce_window_ms": precedence["nonce_window_ms"]["value"],
        "privilege_drop_uid": scopes["privilege_drop_uid"],
        "profile": strings["profile"],
        "quorum_threshold": vote["quorum_threshold"],
        "retry_backoff_base_ms": backoff["retry_backoff_base_ms"],
        "risk_index": risk["risk_index"],
        "seccomp_allowed_count": seccomp["seccomp_allowed_count"],
        "session_ttl_seconds": precedence["session_ttl_seconds"]["value"],
        "tls_floor_score": tls,
        TRAILER_KEY: trailer,
    }

    return {
        "base": base,
        "class": klass,
        "selector": selector,
        "selector_span": span,
        "rate": rate,
        "scopes": scopes,
        "hardening": hardening,
        "risk": risk,
        "quorum": vote,
        "tls_floor_score": tls,
        "seccomp": seccomp,
        "audit_retention_days": retention,
        "precedence": precedence,
        "backoff": backoff,
        "config": config,
    }


def derive_profiles(state):
    """Apply the documented per-profile deltas to the main configuration."""
    main = state["config"]
    ttl = main["session_ttl_seconds"]
    voters = state["quorum"]["healthy_voters"]
    profiles = {}
    for name, delta in sorted(profile_deltas().items()):
        scaled = round_half_even(ttl * int(delta["ttl_scale_permille"]), 1000)
        resolved_ttl = quantize(scaled, HARDENING_STEP)
        quorum_value = clamp(int(main["quorum_threshold"]) + int(delta["quorum_delta"]), 1, voters)
        risk_value = int(main["risk_index"]) + int(delta["risk_delta"])
        profile = dict(main)
        profile["enforcement_profile"] = name
        profile["session_ttl_seconds"] = resolved_ttl
        profile["quorum_threshold"] = quorum_value
        profile["risk_index"] = risk_value
        profiles[name] = {
            "config": profile,
            "ttl_scale_permille": int(delta["ttl_scale_permille"]),
            "ttl_scaled": scaled,
            "ttl_granularity": HARDENING_STEP,
            "quorum_delta": int(delta["quorum_delta"]),
            "risk_delta": int(delta["risk_delta"]),
        }
    return profiles


# -------------------------------------------------------------- sidecar text

def render_rate_limit_plan(state):
    rate = state["rate"]
    return "".join([
        "[rate]\n",
        "class = %d\n" % state["class"],
        "ingress_rate_limit_qps = %d\n" % rate["ingress_rate_limit_qps"],
        "burst_ceiling = %d\n" % rate["burst_ceiling"],
    ])


def render_hardening_fold_trace(state):
    lines = ["order|control_id|weight|carry|status|running"]
    for row in state["hardening"]["trace"]:
        running = "skip" if row["running"] is None else str(row["running"])
        lines.append("%d|%s|%d|%d|%s|%s" % (
            row["order"], row["control_id"], row["weight"], row["carry"],
            row["status"], running))
    return "\n".join(lines) + "\n"


def render_quorum_plan(state):
    vote = state["quorum"]
    return "healthy_voters:%d\nquorum_threshold:%d\n" % (
        vote["healthy_voters"], vote["quorum_threshold"])


def render_risk_ledger(state):
    risk = state["risk"]
    return "HARDENING_BASELINE=%d\nRISK_INDEX=%d\nSEVERITY_PERMILLE=%d\n" % (
        state["hardening"]["hardening_baseline"], risk["risk_index"],
        risk["severity_permille"])


def render_precedence_resolution(state):
    lines = []
    for field in policy.PRECEDENCE_FIELDS:
        entry = state["precedence"][field]
        lines.append("%s.default=%d" % (field, entry["default"]))
        lines.append("%s.resolved=%d" % (field, entry["value"]))
    return "\n".join(lines) + "\n"


def render_privilege_map(state):
    scopes = state["scopes"]
    lines = [
        json.dumps({"scope": name, "uid": scopes["uids"][name]}, sort_keys=True)
        for name in scopes["effective"]
    ]
    return "\n".join(lines) + "\n"


def render_seccomp_summary(state):
    return "class\tseccomp_allowed_count\n%d\t%d\n" % (
        state["class"], state["seccomp"]["seccomp_allowed_count"])


def render_tls_floor(state):
    return "TLS_FLOOR_SCORE=%d\n" % state["tls_floor_score"]


def render_admission_matrix(state):
    config = state["config"]
    header = [
        "active_class", "ingress_rate_limit_qps", "burst_ceiling",
        "effective_scope_count", "privilege_drop_uid", "hardening_baseline",
        "risk_index", "quorum_threshold", "tls_floor_score",
        "seccomp_allowed_count", "audit_retention_days", "session_ttl_seconds",
        "nonce_window_ms", "max_concurrent_sessions", "retry_backoff_base_ms",
    ]
    lines = [",".join(header)]
    lines.append(",".join(str(config[key]) for key in header))
    return "\n".join(lines) + "\n"


def render_scope_reconciliation(state):
    scopes = state["scopes"]
    lines = ["class\tbase_count\toverlay_count\tdeny_count\teffective_scope_count\tprivilege_drop_uid\tscopes"]
    lines.append("%d\t%d\t%d\t%d\t%d\t%d\t%s" % (
        state["class"], len(scopes["base"]), len(scopes["overlay"]),
        len(scopes["deny"]), scopes["effective_scope_count"],
        scopes["privilege_drop_uid"], " ".join(scopes["effective"])))
    return "\n".join(lines) + "\n"


def render_retention_schedule(state):
    config = state["config"]
    return "class,audit_retention_days\n%d,%d\n" % (
        state["class"], config["audit_retention_days"])


def render_class_ordering(state, profiles):
    rows = [(MAIN_PROFILE, state["config"]["risk_index"])]
    for name in sorted(profiles):
        rows.append((name, profiles[name]["config"]["risk_index"]))
    rows.sort(key=lambda row: (row[1], row[0]))
    lines = ["profile\trisk_index"]
    lines.extend("%s\t%d" % row for row in rows)
    return "\n".join(lines) + "\n"


# ------------------------------------------------------------- audit layers

def xml_escape(text):
    return (str(text).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


def render_derivation_audit(state, profiles, transcript):
    config = state["config"]
    rate = state["rate"]
    scopes = state["scopes"]
    hardening = state["hardening"]
    risk = state["risk"]
    vote = state["quorum"]
    backoff = state["backoff"]
    lines = ['<?xml version="1.0" encoding="UTF-8"?>', "<derivationAudit>"]
    lines.append("  <tool>task-ctl</tool>")
    lines.append("  <activeClass selector=\"%d\" span=\"%d\">%d</activeClass>" % (
        state["selector"], state["selector_span"], state["class"]))
    lines.append("  <ingress>")
    lines.append("    <throughputQps>%d</throughputQps>" % rate["qps"])
    lines.append("    <burstPermille>%d</burstPermille>" % rate["burst_permille"])
    lines.append("    <scaledQps>%d</scaledQps>" % rate["scaled"])
    lines.append("    <rateStep>%d</rateStep>" % rate["rate_step"])
    lines.append("    <ingressRateLimitQps>%d</ingressRateLimitQps>" % rate["ingress_rate_limit_qps"])
    lines.append("    <windowSeconds>%d</windowSeconds>" % rate["window_seconds"])
    lines.append("    <burstCeiling>%d</burstCeiling>" % rate["burst_ceiling"])
    lines.append("  </ingress>")
    lines.append("  <scopes>")
    lines.append("    <base>%s</base>" % xml_escape(" ".join(scopes["base"])))
    lines.append("    <overlay>%s</overlay>" % xml_escape(" ".join(scopes["overlay"])))
    lines.append("    <deny>%s</deny>" % xml_escape(" ".join(scopes["deny"])))
    lines.append("    <effective count=\"%d\">%s</effective>" % (
        scopes["effective_scope_count"], xml_escape(" ".join(scopes["effective"]))))
    lines.append("    <uidFloor>%d</uidFloor>" % scopes["uid_floor"])
    lines.append("    <privilegeDropUid>%d</privilegeDropUid>" % scopes["privilege_drop_uid"])
    lines.append("  </scopes>")
    lines.append("  <hardening>")
    for row in hardening["trace"]:
        running = "skip" if row["running"] is None else str(row["running"])
        lines.append("    <control order=\"%d\" id=\"%s\" weight=\"%d\" carry=\"%d\" status=\"%s\" running=\"%s\"/>" % (
            row["order"], xml_escape(row["control_id"]), row["weight"], row["carry"],
            xml_escape(row["status"]), running))
    lines.append("    <folded>%d</folded>" % hardening["folded"])
    lines.append("    <bounds floor=\"%d\" ceil=\"%d\"/>" % (hardening["floor"], hardening["ceil"]))
    lines.append("    <clamped>%d</clamped>" % hardening["clamped"])
    lines.append("    <quantizationStep>%d</quantizationStep>" % hardening["step"])
    lines.append("    <baseline>%d</baseline>" % hardening["hardening_baseline"])
    lines.append("  </hardening>")
    lines.append("  <risk>")
    lines.append("    <baselineComplement>%d</baselineComplement>" % risk["baseline_complement"])
    lines.append("    <severityPermille>%d</severityPermille>" % risk["severity_permille"])
    lines.append("    <divisor>%d</divisor>" % risk["risk_divisor"])
    lines.append("    <riskIndex>%d</riskIndex>" % risk["risk_index"])
    lines.append("  </risk>")
    lines.append("  <quorum>")
    lines.append("    <permille>%d</permille>" % vote["quorum_permille"])
    lines.append("    <healthyVoters>%d</healthyVoters>" % vote["healthy_voters"])
    lines.append("    <threshold lowerBound=\"1\" upperBound=\"%d\">%d</threshold>" % (
        vote["healthy_voters"], vote["quorum_threshold"]))
    lines.append("  </quorum>")
    lines.append("  <bounds>")
    lines.append("    <tlsFloorScore>%d</tlsFloorScore>" % state["tls_floor_score"])
    lines.append("    <seccompAllowedCount>%d</seccompAllowedCount>" % state["seccomp"]["seccomp_allowed_count"])
    lines.append("    <auditRetentionDays>%d</auditRetentionDays>" % state["audit_retention_days"])
    lines.append("  </bounds>")
    lines.append("  <precedence>")
    for field in policy.PRECEDENCE_FIELDS:
        entry = state["precedence"][field]
        lines.append("    <field name=\"%s\" default=\"%d\" override=\"%d\" pinned=\"%s\" resolved=\"%d\"/>" % (
            xml_escape(field), entry["default"], entry["override"],
            "true" if entry["pinned_active"] else "false", entry["value"]))
    lines.append("    <retryBackoff timeoutMs=\"%d\" retryLimit=\"%d\" step=\"%d\" base=\"%d\"/>" % (
        state["base"]["timeout_ms"], state["base"]["retry_limit"],
        backoff["retry_step"], backoff["retry_backoff_base_ms"]))
    lines.append("  </precedence>")
    lines.append("  <profiles>")
    for name in sorted(profiles):
        prof = profiles[name]
        lines.append("    <profile name=\"%s\" ttlScalePermille=\"%d\" sessionTtlSeconds=\"%d\" quorumDelta=\"%d\" quorumThreshold=\"%d\" riskDelta=\"%d\" riskIndex=\"%d\"/>" % (
            xml_escape(name), prof["ttl_scale_permille"],
            prof["config"]["session_ttl_seconds"], prof["quorum_delta"],
            prof["config"]["quorum_threshold"], prof["risk_delta"],
            prof["config"]["risk_index"]))
    lines.append("  </profiles>")
    lines.append("  <trailer>%s</trailer>" % xml_escape(config[TRAILER_KEY]))
    lines.append("  <commandTranscript>")
    for entry in transcript:
        lines.append("    <command seq=\"%d\">%s</command>" % (
            entry["seq"], xml_escape(entry["argv"])))
    lines.append("  </commandTranscript>")
    lines.append("</derivationAudit>")
    return "\n".join(lines) + "\n"


def render_convergence_report(state, profiles, manifest):
    config = state["config"]
    lines = []
    lines.append("task-ctl convergence report")
    lines.append("=========================")
    lines.append("active enforcement class : %d" % state["class"])
    lines.append("base budget selector     : %d of span %d" % (state["selector"], state["selector_span"]))
    lines.append("arithmetic               : exact integer, round-half-even (banker's)")
    lines.append("floating point in graded values : none")
    lines.append("")
    lines.append("resolved graded values")
    lines.append("----------------------")
    for key in required_keys():
        lines.append("%s = %s" % (key, config[key]))
    lines.append("")
    lines.append("profile deltas")
    lines.append("--------------")
    for name in sorted(profiles):
        prof = profiles[name]
        lines.append("%s: ttl_scale_permille=%d -> session_ttl_seconds=%d, quorum_threshold=%d, risk_index=%d" % (
            name, prof["ttl_scale_permille"], prof["config"]["session_ttl_seconds"],
            prof["config"]["quorum_threshold"], prof["config"]["risk_index"]))
    lines.append("")
    lines.append("artifact digests")
    lines.append("----------------")
    for name in sorted(manifest["artifacts"]):
        lines.append("%s sha256=%s" % (name, manifest["artifacts"][name]["sha256"]))
    lines.append("")
    lines.append("status: converged")
    return "\n".join(lines) + "\n"


def render_input_census(state):
    lines = []
    klass = state["class"]
    precedence = state["precedence"]
    entries = [
        ("defaults.json", "base_config.max_records", state["base"]["max_records"]),
        ("defaults.json", "base_config.retry_limit", state["base"]["retry_limit"]),
        ("defaults.json", "base_config.timeout_ms", state["base"]["timeout_ms"]),
        ("defaults.json", "base_config.trailer", state["base"]["trailer"]),
        ("defaults.json", "layer_defaults.session_ttl_seconds", precedence["session_ttl_seconds"]["default"]),
        ("defaults.json", "layer_defaults.nonce_window_ms", precedence["nonce_window_ms"]["default"]),
        ("defaults.json", "layer_defaults.max_concurrent_sessions", precedence["max_concurrent_sessions"]["default"]),
        ("class_index.tsv2", "active_class", klass),
        ("ingress_rate.tsv", "ingress_qps", state["rate"]["qps"]),
        ("burst_multiplier.ini", "burst_multiplier_permille", state["rate"]["burst_permille"]),
        ("window_seconds.conf", "window_seconds", state["rate"]["window_seconds"]),
        ("rate_gran.caret", "rate_step", state["rate"]["rate_step"]),
        ("scope_base.jsonl", "base_scopes", " ".join(state["scopes"]["base"])),
        ("scope_overlay.ndjson", "overlay_scopes", " ".join(state["scopes"]["overlay"])),
        ("scope_deny.psv", "deny_scopes", " ".join(state["scopes"]["deny"])),
        ("uid_map.env", "scope_uids", " ".join("%s=%d" % (s, state["scopes"]["uids"][s]) for s in state["scopes"]["effective"])),
        ("uid_floor.hex", "uid_floor", state["scopes"]["uid_floor"]),
        ("privilege_bits.b64", "privilege_min_uid_mirror", state["scopes"]["privilege_mirror"]),
        ("baseline_controls.scsv", "adopted_controls", len([r for r in state["hardening"]["trace"] if r["running"] is not None])),
        ("hardening_bounds.toml", "floor", state["hardening"]["floor"]),
        ("hardening_bounds.toml", "ceil", state["hardening"]["ceil"]),
        ("severity_weight.kv", "severity_permille", state["risk"]["severity_permille"]),
        ("risk_const.env2", "baseline_complement", state["risk"]["baseline_complement"]),
        ("risk_const.env2", "risk_divisor", state["risk"]["risk_divisor"]),
        ("quorum_permille.tilde", "quorum_permille", state["quorum"]["quorum_permille"]),
        ("voter_health.ndjson", "healthy_voters", state["quorum"]["healthy_voters"]),
        ("tls_matrix.csv", "tls_floor_score", state["tls_floor_score"]),
        ("seccomp_allow.tsv", "allowed_syscalls", " ".join(state["seccomp"]["allowed_syscalls"])),
        ("seccomp_deny.psv", "denied_syscalls", " ".join(state["seccomp"]["denied_syscalls"])),
        ("retention.ini", "audit_retention_days", state["audit_retention_days"]),
        ("layer_overrides.json", "class_session_ttl_seconds", precedence["session_ttl_seconds"]["override"]),
        ("layer_overrides.json", "class_nonce_window_ms", precedence["nonce_window_ms"]["override"]),
        ("layer_overrides.json", "class_max_concurrent_sessions", precedence["max_concurrent_sessions"]["override"]),
        ("pinned_overrides.json", "pinned_active", "true" if precedence["session_ttl_seconds"]["pinned_active"] else "false"),
        ("retry_backoff.psv2", "retry_step", state["backoff"]["retry_step"]),
        ("profile_deltas.json", "profiles", " ".join(sorted(state.get("profiles", {})))),
    ]
    for index, (source, field, value) in enumerate(entries, start=1):
        lines.append(json.dumps({
            "class_id": klass,
            "field": field,
            "seq": index,
            "source": source,
            "status": "ADOPTED",
            "value": value,
        }, sort_keys=True))
    return "\n".join(lines) + "\n"


# ------------------------------------------------------------------- commands

def cmd_init(args):
    schema = json.loads(Path(args.schema).read_text(encoding="utf-8"))
    data = {
        "checksum": str(schema.get("checksum", "")),
        "control_plane": str(schema.get("control_plane", "")),
        "image_runtime": str(schema.get("image_runtime", "")),
        "mode": str(schema.get("mode", "")),
        "profile": str(schema.get("profile", "")),
    }
    write_json(args.out, data)
    print("initialized")


def cmd_set(args):
    path = Path(args.config)
    data = json.loads(path.read_text(encoding="utf-8"))
    key = args.key.lower()
    value = coerce_scalar(args.value)
    if isinstance(value, (dict, list, tuple)):
        raise SystemExit("configuration is scalar-only: refusing non-scalar value for " + key)
    data[key] = value
    write_json(path, data)
    print("set")


def validation_rules():
    return json.loads((policy.DATA / "validation_rules.json").read_text(encoding="utf-8"))


def check_config(schema, data):
    raw = schema.get("required_keys", [])
    if isinstance(raw, str):
        required = [k.strip() for k in raw.split(",") if k.strip()]
    else:
        required = [str(k).strip() for k in raw if str(k).strip()]
    missing = [k for k in required if k not in data]
    if missing:
        raise SystemExit("missing: " + ",".join(missing))
    bad = flat_scalar_config(data)
    if bad:
        raise SystemExit("configuration must be flat: " + ",".join(bad))
    extra = [k for k in sorted(data) if k not in required]
    if extra:
        raise SystemExit("unexpected keys: " + ",".join(extra))
    forbidden = [k for k in validation_rules().get("forbidden_keys", []) if k in data]
    if forbidden:
        raise SystemExit("forbidden keys present: " + ",".join(sorted(forbidden)))


def cmd_validate(args):
    schema = json.loads(Path(args.schema).read_text(encoding="utf-8"))
    data = json.loads(Path(args.config).read_text(encoding="utf-8"))
    check_config(schema, data)
    print("ok")


def cmd_export_report(args):
    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    commands = []
    if args.commands:
        commands = json.loads(Path(args.commands).read_text(encoding="utf-8"))
    digest = config_digest(config)
    if args.digest and args.digest != digest:
        raise SystemExit("digest mismatch: %s != %s" % (args.digest, digest))
    report = {
        "checksum": config.get("checksum", ""),
        "commands": commands,
        "config": config,
        "digest": digest,
        "digest_algorithm": "sha256",
        "flat": True,
        "ok": True,
        "profile": config.get("enforcement_profile", ""),
        "schema_keys": sorted(config),
        "trailer": config.get(TRAILER_KEY, ""),
    }
    write_json(args.out, report)
    print("reported")


def cmd_derive(args):
    state = derive_state()
    config = state["config"]
    check_config(json.loads((policy.DATA / "config_schema.json").read_text(encoding="utf-8")), config)
    write_json(args.out, config)
    if args.facts:
        write_json(args.facts, {
            "backoff": state["backoff"],
            "class": state["class"],
            "precedence": state["precedence"],
            "quorum": state["quorum"],
            "rate": state["rate"],
            "risk": state["risk"],
            "scopes": state["scopes"],
            "selector": state["selector"],
            "selector_span": state["selector_span"],
        })
    print("derived")


def cmd_profile(args):
    if args.name not in profile_deltas():
        raise SystemExit("unknown profile: " + args.name)
    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    state = derive_state()
    if config != state["config"]:
        raise SystemExit("configuration does not match a fresh derivation")
    prof = derive_profiles(state)[args.name]
    write_json(args.out, prof["config"])
    if args.facts:
        write_json(args.facts, prof)
    print("profiled")


# ------------------------------------------------------------- artifact build

SIDECAR_RENDERERS = {
    "admission_matrix.csv": lambda state, profiles: render_admission_matrix(state),
    "class_ordering.tsv": render_class_ordering,
    "hardening_fold_trace.psv": lambda state, profiles: render_hardening_fold_trace(state),
    "precedence_resolution.properties": lambda state, profiles: render_precedence_resolution(state),
    "privilege_map.ndjson": lambda state, profiles: render_privilege_map(state),
    "quorum_plan.kv": lambda state, profiles: render_quorum_plan(state),
    "rate_limit_plan.ini": lambda state, profiles: render_rate_limit_plan(state),
    "retention_schedule.csv": lambda state, profiles: render_retention_schedule(state),
    "risk_ledger.env": lambda state, profiles: render_risk_ledger(state),
    "scope_reconciliation.tsv": lambda state, profiles: render_scope_reconciliation(state),
    "seccomp_summary.tsv": lambda state, profiles: render_seccomp_summary(state),
    "tls_floor.env": lambda state, profiles: render_tls_floor(state),
}


def build_manifest(out_dir, artifact_names, config, profiles, transcript):
    artifacts = {}
    for name in sorted(artifact_names):
        data = (out_dir / name).read_bytes()
        artifacts[name] = {"bytes": len(data), "sha256": sha256_hex(data)}
    return {
        "artifacts": artifacts,
        "artifact_count": len(artifacts),
        "commands": transcript,
        "config_digest": config_digest(config),
        "config_digest_algorithm": "sha256",
        "deterministic": True,
        "excluded_from_digests": [
            "reproducibility_manifest.json", "summary.json", "validation_report.json",
        ],
        "profiles": {
            name: {
                "digest": config_digest(profiles[name]["config"]),
                "quorum_threshold": profiles[name]["config"]["quorum_threshold"],
                "risk_index": profiles[name]["config"]["risk_index"],
                "session_ttl_seconds": profiles[name]["config"]["session_ttl_seconds"],
                "ttl_scale_permille": profiles[name]["ttl_scale_permille"],
            }
            for name in sorted(profiles)
        },
        "tool": "task-ctl",
        "tool_archive": "tool.zip",
        "tool_version": "2-repaired",
    }


TOOL_FILES = ["README.md", "cli.py", "policy.py", "schema.json", "task-ctl"]


def package_tool(out_path, tool_dir):
    """Deterministically package the repaired tool (fixed order and timestamps)."""
    import zipfile

    out_path = Path(out_path)
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for name in TOOL_FILES:
            path = Path(tool_dir) / name
            if not path.exists():
                continue
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o755 << 16 if name == "task-ctl" else 0o644 << 16
            zf.writestr(info, path.read_bytes())
    return out_path


def cmd_package(args):
    tool_dir = Path(__file__).resolve().parent
    package_tool(args.out, tool_dir)
    print("packaged")


def cmd_build(args):
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    transcript = []

    def record(argv):
        transcript.append({"seq": len(transcript) + 1, "argv": " ".join(argv)})

    tool = "task-ctl"
    tool_dir = Path(__file__).resolve().parent
    config_path = out_dir / "config.json"
    report_path = out_dir / "report.json"
    schema_path = policy.DATA / "config_schema.json"

    record([tool, "build", "--out-dir", str(out_dir)])

    argv = [tool, "derive", "--out", str(config_path)]
    cmd_derive(argparse.Namespace(out=str(config_path), facts=None))
    record(argv)

    state = derive_state()
    profiles = derive_profiles(state)
    state["profiles"] = profiles

    for name in sorted(profiles):
        path = out_dir / ("profile_%s.json" % name)
        argv = [tool, "profile", "--name", name, "--config", str(config_path), "--out", str(path)]
        cmd_profile(argparse.Namespace(name=name, config=str(config_path), out=str(path), facts=None))
        record(argv)

    for path in [config_path] + [out_dir / ("profile_%s.json" % n) for n in sorted(profiles)]:
        argv = [tool, "validate", "--schema", str(schema_path), "--config", str(path)]
        cmd_validate(argparse.Namespace(schema=str(schema_path), config=str(path)))
        record(argv)

    main = state["config"]
    delta_report = {"main_digest": config_digest(main), "profiles": {}}
    for name in sorted(profiles):
        prof = profiles[name]
        delta_report["profiles"][name] = {
            "quorum_after": prof["config"]["quorum_threshold"],
            "quorum_before": main["quorum_threshold"],
            "quorum_delta": prof["quorum_delta"],
            "risk_delta": prof["risk_delta"],
            "risk_index_after": prof["config"]["risk_index"],
            "risk_index_before": main["risk_index"],
            "session_ttl_after": prof["config"]["session_ttl_seconds"],
            "session_ttl_before": main["session_ttl_seconds"],
            "session_ttl_delta": prof["config"]["session_ttl_seconds"] - main["session_ttl_seconds"],
            "ttl_scale_permille": prof["ttl_scale_permille"],
        }
    write_json(out_dir / "profile_delta_report.json", delta_report)

    for name in sorted(SIDECAR_RENDERERS):
        write_text(out_dir / name, SIDECAR_RENDERERS[name](state, profiles))

    archive_path = out_dir / "tool.zip"
    argv = [tool, "package", "--out", str(archive_path)]
    package_tool(archive_path, tool_dir)
    record(argv)

    # the export-report command is the last command of this run: the transcript
    # records it while it executes, then the report is written with that list.
    commands_path = out_dir / ".commands.json"
    digest = config_digest(main)
    argv = [tool, "export-report", "--config", str(config_path), "--out",
            str(report_path), "--digest", digest, "--commands", str(commands_path)]
    record(argv)
    write_text(commands_path, dump_json(transcript))
    cmd_export_report(argparse.Namespace(
        config=str(config_path), out=str(report_path), digest=digest,
        commands=str(commands_path)))

    artifacts = sorted(SIDECAR_RENDERERS) + [
        "config.json", "profile_canary.json", "profile_enforce.json",
        "profile_delta_report.json", "report.json", "tool.zip",
    ]
    manifest = build_manifest(out_dir, artifacts, main, profiles, transcript)
    write_json(out_dir / "reproducibility_manifest.json", manifest)
    write_text(out_dir / "derivation_audit.xml",
               render_derivation_audit(state, profiles, transcript))
    write_text(out_dir / "input_census.ndjson", render_input_census(state))
    write_text(out_dir / "convergence_report.txt",
               render_convergence_report(state, profiles, manifest))

    summary_path = out_dir / "summary.json"
    validation_path = out_dir / "validation_report.json"
    # the two coverage artifacts are enumerated last and are themselves excluded
    # from the listing so that repeated runs converge byte-for-byte.
    present = sorted(
        p.name for p in out_dir.iterdir()
        if p.is_file() and not p.name.startswith(".")
        and p.name not in {summary_path.name, validation_path.name}
    )

    write_json(out_dir / "validation_report.json", {
        "artifacts": {name: manifest["artifacts"][name]["sha256"]
                      for name in sorted(manifest["artifacts"])},
        "config": main,
        "config_digest": manifest["config_digest"],
        "flat": True,
        "ok": True,
        "present_artifacts": present,
        "profiles": {name: profiles[name]["config"] for name in sorted(profiles)},
        "required_artifacts": validation_rules()["required_artifacts"],
        "rules": {
            "active_class_from_budget_selector": True,
            "adopted_rows_only": True,
            "exact_integer_arithmetic": True,
            "float_free_graded_values": True,
            "rounding": "half-even",
        },
        "validated": True,
    })

    write_json(out_dir / "summary.json", {
        "active_class": main["active_class"],
        "artifacts": present,
        "config_digest": manifest["config_digest"],
        "enforcement_profile": main["enforcement_profile"],
        "ok": True,
        "profiles": {
            name: {
                "quorum_threshold": profiles[name]["config"]["quorum_threshold"],
                "risk_index": profiles[name]["config"]["risk_index"],
                "session_ttl_seconds": profiles[name]["config"]["session_ttl_seconds"],
            }
            for name in sorted(profiles)
        },
        "risk_index": main["risk_index"],
        "trailer": main[TRAILER_KEY],
    })

    commands_path.unlink(missing_ok=True)
    print("built")


def main():
    parser = argparse.ArgumentParser(prog="task-ctl")
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("init", help="seed fixed contract strings")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set", help="set one scalar key")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate", help="validate a flat configuration")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("export-report", help="emit a truthful command transcript")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest")
    p.add_argument("--commands")
    p.set_defaults(func=cmd_export_report)

    p = sub.add_parser("derive", help="derive the hardened admission configuration")
    p.add_argument("--out", required=True)
    p.add_argument("--facts")
    p.set_defaults(func=cmd_derive)

    p = sub.add_parser("profile", help="apply per-profile deltas to a derived configuration")
    p.add_argument("--name", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--facts")
    p.set_defaults(func=cmd_profile)

    p = sub.add_parser("package", help="repackage the repaired tool deterministically")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_package)

    p = sub.add_parser("build", help="derive and emit every artifact to a directory")
    p.add_argument("--out-dir", required=True)
    p.set_defaults(func=cmd_build)

    args = parser.parse_args()
    if not getattr(args, "command", None):
        parser.print_help()
        return
    args.func(args)


if __name__ == "__main__":
    main()
