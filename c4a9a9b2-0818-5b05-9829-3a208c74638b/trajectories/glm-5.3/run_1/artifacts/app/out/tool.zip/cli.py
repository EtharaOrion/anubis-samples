#!/usr/bin/env python3
"""task-ctl: local admission-control hardening compiler (repaired).

Compiles one flat hardened admission configuration for the active enforcement
class of the admission broker from the interacting numeric policy layers under
/app/data, plus the canary/enforce deployment profiles and the derivation,
audit and coverage sidecars.

Contract highlights (see README.md):
  * every graded number is produced by exact integer arithmetic with
    round-half-even (banker's) rounding; no float ever touches a graded value;
  * the active class comes from the base budget and the ADOPTED selector bands
    of the class index, never from a "first row" of any table;
  * only rows whose status is ADOPTED and whose class matches the active class
    bind; SUPERSEDED/DRAFT/SHADOW/REVOKED rows are decoys;
  * the configuration is a flat map of integer/string scalars.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import re
import zipfile
from pathlib import Path

DATA = Path("/app/data")
ADOPTED = "ADOPTED"
DECOY_STATUSES = ("SUPERSEDED", "DRAFT", "SHADOW", "REVOKED")

# Quantization steps that are properties of the compiler itself rather than of
# any policy layer (no layer carries a hardening/TTL step).
HARDENING_QUANT_STEP = 5
TTL_QUANT_STEP = 5

PRECEDENCE_FIELDS = ("session_ttl_seconds", "nonce_window_ms", "max_concurrent_sessions")


# --------------------------------------------------------------------------
# exact integer arithmetic (round-half-even, no floats)
# --------------------------------------------------------------------------
def rhe(n, d):
    """Round-half-even (banker's) rounding of the exact fraction n/d, d > 0."""
    if d <= 0:
        raise ValueError("divisor must be positive")
    q, r = divmod(n, d)
    if 2 * r > d or (2 * r == d and q % 2 == 1):
        q += 1
    return q


def quantize(value, step):
    """Quantize to a multiple of step using round-half-even arithmetic."""
    if step <= 0:
        raise ValueError("step must be positive")
    return rhe(value, step) * step


def clamp(value, lo, hi):
    return max(lo, min(hi, value))


# --------------------------------------------------------------------------
# generic text/table helpers
# --------------------------------------------------------------------------
def read_text(name):
    return (DATA / name).read_text(encoding="utf-8", errors="replace")


def data_lines(name, comment_prefixes=("#", ";")):
    out = []
    for line in read_text(name).split("\n"):
        s = line.strip()
        if not s or s.startswith(comment_prefixes):
            continue
        out.append(s)
    return out


def delimited_rows(name, sep):
    lines = data_lines(name)
    if not lines:
        return []
    header = [c.strip() for c in lines[0].split(sep)]
    rows = []
    for line in lines[1:]:
        parts = [c.strip() for c in line.split(sep)]
        if len(parts) != len(header):
            continue
        rows.append(dict(zip(header, parts)))
    return rows


def whitespace_rows(name, has_header=True):
    """Whitespace-delimited table (any run of blanks is one separator).

    With has_header the first row names the columns; otherwise the canonical
    column order must be supplied by the caller.
    """
    lines = data_lines(name)
    body = lines[1:] if has_header else lines
    header = lines[0].split() if has_header else None
    rows = []
    for line in body:
        parts = line.split()
        if header is None:
            rows.append(parts)
        elif len(parts) == len(header):
            rows.append(dict(zip(header, parts)))
    return rows


def blank_separated_rows(name):
    """Blank-padded columns with a blank-padded header (fixed-ish mirrors)."""
    return whitespace_rows(name, has_header=True)


def sectioned_ini(name):
    """Parse '[sec]' + 'key = value' files (';'/'#' comments ignored)."""
    sections = {}
    current = None
    for line in data_lines(name):
        if line.startswith("[") and line.endswith("]"):
            current = line[1:-1].strip()
            sections.setdefault(current, {})
            continue
        if current is None or "=" not in line:
            continue
        key, _, val = line.partition("=")
        sections[current][key.strip()] = val.strip()
    return sections


def jsonl_rows(name):
    rows = []
    for line in data_lines(name):
        if line.startswith("{"):
            rows.append(json.loads(line))
    return rows


def env_pairs(name):
    pairs = {}
    for line in data_lines(name):
        key, _, val = line.partition("=")
        pairs[key.strip()] = val.strip()
    return pairs


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_text(path, text):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    if not text.endswith("\n"):
        text += "\n"
    Path(path).write_text(text, encoding="utf-8")


def write_json(path, data):
    write_text(path, json.dumps(data, sort_keys=True, indent=2))


def sha256_bytes(payload):
    return hashlib.sha256(payload).hexdigest()


def sha256_file(path):
    return sha256_bytes(Path(path).read_bytes())


# --------------------------------------------------------------------------
# layer readers: every reader binds only ADOPTED rows for the active class
# --------------------------------------------------------------------------
def base_inputs():
    base = load_json(DATA / "defaults.json")["base_config"]
    return (
        int(base["max_records"]),
        int(base["retry_limit"]),
        int(base["timeout_ms"]),
        str(base["trailer"]),
    )


def layer_defaults():
    return dict(load_json(DATA / "defaults.json")["layer_defaults"])


def select_active_class(max_records):
    """Base budget rule: reduce the base budget into the span tiled by the
    ADOPTED selector bands of the class index, then pick the band containing
    it.  The ADOPTED bands tile [0, max_hi]; no other status label binds."""
    rows = [r for r in whitespace_rows("class_index.tsv2") if r["status"] == ADOPTED]
    if not rows:
        raise SystemExit("no ADOPTED selector bands in class_index.tsv2")
    span = max(int(r["selector_hi"]) for r in rows) + 1
    budget = int(max_records) % span
    for r in rows:
        if int(r["selector_lo"]) <= budget <= int(r["selector_hi"]):
            return int(r["class_id"]), budget, span
    raise SystemExit("budget %d falls outside every ADOPTED selector band" % budget)


def class_row(rows, klass, field):
    """First ADOPTED row for the class (unique by construction of the layers)."""
    for r in rows:
        if str(r.get("class_id", r.get("class", ""))).strip() == str(klass) and r.get("status") == ADOPTED:
            return r
    raise SystemExit("no ADOPTED row for class %s" % klass)


def class_rows(rows, klass, class_key="class_id"):
    return [
        r
        for r in rows
        if str(r.get(class_key, "")).strip() == str(klass) and r.get("status") == ADOPTED
    ]


def ingress_layer(klass):
    row = class_row(delimited_rows("ingress_rate.tsv", "\t"), klass, "ingress_qps")
    return int(row["ingress_qps"])


def rate_step_layer(klass):
    row = class_row(delimited_rows("rate_gran.caret", "^"), klass, "gran")
    return int(row["gran"])


def burst_layer(klass):
    sec = sectioned_ini("burst_multiplier.ini")["class.%d" % klass]
    if sec.get("status") != ADOPTED:
        raise SystemExit("burst multiplier for class %d is not ADOPTED" % klass)
    return int(sec["burst_multiplier_permille"]), int(sec["window_seconds"])


def window_layer(klass):
    # column order is documented in the file's own header comment:
    # class_id  window_seconds  status
    for parts in whitespace_rows("window_seconds.conf", has_header=False):
        if len(parts) == 3 and parts[0] == str(klass) and parts[2] == ADOPTED:
            return int(parts[1])
    raise SystemExit("no ADOPTED window for class %s" % klass)


def scope_layers(klass):
    base = {r["scope"] for r in class_rows(jsonl_rows("scope_base.jsonl"), klass)}
    overlay = {r["scope"] for r in class_rows(jsonl_rows("scope_overlay.ndjson"), klass)}
    deny = {r["scope"] for r in class_rows(delimited_rows("scope_deny.psv", "|"), klass)}
    return base, overlay, deny


def uid_floor_layer(klass):
    row = class_row(delimited_rows("uid_floor.hex", ":"), klass, "floor_hex")
    return int(row["floor_hex"], 16)


def scope_uid_map():
    uids = {}
    for key, val in env_pairs("uid_map.env").items():
        if key.startswith("SCOPE_") and val.isdigit():
            uids[key[len("SCOPE_"):].lower()] = int(val)
    return uids


def control_layer(klass):
    rows = [
        r
        for r in delimited_rows("baseline_controls.scsv", ";")
        if str(r["class_id"]).strip() == str(klass)
    ]
    rows.sort(key=lambda r: int(r["order"]))
    return rows


def hardening_bounds_layer(klass):
    sec = sectioned_ini("hardening_bounds.toml")["class.%d" % klass]
    if sec.get("status", "").strip('"') != ADOPTED:
        raise SystemExit("hardening bounds for class %d are not ADOPTED" % klass)
    return int(sec["floor"]), int(sec["ceil"])


def severity_layer(klass):
    for line in data_lines("severity_weight.kv"):
        name, _, rest = line.partition(":")
        permille, _, status = rest.partition(":")
        if name.strip() == "class%d" % klass and status.strip() == ADOPTED:
            return int(permille)
    raise SystemExit("no ADOPTED severity weight for class %d" % klass)


def risk_constants():
    pairs = env_pairs("risk_const.env2")
    return int(pairs["BASELINE_COMPLEMENT"]), int(pairs["RISK_DIVISOR"])


def healthy_voters(klass):
    return [
        r
        for r in jsonl_rows("voter_health.ndjson")
        if str(r.get("class_id")) == str(klass)
        and r.get("status") == ADOPTED
        and r.get("healthy") is True
    ]


def quorum_permille_layer(klass):
    row = class_row(delimited_rows("quorum_permille.tilde", "~"), klass, "permille")
    return int(row["permille"])


def tls_floor_layer(klass):
    rows = delimited_rows("tls_matrix.csv", ",")
    bound = [
        int(r["score"])
        for r in rows
        if str(r["class_id"]) == str(klass)
        and r["status"] == ADOPTED
        and r["enabled"].strip().lower() == "true"
    ]
    if not bound:
        raise SystemExit("no ADOPTED enabled TLS suite for class %d" % klass)
    return bound[0]


def seccomp_allow_layer(klass):
    rows = delimited_rows("seccomp_ledger.scsv2", ";;")
    allowed = [
        r["syscall"]
        for r in rows
        if str(r["class_id"]) == str(klass)
        and r.get("action") == "allow"
        and r.get("status") == ADOPTED
    ]
    return sorted(set(allowed))


def retention_layer(klass):
    sec = sectioned_ini("retention.ini")["class.%d" % klass]
    if sec.get("status") != ADOPTED:
        raise SystemExit("audit retention for class %d is not ADOPTED" % klass)
    return int(sec["retention_days"])


def retry_step_layer(klass):
    row = class_row(delimited_rows("retry_backoff.psv2", "||"), klass, "step")
    return int(row["step"])


def resolve_precedence(klass):
    """base defaults < class override layer < pinned layer (only when pinned).

    A pinned==false entry is inert and must never reach the resolved value.
    """
    defaults = layer_defaults()
    overrides = load_json(DATA / "layer_overrides.json").get("class_%d" % klass, {})
    pinned = load_json(DATA / "pinned_overrides.json").get("class_%d" % klass, {})
    pinned_active = bool(pinned.get("pinned"))
    resolved = {}
    for field in PRECEDENCE_FIELDS:
        value = int(defaults[field])
        if field in overrides:
            value = int(overrides[field])
        source = "layer_override"
        if pinned_active and field in pinned:
            value = int(pinned[field])
            source = "pinned"
        elif field not in overrides:
            source = "default"
        resolved[field] = {"default": int(defaults[field]), "value": value, "source": source,
                           "pinned": pinned_active}
    return resolved


# --------------------------------------------------------------------------
# mirror cross-checks (independent re-statements of the same canonical values)
# --------------------------------------------------------------------------
def mirror_value(rows, klass, field, class_key="class"):
    for r in rows:
        if str(r.get(class_key, "")).strip() == str(klass) and r.get("status") == ADOPTED:
            return r[field]
    return None


def cross_checks(klass, derived):
    checks = {}

    def record(name, ok, detail):
        checks[name] = {"ok": bool(ok), "detail": detail}

    qps = mirror_value(delimited_rows("ingress_mirror.pipe", "|"), klass, "qps")
    record("ingress_mirror.pipe", qps is not None and int(qps) == derived["ingress_qps"],
           "qps=%s" % qps)

    alt = [
        r for r in jsonl_rows("ingress_alt.jsonl2")
        if str(r.get("c")) == str(klass) and r.get("s") == ADOPTED
    ]
    record("ingress_alt.jsonl2", bool(alt) and int(alt[0]["qps"]) == derived["ingress_qps"],
           "qps=%s" % (alt[0]["qps"] if alt else None))

    gran = mirror_value(blank_separated_rows("gran_mirror.fixed2"), klass, "gran")
    record("gran_mirror.fixed2", gran is not None and int(gran) == derived["rate_step"],
           "gran=%s" % gran)

    burst = mirror_value(delimited_rows("burst_mirror.hex2", "="), klass, "permille_hex")
    burst_perm = int(str(burst), 16) if burst else None
    record("burst_mirror.hex2", burst_perm == derived["burst_permille"],
           "permille=%s" % burst_perm)

    burst_props = env_pairs("burst_alt.properties")
    record("burst_alt.properties",
           burst_props.get("burst.class%d.permille" % klass) == str(derived["burst_permille"]),
           "permille=%s" % burst_props.get("burst.class%d.permille" % klass))

    win = mirror_value(delimited_rows("window_mirror.scsv3", ";;;"), klass, "window")
    record("window_mirror.scsv3", win is not None and int(win) == derived["window_seconds"],
           "window=%s" % win)

    scopes = mirror_value(blank_separated_rows("scopecount_mirror.tsv3"), klass, "scopes")
    record("scopecount_mirror.tsv3",
           scopes is not None and int(scopes) == derived["effective_scope_count"],
           "scopes=%s" % scopes)

    census = None
    for line in data_lines("scope_census.edn"):
        if ":class %d " % klass in line and ':status "ADOPTED"' in line:
            census = line
            break
    if census:
        m = {k: int(v) for k, v in re.findall(r":(\w+) (\d+)", census)}
        record("scope_census.edn",
               m.get("base") == derived["base_scope_count"]
               and m.get("overlay") == derived["overlay_scope_count"]
               and m.get("deny") == derived["deny_scope_count"], census)
    else:
        record("scope_census.edn", False, "no ADOPTED census row")

    voters = mirror_value(delimited_rows("voters_mirror.kv4", "::"), klass, "voters")
    record("voters_mirror.kv4",
           voters is not None and int(voters) == derived["healthy_voter_count"],
           "voters=%s" % voters)

    quorum = mirror_value(delimited_rows("quorum_mirror.rst2", " :: "), klass, "permille")
    record("quorum_mirror.rst2",
           quorum is not None and int(quorum) == derived["quorum_permille"],
           "permille=%s" % quorum)

    severity = mirror_value(delimited_rows("severity_mirror.caret2", "^^"), klass, "permille")
    record("severity_mirror.caret2",
           severity is not None and int(severity) == derived["severity_permille"],
           "permille=%s" % severity)

    curve = None
    for line in data_lines("risk_curve.sexp"):
        if "(class %d)" % klass in line and "(status ADOPTED)" in line:
            curve = int(re.search(r"permille (\d+)", line).group(1))
            break
    record("risk_curve.sexp", curve == derived["severity_permille"], "permille=%s" % curve)

    tls = mirror_value(delimited_rows("tls_mirror.tilde3", "~~~"), klass, "score")
    record("tls_mirror.tilde3", tls is not None and int(tls) == derived["tls_floor_score"],
           "score=%s" % tls)

    ret = mirror_value(delimited_rows("retention_mirror.psv4", "||||"), klass, "days")
    record("retention_mirror.psv4", ret is not None and int(ret) == derived["audit_retention_days"],
           "days=%s" % ret)

    ret_alt = env_pairs("retention_alt.kv2")
    record("retention_alt.kv2",
           ret_alt.get("retention.class.%d.days" % klass) == str(derived["audit_retention_days"]),
           "days=%s" % ret_alt.get("retention.class.%d.days" % klass))

    allow_alt = class_rows(delimited_rows("seccomp_allow.tsv", "\t"), klass, "class_id")
    record("seccomp_allow.tsv",
           len(allow_alt) == derived["seccomp_allowed_count"],
           "count=%d" % len(allow_alt))

    uid = None
    for line in data_lines("privilege_bits.b64"):
        try:
            decoded = base64.b64decode(line).decode("utf-8")
        except Exception:
            continue
        parts = dict(p.split("=", 1) for p in decoded.split(";") if "=" in p)
        if parts.get("class") == str(klass) and parts.get("status") == ADOPTED:
            uid = int(parts["uid"])
            break
    record("privilege_bits.b64", uid == derived["privilege_drop_uid"], "uid=%s" % uid)

    fixed = None
    for line in data_lines("bounds_alt.fixed"):
        if not line.strip() or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) >= 4 and parts[0] == str(klass) and parts[3] == ADOPTED:
            fixed = (int(parts[1]), int(parts[2]))
            break
    record("bounds_alt.fixed", fixed == (derived["hardening_floor"], derived["hardening_ceil"]),
           "bounds=%s" % (fixed,))

    alt_controls = class_rows(delimited_rows("controls_alt.psv3", "|||"), klass, "class_id")
    adopted_alt = sum(int(r["weight"]) for r in alt_controls)
    record("controls_alt.psv3",
           adopted_alt == derived["hardening_weight_sum"],
           "weight_sum=%s" % adopted_alt)

    roster = 0
    for line in data_lines("voter_roster.html2"):
        m = re.search(r'data-class="(\d+)" data-status="([A-Z]+)">(\w+)<', line)
        if m and m.group(1) == str(klass) and m.group(2) == ADOPTED and m.group(3) == "healthy":
            roster += 1
    record("voter_roster.html2", roster == derived["healthy_voter_count"], "voters=%d" % roster)

    return checks


# --------------------------------------------------------------------------
# derivation
# --------------------------------------------------------------------------
def fold_controls(rows):
    """Carry-aware fold over the ordered adopted controls.

    For each adopted control the running score gains the control weight; when
    the control's carry flag is set the fold also carries half (round-half-even)
    of the running score that preceded it, i.e. the carry bridges this control
    and the consecutive adopted control before it.  Non-adopted controls are
    skipped and contribute nothing.
    """
    running = 0
    trace = []
    for r in rows:
        adopted = r.get("status") == ADOPTED
        entry = {
            "order": int(r["order"]),
            "control_id": r["control_id"],
            "weight": int(r["weight"]),
            "carry": int(r["carry_flag"]),
            "status": r["status"],
        }
        if adopted:
            previous = running
            running += int(r["weight"])
            if int(r["carry_flag"]):
                running += rhe(previous, 2)
            entry["running"] = running
        else:
            entry["running"] = "skip"
        trace.append(entry)
    return running, trace


def derive_all():
    max_records, retry_limit, timeout_ms, trailer = base_inputs()
    klass, budget, span = select_active_class(max_records)

    # ingress rate limit: scale per-class throughput by the burst factor, then
    # quantize to the documented rate step; burst ceiling from the resolved
    # rate limit and the per-class window (never from the raw throughput).
    ingress_qps = ingress_layer(klass)
    rate_step = rate_step_layer(klass)
    burst_permille, burst_window = burst_layer(klass)
    window_seconds = window_layer(klass)
    if burst_window != window_seconds:
        raise SystemExit("window layers disagree for class %d" % klass)
    scaled = rhe(ingress_qps * burst_permille, 1000)
    rate_limit = quantize(scaled, rate_step)
    burst_ceiling = rate_limit * window_seconds

    # scope reconciliation: base union overlay minus deny, active class only.
    base_scopes, overlay_scopes, deny_scopes = scope_layers(klass)
    effective_scopes = sorted((base_scopes | overlay_scopes) - deny_scopes)
    effective_scope_count = len(effective_scopes)

    uid_floor = uid_floor_layer(klass)
    uids = scope_uid_map()
    missing = [s for s in effective_scopes if s not in uids]
    if missing:
        raise SystemExit("no granted uid for scopes: %s" % ",".join(missing))
    granted = [uids[s] for s in effective_scopes]
    privilege_drop_uid = clamp(min(granted), uid_floor, max(granted + [uid_floor]))

    # hardening baseline: carry-aware fold, clamp to per-class bounds, quantize.
    controls = control_layer(klass)
    fold_score, fold_trace = fold_controls(controls)
    hardening_floor, hardening_ceil = hardening_bounds_layer(klass)
    clamped = clamp(fold_score, hardening_floor, hardening_ceil)
    hardening_baseline = quantize(clamped, HARDENING_QUANT_STEP)

    severity_permille = severity_layer(klass)
    complement, risk_divisor = risk_constants()
    risk_index = rhe((complement - hardening_baseline) * severity_permille, risk_divisor)

    voters = healthy_voters(klass)
    healthy_voter_count = len(voters)
    quorum_permille = quorum_permille_layer(klass)
    quorum_threshold = clamp(rhe(healthy_voter_count * quorum_permille, 1000), 1, healthy_voter_count)

    tls_floor_score = tls_floor_layer(klass)
    seccomp_allowed = seccomp_allow_layer(klass)
    seccomp_allowed_count = len(seccomp_allowed)
    audit_retention_days = retention_layer(klass)

    precedence = resolve_precedence(klass)

    retry_step = retry_step_layer(klass)
    retry_backoff_base_ms = quantize(rhe(timeout_ms * (retry_limit + 1), 8), retry_step)

    weight_sum = sum(int(r["weight"]) for r in controls if r.get("status") == ADOPTED)

    derived = {
        "active_class": klass,
        "budget": budget,
        "budget_span": span,
        "max_records": max_records,
        "retry_limit": retry_limit,
        "timeout_ms": timeout_ms,
        "trailer": trailer,
        "ingress_qps": ingress_qps,
        "burst_permille": burst_permille,
        "scaled_qps": scaled,
        "rate_step": rate_step,
        "window_seconds": window_seconds,
        "ingress_rate_limit_qps": rate_limit,
        "burst_ceiling": burst_ceiling,
        "base_scopes": sorted(base_scopes),
        "overlay_scopes": sorted(overlay_scopes),
        "deny_scopes": sorted(deny_scopes),
        "effective_scopes": effective_scopes,
        "effective_scope_count": effective_scope_count,
        "base_scope_count": len(base_scopes),
        "overlay_scope_count": len(overlay_scopes),
        "deny_scope_count": len(deny_scopes),
        "uid_floor": uid_floor,
        "granted_uids": granted,
        "privilege_drop_uid": privilege_drop_uid,
        "fold_score": fold_score,
        "fold_trace": fold_trace,
        "hardening_floor": hardening_floor,
        "hardening_ceil": hardening_ceil,
        "hardening_clamped": clamped,
        "hardening_quant_step": HARDENING_QUANT_STEP,
        "hardening_baseline": hardening_baseline,
        "hardening_weight_sum": weight_sum,
        "severity_permille": severity_permille,
        "baseline_complement": complement,
        "risk_divisor": risk_divisor,
        "risk_index": risk_index,
        "healthy_voter_count": healthy_voter_count,
        "quorum_permille": quorum_permille,
        "quorum_threshold": quorum_threshold,
        "tls_floor_score": tls_floor_score,
        "seccomp_allowed": seccomp_allowed,
        "seccomp_allowed_count": seccomp_allowed_count,
        "audit_retention_days": audit_retention_days,
        "precedence": precedence,
        "retry_step": retry_step,
        "retry_backoff_base_ms": retry_backoff_base_ms,
    }
    derived["cross_checks"] = cross_checks(klass, derived)
    return derived


def contract_strings(schema):
    return {
        "profile": str(schema["profile"]),
        "checksum": str(schema["checksum"]),
        "mode": str(schema["mode"]),
        "control_plane": str(schema["control_plane"]),
        "image_runtime": str(schema["image_runtime"]),
    }


def build_config(derived, schema):
    config = contract_strings(schema)
    config.update(
        {
            "active_class": derived["active_class"],
            "audit_retention_days": derived["audit_retention_days"],
            "burst_ceiling": derived["burst_ceiling"],
            "effective_scope_count": derived["effective_scope_count"],
            "enforcement_profile": "main",
            "hardening_baseline": derived["hardening_baseline"],
            "ingress_rate_limit_qps": derived["ingress_rate_limit_qps"],
            "max_concurrent_sessions": derived["precedence"]["max_concurrent_sessions"]["value"],
            "nonce_window_ms": derived["precedence"]["nonce_window_ms"]["value"],
            "privilege_drop_uid": derived["privilege_drop_uid"],
            "quorum_threshold": derived["quorum_threshold"],
            "retry_backoff_base_ms": derived["retry_backoff_base_ms"],
            "risk_index": derived["risk_index"],
            "seccomp_allowed_count": derived["seccomp_allowed_count"],
            "session_ttl_seconds": derived["precedence"]["session_ttl_seconds"]["value"],
            "tls_floor_score": derived["tls_floor_score"],
            "trailer": derived["trailer"],
        }
    )
    return {k: config[k] for k in sorted(config)}


def apply_profile(config, name, deltas, voter_count):
    profile = dict(config)
    delta = deltas[name]
    ttl = quantize(rhe(int(config["session_ttl_seconds"]) * int(delta["ttl_scale_permille"]), 1000),
                   TTL_QUANT_STEP)
    quorum = clamp(int(config["quorum_threshold"]) + int(delta["quorum_delta"]), 1, voter_count)
    risk = int(config["risk_index"]) + int(delta["risk_delta"])
    profile["session_ttl_seconds"] = ttl
    profile["quorum_threshold"] = quorum
    profile["risk_index"] = risk
    profile["enforcement_profile"] = name
    profile["profile"] = name
    return {k: profile[k] for k in sorted(profile)}


# --------------------------------------------------------------------------
# artifact emitters
# --------------------------------------------------------------------------
def emit_rate_limit_plan(path, derived):
    lines = ["[rate]",
             "class = %d" % derived["active_class"],
             "ingress_rate_limit_qps = %d" % derived["ingress_rate_limit_qps"],
             "burst_ceiling = %d" % derived["burst_ceiling"]]
    write_text(path, "\n".join(lines))


def emit_scope_reconciliation(path, derived):
    union = sorted(set(derived["base_scopes"]) | set(derived["overlay_scopes"]) | set(derived["deny_scopes"]))
    rows = ["scope\tin_base\tin_overlay\tdenied\teffective"]
    for scope in union:
        rows.append("%s\t%d\t%d\t%d\t%d" % (
            scope,
            1 if scope in derived["base_scopes"] else 0,
            1 if scope in derived["overlay_scopes"] else 0,
            1 if scope in derived["deny_scopes"] else 0,
            1 if scope in derived["effective_scopes"] else 0,
        ))
    write_text(path, "\n".join(rows))


def emit_hardening_fold_trace(path, derived):
    rows = ["order|control_id|weight|carry|status|running"]
    for entry in derived["fold_trace"]:
        rows.append("%d|%s|%d|%d|%s|%s" % (
            entry["order"], entry["control_id"], entry["weight"], entry["carry"],
            entry["status"], entry["running"]))
    write_text(path, "\n".join(rows))


def emit_quorum_plan(path, derived):
    write_text(path, "healthy_voters:%d\nquorum_threshold:%d" % (
        derived["healthy_voter_count"], derived["quorum_threshold"]))


def emit_risk_ledger(path, derived):
    write_text(path, "HARDENING_BASELINE=%d\nRISK_INDEX=%d\nSEVERITY_PERMILLE=%d" % (
        derived["hardening_baseline"], derived["risk_index"], derived["severity_permille"]))


def emit_precedence_resolution(path, derived):
    lines = []
    for field in PRECEDENCE_FIELDS:
        info = derived["precedence"][field]
        lines.append("%s.default=%d" % (field, info["default"]))
        lines.append("%s.resolved=%d" % (field, info["value"]))
    write_text(path, "\n".join(lines))


def emit_privilege_map(path, derived):
    uids = scope_uid_map()
    lines = []
    for scope in derived["effective_scopes"]:
        lines.append(json.dumps({"scope": scope, "uid": uids[scope]}, sort_keys=True))
    write_text(path, "\n".join(lines))


def emit_seccomp_summary(path, derived):
    write_text(path, "class\tseccomp_allowed_count\n%d\t%d" % (
        derived["active_class"], derived["seccomp_allowed_count"]))


def emit_tls_floor(path, derived):
    write_text(path, "TLS_FLOOR_SCORE=%d" % derived["tls_floor_score"])


def emit_retention_schedule(path, derived):
    write_text(path, "class,audit_retention_days\n%d,%d" % (
        derived["active_class"], derived["audit_retention_days"]))


def emit_admission_matrix(path, config):
    rows = ["field,class_id,value"]
    for key in sorted(config):
        value = config[key]
        if isinstance(value, int):
            rows.append("%s,%d,%d" % (key, config["active_class"], value))
    write_text(path, "\n".join(rows))


def emit_derivation_audit(path, derived, config):
    d = derived
    lines = ['<?xml version="1.0" encoding="UTF-8"?>',
             '<derivation_audit tool="task-ctl" profile="%s" control_plane="%s" trailer="%s">' % (
                 config["profile"], config["control_plane"], config["trailer"])]
    lines.append('  <active_class id="%d" budget="%d" budget_span="%d" max_records="%d"/>' % (
        d["active_class"], d["budget"], d["budget_span"], d["max_records"]))
    lines.append('  <ingress qps="%d" burst_permille="%d" scaled_qps="%d" rate_step="%d" '
                 'rate_limit_qps="%d" window_seconds="%d" burst_ceiling="%d"/>' % (
                     d["ingress_qps"], d["burst_permille"], d["scaled_qps"], d["rate_step"],
                     d["ingress_rate_limit_qps"], d["window_seconds"], d["burst_ceiling"]))
    lines.append('  <scopes base="%d" overlay="%d" deny="%d" effective="%d" uid_floor="%d" '
                 'privilege_drop_uid="%d">' % (
                     d["base_scope_count"], d["overlay_scope_count"], d["deny_scope_count"],
                     d["effective_scope_count"], d["uid_floor"], d["privilege_drop_uid"]))
    for scope in d["effective_scopes"]:
        lines.append('    <scope name="%s"/>' % scope)
    lines.append('  </scopes>')
    lines.append('  <hardening fold_score="%d" floor="%d" ceil="%d" clamped="%d" quant_step="%d" '
                 'baseline="%d" weight_sum="%d"/>' % (
                     d["fold_score"], d["hardening_floor"], d["hardening_ceil"], d["hardening_clamped"],
                     d["hardening_quant_step"], d["hardening_baseline"], d["hardening_weight_sum"]))
    lines.append('  <risk baseline="%d" complement="%d" severity_permille="%d" divisor="%d" '
                 'risk_index="%d"/>' % (
                     d["hardening_baseline"], d["baseline_complement"], d["severity_permille"],
                     d["risk_divisor"], d["risk_index"]))
    lines.append('  <quorum healthy_voters="%d" permille="%d" threshold="%d"/>' % (
        d["healthy_voter_count"], d["quorum_permille"], d["quorum_threshold"]))
    lines.append('  <tls_floor score="%d"/>' % d["tls_floor_score"])
    lines.append('  <seccomp allowed_count="%d"/>' % d["seccomp_allowed_count"])
    lines.append('  <retention days="%d"/>' % d["audit_retention_days"])
    for field in PRECEDENCE_FIELDS:
        info = d["precedence"][field]
        lines.append('  <precedence field="%s" default="%d" resolved="%d" source="%s" pinned="%s"/>' % (
            field, info["default"], info["value"], info["source"], str(info["pinned"]).lower()))
    lines.append('  <retry timeout_ms="%d" retry_limit="%d" step="%d" backoff_base_ms="%d"/>' % (
        d["timeout_ms"], d["retry_limit"], d["retry_step"], d["retry_backoff_base_ms"]))
    lines.append('  <cross_checks total="%d" agreed="%d">' % (
        len(d["cross_checks"]), sum(1 for c in d["cross_checks"].values() if c["ok"])))
    for name in sorted(d["cross_checks"]):
        check = d["cross_checks"][name]
        detail = str(check["detail"]).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")
        lines.append('    <mirror name="%s" ok="%s" detail="%s"/>' % (
            name, str(check["ok"]).lower(), detail))
    lines.append('  </cross_checks>')
    lines.append('</derivation_audit>')
    write_text(path, "\n".join(lines))


def emit_convergence_report(path, derived, config):
    d = derived
    agreed = sum(1 for c in d["cross_checks"].values() if c["ok"])
    lines = [
        "task-ctl convergence report",
        "profile=%s control_plane=%s mode=%s" % (config["profile"], config["control_plane"], config["mode"]),
        "trailer=%s" % config["trailer"],
        "active_class=%d (budget=%d %% span=%d)" % (d["active_class"], d["budget"], d["budget_span"]),
        "",
        "ingress: qps=%d burst_permille=%d scaled=%d step=%d -> rate_limit=%d ; window=%d -> burst_ceiling=%d" % (
            d["ingress_qps"], d["burst_permille"], d["scaled_qps"], d["rate_step"],
            d["ingress_rate_limit_qps"], d["window_seconds"], d["burst_ceiling"]),
        "scopes: base=%s overlay=%s deny=%s -> effective=%s (count=%d)" % (
            ",".join(d["base_scopes"]), ",".join(d["overlay_scopes"]), ",".join(d["deny_scopes"]),
            ",".join(d["effective_scopes"]), d["effective_scope_count"]),
        "privilege: uid_floor=%d granted=%s -> privilege_drop_uid=%d" % (
            d["uid_floor"], ",".join(str(u) for u in sorted(d["granted_uids"])), d["privilege_drop_uid"]),
        "hardening: fold_score=%d bounds=[%d,%d] clamped=%d step=%d -> baseline=%d" % (
            d["fold_score"], d["hardening_floor"], d["hardening_ceil"], d["hardening_clamped"],
            d["hardening_quant_step"], d["hardening_baseline"]),
        "risk: (%d - %d) * %d / %d -> risk_index=%d" % (
            d["baseline_complement"], d["hardening_baseline"], d["severity_permille"],
            d["risk_divisor"], d["risk_index"]),
        "quorum: voters=%d permille=%d -> threshold=%d" % (
            d["healthy_voter_count"], d["quorum_permille"], d["quorum_threshold"]),
        "tls_floor_score=%d seccomp_allowed_count=%d audit_retention_days=%d" % (
            d["tls_floor_score"], d["seccomp_allowed_count"], d["audit_retention_days"]),
        "retry: timeout_ms=%d retry_limit=%d step=%d -> retry_backoff_base_ms=%d" % (
            d["timeout_ms"], d["retry_limit"], d["retry_step"], d["retry_backoff_base_ms"]),
        "",
        "precedence resolution:",
    ]
    for field in PRECEDENCE_FIELDS:
        info = d["precedence"][field]
        lines.append("  %s default=%d resolved=%d source=%s pinned=%s" % (
            field, info["default"], info["value"], info["source"], str(info["pinned"]).lower()))
    lines.append("")
    lines.append("mirror cross-checks: %d/%d agreed" % (agreed, len(d["cross_checks"])))
    for name in sorted(d["cross_checks"]):
        check = d["cross_checks"][name]
        lines.append("  %s %s (%s)" % ("OK" if check["ok"] else "FAIL", name, check["detail"]))
    lines.append("")
    lines.append("status: converged" if agreed == len(d["cross_checks"]) else "status: DIVERGENT")
    write_text(path, "\n".join(lines))


INPUT_FILES = [
    "baseline_controls.scsv", "bounds_alt.fixed", "burst_alt.properties", "burst_mirror.hex2",
    "burst_multiplier.ini", "class_index.tsv2", "config_schema.json", "controls_alt.psv3",
    "defaults.json", "field_registry.ndjson", "gran_mirror.fixed2", "hardening_bounds.toml",
    "ingress_alt.jsonl2", "ingress_mirror.pipe", "ingress_rate.tsv", "layer_overrides.json",
    "nonce_bounds.toml2", "pinned_overrides.json", "privilege_bits.b64", "profile_deltas.json",
    "profile_map.kv3", "quorum_mirror.rst2", "quorum_permille.tilde", "rate_gran.caret",
    "retention.ini", "retention_alt.kv2", "retention_mirror.psv4", "retry_backoff.psv2",
    "risk_const.env2", "risk_curve.sexp", "scope_base.jsonl", "scope_census.edn",
    "scope_deny.psv", "scope_overlay.ndjson", "scopecount_mirror.tsv3", "seccomp_allow.tsv",
    "seccomp_deny.psv", "seccomp_ledger.scsv2", "sessions_cap.csv2", "severity_mirror.caret2",
    "severity_weight.kv", "tls_matrix.csv", "tls_mirror.tilde3", "tls_suites.rst",
    "trailer_registry.txt3", "uid_floor.hex", "uid_map.env", "validation_rules.json",
    "voter_health.ndjson", "voter_roster.html2", "voters_mirror.kv4", "window_mirror.scsv3",
    "window_seconds.conf",
]


def emit_input_census(path):
    lines = []
    for name in sorted(INPUT_FILES):
        payload = (DATA / name).read_bytes()
        lines.append(json.dumps({
            "file": name,
            "bytes": len(payload),
            "lines": len((DATA / name).read_text(encoding="utf-8", errors="replace").splitlines()),
            "sha256": sha256_bytes(payload),
        }, sort_keys=True))
    write_text(path, "\n".join(lines))


def emit_class_ordering(path, config, profiles):
    rows = [("main", int(config["risk_index"]))]
    for name in ("canary", "enforce"):
        rows.append((name, int(profiles[name]["risk_index"])))
    rows.sort(key=lambda r: (r[1], r[0]))
    out = ["profile\trisk_index"] + ["%s\t%d" % r for r in rows]
    write_text(path, "\n".join(out))


def emit_profile_delta_report(path, config, profiles):
    report = {}
    for name in sorted(profiles):
        deltas = {}
        for key in sorted(config):
            if key in ("profile", "enforcement_profile"):
                continue
            before, after = config[key], profiles[name][key]
            if isinstance(before, int) and isinstance(after, int) and before != after:
                deltas[key] = after - before
        report[name] = deltas
    write_json(path, report)


def emit_reproducibility_manifest(path, outdir, config, derived):
    entries = {}
    for artifact in sorted(p.name for p in Path(outdir).iterdir() if p.is_file()):
        if artifact == Path(path).name:
            # a manifest cannot attest its own bytes
            continue
        entries[artifact] = sha256_file(Path(outdir) / artifact)
    manifest = {
        "tool": "task-ctl",
        "profile": config["profile"],
        "trailer": config["trailer"],
        "active_class": derived["active_class"],
        "arithmetic": "integer round-half-even",
        "config_digest": sha256_file(Path(outdir) / "config.json"),
        "artifacts": entries,
    }
    write_json(path, manifest)


def emit_validation_report(path, outdir, config, schema, derived):
    rules = load_json(DATA / "validation_rules.json")
    required = rules["required_artifacts"]
    self_name = Path(path).name
    present = sorted(p.name for p in Path(outdir).iterdir() if p.is_file())
    # summary.json/validation_report.json are emitted by this same finalize
    # step, so they are anticipated rather than absent.
    anticipated = {self_name, "summary.json"}
    missing = [a for a in required if a not in present and a not in anticipated]
    forbidden = [k for k in rules["forbidden_keys"] if k in config]
    schema_keys = required_schema_keys(schema)
    missing_keys = [k for k in schema_keys if k not in config]
    non_scalar = [k for k, v in config.items() if isinstance(v, (dict, list, tuple))]
    largest = max((p.stat().st_size for p in Path(outdir).iterdir() if p.is_file()), default=0)
    agreed = sum(1 for c in derived["cross_checks"].values() if c["ok"])
    report = {
        "ok": not missing and not forbidden and not missing_keys and not non_scalar
        and agreed == len(derived["cross_checks"]) and largest <= rules["max_artifact_bytes"],
        "schema_keys_present": sorted(schema_keys),
        "missing_keys": sorted(missing_keys),
        "missing_artifacts": sorted(missing),
        "anticipated_artifacts": sorted(a for a in required if a in anticipated),
        "forbidden_keys": sorted(forbidden),
        "non_scalar_keys": sorted(non_scalar),
        "flat": not non_scalar,
        "profiles": sorted(rules["profiles"]),
        "required_artifacts": sorted(required),
        "present_artifacts": present,
        "max_artifact_bytes": rules["max_artifact_bytes"],
        "largest_artifact_bytes": largest,
        "mirror_cross_checks_agreed": agreed,
        "mirror_cross_checks_total": len(derived["cross_checks"]),
        "trailer": config["trailer"],
    }
    write_json(path, report)


def emit_summary(path, config, profiles, derived):
    summary = {
        "active_class": derived["active_class"],
        "config": config,
        "profiles": {name: profiles[name] for name in sorted(profiles)},
        "derived": {
            "budget": derived["budget"],
            "effective_scopes": derived["effective_scopes"],
            "fold_score": derived["fold_score"],
            "granted_uids": sorted(derived["granted_uids"]),
            "healthy_voter_count": derived["healthy_voter_count"],
            "seccomp_allowed": derived["seccomp_allowed"],
            "uid_floor": derived["uid_floor"],
        },
        "trailer": config["trailer"],
    }
    write_json(path, summary)


# --------------------------------------------------------------------------
# commands
# --------------------------------------------------------------------------
def required_schema_keys(schema):
    keys = schema.get("required_keys")
    if isinstance(keys, str):
        return [k.strip() for k in keys.split(",") if k.strip()]
    return list(keys or [])


def cmd_derive(args):
    schema = load_json(args.schema)
    derived = derive_all()
    config = load_json(args.config) if Path(args.config).exists() else {}
    config.update(build_config(derived, schema))
    config = {k: config[k] for k in sorted(config)}
    write_json(args.out, config)

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    emit_rate_limit_plan(outdir / "rate_limit_plan.ini", derived)
    emit_scope_reconciliation(outdir / "scope_reconciliation.tsv", derived)
    emit_hardening_fold_trace(outdir / "hardening_fold_trace.psv", derived)
    emit_quorum_plan(outdir / "quorum_plan.kv", derived)
    emit_risk_ledger(outdir / "risk_ledger.env", derived)
    emit_precedence_resolution(outdir / "precedence_resolution.properties", derived)
    emit_privilege_map(outdir / "privilege_map.ndjson", derived)
    emit_seccomp_summary(outdir / "seccomp_summary.tsv", derived)
    emit_tls_floor(outdir / "tls_floor.env", derived)
    emit_retention_schedule(outdir / "retention_schedule.csv", derived)
    emit_admission_matrix(outdir / "admission_matrix.csv", config)
    emit_derivation_audit(outdir / "derivation_audit.xml", derived, config)
    emit_convergence_report(outdir / "convergence_report.txt", derived, config)
    emit_input_census(outdir / "input_census.ndjson")
    write_json(Path(args.trace), {
        "active_class": derived["active_class"],
        "config": config,
        "derived": {k: v for k, v in derived.items() if k not in ("fold_trace", "cross_checks")},
        "cross_checks": derived["cross_checks"],
        "fold_trace": derived["fold_trace"],
    })
    print("derived class=%d baseline=%d risk=%d rate=%d burst=%d scopes=%d uid=%d quorum=%d" % (
        derived["active_class"], derived["hardening_baseline"], derived["risk_index"],
        derived["ingress_rate_limit_qps"], derived["burst_ceiling"], derived["effective_scope_count"],
        derived["privilege_drop_uid"], derived["quorum_threshold"]))


def cmd_profile(args):
    if args.name not in load_json(DATA / "validation_rules.json")["profiles"]:
        raise SystemExit("unknown profile: %s" % args.name)
    config = load_json(args.config)
    trace = load_json(args.trace)
    voter_count = trace["derived"]["healthy_voter_count"]
    deltas = load_json(DATA / "profile_deltas.json")
    profile = apply_profile(config, args.name, deltas, voter_count)
    write_json(args.out, profile)
    print("profiled %s ttl=%d quorum=%d risk=%d" % (
        args.name, profile["session_ttl_seconds"], profile["quorum_threshold"], profile["risk_index"]))


def cmd_finalize(args):
    config = load_json(args.config)
    trace = load_json(args.trace)
    derived = trace["derived"]
    derived["cross_checks"] = trace["cross_checks"]
    outdir = Path(args.outdir)
    profiles = {
        name: load_json(outdir / ("profile_%s.json" % name))
        for name in load_json(DATA / "validation_rules.json")["profiles"]
    }
    emit_profile_delta_report(outdir / "profile_delta_report.json", config, profiles)
    emit_class_ordering(outdir / "class_ordering.tsv", config, profiles)
    emit_reproducibility_manifest(outdir / "reproducibility_manifest.json", outdir, config, derived)
    emit_validation_report(outdir / "validation_report.json", outdir, config, load_json(args.schema), derived)
    emit_summary(outdir / "summary.json", config, profiles, derived)
    print("finalized")


def cmd_init(args):
    schema = load_json(args.schema)
    _, _, _, trailer = base_inputs()
    data = contract_strings(schema)
    data["trailer"] = trailer
    write_json(args.out, {k: data[k] for k in sorted(data)})
    print("initialized")


def cmd_set(args):
    data = load_json(args.config)
    key = args.key.strip().lower()
    value = args.value
    if value.lstrip("-").isdigit():
        value = int(value)
    if isinstance(value, (dict, list, tuple)):
        raise SystemExit("configuration must be flat: %s" % key)
    data[key] = value
    write_json(args.config, {k: data[k] for k in sorted(data)})
    print("set %s=%s" % (key, value))


def cmd_validate(args):
    schema = load_json(args.schema)
    data = load_json(args.config)
    required = required_schema_keys(schema)
    missing = [k for k in required if k not in data]
    if missing:
        raise SystemExit("missing: " + ",".join(missing))
    bad = [k for k, v in data.items() if isinstance(v, (dict, list, tuple))]
    if bad:
        raise SystemExit("configuration must be flat: " + ",".join(sorted(bad)))
    extra = [k for k in sorted(data) if k not in required]
    if extra:
        raise SystemExit("unexpected keys: " + ",".join(extra))
    if str(data["trailer"]) != base_inputs()[3]:
        raise SystemExit("trailer mismatch")
    print("ok")


def cmd_report(args):
    data = load_json(args.config)
    commands = load_json(args.commands) if args.commands else []
    digest = args.digest if args.digest else sha256_file(args.config)
    report = {
        "ok": True,
        "tool": "task-ctl",
        "profile": data["profile"],
        "control_plane": data["control_plane"],
        "mode": data["mode"],
        "digest": digest,
        "commands": commands,
        "config": {k: data[k] for k in sorted(data)},
        "trailer": data["trailer"],
    }
    write_json(args.out, report)
    print("reported")


def cmd_package(args):
    src = Path(args.src)
    files = sorted(p.name for p in src.iterdir() if p.is_file() and not p.name.startswith("."))
    with zipfile.ZipFile(args.out, "w", zipfile.ZIP_DEFLATED) as zf:
        for name in files:
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            zf.writestr(info, (src / name).read_bytes())
    print("packaged %d files" % len(files))


def main():
    parser = argparse.ArgumentParser(prog="task-ctl")
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("derive")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--outdir", required=True)
    p.add_argument("--trace", required=True)
    p.set_defaults(func=cmd_derive)

    p = sub.add_parser("profile")
    p.add_argument("--name", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--trace", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_profile)

    p = sub.add_parser("finalize")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--outdir", required=True)
    p.add_argument("--trace", required=True)
    p.set_defaults(func=cmd_finalize)

    p = sub.add_parser("init")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("export-report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest", default=None)
    p.add_argument("--commands", default=None)
    p.set_defaults(func=cmd_report)

    p = sub.add_parser("package")
    p.add_argument("--src", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_package)

    args = parser.parse_args()
    if not getattr(args, "command", None):
        parser.print_help()
        return
    args.func(args)


if __name__ == "__main__":
    main()
