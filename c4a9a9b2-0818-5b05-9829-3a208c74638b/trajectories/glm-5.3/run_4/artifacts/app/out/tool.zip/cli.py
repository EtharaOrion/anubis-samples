#!/usr/bin/env python3
"""task-ctl: local admission-control hardening compiler (REPAIRED).

Compiles one flat hardened admission configuration for the active enforcement
class from the interacting numeric policy layers under /app/data, plus the
canary/enforce deployment profiles and every derivation/audit sidecar.

All arithmetic reaching a graded value is exact integer arithmetic using
round-half-even (banker's) rounding; no floating point is used anywhere.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import zipfile
from pathlib import Path

DATA = Path("/app/data")
ADOPTED = "ADOPTED"

PRECEDENCE_FIELDS = ("session_ttl_seconds", "nonce_window_ms", "max_concurrent_sessions")
HARDENING_QUANT = 5


# ---------------------------------------------------------------- primitives

def round_half_even(num, den):
    """Exact integer round-half-even of num/den (den > 0)."""
    num, den = int(num), int(den)
    if den <= 0:
        raise ValueError("denominator must be positive")
    sign = -1 if num < 0 else 1
    n = -num if num < 0 else num
    q, r = divmod(n, den)
    twice = 2 * r
    if twice > den or (twice == den and q % 2 == 1):
        q += 1
    return sign * q


def quantize(value, step):
    """Quantize value to the nearest multiple of step (round-half-even)."""
    return round_half_even(value, step) * step


def div_permille(value, permille):
    return round_half_even(int(value) * int(permille), 1000)


def clamp(value, lo, hi):
    return max(lo, min(hi, value))


# -------------------------------------------------------------------- loading

def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def read_lines(name):
    out = []
    for line in (DATA / name).read_text(encoding="utf-8", errors="replace").split("\n"):
        s = line.strip()
        if not s or s.startswith("#") or s.startswith(";") or s.startswith(".."):
            continue
        out.append(line.rstrip("\n"))
    return out


def delimited_rows(name, sep):
    lines = read_lines(name)
    if not lines:
        return []
    header = [c.strip() for c in lines[0].split(sep)]
    width = len(lines[0].split(sep))
    rows = []
    for line in lines[1:]:
        parts = [c.strip() for c in line.split(sep)]
        if len(parts) != width:
            continue
        rows.append(dict(zip(header, parts)))
    return rows


def ini_sections(name):
    sections = {}
    cur = None
    for line in read_lines(name):
        s = line.strip()
        if s.startswith("[") and s.endswith("]"):
            cur = s[1:-1]
            sections.setdefault(cur, {})
            continue
        if "=" in s and cur is not None:
            key, _, val = s.partition("=")
            sections[cur][key.strip()] = val.strip()
    return sections


def properties_pairs(name):
    out = []
    for line in read_lines(name):
        s = line.strip()
        if "=" in s:
            key, _, val = s.partition("=")
            out.append((key.strip(), val.strip()))
    return out


def ndjson_rows(name):
    return [json.loads(s) for s in read_lines(name) if s.strip()]


# ------------------------------------------------------------------ selectors

def base_inputs():
    base = load_json(DATA / "defaults.json")
    cfg = base["base_config"]
    return (
        int(cfg["max_records"]),
        int(cfg["retry_limit"]),
        int(cfg["timeout_ms"]),
        str(cfg["trailer"]),
        base["layer_defaults"],
    )


def budget_index(max_records, retry_limit):
    return (max_records // 37) + 3 * retry_limit


def adopted_selector_rows():
    rows = []
    for line in read_lines("class_index.tsv2"):
        parts = [c.strip() for c in line.split("\t") if c.strip()]
        if len(parts) == 4 and parts[3] == ADOPTED:
            rows.append((int(parts[0]), int(parts[1]), int(parts[2])))
    return rows


def select_active_class(max_records, retry_limit):
    """Active class = the ADOPTED selector range containing the base budget
    index; never simply the first table row."""
    idx = budget_index(max_records, retry_limit)
    for klass, lo, hi in adopted_selector_rows():
        if lo <= idx <= hi:
            return klass, idx, (lo, hi)
    raise SystemExit("budget index %d outside adopted selector ranges" % idx)


# --------------------------------------------------------------- layer readers

def ingress_qps(klass):
    hits = [int(r["ingress_qps"]) for r in delimited_rows("ingress_rate.tsv", "\t")
            if r.get("class_id") == str(klass) and r.get("status") == ADOPTED]
    if not hits:
        raise SystemExit("no adopted ingress row for class %d" % klass)
    return hits[0]


def burst_layer(klass):
    sec = ini_sections("burst_multiplier.ini").get("class.%d" % klass, {})
    if sec.get("status") != ADOPTED:
        raise SystemExit("no adopted burst block for class %d" % klass)
    return int(sec["burst_multiplier_permille"]), int(sec["window_seconds"])


def window_seconds(klass):
    for line in read_lines("window_seconds.conf"):
        p = line.split()
        if len(p) == 3 and p[0] == str(klass) and p[2] == ADOPTED:
            return int(p[1])
    raise SystemExit("no adopted window row for class %d" % klass)


def rate_step(klass):
    hits = [int(r["gran"]) for r in delimited_rows("rate_gran.caret", "^")
            if r.get("class_id") == str(klass) and r.get("status") == ADOPTED]
    if not hits:
        raise SystemExit("no adopted rate step for class %d" % klass)
    return hits[0]


def scope_layers(klass):
    base = {r["scope"] for r in ndjson_rows("scope_base.jsonl")
            if str(r.get("class_id")) == str(klass) and r.get("status") == ADOPTED}
    overlay = {r["scope"] for r in ndjson_rows("scope_overlay.ndjson")
               if str(r.get("class_id")) == str(klass) and r.get("status") == ADOPTED}
    deny = {r["scope"] for r in delimited_rows("scope_deny.psv", "|")
            if r.get("class_id") == str(klass) and r.get("status") == ADOPTED}
    return base, overlay, deny


def scope_uids():
    uids = {}
    for key, val in properties_pairs("uid_map.env"):
        if key.startswith("SCOPE_") and val.isdigit():
            uids[key[len("SCOPE_"):].lower()] = int(val)
    return uids


def uid_floor(klass):
    for line in read_lines("uid_floor.hex"):
        p = [c.strip() for c in line.split(":") if c.strip()]
        if len(p) == 3 and p[0] == str(klass) and p[2] == ADOPTED:
            return int(p[1], 16)
    raise SystemExit("no adopted uid floor for class %d" % klass)


def control_rows(klass):
    rows = [r for r in delimited_rows("baseline_controls.scsv", ";")
            if str(r.get("class_id")).strip() == str(klass)]
    rows.sort(key=lambda r: int(r["order"]))
    return rows


def hardening_bounds(klass):
    sec = ini_sections("hardening_bounds.toml").get("class.%d" % klass, {})
    if sec.get("status", "").strip('"') != ADOPTED:
        raise SystemExit("no adopted hardening bounds for class %d" % klass)
    return int(sec["floor"]), int(sec["ceil"])


def severity_permille(klass):
    for line in read_lines("severity_weight.kv"):
        parts = [c.strip() for c in line.split(":")]
        if len(parts) == 3 and parts[0] == "class%d" % klass and parts[2] == ADOPTED:
            return int(parts[1])
    raise SystemExit("no adopted severity weight for class %d" % klass)


def risk_constants():
    vals = dict(properties_pairs("risk_const.env2"))
    return int(vals["BASELINE_COMPLEMENT"]), int(vals["RISK_DIVISOR"])


def healthy_voters(klass):
    return sum(1 for r in ndjson_rows("voter_health.ndjson")
               if str(r.get("class_id")) == str(klass)
               and r.get("status") == ADOPTED and bool(r.get("healthy")))


def quorum_permille(klass):
    for line in read_lines("quorum_permille.tilde"):
        p = [c.strip() for c in re.split("[~‾]", line) if c.strip()]
        if len(p) == 3 and p[0] == str(klass) and p[2] == ADOPTED:
            return int(p[1])
    raise SystemExit("no adopted quorum permille for class %d" % klass)


def tls_floor(klass):
    scores = [int(r["score"]) for r in delimited_rows("tls_matrix.csv", ",")
              if r.get("class_id") == str(klass) and r.get("status") == ADOPTED
              and str(r.get("enabled")).strip().lower() == "true"]
    if not scores:
        raise SystemExit("no adopted enabled TLS suite for class %d" % klass)
    return max(scores)


def seccomp_allowed(klass):
    allowed = set()
    for r in delimited_rows("seccomp_ledger.scsv2", ";"):
        if r.get("class_id") != str(klass) or r.get("status") != ADOPTED:
            continue
        if r.get("action") == "allow":
            allowed.add(r["syscall"])
        elif r.get("action") == "deny":
            allowed.discard(r["syscall"])
    for r in delimited_rows("seccomp_deny.psv", "|"):
        if r.get("class_id") == str(klass) and r.get("status") == ADOPTED:
            allowed.discard(r["syscall"])
    return allowed


def retention_days(klass):
    sec = ini_sections("retention.ini").get("class.%d" % klass, {})
    if sec.get("status") != ADOPTED:
        raise SystemExit("no adopted retention block for class %d" % klass)
    return int(sec["retention_days"])


def retry_step(klass):
    hits = [int(r["step"]) for r in delimited_rows("retry_backoff.psv2", "||")
            if r.get("class_id") == str(klass) and r.get("status") == ADOPTED]
    if not hits:
        raise SystemExit("no adopted retry step for class %d" % klass)
    return hits[0]


def nonce_floor_ms(klass):
    sec = ini_sections("nonce_bounds.toml2").get("class.%d" % klass, {})
    return int(sec.get("floor_ms", 0))


def sessions_ceiling(klass):
    hits = [int(r["abs_ceil"]) for r in delimited_rows("sessions_cap.csv2", ",")
            if r.get("class_id") == str(klass) and r.get("status") == ADOPTED]
    if not hits:
        raise SystemExit("no adopted sessions ceiling for class %d" % klass)
    return hits[0]


def resolve_precedence(klass, layer_defaults):
    """defaults < class overlay < pinned (only when pinned == true)."""
    overlays = load_json(DATA / "layer_overrides.json")
    pinned = load_json(DATA / "pinned_overrides.json")
    overlay = overlays.get("class_%d" % klass, {})
    pin = pinned.get("class_%d" % klass, {})
    pin_active = bool(pin.get("pinned"))
    resolved = {}
    trace = {}
    for field in PRECEDENCE_FIELDS:
        default = int(layer_defaults[field])
        value = default
        source = "default"
        if field in overlay:
            value = int(overlay[field])
            source = "overlay"
        if pin_active and field in pin:
            value = int(pin[field])
            source = "pinned"
        resolved[field] = value
        trace[field] = {"default": default, "resolved": value, "source": source,
                        "pinned": pin_active}
    return resolved, trace


# ------------------------------------------------------------------- deriving

def derive_state():
    max_records, retry_limit, timeout_ms, trailer, layer_defaults = base_inputs()
    klass, index, selector = select_active_class(max_records, retry_limit)

    qps = ingress_qps(klass)
    permille, _window = burst_layer(klass)
    step = rate_step(klass)
    rate_limit = quantize(div_permille(qps, permille), step)
    window = window_seconds(klass)
    burst_ceiling = rate_limit * window

    base_scopes, overlay_scopes, deny_scopes = scope_layers(klass)
    effective = sorted((base_scopes | overlay_scopes) - deny_scopes)
    uids = scope_uids()
    floor = uid_floor(klass)
    granted = [(s, uids[s]) for s in effective if s in uids]
    if not granted:
        raise SystemExit("no granted uid for class %d scopes" % klass)
    privilege_drop_uid = max(floor, min(u for _, u in granted))

    fold_rows = []
    running = 0
    prev_weight = None
    for r in control_rows(klass):
        weight = int(r["weight"])
        carry = int(r["carry_flag"])
        if r.get("status") != ADOPTED:
            fold_rows.append({"order": int(r["order"]), "control_id": r["control_id"],
                              "weight": weight, "carry": carry, "status": r["status"],
                              "running": "skip"})
            continue
        running += weight + (prev_weight if carry and prev_weight is not None else 0)
        fold_rows.append({"order": int(r["order"]), "control_id": r["control_id"],
                          "weight": weight, "carry": carry, "status": r["status"],
                          "running": running})
        prev_weight = weight
    lo, hi = hardening_bounds(klass)
    hardening_baseline = quantize(clamp(running, lo, hi), HARDENING_QUANT)

    complement, divisor = risk_constants()
    severity = severity_permille(klass)
    risk_index = round_half_even((complement - hardening_baseline) * severity, divisor)

    voters = healthy_voters(klass)
    quorum = clamp(round_half_even(voters * quorum_permille(klass), 1000), 1, voters)

    resolved, prec_trace = resolve_precedence(klass, layer_defaults)

    return {
        "active_class": klass,
        "budget_index": index,
        "selector": selector,
        "max_records": max_records,
        "retry_limit": retry_limit,
        "timeout_ms": timeout_ms,
        "trailer": trailer,
        "qps": qps,
        "burst_permille": permille,
        "window": window,
        "rate_step": step,
        "ingress_rate_limit_qps": rate_limit,
        "burst_ceiling": burst_ceiling,
        "base_scopes": sorted(base_scopes),
        "overlay_scopes": sorted(overlay_scopes),
        "deny_scopes": sorted(deny_scopes),
        "effective_scopes": effective,
        "effective_scope_count": len(effective),
        "scope_uids": granted,
        "uid_floor": floor,
        "privilege_drop_uid": privilege_drop_uid,
        "fold_rows": fold_rows,
        "fold_raw": running,
        "bounds": (lo, hi),
        "hardening_baseline": hardening_baseline,
        "severity_permille": severity,
        "risk_index": risk_index,
        "healthy_voters": voters,
        "quorum_permille": quorum_permille(klass),
        "quorum_threshold": quorum,
        "tls_floor_score": tls_floor(klass),
        "seccomp_allowed": sorted(seccomp_allowed(klass)),
        "seccomp_allowed_count": len(seccomp_allowed(klass)),
        "audit_retention_days": retention_days(klass),
        "precedence": prec_trace,
        "session_ttl_seconds": int(resolved["session_ttl_seconds"]),
        "nonce_window_ms": clamp(int(resolved["nonce_window_ms"]), nonce_floor_ms(klass), 10 ** 9),
        "max_concurrent_sessions": min(int(resolved["max_concurrent_sessions"]),
                                       sessions_ceiling(klass)),
        "retry_backoff_base_ms": quantize(
            round_half_even(timeout_ms * (retry_limit + 1), 8), retry_step(klass)),
    }


def build_config(state, profile="main"):
    schema = load_json(DATA / "config_schema.json")
    cfg = {
        "active_class": int(state["active_class"]),
        "audit_retention_days": int(state["audit_retention_days"]),
        "burst_ceiling": int(state["burst_ceiling"]),
        "checksum": schema["checksum"],
        "control_plane": schema["control_plane"],
        "effective_scope_count": int(state["effective_scope_count"]),
        "enforcement_profile": profile,
        "hardening_baseline": int(state["hardening_baseline"]),
        "image_runtime": schema["image_runtime"],
        "ingress_rate_limit_qps": int(state["ingress_rate_limit_qps"]),
        "max_concurrent_sessions": int(state["max_concurrent_sessions"]),
        "mode": schema["mode"],
        "nonce_window_ms": int(state["nonce_window_ms"]),
        "privilege_drop_uid": int(state["privilege_drop_uid"]),
        "profile": schema["profile"] if profile == "main" else profile,
        "quorum_threshold": int(state["quorum_threshold"]),
        "retry_backoff_base_ms": int(state["retry_backoff_base_ms"]),
        "risk_index": int(state["risk_index"]),
        "seccomp_allowed_count": int(state["seccomp_allowed_count"]),
        "session_ttl_seconds": int(state["session_ttl_seconds"]),
        "tls_floor_score": int(state["tls_floor_score"]),
        "trailer": state["trailer"],
    }
    return {k: cfg[k] for k in sorted(cfg)}


def apply_profile(state, name):
    deltas = load_json(DATA / "profile_deltas.json")[name]
    prof = dict(state)
    prof["session_ttl_seconds"] = quantize(
        div_permille(state["session_ttl_seconds"], deltas["ttl_scale_permille"]),
        HARDENING_QUANT)
    prof["quorum_threshold"] = int(state["quorum_threshold"]) + int(deltas["quorum_delta"])
    prof["risk_index"] = int(state["risk_index"]) + int(deltas["risk_delta"])
    return prof


# ------------------------------------------------------------------- emitting

def write_text(path, text):
    Path(path).write_text(text, encoding="utf-8", newline="\n")


def write_json(path, data):
    write_text(path, json.dumps(data, sort_keys=True, indent=2) + "\n")


def emit_sidecars(out, state, config, profiles):
    d = Path(out)

    lines = ["[rate]",
             "class = %d" % state["active_class"],
             "ingress_rate_limit_qps = %d" % state["ingress_rate_limit_qps"],
             "burst_ceiling = %d" % state["burst_ceiling"]]
    write_text(d / "rate_limit_plan.ini", "\n".join(lines) + "\n")

    rows = ["order|control_id|weight|carry|status|running"]
    for r in sorted(state["fold_rows"], key=lambda r: r["order"]):
        rows.append("%d|%s|%d|%d|%s|%s" % (r["order"], r["control_id"], r["weight"],
                                           r["carry"], r["status"], r["running"]))
    write_text(d / "hardening_fold_trace.psv", "\n".join(rows) + "\n")

    write_text(d / "quorum_plan.kv",
               "healthy_voters:%d\nquorum_threshold:%d\n"
               % (state["healthy_voters"], state["quorum_threshold"]))

    write_text(d / "risk_ledger.env",
               "HARDENING_BASELINE=%d\nRISK_INDEX=%d\nSEVERITY_PERMILLE=%d\n"
               % (state["hardening_baseline"], state["risk_index"],
                  state["severity_permille"]))

    lines = []
    for field in PRECEDENCE_FIELDS:
        lines.append("%s.default=%d" % (field, state["precedence"][field]["default"]))
        lines.append("%s.resolved=%d" % (field, state["precedence"][field]["resolved"]))
    write_text(d / "precedence_resolution.properties", "\n".join(lines) + "\n")

    lines = [json.dumps({"scope": s, "uid": u}, sort_keys=True)
             for s, u in state["scope_uids"]]
    write_text(d / "privilege_map.ndjson", "\n".join(lines) + "\n")

    write_text(d / "seccomp_summary.tsv",
               "class\tseccomp_allowed_count\n%d\t%d\n"
               % (state["active_class"], state["seccomp_allowed_count"]))

    write_text(d / "tls_floor.env", "TLS_FLOOR_SCORE=%d\n" % state["tls_floor_score"])

    entries = [("main", config["risk_index"])]
    for name in sorted(profiles):
        entries.append((name, profiles[name]["risk_index"]))
    entries.sort(key=lambda e: (e[1], e[0]))
    rows = ["profile\trisk_index"] + ["%s\t%d" % (n, r) for n, r in entries]
    write_text(d / "class_ordering.tsv", "\n".join(rows) + "\n")

    rows = ["class,rate_limit,window_seconds,burst_ceiling,scope_count,privilege_drop_uid,tls_floor_score,retention_days",
            "%d,%d,%d,%d,%d,%d,%d,%d" % (
                state["active_class"], state["ingress_rate_limit_qps"], state["window"],
                state["burst_ceiling"], state["effective_scope_count"],
                state["privilege_drop_uid"], state["tls_floor_score"],
                state["audit_retention_days"])]
    write_text(d / "admission_matrix.csv", "\n".join(rows) + "\n")

    rows = ["class\tbase_scopes\toverlay_scopes\tdeny_scopes\teffective_scopes\teffective_scope_count\tprivilege_drop_uid",
            "%d\t%s\t%s\t%s\t%s\t%d\t%d" % (
                state["active_class"],
                ",".join(state["base_scopes"]),
                ",".join(state["overlay_scopes"]),
                ",".join(state["deny_scopes"]),
                ",".join(state["effective_scopes"]),
                state["effective_scope_count"],
                state["privilege_drop_uid"])]
    write_text(d / "scope_reconciliation.tsv", "\n".join(rows) + "\n")

    rows = ["class,retention_days",
            "%d,%d" % (state["active_class"], state["audit_retention_days"])]
    write_text(d / "retention_schedule.csv", "\n".join(rows) + "\n")


def write_manifest(out, trailer, tool="task-ctl"):
    """Digest every artifact produced by the run (this file excluded)."""
    d = Path(out)
    manifest = {
        "artifacts": [],
        "deterministic": True,
        "float_used": False,
        "rounding": "round_half_even",
        "tool": tool,
        "trailer": trailer,
    }
    for p in sorted(d.iterdir()):
        if p.is_file() and p.name != "reproducibility_manifest.json":
            manifest["artifacts"].append({
                "bytes": p.stat().st_size,
                "name": p.name,
                "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
            })
    write_json(d / "reproducibility_manifest.json", manifest)


def emit_audit(out, state, config, profiles):
    d = Path(out)

    x = ['<?xml version="1.0" encoding="UTF-8"?>', "<derivation_audit>"]
    x.append('  <class selection="selector_range" budget_index="%d" selector_lo="%d" selector_hi="%d" active_class="%d"/>'
             % (state["budget_index"], state["selector"][0], state["selector"][1],
                state["active_class"]))
    x.append('  <rate class="%d" ingress_qps="%d" burst_multiplier_permille="%d" window_seconds="%d" rate_step="%d" ingress_rate_limit_qps="%d" burst_ceiling="%d"/>'
             % (state["active_class"], state["qps"], state["burst_permille"],
                state["window"], state["rate_step"], state["ingress_rate_limit_qps"],
                state["burst_ceiling"]))
    x.append('  <scopes class="%d" base="%s" overlay="%s" deny="%s" effective="%s" effective_scope_count="%d" uid_floor="%d" privilege_drop_uid="%d"/>'
             % (state["active_class"], ",".join(state["base_scopes"]),
                ",".join(state["overlay_scopes"]), ",".join(state["deny_scopes"]),
                ",".join(state["effective_scopes"]), state["effective_scope_count"],
                state["uid_floor"], state["privilege_drop_uid"]))
    x.append('  <hardening class="%d" fold_raw="%d" floor="%d" ceil="%d" quant="%d" hardening_baseline="%d" severity_permille="%d" risk_index="%d"/>'
             % (state["active_class"], state["fold_raw"], state["bounds"][0],
                state["bounds"][1], HARDENING_QUANT, state["hardening_baseline"],
                state["severity_permille"], state["risk_index"]))
    x.append('  <quorum class="%d" healthy_voters="%d" permille="%d" quorum_threshold="%d"/>'
             % (state["active_class"], state["healthy_voters"],
                state["quorum_permille"], state["quorum_threshold"]))
    x.append('  <tls class="%d" tls_floor_score="%d"/>'
             % (state["active_class"], state["tls_floor_score"]))
    x.append('  <seccomp class="%d" seccomp_allowed_count="%d" allowed="%s"/>'
             % (state["active_class"], state["seccomp_allowed_count"],
                ",".join(state["seccomp_allowed"])))
    x.append('  <retention class="%d" audit_retention_days="%d"/>'
             % (state["active_class"], state["audit_retention_days"]))
    for field in PRECEDENCE_FIELDS:
        t = state["precedence"][field]
        x.append('  <precedence field="%s" default="%d" overlay_applied="true" pinned="%s" source="%s" resolved="%d"/>'
                 % (field, t["default"], str(t["pinned"]).lower(), t["source"],
                    t["resolved"]))
    x.append('  <retry timeout_ms="%d" retry_limit="%d" divide_by="8" quant_step="%d" retry_backoff_base_ms="%d"/>'
             % (state["timeout_ms"], state["retry_limit"], retry_step(state["active_class"]),
                state["retry_backoff_base_ms"]))
    for name in sorted(profiles):
        p = profiles[name]
        x.append('  <profile name="%s" session_ttl_seconds="%d" quorum_threshold="%d" risk_index="%d"/>'
                 % (name, p["session_ttl_seconds"], p["quorum_threshold"],
                    p["risk_index"]))
    x.append('  <trailer value="%s"/>' % config["trailer"])
    x.append("</derivation_audit>")
    write_text(d / "derivation_audit.xml", "\n".join(x) + "\n")

    c = ["convergence report",
         "active_class=%d" % state["active_class"],
         "budget_index=%d" % state["budget_index"],
         "selector_range=%d-%d" % state["selector"],
         "rounding=round_half_even",
         "float_used=false",
         "iterations=1",
         "converged=true",
         "trailer=%s" % config["trailer"]]
    for key in ("ingress_rate_limit_qps", "burst_ceiling", "effective_scope_count",
                "privilege_drop_uid", "hardening_baseline", "risk_index",
                "quorum_threshold", "tls_floor_score", "seccomp_allowed_count",
                "audit_retention_days", "session_ttl_seconds", "nonce_window_ms",
                "max_concurrent_sessions", "retry_backoff_base_ms"):
        c.append("%s=%d" % (key, state[key]))
    for name in sorted(profiles):
        p = profiles[name]
        c.append("profile.%s.session_ttl_seconds=%d" % (name, p["session_ttl_seconds"]))
        c.append("profile.%s.quorum_threshold=%d" % (name, p["quorum_threshold"]))
        c.append("profile.%s.risk_index=%d" % (name, p["risk_index"]))
    write_text(d / "convergence_report.txt", "\n".join(c) + "\n")

    census = []
    for p in sorted(DATA.iterdir()):
        if p.is_file():
            census.append({
                "bytes": p.stat().st_size,
                "name": p.name,
                "role": "input",
                "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
            })
    write_text(d / "input_census.ndjson",
               "\n".join(json.dumps(r, sort_keys=True) for r in census) + "\n")


def delta_report(config, profiles, deltas_by_name):
    out = {"profiles": {}}
    for name in sorted(profiles):
        prof = profiles[name]
        deltas = deltas_by_name[name]
        diff = {}
        for key in sorted(config):
            if key not in prof or prof[key] == config[key]:
                continue
            entry = {"base": config[key], "profile": prof[key]}
            if isinstance(config[key], int) and not isinstance(config[key], bool):
                entry["delta"] = prof[key] - config[key]
            diff[key] = entry
        out["profiles"][name] = {
            "deltas": diff,
            "quorum_delta": deltas["quorum_delta"],
            "risk_delta": deltas["risk_delta"],
            "ttl_scale_permille": deltas["ttl_scale_permille"],
        }
    return out


def cmd_derive(args):
    state = derive_state()
    config = build_config(state, "main")
    raw_deltas = {k: v for k, v in load_json(DATA / "profile_deltas.json").items()
                  if isinstance(v, dict)}
    names = tuple(sorted(raw_deltas))
    profiles = {name: build_config(apply_profile(state, name), name) for name in names}
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    write_json(out / "config.json", config)
    for name, prof in profiles.items():
        write_json(out / ("profile_%s.json" % name), prof)
    write_json(out / "profile_delta_report.json",
               delta_report(config, profiles, raw_deltas))
    emit_sidecars(out, state, config, profiles)
    emit_audit(out, state, config, profiles)
    write_manifest(out, config["trailer"])
    print("derived")


def cmd_profile(args):
    if args.name not in ("canary", "enforce"):
        raise SystemExit("unknown profile: %s" % args.name)
    state = derive_state()
    prof = build_config(apply_profile(state, args.name), args.name)
    write_json(args.out, prof)
    print("profiled")


def cmd_init(args):
    schema = load_json(args.schema)
    data = {
        "checksum": schema["checksum"],
        "control_plane": schema["control_plane"],
        "image_runtime": schema["image_runtime"],
        "mode": schema["mode"],
        "profile": schema["profile"],
    }
    write_json(args.out, {k: data[k] for k in sorted(data)})
    print("initialized")


def cmd_set(args):
    path = Path(args.config)
    data = load_json(path)
    s = str(args.value).strip()
    value = int(s) if re.fullmatch(r"-?\d+", s) else s
    if isinstance(value, (dict, list)):
        raise SystemExit("non-scalar value rejected: %s" % args.value)
    data[args.key.lower()] = value
    write_json(path, data)
    print("set")


def cmd_validate(args):
    schema = load_json(args.schema)
    data = load_json(args.config)
    if isinstance(data, dict) and set(data) == {"admission"}:
        raise SystemExit("configuration must be flat")
    required = schema["required_keys"]
    if isinstance(required, str):
        required = [k.strip() for k in required.split(",") if k.strip()]
    missing = [k for k in required if k not in data]
    if missing:
        raise SystemExit("missing: " + ",".join(missing))
    bad = [k for k, v in data.items() if isinstance(v, (dict, list))]
    if bad:
        raise SystemExit("configuration must be flat: " + ",".join(sorted(bad)))
    forbidden = load_json(DATA / "validation_rules.json")["forbidden_keys"]
    present = [k for k in forbidden if k in data]
    if present:
        raise SystemExit("forbidden keys present: " + ",".join(sorted(present)))
    print("ok")


def cmd_report(args):
    data = load_json(args.config)
    commands = load_json(args.commands) if args.commands else []
    digest = ""
    if args.digest:
        digest = Path(args.digest).read_text(encoding="utf-8").strip()
    payload = json.dumps(data, sort_keys=True)
    actual = hashlib.sha256(payload.encode("utf-8")).hexdigest()
    report = {
        "checksum": data.get("checksum"),
        "commands": commands,
        "config": data,
        "digest_matches": digest == actual,
        "ok": True,
        "sha256": actual,
        "trailer": data.get("trailer"),
    }
    write_json(args.out, report)
    print("reported")


def cmd_verify(args):
    """Validate the emitted artifact set and write the coverage artifacts."""
    out = Path(args.out)
    rules = load_json(DATA / "validation_rules.json")
    state = derive_state()
    config = build_config(state, "main")
    profiles = {name: build_config(apply_profile(state, name), name)
                for name in ("canary", "enforce")}

    # coverage artifacts exist for the run before they are audited
    write_text(out / "validation_report.json", json.dumps({
        "checks": [], "ok": True, "tool": "task-ctl",
        "trailer": state["trailer"], "validated_artifacts": len(rules["required_artifacts"]),
    }, sort_keys=True, indent=2) + "\n")
    write_json(out / "summary.json", {
        "active_class": config["active_class"],
        "artifacts": len(rules["required_artifacts"]),
        "burst_ceiling": config["burst_ceiling"],
        "effective_scope_count": config["effective_scope_count"],
        "enforcement_profile": config["enforcement_profile"],
        "hardening_baseline": config["hardening_baseline"],
        "ingress_rate_limit_qps": config["ingress_rate_limit_qps"],
        "profiles": {},
        "quorum_threshold": config["quorum_threshold"],
        "risk_index": config["risk_index"],
        "rounding": "round_half_even",
        "tool": "task-ctl",
        "trailer": config["trailer"],
        "validation_ok": True,
    })

    checks = []

    def check(name, ok, detail):
        checks.append({"check": name, "ok": bool(ok), "detail": detail})

    required = rules["required_artifacts"]
    for name in required:
        check("artifact_present:" + name, (out / name).is_file(),
              str((out / name).stat().st_size) if (out / name).is_file() else "missing")

    emitted = sorted(p.name for p in out.iterdir() if p.is_file())
    check("emitted_set", set(emitted) == set(required), ",".join(emitted))

    for label, doc in [("config", config)] + [(n, profiles[n]) for n in sorted(profiles)]:
        path = out / ("config.json" if label == "config" else "profile_%s.json" % label)
        disk = load_json(path)
        check("rederive:" + label, disk == doc, "matches" if disk == doc else "mismatch")
        flat = all(not isinstance(v, (dict, list)) for v in disk.values())
        check("flat:" + label, flat, "scalar_only")
        check("trailer:" + label, disk.get("trailer") == state["trailer"], state["trailer"])
        missing = [k for k in load_json(DATA / "config_schema.json")["required_keys"]
                   if k not in disk]
        check("required_keys:" + label, not missing, ",".join(missing) or "complete")
        forbidden = [k for k in rules["forbidden_keys"] if k in disk]
        check("forbidden_keys:" + label, not forbidden, ",".join(forbidden) or "none")

    for name in required:
        p = out / name
        if p.is_file():
            check("size:" + name, p.stat().st_size <= rules["max_artifact_bytes"],
                  str(p.stat().st_size))

    sidecar_pairs = [
        ("rate_limit_plan.ini", state["ingress_rate_limit_qps"]),
        ("risk_ledger.env", state["risk_index"]),
        ("quorum_plan.kv", state["quorum_threshold"]),
        ("tls_floor.env", state["tls_floor_score"]),
    ]
    for name, value in sidecar_pairs:
        text = (out / name).read_text(encoding="utf-8")
        check("sidecar_value:" + name, str(value) in text, str(value))

    ordering = (out / "class_ordering.tsv").read_text(encoding="utf-8").strip().split("\n")[1:]
    risks = [int(line.split("\t")[1]) for line in ordering]
    check("class_ordering_ascending", risks == sorted(risks), str(risks))
    check("class_ordering_rows", len(ordering) == 3, str(len(ordering)))

    priv_lines = [l for l in (out / "privilege_map.ndjson").read_text(
        encoding="utf-8").strip().split("\n") if l]
    check("privilege_map_lines", len(priv_lines) == state["effective_scope_count"],
          str(len(priv_lines)))

    report = {
        "checks": checks,
        "ok": all(c["ok"] for c in checks),
        "tool": "task-ctl",
        "trailer": state["trailer"],
        "validated_artifacts": len(required),
    }
    write_json(out / "validation_report.json", report)

    summary = {
        "active_class": config["active_class"],
        "artifacts": len(required),
        "burst_ceiling": config["burst_ceiling"],
        "effective_scope_count": config["effective_scope_count"],
        "enforcement_profile": config["enforcement_profile"],
        "hardening_baseline": config["hardening_baseline"],
        "ingress_rate_limit_qps": config["ingress_rate_limit_qps"],
        "profiles": {name: {"quorum_threshold": profiles[name]["quorum_threshold"],
                            "risk_index": profiles[name]["risk_index"],
                            "session_ttl_seconds": profiles[name]["session_ttl_seconds"]}
                     for name in sorted(profiles)},
        "quorum_threshold": config["quorum_threshold"],
        "risk_index": config["risk_index"],
        "rounding": "round_half_even",
        "tool": "task-ctl",
        "trailer": config["trailer"],
        "validation_ok": report["ok"],
    }
    write_json(out / "summary.json", summary)
    write_manifest(out, config["trailer"])
    print("verified" if report["ok"] else "verification failed")
    if not report["ok"]:
        raise SystemExit(1)


ZIP_EPOCH = (1980, 1, 1, 0, 0, 0)


def cmd_package(args):
    """Repackage the repaired tool deterministically."""
    src = Path(args.src)
    target = Path(args.out)
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(src.rglob("*")):
            if not path.is_file():
                continue
            rel = path.relative_to(src).as_posix()
            info = zipfile.ZipInfo(rel, date_time=ZIP_EPOCH)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            info.create_system = 3
            zf.writestr(info, path.read_bytes())
    print("packaged")


def main():
    parser = argparse.ArgumentParser(prog="task-ctl")
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("derive")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_derive)

    p = sub.add_parser("profile")
    p.add_argument("--name", required=True)
    p.add_argument("--config")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_profile)

    p = sub.add_parser("init")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("export-report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest")
    p.add_argument("--commands")
    p.set_defaults(func=cmd_report)

    p = sub.add_parser("verify")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_verify)

    p = sub.add_parser("package")
    p.add_argument("--src", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_package)

    args = parser.parse_args()
    if not getattr(args, "command", None):
        return
    args.func(args)


if __name__ == "__main__":
    main()
