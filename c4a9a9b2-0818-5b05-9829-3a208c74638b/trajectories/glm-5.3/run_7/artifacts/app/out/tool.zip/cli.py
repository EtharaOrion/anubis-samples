#!/usr/bin/env python3
"""task-ctl: local admission-control hardening compiler.

Compiles a flat hardened admission configuration for the active enforcement
class from the interacting numeric policy layers under /app/data, plus the
canary/enforce deployment profiles and the derivation sidecars.

All graded arithmetic is exact integer arithmetic with round-half-even
(banker's) rounding; no floating-point value ever reaches a graded key.
"""
from __future__ import annotations

import argparse
import configparser
import hashlib
import io
import json
import re
import shutil
import zipfile
from pathlib import Path

DATA = Path("/app/data")
ADOPTED = "ADOPTED"
DECOY_STATUS = ("SUPERSEDED", "DRAFT", "SHADOW", "REVOKED")


# ---------------------------------------------------------------- primitives


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, data):
    Path(path).write_text(json.dumps(data, sort_keys=True) + "\n", encoding="utf-8")


def write_text(path, text):
    Path(path).write_text(text, encoding="utf-8")


def read_lines(name):
    out = []
    for line in (DATA / name).read_text(encoding="utf-8", errors="replace").split("\n"):
        s = line.strip()
        if not s or s.startswith("#") or s.startswith(";"):
            continue
        out.append(line)
    return out


def delimited_rows(name, sep):
    lines = read_lines(name)
    if not lines:
        return []
    header = [c.strip() for c in lines[0].split(sep)]
    rows = []
    for line in lines[1:]:
        parts = [c.strip() for c in line.split(sep)]
        if len(parts) != len(header):
            continue
        rows.append(dict(zip(header, parts)))
    return rows


def round_half_even(num, den):
    """Exact integer round-half-even of num/den. No floats involved."""
    if den == 0:
        raise ValueError("division by zero")
    if den < 0:
        num, den = -num, -den
    q, r = divmod(num, den)
    twice = 2 * r
    if twice > den or (twice == den and q % 2 != 0):
        q += 1
    return q


def quantize_floor(value, step):
    if step <= 0:
        raise ValueError("step must be positive")
    return (value // step) * step


def clamp(value, lo, hi):
    return min(max(value, lo), hi)


def sha256_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


# ------------------------------------------------------------------- loaders


def base_inputs():
    base = load_json(DATA / "defaults.json")["base_config"]
    return int(base["max_records"]), int(base["retry_limit"]), int(base["timeout_ms"]), str(base["trailer"])


def adopted(rows, klass):
    """Rows that bind: matching class and ADOPTED status (others are decoys)."""
    return [r for r in rows
            if str(r.get("class_id", "")).strip() == str(klass)
            and str(r.get("status", "")).strip() == ADOPTED]


def ini_sections(name):
    cp = configparser.ConfigParser(interpolation=None, strict=False)
    cp.optionxform = str
    with io.StringIO("\n".join(read_lines(name))) as fh:
        cp.read_file(fh)
    return {s: dict(cp[s]) for s in cp.sections()}


def toml_sections(name):
    sections = {}
    cur = None
    for line in read_lines(name):
        s = line.strip()
        m = re.match(r"^\[([^\]]+)\]$", s)
        if m:
            cur = m.group(1)
            sections[cur] = {}
            continue
        if cur is None or "=" not in s:
            continue
        k, _, v = s.partition("=")
        sections[cur][k.strip()] = v.strip().strip('"').strip()
    return sections


def active_class(max_records):
    """Active class from the class_index budget selector, ADOPTED rows only.

    The adopted selector bands tile a contiguous budget axis [lo, hi]; a base
    budget outside that axis folds back onto it by the axis width before the
    band lookup. Non-ADOPTED selector rows are decoys and never bind.
    """
    bands = [(int(r["selector_lo"]), int(r["selector_hi"]), int(r["class_id"]))
             for r in delimited_rows("class_index.tsv2", "\t")
             if str(r.get("status")).strip() == ADOPTED]
    if not bands:
        raise SystemExit("no adopted selector rows in class_index")
    width = max(b[1] for b in bands) - min(b[0] for b in bands) + 1
    budget = max_records % width
    for lo, hi, klass in bands:
        if lo <= budget <= hi:
            return klass
    raise SystemExit("no adopted selector row covers the base budget")


def ingress_layers(klass):
    qps = None
    for r in adopted(delimited_rows("ingress_rate.tsv", "\t"), klass):
        qps = int(r["ingress_qps"])
    burst = ini_sections("burst_multiplier.ini")["class.%d" % klass]
    if str(burst.get("status")).strip() != ADOPTED:
        raise SystemExit("burst layer not adopted for class %s" % klass)
    permille = int(burst["burst_multiplier_permille"])
    window = int(burst["window_seconds"])
    for line in read_lines("window_seconds.conf"):
        p = line.split()
        if len(p) >= 3 and p[0] == str(klass) and p[2].strip() == ADOPTED:
            window = int(p[1])
    gran = None
    for r in adopted(delimited_rows("rate_gran.caret", "^"), klass):
        gran = int(r["gran"])
    return qps, permille, window, gran


def scope_layers(klass):
    base, overlay, deny = set(), set(), set()
    for fn in ("scope_base.jsonl", "scope_overlay.ndjson"):
        for line in read_lines(fn):
            obj = json.loads(line)
            if str(obj.get("class_id")) != str(klass) or obj.get("status") != ADOPTED:
                continue
            if obj.get("layer") == "base":
                base.add(str(obj["scope"]))
            elif obj.get("layer") == "overlay":
                overlay.add(str(obj["scope"]))
    for r in adopted(delimited_rows("scope_deny.psv", "|"), klass):
        deny.add(str(r["scope"]))
    return base, overlay, deny


def scope_uid_map():
    uids = {}
    for line in read_lines("uid_map.env"):
        key, _, val = line.strip().partition("=")
        v = val.strip()
        if key.startswith("SCOPE_") and v.isdigit():
            uids[key[len("SCOPE_"):].lower()] = int(v)
    return uids


def uid_floor(klass):
    floor = None
    for r in adopted(delimited_rows("uid_floor.hex", ":"), klass):
        floor = int(r["floor_hex"], 16)
    return floor


def control_rows(klass):
    rows = [r for r in delimited_rows("baseline_controls.scsv", ";")
            if str(r.get("class_id")).strip() == str(klass)]
    rows.sort(key=lambda r: int(r["order"]))
    return rows


def hardening_bounds(klass):
    sec = toml_sections("hardening_bounds.toml")["class.%d" % klass]
    if str(sec.get("status")).strip() != ADOPTED:
        raise SystemExit("hardening bounds not adopted for class %s" % klass)
    return int(sec["floor"]), int(sec["ceil"])


def severity_permille(klass):
    val = None
    for line in read_lines("severity_weight.kv"):
        parts = [p.strip() for p in line.strip().split(":")]
        if len(parts) < 3:
            continue
        m = re.match(r"^class_?(\d+)$", parts[0])
        if m and m.group(1) == str(klass) and parts[2] == ADOPTED:
            val = int(parts[1])
    return val


def risk_constants():
    vals = {}
    for line in read_lines("risk_const.env2"):
        k, _, v = line.strip().partition("=")
        vals[k.strip()] = v.strip()
    return int(vals["BASELINE_COMPLEMENT"]), int(vals["RISK_DIVISOR"])


def healthy_voters(klass):
    count = 0
    for line in read_lines("voter_health.ndjson"):
        obj = json.loads(line)
        if str(obj.get("class_id")) == str(klass) and obj.get("status") == ADOPTED and obj.get("healthy") is True:
            count += 1
    return count


def quorum_permille(klass):
    val = None
    for r in adopted(delimited_rows("quorum_permille.tilde", "~"), klass):
        val = int(r["permille"])
    return val


def tls_floor_score(klass):
    rows = [r for r in adopted(delimited_rows("tls_matrix.csv", ","), klass)
            if str(r.get("enabled", "")).strip().lower() == "true"]
    if not rows:
        raise SystemExit("no adopted enabled tls suite for class %s" % klass)
    return int(rows[0]["score"])


def seccomp_allowed_count(klass):
    return len(adopted(delimited_rows("seccomp_allow.tsv", "\t"), klass))


def audit_retention_days(klass):
    sec = ini_sections("retention.ini")["class.%d" % klass]
    if str(sec.get("status")).strip() != ADOPTED:
        raise SystemExit("retention layer not adopted for class %s" % klass)
    return int(sec["retention_days"])


def precedence_fields(klass):
    """defaults -> class override -> pinned layer (only when pinned==true)."""
    defaults = load_json(DATA / "defaults.json")["layer_defaults"]
    overrides = load_json(DATA / "layer_overrides.json")
    pinned = load_json(DATA / "pinned_overrides.json")
    fields = {}
    for f in ("session_ttl_seconds", "nonce_window_ms", "max_concurrent_sessions"):
        value = int(defaults[f])
        ov = overrides.get("class_%d" % klass)
        if ov is not None and f in ov:
            value = int(ov[f])
        pin = pinned.get("class_%d" % klass)
        if pin is not None and pin.get("pinned") is True and f in pin:
            value = int(pin[f])
        fields[f] = value
    return fields


def retry_step(klass):
    val = None
    for r in adopted(delimited_rows("retry_backoff.psv2", "||"), klass):
        val = int(r["step"])
    return val


# ------------------------------------------------------------------ pipeline


class Derivation:
    """Deterministic derivation of every graded scalar for the active class."""

    def __init__(self):
        self.trace = {}
        max_records, retry_limit, timeout_ms, trailer = base_inputs()
        self.max_records = max_records
        self.retry_limit = retry_limit
        self.timeout_ms = timeout_ms
        self.trailer = trailer
        klass = active_class(max_records)
        self.klass = klass

        # ingress: throughput scaled by the burst factor, quantized to the rate
        # step; the burst ceiling follows the resolved limit and class window.
        qps, permille, window, gran = ingress_layers(klass)
        rate_pre = round_half_even(qps * permille, 1000)
        rate_limit = quantize_floor(rate_pre, gran)
        burst_ceiling = round_half_even(rate_limit * window, 1)
        self.trace["rate"] = {
            "ingress_qps": qps, "burst_permille": permille, "window_seconds": window,
            "rate_step": gran, "scaled": rate_pre, "rate_limit": rate_limit,
            "burst_ceiling": burst_ceiling,
        }

        # scopes: base union overlay, reduced by deny, for the active class only.
        base, overlay, deny = scope_layers(klass)
        effective = sorted((base | overlay) - deny)
        uids = scope_uid_map()
        floor = uid_floor(klass)
        granted = [uids[s] for s in effective if s in uids]
        privilege_drop_uid = max(min(granted), floor) if granted else floor
        self.trace["scope"] = {
            "base": sorted(base), "overlay": sorted(overlay), "deny": sorted(deny),
            "effective": effective, "uid_floor": floor,
            "granted_uids": sorted(granted), "privilege_drop_uid": privilege_drop_uid,
        }

        # hardening fold: carry rule applies between consecutive adopted controls.
        running = 0
        prev_weight = 0
        prev_carry = 0
        fold_rows = []
        for r in control_rows(klass):
            entry = {
                "order": int(r["order"]), "control_id": r["control_id"],
                "weight": int(r["weight"]), "carry": int(r["carry_flag"]),
                "status": str(r["status"]),
            }
            if entry["status"] == ADOPTED:
                running += entry["weight"] + (prev_weight if prev_carry else 0)
                entry["running"] = running
                prev_weight = entry["weight"]
                prev_carry = entry["carry"]
            else:
                entry["running"] = "skip"
            fold_rows.append(entry)
        lo, hi = hardening_bounds(klass)
        hardening_baseline = quantize_floor(clamp(running, lo, hi), 5)

        complement, divisor = risk_constants()
        severity = severity_permille(klass)
        risk_index = round_half_even((complement - hardening_baseline) * severity, divisor)
        self.trace["hardening"] = {
            "controls": fold_rows, "fold_score": running, "bounds": [lo, hi],
            "quantize_step": 5, "hardening_baseline": hardening_baseline,
            "baseline_complement": complement, "risk_divisor": divisor,
            "severity_permille": severity, "risk_index": risk_index,
        }

        # quorum from healthy authoritative voters, bounded by [1, voters].
        voters = healthy_voters(klass)
        qp = quorum_permille(klass)
        raw = round_half_even(voters * qp, 1000)
        quorum = clamp(raw, 1, voters)
        self.trace["quorum"] = {
            "healthy_voters": voters, "permille": qp, "raw": raw,
            "quorum_threshold": quorum,
        }

        self.tls_floor_score = tls_floor_score(klass)
        self.seccomp_allowed_count = seccomp_allowed_count(klass)
        self.audit_retention_days = audit_retention_days(klass)

        fields = precedence_fields(klass)
        self.session_ttl_seconds = fields["session_ttl_seconds"]
        self.nonce_window_ms = fields["nonce_window_ms"]
        self.max_concurrent_sessions = fields["max_concurrent_sessions"]

        step = retry_step(klass)
        backoff = quantize_floor(round_half_even(timeout_ms * (retry_limit + 1), 8), step)
        self.retry_backoff_base_ms = backoff
        self.trace["retry"] = {
            "timeout_ms": timeout_ms, "retry_limit": retry_limit, "divisor": 8,
            "step": step, "retry_backoff_base_ms": backoff,
        }

        self.rate_limit = rate_limit
        self.burst_ceiling = burst_ceiling
        self.effective_scopes = effective
        self.effective_scope_count = len(effective)
        self.privilege_drop_uid = privilege_drop_uid
        self.hardening_baseline = hardening_baseline
        self.risk_index = risk_index
        self.severity_permille = severity
        self.quorum_threshold = quorum
        self.healthy_voters = voters

    def base_config(self, schema):
        return {
            "active_class": self.klass,
            "audit_retention_days": self.audit_retention_days,
            "burst_ceiling": self.burst_ceiling,
            "checksum": schema["checksum"],
            "control_plane": schema["control_plane"],
            "effective_scope_count": self.effective_scope_count,
            "enforcement_profile": "main",
            "hardening_baseline": self.hardening_baseline,
            "image_runtime": schema["image_runtime"],
            "ingress_rate_limit_qps": self.rate_limit,
            "max_concurrent_sessions": self.max_concurrent_sessions,
            "mode": schema["mode"],
            "nonce_window_ms": self.nonce_window_ms,
            "privilege_drop_uid": self.privilege_drop_uid,
            "profile": schema["profile"],
            "quorum_threshold": self.quorum_threshold,
            "retry_backoff_base_ms": self.retry_backoff_base_ms,
            "risk_index": self.risk_index,
            "seccomp_allowed_count": self.seccomp_allowed_count,
            "session_ttl_seconds": self.session_ttl_seconds,
            "tls_floor_score": self.tls_floor_score,
            "trailer": self.trailer,
        }

    def profile_config(self, schema, base_cfg, name):
        deltas = load_json(DATA / "profile_deltas.json")[name]
        cfg = dict(base_cfg)
        ttl = round_half_even(self.session_ttl_seconds * int(deltas["ttl_scale_permille"]), 1000)
        cfg["session_ttl_seconds"] = quantize_floor(ttl, 5)
        cfg["quorum_threshold"] = clamp(self.quorum_threshold + int(deltas["quorum_delta"]),
                                        1, self.healthy_voters)
        cfg["risk_index"] = self.risk_index + int(deltas["risk_delta"])
        cfg["profile"] = name
        cfg["enforcement_profile"] = name
        return cfg


# --------------------------------------------------------------- sidecars


def render_sidecars(d, config):
    out = {}

    out["admission_matrix.csv"] = "\n".join(
        ["class,key,value"] +
        ["%d,%s,%d" % (d.klass, k, config[k]) for k in sorted(config)
         if isinstance(config[k], int) and not isinstance(config[k], bool)]
    ) + "\n"

    rate = d.trace["rate"]
    out["rate_limit_plan.ini"] = (
        "[rate]\n"
        "class = %d\n"
        "ingress_rate_limit_qps = %d\n"
        "burst_ceiling = %d\n" % (d.klass, rate["rate_limit"], rate["burst_ceiling"])
    )

    sc = d.trace["scope"]
    lines = ["class\tlayer\tscope\tstatus"]
    for layer in ("base", "overlay", "deny"):
        for s in sc[layer]:
            lines.append("%d\t%s\t%s\t%s" % (d.klass, layer, s, ADOPTED))
    for s in sc["effective"]:
        lines.append("%d\teffective\t%s\t%s" % (d.klass, s, ADOPTED))
    lines.append("%d\teffective_scope_count\t%d\t%s" % (d.klass, d.effective_scope_count, ADOPTED))
    out["scope_reconciliation.tsv"] = "\n".join(lines) + "\n"

    lines = ["order|control_id|weight|carry|status|running"]
    for r in d.trace["hardening"]["controls"]:
        run = r["running"] if r["running"] == "skip" else str(r["running"])
        lines.append("%d|%s|%d|%d|%s|%s" % (
            r["order"], r["control_id"], r["weight"], r["carry"], r["status"], run))
    out["hardening_fold_trace.psv"] = "\n".join(lines) + "\n"

    q = d.trace["quorum"]
    out["quorum_plan.kv"] = "healthy_voters:%d\nquorum_threshold:%d\n" % (
        q["healthy_voters"], q["quorum_threshold"])

    out["risk_ledger.env"] = "HARDENING_BASELINE=%d\nRISK_INDEX=%d\nSEVERITY_PERMILLE=%d\n" % (
        d.hardening_baseline, d.risk_index, d.severity_permille)

    defaults = load_json(DATA / "defaults.json")["layer_defaults"]
    lines = []
    for f in ("session_ttl_seconds", "nonce_window_ms", "max_concurrent_sessions"):
        lines.append("%s.default=%d" % (f, int(defaults[f])))
        lines.append("%s.resolved=%d" % (f, config[f]))
    out["precedence_resolution.properties"] = "\n".join(lines) + "\n"

    uids = scope_uid_map()
    lines = [json.dumps({"scope": s, "uid": uids.get(s)}, sort_keys=True)
             for s in d.effective_scopes]
    out["privilege_map.ndjson"] = "\n".join(lines) + "\n"

    out["seccomp_summary.tsv"] = "class\tseccomp_allowed_count\n%d\t%d\n" % (
        d.klass, d.seccomp_allowed_count)
    out["tls_floor.env"] = "TLS_FLOOR_SCORE=%d\n" % d.tls_floor_score
    out["retention_schedule.csv"] = "class,audit_retention_days\n%d,%d\n" % (
        d.klass, d.audit_retention_days)
    return out


# ------------------------------------------------------------------ commands


def cmd_derive(args):
    d = Derivation()
    config = d.base_config(load_json(args.schema))
    write_json(args.out, config)
    print("derived")


def cmd_profile(args):
    config = load_json(args.config)
    d = Derivation()
    cfg = d.profile_config(load_json(args.schema), config, args.name)
    write_json(args.out, cfg)
    print("profiled")


def cmd_init(args):
    schema = load_json(args.schema)
    data = {k: schema[k] for k in
            ("profile", "checksum", "mode", "control_plane", "image_runtime") if k in schema}
    write_json(args.out, data)
    print("initialized")


def cmd_set(args):
    data = load_json(args.config)
    key = args.key.lower()
    if key not in data:
        raise SystemExit("unknown key: " + key)
    if isinstance(data[key], int) and not isinstance(data[key], bool):
        if not re.fullmatch(r"-?\d+", args.value.strip()):
            raise SystemExit("value must be an integer for key " + key)
        value = int(args.value.strip())
    else:
        value = args.value
    if isinstance(value, (dict, list)):
        raise SystemExit("non-scalar value rejected for key " + key)
    data[key] = value
    write_json(args.config, data)
    print("set")


def required_keys(schema):
    required = schema.get("required_keys")
    if isinstance(required, str):
        required = [k.strip() for k in required.split(",") if k.strip()]
    return list(required or [])


def cmd_validate(args):
    schema = load_json(args.schema)
    data = load_json(args.config)
    required = required_keys(schema)
    missing = [k for k in required if k not in data]
    if missing:
        raise SystemExit("missing: " + ",".join(missing))
    bad = [k for k, v in data.items() if isinstance(v, (dict, list))]
    if bad:
        raise SystemExit("configuration must be flat: " + ",".join(sorted(bad)))
    extra = [k for k in sorted(data) if k not in required]
    if extra:
        raise SystemExit("unexpected keys: " + ",".join(extra))
    print("ok")


def cmd_report(args):
    data = load_json(args.config)
    digest = Path(args.digest).read_text(encoding="utf-8").strip()
    commands = json.loads(Path(args.commands).read_text(encoding="utf-8"))
    report = {
        "commands": commands,
        "config": data,
        "config_sha256": digest,
        "ok": True,
        "tool": "task-ctl",
    }
    write_json(args.out, report)
    print("reported")


def audit_artifacts(d, config, canary, enforce, deltas, commands, validate_ok, out, tool_zip):
    """Audit, provenance and coverage artifacts re-expressing the same values."""
    klass = d.klass
    rate = d.trace["rate"]
    sc = d.trace["scope"]
    hard = d.trace["hardening"]
    q = d.trace["quorum"]

    # derivation_audit.xml
    x = ['<?xml version="1.0" encoding="UTF-8"?>', '<derivation_audit>']
    x.append('  <active_class value="%d"/>' % klass)
    x.append('  <base_budget max_records="%d" retry_limit="%d" timeout_ms="%d"/>'
             % (d.max_records, d.retry_limit, d.timeout_ms))
    x.append('  <ingress qps="%d" burst_permille="%d" window_seconds="%d" rate_step="%d" '
             'rate_limit="%d" burst_ceiling="%d"/>'
             % (rate["ingress_qps"], rate["burst_permille"], rate["window_seconds"],
                rate["rate_step"], rate["rate_limit"], rate["burst_ceiling"]))
    x.append('  <scopes base="%d" overlay="%d" deny="%d" effective="%d" uid_floor="%d" '
             'privilege_drop_uid="%d"/>'
             % (len(sc["base"]), len(sc["overlay"]), len(sc["deny"]),
                d.effective_scope_count, sc["uid_floor"], d.privilege_drop_uid))
    for s in d.effective_scopes:
        x.append('  <effective_scope name="%s" uid="%d"/>' % (s, scope_uid_map().get(s)))
    x.append('  <hardening fold_score="%d" floor="%d" ceil="%d" quantize_step="%d" '
             'baseline="%d" severity_permille="%d" risk_index="%d"/>'
             % (hard["fold_score"], hard["bounds"][0], hard["bounds"][1],
                hard["quantize_step"], d.hardening_baseline, d.severity_permille, d.risk_index))
    x.append('  <quorum healthy_voters="%d" permille="%d" quorum_threshold="%d"/>'
             % (q["healthy_voters"], q["permille"], q["quorum_threshold"]))
    x.append('  <tls_floor_score value="%d"/>' % d.tls_floor_score)
    x.append('  <seccomp_allowed_count value="%d"/>' % d.seccomp_allowed_count)
    x.append('  <audit_retention_days value="%d"/>' % d.audit_retention_days)
    x.append('  <precedence session_ttl_seconds="%d" nonce_window_ms="%d" '
             'max_concurrent_sessions="%d"/>'
             % (d.session_ttl_seconds, d.nonce_window_ms, d.max_concurrent_sessions))
    x.append('  <retry timeout_ms="%d" retry_limit="%d" step="%d" backoff_ms="%d"/>'
             % (d.timeout_ms, d.retry_limit, d.trace["retry"]["step"], d.retry_backoff_base_ms))
    x.append('  <trailer value="%s"/>' % config["trailer"])
    x.append('</derivation_audit>')
    audit_xml = "\n".join(x) + "\n"

    # convergence_report.txt
    lines = [
        "task-ctl convergence report",
        "active_class=%d" % klass,
        "ingress_rate_limit_qps=%d" % config["ingress_rate_limit_qps"],
        "burst_ceiling=%d" % config["burst_ceiling"],
        "effective_scope_count=%d" % config["effective_scope_count"],
        "privilege_drop_uid=%d" % config["privilege_drop_uid"],
        "hardening_baseline=%d" % config["hardening_baseline"],
        "risk_index=%d" % config["risk_index"],
        "quorum_threshold=%d" % config["quorum_threshold"],
        "tls_floor_score=%d" % config["tls_floor_score"],
        "seccomp_allowed_count=%d" % config["seccomp_allowed_count"],
        "audit_retention_days=%d" % config["audit_retention_days"],
        "session_ttl_seconds=%d" % config["session_ttl_seconds"],
        "nonce_window_ms=%d" % config["nonce_window_ms"],
        "max_concurrent_sessions=%d" % config["max_concurrent_sessions"],
        "retry_backoff_base_ms=%d" % config["retry_backoff_base_ms"],
        "profile_canary: session_ttl_seconds=%d quorum_threshold=%d risk_index=%d"
        % (canary["session_ttl_seconds"], canary["quorum_threshold"], canary["risk_index"]),
        "profile_enforce: session_ttl_seconds=%d quorum_threshold=%d risk_index=%d"
        % (enforce["session_ttl_seconds"], enforce["quorum_threshold"], enforce["risk_index"]),
        "validate=%s" % ("ok" if validate_ok else "failed"),
        "arithmetic=integer round-half-even",
        "converged=true",
    ]
    convergence = "\n".join(lines) + "\n"

    # input_census.ndjson: every policy layer read for the derivation
    census = []
    files = sorted(p.name for p in DATA.iterdir() if p.is_file() and p.name != "tool.zip")
    for name in files:
        census.append(json.dumps({"file": name, "bytes": (DATA / name).stat().st_size,
                                  "sha256": sha256_file(DATA / name)}, sort_keys=True))
    census_text = "\n".join(census) + "\n"

    # validation_report.json / summary.json
    required = required_keys(load_json(DATA / "config_schema.json"))
    validation = {
        "active_class": klass,
        "config_keys": len(config),
        "config_path": str(out / "config.json"),
        "flat": True,
        "missing_keys": [],
        "required_keys": len(required),
        "result": "ok" if validate_ok else "failed",
        "schema": str(DATA / "config_schema.json"),
        "tool": "task-ctl",
    }
    summary = {
        "active_class": klass,
        "artifacts": len(validation_rules_artifacts()),
        "config": {k: config[k] for k in sorted(config)},
        "profiles": {
            "canary": {k: canary[k] for k in sorted(canary)},
            "enforce": {k: enforce[k] for k in sorted(enforce)},
        },
        "profile_deltas": deltas,
        "tool_zip": str(tool_zip),
        "trailer": config["trailer"],
        "validate": "ok" if validate_ok else "failed",
    }
    return {
        "derivation_audit.xml": audit_xml,
        "convergence_report.txt": convergence,
        "input_census.ndjson": census_text,
        "validation_report.json": json.dumps(validation, sort_keys=True) + "\n",
        "summary.json": json.dumps(summary, sort_keys=True) + "\n",
    }


def validation_rules_artifacts():
    return load_json(DATA / "validation_rules.json")["required_artifacts"]


def repackage_tool(dest, tool_dir):
    """Byte-stable zip of the repaired tool (fixed timestamps, sorted names)."""
    path = Path(dest)
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for name in sorted(p.name for p in Path(tool_dir).iterdir()
                           if p.is_file() and p.suffix == ".py" or p.name in
                           ("README.md", "schema.json")):
            if name == "__pycache__":
                continue
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            zf.writestr(info, (Path(tool_dir) / name).read_bytes())
    return path


def cmd_compile(args):
    """Full deterministic artifact build through the repaired tool surface."""
    import subprocess
    import sys

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    tool_cli = str(Path(__file__).resolve())
    schema = str(DATA / "config_schema.json")
    scratch = Path("/tmp/task-ctl-scratch")
    scratch.mkdir(parents=True, exist_ok=True)
    seed = scratch / "seed.json"
    digest_path = scratch / "digest.txt"
    commands_path = scratch / "commands.json"

    commands = []

    def run(*argv):
        display = ["task-ctl"] + [str(Path(a).name) if str(a).startswith(str(out)) else a
                                 for a in argv]
        commands.append(display)
        subprocess.run([sys.executable, tool_cli, *argv], check=True,
                       stdout=subprocess.DEVNULL)

    run("init", "--schema", schema, "--out", str(seed))
    run("derive", "--schema", schema, "--out", str(out / "config.json"))
    run("validate", "--schema", schema, "--config", str(out / "config.json"))
    run("profile", "--name", "canary", "--schema", schema,
        "--config", str(out / "config.json"), "--out", str(out / "profile_canary.json"))
    run("profile", "--name", "enforce", "--schema", schema,
        "--config", str(out / "config.json"), "--out", str(out / "profile_enforce.json"))

    config = load_json(out / "config.json")
    canary = load_json(out / "profile_canary.json")
    enforce = load_json(out / "profile_enforce.json")

    deltas = {}
    for name, cfg in (("canary", canary), ("enforce", enforce)):
        deltas[name] = {
            k: (cfg[k] - config[k]
                if isinstance(cfg[k], int) and isinstance(config[k], int)
                and not isinstance(cfg[k], bool) else cfg[k])
            for k in sorted(cfg)}
    write_json(out / "profile_delta_report.json", deltas)

    d = Derivation()
    for fname, text in render_sidecars(d, config).items():
        write_text(out / fname, text)

    rows = sorted((("main", config["risk_index"]),
                   ("canary", canary["risk_index"]),
                   ("enforce", enforce["risk_index"])), key=lambda r: (r[1], r[0]))
    write_text(out / "class_ordering.tsv",
               "profile\trisk_index\n" + "".join("%s\t%d\n" % r for r in rows))

    tool_zip = repackage_tool(out / "tool.zip", Path(__file__).resolve().parent)

    validate_ok = subprocess.run(
        [sys.executable, tool_cli, "validate", "--schema", schema,
         "--config", str(out / "config.json")],
        stdout=subprocess.DEVNULL).returncode == 0
    for name in ("profile_canary.json", "profile_enforce.json"):
        validate_ok = validate_ok and subprocess.run(
            [sys.executable, tool_cli, "validate", "--schema", schema,
             "--config", str(out / name)],
            stdout=subprocess.DEVNULL).returncode == 0
        commands.append(["task-ctl", "validate", "--schema", schema,
                         "--config", name])

    digest_path.write_text(sha256_file(out / "config.json") + "\n", encoding="utf-8")
    commands_path.write_text(json.dumps(commands, indent=2) + "\n", encoding="utf-8")
    run("export-report", "--config", str(out / "config.json"), "--out",
        str(out / "report.json"), "--digest", str(digest_path),
        "--commands", str(commands_path))

    audit_out = Path("config.json").parent  # reports use artifact-relative names
    for fname, text in audit_artifacts(d, config, canary, enforce, deltas,
                                       commands, validate_ok, audit_out, "tool.zip").items():
        write_text(out / fname, text)

    manifest = {"artifacts": {}}
    for name in validation_rules_artifacts() + ["reproducibility_manifest.json"]:
        p = out / name
        if name == "reproducibility_manifest.json" or not p.exists():
            continue
        manifest["artifacts"][name] = sha256_file(p)
    manifest["arithmetic"] = "integer round-half-even"
    manifest["deterministic"] = True
    manifest["tool_sha256"] = sha256_file(tool_cli)
    write_json(out / "reproducibility_manifest.json", manifest)

    for p in (seed, digest_path, commands_path):
        p.unlink(missing_ok=True)
    print("compiled")


def main():
    parser = argparse.ArgumentParser(prog="task-ctl")
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("derive")
    p.add_argument("--schema", default=str(DATA / "config_schema.json"))
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_derive)

    p = sub.add_parser("profile")
    p.add_argument("--name", required=True)
    p.add_argument("--schema", default=str(DATA / "config_schema.json"))
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_profile)

    p = sub.add_parser("init")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("export-report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest", required=True)
    p.add_argument("--commands", required=True)
    p.set_defaults(func=cmd_report)

    p = sub.add_parser("compile")
    p.add_argument("--schema", default=str(DATA / "config_schema.json"))
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_compile)

    args = parser.parse_args()
    if not getattr(args, "command", None):
        return
    args.func(args)


if __name__ == "__main__":
    main()
