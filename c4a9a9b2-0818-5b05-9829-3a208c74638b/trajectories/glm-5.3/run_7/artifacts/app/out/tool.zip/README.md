# task-ctl

An offline container-image admission-control hardening compiler for a
server-side admission broker. It reads interacting numeric policy layers from
`/app/data`, selects the active enforcement class, and derives one flat hardened
admission configuration plus two deployment profiles (canary and enforce).

## Commands

- `init --schema <schema> --out <config>`: seed fixed contract strings.
- `derive --schema <schema> --out <config>`: derive the hardened configuration
  for the active enforcement class.
- `set --config <config> --key <key> --value <value>`: set one scalar key with
  correct case and type coercion; reject any non-scalar value.
- `validate --schema <schema> --config <config>`: confirm every required key is
  present and the configuration is flat; print `ok`.
- `profile --name <canary|enforce> --schema <schema> --config <config> --out <config>`:
  apply the documented per-profile deltas.
- `export-report --config <config> --out <report> --digest <sha256> --commands <json>`:
  emit a truthful command transcript.
- `compile --schema <schema> --out <dir>`: run the whole build and emit every
  artifact (configuration, profiles, sidecars, audit and coverage files).

## Contract notes

- Every graded value is derived with exact integer arithmetic using
  round-half-even (banker's) rounding; no floating-point value reaches a
  graded key.
- The configuration is flat: keys map directly to integer or string scalars.
- The required key set is authoritative in `schema.json` and mirrored by the
  field registry in the policy layers.
- Only rows whose status is `ADOPTED` for the active enforcement class bind; rows
  labelled `SUPERSEDED`, `DRAFT`, `SHADOW`, or `REVOKED` are context decoys.

## Derivation summary (repaired)

- **Active class**: the base budget (`max_records`) is folded onto the contiguous
  `ADOPTED` selector axis of `class_index.tsv2`; the band that contains the
  folded budget selects the class. No first-row or modular-formula shortcut.
- **Ingress**: per-class throughput × burst permille, rounded half-even to an
  integer, then floor-quantized to the class rate step; the burst ceiling is the
  resolved rate limit × the class window (never the raw throughput).
- **Scopes**: `base ∪ overlay − deny` for the active class only; the count is the
  size of that set and the privilege-drop uid is the minimum granted uid for the
  set, floored by the class uid floor.
- **Hardening**: the ordered adopted controls fold with a carry rule applied
  between consecutive adopted controls (a control with `carry=1` carries its
  weight into the next adopted control); the fold is clamped to the per-class
  bounds and quantized. `risk_index = (100 − baseline) × severity_permille / 1000`.
- **Quorum**: healthy `ADOPTED` voters × quorum permille, rounded half-even and
  clamped to `[1, voters]`.
- **TLS / seccomp / retention**: adopted per-class layer values.
- **Precedence**: `defaults` → `layer_overrides[class]` → `pinned_overrides[class]`
  only when `pinned == true`.
- **Retry backoff**: `timeout_ms × (retry_limit + 1)`, rounded half-even to the
  divisor 8 and floor-quantized to the class retry step.
