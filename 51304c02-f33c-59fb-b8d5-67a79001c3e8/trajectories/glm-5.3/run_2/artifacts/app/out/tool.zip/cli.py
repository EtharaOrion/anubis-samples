#!/usr/bin/env python3
"""task-ctl -- create, update, validate and report flat JSON task configurations.

Stdlib-only, offline CLI.  A configuration is a *flat* JSON object (scalars
only) built from:

  * a schema file        (config_schema.json)  -- the contract: static values,
                                                  required keys, scalar rule
  * a defaults file      (defaults.json)       -- base values + base_config
  * env overrides        (env_overrides.json)  -- per-profile values and deltas
  * a profile sample     (sample_config_<p>.json) -- per-profile values/deltas
  * validation rules     (validation_rules.json) -- forbidden keys, known
                                                     profiles, artifact rules

Sibling files are auto-discovered next to the schema (or next to the config,
the working directory, or this script), so the short forms documented in
README.md keep working; every one of them can also be passed explicitly.

See REPAIR.md for the faults that were fixed in the original broken sources.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
import platform
import re
import sys
import time
from pathlib import Path

TOOL_NAME = "task-ctl"
TOOL_VERSION = "1.1.0"
RUN_LOG_NAME = "run_log.jsonl"

SCHEMA_STATIC_KEYS = ("profile", "producer", "container", "checksum")
DEFAULTS_TOP_KEYS = ("checksum", "mode", "producer", "container")
STRING_KEYS = ("profile", "producer", "container", "checksum", "mode", "trailer")
INTEGER_KEYS = ("max_records", "retry_limit", "timeout_ms")
POSITIVE_KEYS = ("max_records", "timeout_ms")
NON_NEGATIVE_KEYS = ("retry_limit",)
TRAILER_SHAPE = r"^harbor:cli-config:[A-Za-z0-9_.-]+:[0-9]+$"


# --------------------------------------------------------------------------- #
# JSON helpers
# --------------------------------------------------------------------------- #
def load_json(path):
    """Load a JSON document, exiting with a readable message on failure."""
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise SystemExit(f"{TOOL_NAME}: file not found: {path}") from None
    except json.JSONDecodeError as exc:
        raise SystemExit(f"{TOOL_NAME}: invalid JSON in {path}: {exc}") from None
    except OSError as exc:
        raise SystemExit(f"{TOOL_NAME}: cannot read {path}: {exc}") from None


def load_json_if(path):
    """Load a JSON document when it exists, else None."""
    if not path:
        return None
    return None if not Path(path).is_file() else load_json(path)


def write_json(path, data):
    """Write a JSON document deterministically (2-space indent + newline)."""
    text = json.dumps(data, indent=2, ensure_ascii=False) + "\n"
    Path(path).write_text(text, encoding="utf-8")
    return text


def file_info(path):
    """Provenance record for a file: size and sha256 digest."""
    path = Path(path)
    if not path.is_file():
        return {"path": str(path), "exists": False}
    raw = path.read_bytes()
    return {
        "path": str(path),
        "exists": True,
        "bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
    }


def discover(name, *sources):
    """Find ``name`` next to each source path (or in it, for a directory)."""
    seen = []
    for source in sources:
        if not source:
            continue
        path = Path(source).expanduser().resolve()
        parent = path if path.is_dir() else path.parent
        if parent not in seen:
            seen.append(parent)
    for extra in (Path.cwd().resolve(), Path(__file__).resolve().parent):
        if extra not in seen:
            seen.append(extra)
    for parent in seen:
        candidate = parent / name
        if candidate.is_file():
            return str(candidate)
    return None


# --------------------------------------------------------------------------- #
# Run journal (the "transcript" the old export-report faked with a string)
# --------------------------------------------------------------------------- #
def run_log_path(explicit, *targets):
    if explicit:
        return Path(explicit).expanduser()
    for target in targets:
        if target:
            return Path(target).expanduser().resolve().parent / RUN_LOG_NAME
    return None


def append_run_log(path, entry):
    if path is None:
        return None
    path = Path(path)
    if path.parent and not path.parent.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
    seq = 1
    if path.exists():
        with path.open("r", encoding="utf-8") as handle:
            seq = sum(1 for line in handle if line.strip()) + 1
    record = {"seq": seq, "recorded_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    record.update(entry)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, ensure_ascii=False) + "\n")
    return record


def read_run_log(path):
    if not path or not Path(path).is_file():
        return []
    entries = []
    with Path(path).open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            try:
                entries.append(json.loads(line))
            except json.JSONDecodeError:
                entries.append({"note": "unreadable journal line", "raw": line[:200]})
    return entries


# --------------------------------------------------------------------------- #
# Schema / config helpers
# --------------------------------------------------------------------------- #
def required_keys(schema):
    """required_keys may be a JSON array or the legacy comma-separated string."""
    raw = schema.get("required_keys", [])
    if isinstance(raw, str):
        keys = [part.strip() for part in raw.split(",")]
    elif isinstance(raw, list):
        keys = [str(part).strip() for part in raw]
    else:
        raise SystemExit(f"{TOOL_NAME}: unsupported required_keys type: {type(raw).__name__}")
    return [key for key in keys if key]


def known_profiles(schema, rules, env_overrides=None):
    """Profiles a config may declare: the schema base, the rules list, and any
    profile that has environment overrides."""
    profiles = []
    for source in (schema, rules or {}):
        value = source.get("profile") if isinstance(source, dict) else None
        if isinstance(value, str) and value and value not in profiles:
            profiles.append(value)
    for value in (rules or {}).get("profiles", []) or []:
        if value not in profiles:
            profiles.append(value)
    for value in sorted(env_overrides) if isinstance(env_overrides, dict) else []:
        if value not in profiles:
            profiles.append(value)
    return profiles


def coerce_scalar(raw):
    """Turn a CLI string into the scalar it denotes (bool/int/float/str)."""
    text = str(raw).strip()
    if not text:
        return ""
    lowered = text.lower()
    if lowered == "true":
        return True
    if lowered == "false":
        return False
    if lowered == "null":
        return None
    for caster in (int, float):
        try:
            return caster(text)
        except ValueError:
            pass
    if len(text) >= 2 and text[0] == text[-1] and text[0] in "\"'":
        return text[1:-1]
    return raw if isinstance(raw, str) else text


def resolve_key(data, key):
    """Map a CLI key onto the key stored in the config (case-insensitively)."""
    folded = key.strip().lower()
    for existing in data:
        if existing.lower() == folded:
            return existing
    return folded


def order_config(config, schema):
    """Emit required keys in contract order, then any extras alphabetically."""
    ordered = {}
    for key in required_keys(schema):
        if key in config:
            ordered[key] = config[key]
    for key in sorted(config):
        if key not in ordered:
            ordered[key] = config[key]
    return ordered


def apply_deltas(config, blocks):
    """Apply ``<key>_delta`` entries from each block onto their base key."""
    for label, block in blocks:
        if not isinstance(block, dict):
            continue
        for key, delta in block.items():
            if not key.endswith("_delta"):
                continue
            base_key = key[: -len("_delta")]
            if base_key not in config:
                raise SystemExit(f"{TOOL_NAME}: delta for unknown key {base_key!r} ({label})")
            base = config[base_key]
            numeric = lambda v: isinstance(v, (int, float)) and not isinstance(v, bool)
            if not numeric(base) or not numeric(delta):
                raise SystemExit(
                    f"{TOOL_NAME}: cannot apply {key}={delta!r} to {base_key}={base!r} ({label})"
                )
            config[base_key] = base + delta
    return config


def build_config(schema, defaults, env_overrides, sample, profile):
    """Merge schema -> defaults -> env overrides -> sample into a flat config."""
    config = {}
    for key in SCHEMA_STATIC_KEYS:
        if schema.get(key) is not None:
            config[key] = schema[key]
    if isinstance(defaults, dict):
        for key in DEFAULTS_TOP_KEYS:
            if defaults.get(key) not in (None, ""):
                config[key] = defaults[key]
        for key, value in (defaults.get("base_config") or {}).items():
            config[key] = value
    env_block = {}
    if profile is not None:
        if not isinstance(env_overrides, dict) or profile not in env_overrides:
            known = sorted(env_overrides) if isinstance(env_overrides, dict) else []
            raise SystemExit(f"{TOOL_NAME}: unknown profile {profile!r}; known: {','.join(known) or 'none'}")
        env_block = env_overrides[profile] or {}
    if isinstance(env_block, dict):
        for key, value in env_block.items():
            if not key.endswith("_delta"):
                config[key] = value
    if isinstance(sample, dict):
        for key, value in sample.items():
            if not key.endswith("_delta") and not isinstance(value, (dict, list)):
                config[key] = value
    if profile is not None:
        config["profile"] = profile
    elif isinstance(sample, dict) and sample.get("profile"):
        config["profile"] = sample["profile"]
    apply_deltas(config, (("env_overrides", env_block), ("sample", sample)))
    return config


# --------------------------------------------------------------------------- #
# Validation
# --------------------------------------------------------------------------- #
def _check(check_id, ok, detail, severity="error", problems=None):
    entry = {"id": check_id, "status": "pass" if ok else "fail", "severity": severity, "detail": detail}
    if problems:
        entry["problems"] = problems
    return entry


def validate_config(data, schema, rules, defaults=None, env_overrides=None, expected=None):
    """Validate one config document; returns (checks, ok)."""
    checks = []

    checks.append(_check("json_object", isinstance(data, dict), "configuration is a JSON object",
                         problems=None if isinstance(data, dict) else [f"got {type(data).__name__}"]))
    if not isinstance(data, dict):
        return checks, False

    keys = required_keys(schema)
    missing = [key for key in keys if key not in data]
    checks.append(_check("required_keys", not missing,
                         f"all {len(keys)} required keys present ({', '.join(keys)})",
                         problems=[f"missing: {key}" for key in missing] or None))

    scalar_only = bool(schema.get("scalar_only", True))
    nested = [key for key, value in data.items() if isinstance(value, (dict, list))]
    checks.append(_check("scalar_only", (not scalar_only) or (not nested),
                         "flat configuration (scalar values only)" if scalar_only else "nesting allowed by schema",
                         problems=[f"{key} is {type(data[key]).__name__}" for key in nested] or None))

    bad_types = []
    for key in INTEGER_KEYS:
        if key in data and (isinstance(data[key], bool) or not isinstance(data[key], int)):
            bad_types.append(f"{key} must be an integer, got {type(data[key]).__name__}")
    for key in STRING_KEYS:
        if key in data and not isinstance(data[key], str):
            bad_types.append(f"{key} must be a string, got {type(data[key]).__name__}")
    checks.append(_check("scalar_types", not bad_types, "declared scalar types match the contract",
                         problems=bad_types or None))

    out_of_range = []
    for key in POSITIVE_KEYS:
        if key in data and isinstance(data[key], int) and data[key] <= 0:
            out_of_range.append(f"{key} must be > 0, got {data[key]}")
    for key in NON_NEGATIVE_KEYS:
        if key in data and isinstance(data[key], int) and data[key] < 0:
            out_of_range.append(f"{key} must be >= 0, got {data[key]}")
    checks.append(_check("numeric_ranges", not out_of_range, "numeric keys within range",
                         problems=out_of_range or None))

    schema_checksum = schema.get("checksum")
    if schema_checksum:
        actual = data.get("checksum")
        checks.append(_check("checksum_algorithm", actual == schema_checksum,
                             f"checksum algorithm is {schema_checksum!r}",
                             problems=None if actual == schema_checksum else [f"got {actual!r}"]))
    else:
        checks.append(_check("checksum_algorithm", True, "schema declares no checksum algorithm"))

    profiles = known_profiles(schema, rules, env_overrides)
    declared = data.get("profile")
    profile_ok = isinstance(declared, str) and declared in profiles
    checks.append(_check("profile_known", profile_ok,
                         f"profile is one of {profiles}",
                         problems=None if profile_ok else [f"got {declared!r}"]))

    forbidden = sorted((rules or {}).get("forbidden_keys", []) or [])
    present = [key for key in forbidden if key in data]
    checks.append(_check("forbidden_keys", not present,
                         "no forbidden keys present" + (f" ({', '.join(forbidden)})" if forbidden else ""),
                         problems=[f"forbidden: {key}={data[key]!r}" for key in present] or None))

    unknown = [key for key in sorted(data) if key not in keys]
    checks.append(_check("unknown_keys", not unknown, "no keys beyond the contract",
                         severity="warning", problems=unknown or None))

    trailer = data.get("trailer")
    trailer_ok = isinstance(trailer, str) and bool(trailer)
    shape_ok = trailer_ok and _matches(TRAILER_SHAPE, trailer)
    checks.append(_check("trailer_present", trailer_ok, "trailer is a non-empty string",
                         problems=None if trailer_ok else [f"got {trailer!r}"]))
    checks.append(_check("trailer_shape", shape_ok,
                         "trailer matches 'harbor:cli-config:<name>:<number>'",
                         severity="warning",
                         problems=None if shape_ok else [f"got {trailer!r}"]))

    if expected is not None:
        drift = []
        for key in sorted(set(expected) | set(data)):
            if expected.get(key) != data.get(key):
                drift.append(f"{key}: derived {expected.get(key)!r} != stored {data.get(key)!r}")
        checks.append(_check("derivation", not drift,
                             "stored values match the values derived from defaults+overrides",
                             severity="warning", problems=drift or None))

    errors = [c for c in checks if c["status"] == "fail" and c["severity"] == "error"]
    warnings = [c for c in checks if c["status"] == "fail" and c["severity"] == "warning"]
    return checks, not errors


def _matches(pattern, text):
    return re.match(pattern, text) is not None


def _first_found(*candidates):
    """Absolute path of the first candidate that exists, else None."""
    for candidate in candidates:
        if candidate and Path(candidate).is_file():
            return str(Path(candidate).resolve())
    return None


def derive_expected(schema_path, schema, defaults, env_overrides, profile):
    """Recompute the config a file *should* hold, for the derivation check."""
    sample = None
    if profile:
        sample = load_json_if(discover(f"sample_config_{profile}.json", schema_path))
    expected = build_config(schema, defaults or {}, env_overrides or {}, sample, profile)
    return order_config(expected, schema)


def validate_artifacts(directory, rules):
    """Check required_artifacts / max_artifact_bytes from the rules file."""
    names = list((rules or {}).get("required_artifacts", []) or [])
    max_bytes = (rules or {}).get("max_artifact_bytes", 0)
    items, extra = [], []
    known = set(names)
    for entry in sorted(Path(directory).iterdir()) if Path(directory).is_dir() else []:
        if entry.name not in known and entry.is_file():
            extra.append(entry.name)
    for name in names:
        path = Path(directory) / name
        exists = path.is_file()
        size = path.stat().st_size if exists else None
        too_big = bool(max_bytes) and exists and size > int(max_bytes)
        items.append({
            "name": name,
            "path": str(path),
            "exists": exists,
            "bytes": size,
            "max_bytes": max_bytes,
            "ok": exists and not too_big,
            "problem": None if exists and not too_big else
                       ("missing" if not exists else f"{size} bytes > {max_bytes}"),
        })
    return {
        "dir": str(directory),
        "max_artifact_bytes": max_bytes,
        "items": items,
        "extra_files": extra,
        "ok": bool(items) and all(item["ok"] for item in items),
    }


def validate_paths(args, paths):
    """Validate a list of config paths against schema/rules/defaults."""
    schema_path = args.schema
    schema = load_json(schema_path)
    pick = lambda name: getattr(args, name, None)
    rules_path = pick("rules") or discover("validation_rules.json", schema_path, *paths)
    defaults_path = pick("defaults") or discover("defaults.json", schema_path, *paths)
    env_path = pick("env_overrides") or discover("env_overrides.json", schema_path, *paths)
    rules = load_json_if(rules_path)
    defaults = load_json_if(defaults_path)
    env_overrides = load_json_if(env_path)
    env_profiles = sorted(env_overrides) if isinstance(env_overrides, dict) else []
    results = []
    for path in paths:
        data = load_json(path)
        profile = data.get("profile") if isinstance(data, dict) else None
        expected = None
        if defaults:
            expected = derive_expected(schema_path, schema, defaults, env_overrides,
                                       profile if profile in env_profiles else None)
        checks, ok = validate_config(data, schema, rules, defaults, env_overrides, expected)
        errors = [f"{c['id']}: {p}" for c in checks if c["status"] == "fail" and c["severity"] == "error"
                  for p in c.get("problems", [])]
        warnings = [f"{c['id']}: {p}" for c in checks if c["status"] == "fail" and c["severity"] == "warning"
                    for p in c.get("problems", [])]
        results.append({
            "path": str(Path(path).resolve()),
            "profile": profile,
            "ok": ok,
            "checks": checks,
            "errors": errors,
            "warnings": warnings,
        })
    return {
        "schema": str(Path(schema_path).resolve()),
        "rules": _first_found(rules_path),
        "defaults": _first_found(defaults_path),
        "env_overrides": _first_found(env_path),
        "known_profiles": known_profiles(schema, rules, env_overrides),
        "profiles_with_overrides": env_profiles,
        "configs": results,
    }


def print_validation(report, artifacts=None):
    for result in report["configs"]:
        if result["ok"]:
            print(f"ok   {result['path']} (profile={result['profile']}, "
                  f"{len(result['checks'])} checks, {len(result['warnings'])} warnings)")
        else:
            print(f"FAIL {result['path']}")
            for problem in result["errors"]:
                print(f"     error: {problem}")
        for problem in result["warnings"]:
            print(f"     warning: {problem}")
    if artifacts:
        for item in artifacts["items"]:
            state = "ok  " if item["ok"] else "FAIL"
            print(f"{state} artifact {item['name']} ({item['bytes']} bytes)")
            if not item["ok"]:
                print(f"     error: {item['problem']}")
        for name in artifacts["extra_files"]:
            print(f"note extra file in artifact dir: {name}")


# --------------------------------------------------------------------------- #
# Commands
# --------------------------------------------------------------------------- #
def cmd_init(args):
    schema = load_json(args.schema)
    defaults = load_json_if(args.defaults or discover("defaults.json", args.schema))
    env_overrides = load_json_if(args.env_overrides or discover("env_overrides.json", args.schema))
    rules = load_json_if(args.rules or discover("validation_rules.json", args.schema))
    if defaults is None:
        raise SystemExit(f"{TOOL_NAME}: no defaults file found next to {args.schema}; pass --defaults")
    profile = args.profile
    sample = None
    if profile is not None:
        sample_path = args.sample
        if sample_path is None and not args.no_sample:
            sample_path = discover(f"sample_config_{profile}.json", args.schema)
        if sample_path is None and not args.no_sample:
            raise SystemExit(f"{TOOL_NAME}: no sample file for profile {profile!r} (pass --sample)")
        sample = load_json_if(sample_path)
    elif args.sample:
        sample = load_json_if(args.sample)

    config = build_config(schema, defaults or {}, env_overrides or {}, sample, profile)
    config = order_config(config, schema)
    missing = [key for key in required_keys(schema) if key not in config]
    if missing:
        raise SystemExit(f"{TOOL_NAME}: derived config is missing required keys: {', '.join(missing)}")
    write_json(args.out, config)

    data = load_json(args.out)
    checks, ok = validate_config(data, schema, rules, defaults, env_overrides, config)
    label = profile or schema.get("profile") or "base"
    print(f"wrote {args.out} (profile={label})")
    for key, value in data.items():
        print(f"  {key} = {value!r}")
    if not ok:
        for check in checks:
            if check["status"] == "fail":
                print(f"  error: {check['id']}: {'; '.join(check.get('problems', []))}", file=sys.stderr)
        raise SystemExit(f"{TOOL_NAME}: generated configuration failed validation")
    print(f"validated {args.out}: ok ({len(checks)} checks)")
    return 0


def cmd_set(args):
    data = load_json(args.config)
    rules = load_json_if(args.rules or discover("validation_rules.json", args.config, args.schema))
    forbidden = set((rules or {}).get("forbidden_keys", []) or [])
    key = resolve_key(data, args.key)
    if key.lower() in forbidden:
        raise SystemExit(f"{TOOL_NAME}: refusing to set forbidden key {key!r}")
    value = coerce_scalar(args.value)
    if isinstance(value, (dict, list)):
        raise SystemExit(f"{TOOL_NAME}: refusing to store non-scalar value for {key!r}")
    previous = data.get(key)
    data[key] = value
    if args.schema:
        schema = load_json(args.schema)
        data = order_config(data, schema)
    write_json(args.config, data)
    print(f"set {key} = {value!r} ({type(value).__name__})"
          + (f" (was {previous!r})" if previous is not None else ""))
    if args.schema:
        report = validate_paths(args, [args.config])
        print_validation(report)
        if not all(result["ok"] for result in report["configs"]):
            raise SystemExit(f"{TOOL_NAME}: configuration invalid after set")
    return 0


def cmd_validate(args):
    report = validate_paths(args, args.config)
    artifacts = validate_artifacts(args.artifacts, load_json_if(
        args.rules or discover("validation_rules.json", args.schema, *args.config))) if args.artifacts else None
    document = {
        "ok": all(result["ok"] for result in report["configs"]) and (artifacts is None or artifacts["ok"]),
        "tool": tool_identity(),
        "validation": report,
        "artifacts": artifacts,
        "summary": {
            "configs_checked": len(report["configs"]),
            "configs_ok": sum(1 for result in report["configs"] if result["ok"]),
            "errors": sum(len(result["errors"]) for result in report["configs"])
                      + (0 if artifacts is None else sum(1 for i in artifacts["items"] if not i["ok"])),
            "warnings": sum(len(result["warnings"]) for result in report["configs"]),
            "artifacts_checked": 0 if artifacts is None else len(artifacts["items"]),
        },
    }
    print_validation(report, artifacts)
    status = "OK" if document["ok"] else "FAILED"
    summary = document["summary"]
    print(f"validation: {status} ({summary['configs_ok']}/{summary['configs_checked']} configs, "
          f"{summary['errors']} errors, {summary['warnings']} warnings, "
          f"{summary['artifacts_checked']} artifacts)")
    if args.out:
        write_json(args.out, document)
        print(f"wrote {args.out}")
    return 0 if document["ok"] else 1


def cmd_report(args):
    report = validate_paths(args, args.config)
    log = run_log_path(args.journal, *args.config)
    transcript = read_run_log(log)
    notes = {}
    for path in args.notes or []:
        note = load_json(path)
        if not isinstance(note, dict):
            raise SystemExit(f"{TOOL_NAME}: notes file must hold a JSON object: {path}")
        notes.update(note)
    inputs = [
        {"role": role, **file_info(path)}
        for role, path in (
            ("schema", args.schema),
            ("defaults", args.defaults or discover("defaults.json", args.schema)),
            ("env_overrides", args.env_overrides or discover("env_overrides.json", args.schema)),
            ("rules", args.rules or discover("validation_rules.json", args.schema)),
        )
        if path
    ]
    configs = []
    for result in report["configs"]:
        data = load_json(result["path"])
        configs.append({**result, "data": data})
    ok = all(result["ok"] for result in report["configs"])
    document = {
        "ok": ok,
        "tool": tool_identity(),
        "repair": notes.get("repair"),
        "decisions": notes.get("decisions"),
        "run": {
            "journal": str(log) if log else None,
            "current_command": list(getattr(args, "argv_used", [])),
            "commands": transcript,
            "command_note": "the journal holds every command that completed before this report "
                            "was written; this export-report invocation is listed above",
            "inputs": inputs,
            "outputs": [{"role": "config", **file_info(result["path"])} for result in report["configs"]],
            "notes": notes.get("run_notes"),
        },
        "validation": report,
        "configs": configs,
    }
    write_json(args.out, document)
    print(f"wrote {args.out} ({len(transcript)} journal entries, "
          f"{len(report['configs'])} configs, ok={ok})")
    return 0 if ok else 1


def cmd_summarize(args):
    rules_path = args.rules or discover("validation_rules.json", args.dir)
    if not rules_path:
        raise SystemExit(f"{TOOL_NAME}: no validation_rules.json found for {args.dir}; pass --rules")
    rules = load_json(rules_path)
    artifacts = validate_artifacts(args.dir, rules)
    validation = load_json_if(args.validation or Path(args.dir) / "validation_report.json") or {}
    report = load_json_if(args.report or Path(args.dir) / "report.json") or {}
    notes = {}
    for path in args.notes or []:
        notes.update(load_json(path))
    configs = [
        {"path": result["path"], "profile": result.get("profile"), "ok": result.get("ok", False)}
        for result in (validation.get("validation", {}) or {}).get("configs", [])
    ]
    repair = report.get("repair") or {}
    faults = repair.get("faults") or []
    self = {"name": Path(args.out).name, "self_referential": True,
            "note": "this file; hash/sizes refer to the previous pass"}
    for item in artifacts["items"]:
        if item["name"] == Path(args.out).name:
            item.update(self)
            item["ok"] = True
            item["problem"] = None
    document = {
        "ok": bool(artifacts["ok"] and validation.get("ok") and report.get("ok")),
        "tool": tool_identity(),
        "task": {
            "artifacts_dir": str(Path(args.dir).resolve()),
            "rules": str(Path(rules_path).resolve()),
            "profiles_requested": list(rules.get("profiles", []) or []),
        },
        "artifacts": artifacts,
        "config_files": configs,
        "validation": {
            "path": str(Path(args.validation or Path(args.dir) / "validation_report.json").resolve()),
            "ok": validation.get("ok"),
            "summary": validation.get("summary"),
        },
        "report": {
            "path": str(Path(args.report or Path(args.dir) / "report.json").resolve()),
            "ok": report.get("ok"),
            "faults_fixed": len(faults),
            "fault_ids": [fault.get("id") for fault in faults],
            "commands_recorded": len((report.get("run", {}) or {}).get("commands", []) or []),
        },
        "values": {name: load_json(Path(args.dir) / name) for name in rules.get("required_artifacts", [])
                   if name.startswith(("config", "profile_")) and (Path(args.dir) / name).is_file()},
        "decisions": notes.get("decisions"),
        "reproduction": notes.get("reproduction"),
    }
    write_json(args.out, document)
    total = len(artifacts["items"])
    print(f"wrote {args.out}: {sum(1 for i in artifacts['items'] if i['ok'])}/{total} artifacts ok, "
          f"validation_ok={validation.get('ok')}, report_ok={report.get('ok')}")
    return 0 if document["ok"] else 1


def cmd_package(args):
    """Zip the tool directory so the repaired tool can be delivered as-is."""
    import zipfile

    source = Path(args.dir).resolve()
    if not source.is_dir():
        raise SystemExit(f"{TOOL_NAME}: not a directory: {source}")
    excludes = set(args.exclude or []) | {"__pycache__", ".git"}
    members = []
    for path in sorted(source.rglob("*")):
        if path.is_dir():
            continue
        relative = path.relative_to(source)
        if any(part in excludes for part in relative.parts) or relative.as_posix() in excludes:
            continue
        if relative.suffix in {".pyc", ".pyo"}:
            continue
        members.append((path, relative))
    if not members:
        raise SystemExit(f"{TOOL_NAME}: nothing to package in {source}")
    out = Path(args.out)
    if out.parent and not out.parent.exists():
        out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as bundle:
        for path, relative in members:
            info = zipfile.ZipInfo(relative.as_posix(), date_time=(1980, 1, 1, 0, 0, 0))
            info.external_attr = 0o755 << 16 if os.access(path, os.X_OK) else 0o644 << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            bundle.writestr(info, path.read_bytes())
    print(f"wrote {out} ({len(members)} files, {out.stat().st_size} bytes)")
    for path, relative in members:
        print(f"  {relative.as_posix()} ({path.stat().st_size} bytes)")
    return 0


def tool_identity():
    return {
        "name": TOOL_NAME,
        "version": TOOL_VERSION,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "entry_point": str(Path(__file__).resolve()),
    }


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
def build_parser():
    parser = argparse.ArgumentParser(prog=TOOL_NAME, description=__doc__.splitlines()[0])
    parser.add_argument("--version", action="version", version=f"{TOOL_NAME} {TOOL_VERSION}")
    sub = parser.add_subparsers(dest="command", required=True, metavar="command")

    p = sub.add_parser("init", help="build a flat config from schema+defaults+overrides")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--profile", help="environment profile to apply (e.g. dev, prod)")
    p.add_argument("--sample", help=f"path to sample_config_<profile>.json (default: discovered)")
    p.add_argument("--no-sample", action="store_true", help="do not merge a profile sample file")
    p.add_argument("--defaults")
    p.add_argument("--env-overrides")
    p.add_argument("--rules")
    p.add_argument("--journal", help=f"run journal path (default: <out dir>/{RUN_LOG_NAME})")
    p.set_defaults(func=cmd_init, journal_target="out")

    p = sub.add_parser("set", help="set one scalar key on an existing config")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.add_argument("--schema", help="re-order and re-validate after the change")
    p.add_argument("--defaults")
    p.add_argument("--env-overrides")
    p.add_argument("--rules")
    p.add_argument("--journal", help=f"run journal path (default: <config dir>/{RUN_LOG_NAME})")
    p.set_defaults(func=cmd_set, journal_target="config")

    p = sub.add_parser("validate", help="validate config(s) and optionally the artifact set")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", action="append", required=True, help="config to validate (repeatable)")
    p.add_argument("--artifacts", help="directory to check against required_artifacts/max_artifact_bytes")
    p.add_argument("--out", help="write the structured validation report here")
    p.add_argument("--defaults")
    p.add_argument("--env-overrides")
    p.add_argument("--rules")
    p.add_argument("--journal", help=f"run journal path (default: <config dir>/{RUN_LOG_NAME})")
    p.set_defaults(func=cmd_validate, journal_target="config")

    p = sub.add_parser("export-report", help="write a report about the configs and the run")
    p.add_argument("--config", action="append", required=True, help="config to include (repeatable)")
    p.add_argument("--out", required=True)
    p.add_argument("--schema", required=True)
    p.add_argument("--notes", action="append", help="JSON file merged into the report (repeatable)")
    p.add_argument("--defaults")
    p.add_argument("--env-overrides")
    p.add_argument("--rules")
    p.add_argument("--journal", help=f"run journal path (default: <config dir>/{RUN_LOG_NAME})")
    p.set_defaults(func=cmd_report, journal_target="config")

    p = sub.add_parser("summarize", help="summarize an artifact directory against the rules")
    p.add_argument("--dir", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--rules")
    p.add_argument("--validation", help="path to validation_report.json (default: <dir>/validation_report.json)")
    p.add_argument("--report", help="path to report.json (default: <dir>/report.json)")
    p.add_argument("--notes", action="append", help="JSON file merged into the summary (repeatable)")
    p.add_argument("--journal", help=f"run journal path (default: <out dir>/{RUN_LOG_NAME})")
    p.set_defaults(func=cmd_summarize, journal_target="out")

    p = sub.add_parser("package", help="zip the tool directory for delivery")
    p.add_argument("--dir", required=True, help="tool directory to package")
    p.add_argument("--out", required=True, help="destination .zip path")
    p.add_argument("--exclude", action="append", help="file or directory name to skip (repeatable)")
    p.add_argument("--journal", help=f"run journal path (default: <out dir>/{RUN_LOG_NAME})")
    p.set_defaults(func=cmd_package, journal_target="out")
    return parser


class _Tee(io.TextIOBase):
    """Stream that mirrors writes into several targets (stdout + capture)."""

    def __init__(self, *streams):
        self.streams = streams

    def write(self, text):
        for stream in self.streams:
            stream.write(text)
        return len(text)

    def flush(self):
        for stream in self.streams:
            stream.flush()


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    config_target = getattr(args, "config", None)
    if isinstance(config_target, (list, tuple)):
        targets = list(config_target)
    else:
        targets = [config_target] if config_target else []
    targets += [getattr(args, "out", None), getattr(args, "dir", None)]
    journal = run_log_path(getattr(args, "journal", None), *[t for t in targets if t])
    captured, captured_err = io.StringIO(), io.StringIO()
    stdout, stderr = sys.stdout, sys.stderr
    sys.stdout, sys.stderr = _Tee(stdout, captured), _Tee(stderr, captured_err)
    used_argv = list(sys.argv[1:] if argv is None else argv)
    args.argv_used = used_argv
    entry = {"command": args.command, "argv": used_argv}
    try:
        code = args.func(args)
        code = 0 if code is None else int(code)
    except SystemExit as exc:
        code = exc.code if isinstance(exc.code, int) else (0 if exc.code is None else 1)
        if isinstance(exc.code, str) and exc.code.strip():
            print(exc.code.strip(), file=sys.stderr)
        if code != 0:
            entry["error"] = str(exc.code)
    finally:
        sys.stdout, sys.stderr = stdout, stderr
    entry["exit_code"] = code
    output = captured.getvalue().strip()
    if output:
        entry["output"] = output[:4000]
    output_err = captured_err.getvalue().strip()
    if output_err:
        entry["stderr"] = output_err[:2000]
    append_run_log(journal, entry)
    return code


if __name__ == "__main__":
    sys.exit(main())
