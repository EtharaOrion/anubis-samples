# task-ctl

A stdlib-only, offline CLI that creates, updates, validates and reports a flat
JSON configuration for TASK processing. The original sources were broken in
several places; see `REPAIR.md` for the fault list and the fixes.

## Layout

| file                | role                                                      |
|---------------------|-----------------------------------------------------------|
| `task-ctl`          | executable entry point (`./task-ctl <command> ...`)       |
| `cli.py`            | implementation (also runnable as `python3 cli.py ...`)    |
| `schema.json`       | copy of the configuration contract                         |
| `defaults.json`     | baseline values (`base_config` + top-level defaults)       |
| `env_overrides.json`| per-profile values and `*_delta` adjustments               |
| `validation_rules.json` | the rules contract (forbidden keys, profiles, artifacts)|
| `REPAIR.md`         | faults found in the original sources and their fixes       |
| `tests/`            | offline regression tests (`python3 -m unittest discover -s tests`) |

Inputs are discovered next to `--schema` (then the working directory, then this
directory), so the short command forms below work as-is; every input can also be
passed explicitly with `--defaults`, `--env-overrides`, `--rules` or `--sample`.

## Commands

```bash
# base configuration (profile taken from the schema)
python3 cli.py init --schema schema.json --out config.json

# environment profiles: defaults + env_overrides[<profile>] + sample_config_<profile>.json
python3 cli.py init --schema schema.json --out profile_dev.json  --profile dev
python3 cli.py init --schema schema.json --out profile_prod.json --profile prod

# set one scalar key (case-insensitive key match, value coerced to bool/int/float/str)
python3 cli.py set --config config.json --key max_records --value 100 --schema schema.json

# validate config(s); --artifacts also checks required_artifacts/max_artifact_bytes
python3 cli.py validate --schema schema.json --config config.json \
                        --artifacts . --out validation_report.json

# report on configs + the recorded run journal
python3 cli.py export-report --schema schema.json --config config.json --out report.json

# summarize an artifact directory against validation_rules.json
python3 cli.py summarize --dir . --out summary.json

# zip the tool directory for delivery (skips __pycache__/*.pyc)
python3 cli.py package --dir . --out tool.zip
```

Every invocation appends one JSON line to `run_log.jsonl` beside its target
(command, argv, captured output, exit code); `export-report` replays that
journal as the run transcript. Exit status is `0` on success and `1` on any
validation failure, so the commands compose in shell scripts.

## Configuration contract

A valid configuration is a flat JSON object (scalars only) holding every key in
the schema's `required_keys`, with `checksum` equal to the schema's checksum
algorithm, a `profile` that is either the schema's base profile or one of the
profiles in `validation_rules.json`, and none of the rules' `forbidden_keys`.
`init` refuses to write a configuration that fails those checks.
