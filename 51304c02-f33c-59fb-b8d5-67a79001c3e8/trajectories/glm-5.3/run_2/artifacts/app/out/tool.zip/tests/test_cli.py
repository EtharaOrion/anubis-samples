"""Offline regression tests for the repaired task-ctl CLI (stdlib unittest only)."""
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import cli  # noqa: E402

SCHEMA = {
    "profile": "TASK",
    "producer": "",
    "container": "",
    "required_keys": [
        "profile", "producer", "container", "max_records", "retry_limit",
        "timeout_ms", "checksum", "mode", "trailer",
    ],
    "scalar_only": True,
    "checksum": "crc32",
}
DEFAULTS = {
    "checksum": "crc32",
    "mode": "strict-local",
    "producer": "",
    "container": "",
    "base_config": {
        "max_records": 145,
        "retry_limit": 3,
        "timeout_ms": 1771,
        "trailer": "harbor:cli-config:TASK:0000000000016384",
    },
}
ENV_OVERRIDES = {
    "dev": {"mode": "strict-local", "retry_limit_delta": 1, "timeout_ms_delta": -125},
    "prod": {"mode": "strict-local", "retry_limit_delta": 0, "timeout_ms_delta": 250},
}
RULES = {
    "profiles": ["dev", "prod"],
    "forbidden_keys": ["timestamp", "generated_at", "uuid", "random_seed"],
    "required_artifacts": ["config.json"],
    "max_artifact_bytes": 1048576,
}


class CliTestCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)
        self.addCleanup(self.tmp.cleanup)
        for name, payload in (
            ("schema.json", SCHEMA),
            ("defaults.json", DEFAULTS),
            ("env_overrides.json", ENV_OVERRIDES),
            ("validation_rules.json", RULES),
            ("sample_config_dev.json", {"profile": "dev", "max_records_delta": -10, "checksum": "crc32"}),
        ):
            (self.dir / name).write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
        self.prev_cwd = os.getcwd()
        os.chdir(self.dir)
        self.addCleanup(os.chdir, self.prev_cwd)

    def run_cli(self, *argv):
        journal = self.dir / "run_log.jsonl"
        return cli.main(list(argv) + ["--journal", str(journal)])

    def run_cli_failed(self, *argv):
        code = self.run_cli(*argv)
        self.assertEqual(code, 1, f"expected failure: {argv}")
        return code

    def init(self, out="config.json", extra=()):
        self.run_cli("init", "--schema", "schema.json", "--out", out, *extra)
        return json.loads((self.dir / out).read_text(encoding="utf-8"))

    def test_init_builds_flat_complete_config(self):
        config = self.init()
        self.assertEqual(config["profile"], "TASK")
        self.assertEqual(config["max_records"], 145)
        self.assertEqual(sorted(config), sorted(SCHEMA["required_keys"]))
        self.assertTrue(all(not isinstance(v, (dict, list)) for v in config.values()))

    def test_init_applies_profile_deltas(self):
        dev = self.init("dev.json", ("--profile", "dev"))
        self.assertEqual(dev["profile"], "dev")
        self.assertEqual(dev["max_records"], 135)
        self.assertEqual(dev["retry_limit"], 4)
        self.assertEqual(dev["timeout_ms"], 1646)
        self.assertNotIn("max_records_delta", dev)

    def test_init_rejects_unknown_profile(self):
        self.run_cli_failed("init", "--schema", "schema.json", "--out", "bad.json",
                            "--profile", "staging")

    def test_legacy_comma_separated_required_keys(self):
        legacy = dict(SCHEMA, required_keys=",".join(SCHEMA["required_keys"]))
        (self.dir / "legacy_schema.json").write_text(json.dumps(legacy), encoding="utf-8")
        self.run_cli("init", "--schema", "legacy_schema.json", "--out", "legacy.json")
        config = json.loads((self.dir / "legacy.json").read_text(encoding="utf-8"))
        self.assertEqual(len(config), 9)

    def test_set_resolves_key_case_and_coerces_scalar(self):
        self.init()
        self.run_cli("set", "--config", "config.json", "--key", "MAX_RECORDS", "--value", "100",
                     "--schema", "schema.json")
        config = json.loads((self.dir / "config.json").read_text(encoding="utf-8"))
        self.assertEqual(config["max_records"], 100)
        self.assertIsInstance(config["max_records"], int)
        self.assertNotIn("MAX_RECORDS", config)

    def test_set_refuses_forbidden_key(self):
        self.init()
        self.run_cli_failed("set", "--config", "config.json", "--key", "uuid", "--value", "x")
        config = json.loads((self.dir / "config.json").read_text(encoding="utf-8"))
        self.assertNotIn("uuid", config)

    def test_validate_passes_on_generated_configs(self):
        self.init()
        self.init("dev.json", ("--profile", "dev"))
        code = self.run_cli("validate", "--schema", "schema.json", "--config", "config.json",
                            "--config", "dev.json")
        self.assertEqual(code, 0)

    def test_validate_fails_on_missing_and_nested_keys(self):
        (self.dir / "broken.json").write_text(json.dumps({"profile": "dev"}), encoding="utf-8")
        code = self.run_cli("validate", "--schema", "schema.json", "--config", "broken.json")
        self.assertEqual(code, 1)
        (self.dir / "nested.json").write_text(
            json.dumps({key: 1 for key in SCHEMA["required_keys"]} | {"settings": {"a": 1}}),
            encoding="utf-8")
        code = self.run_cli("validate", "--schema", "schema.json", "--config", "nested.json")
        self.assertEqual(code, 1)

    def test_validate_fails_on_forbidden_key_and_unknown_profile(self):
        config = {key: ("" if key in cli.STRING_KEYS else 1) for key in SCHEMA["required_keys"]}
        config.update({"profile": "staging", "checksum": "crc32", "trailer": "harbor:cli-config:TASK:1",
                       "mode": "strict-local", "uuid": "nope"})
        (self.dir / "bad.json").write_text(json.dumps(config), encoding="utf-8")
        code = self.run_cli("validate", "--schema", "schema.json", "--config", "bad.json")
        self.assertEqual(code, 1)

    def test_validate_reports_artifacts(self):
        self.init()
        self.run_cli("validate", "--schema", "schema.json", "--config", "config.json",
                     "--artifacts", str(self.dir), "--out", "validation_report.json")
        report = json.loads((self.dir / "validation_report.json").read_text(encoding="utf-8"))
        self.assertTrue(report["ok"])
        self.assertEqual([i["name"] for i in report["artifacts"]["items"]], ["config.json"])

    def test_export_report_contains_transcript(self):
        self.init()
        self.init("dev.json", ("--profile", "dev"))
        self.run_cli("export-report", "--schema", "schema.json", "--config", "config.json",
                     "--config", "dev.json", "--out", "report.json")
        report = json.loads((self.dir / "report.json").read_text(encoding="utf-8"))
        self.assertTrue(report["ok"])
        commands = [entry["command"] for entry in report["run"]["commands"]]
        self.assertIn("init", commands)
        self.assertEqual(report["run"]["current_command"][0], "export-report")
        self.assertTrue(all(isinstance(c, dict) for c in report["run"]["commands"]))

    def test_summarize_reports_artifact_state(self):
        self.init()
        self.run_cli("validate", "--schema", "schema.json", "--config", "config.json",
                     "--artifacts", str(self.dir), "--out", "validation_report.json")
        self.run_cli("export-report", "--schema", "schema.json", "--config", "config.json",
                     "--out", "report.json")
        code = self.run_cli("summarize", "--dir", str(self.dir), "--out", "summary.json")
        summary = json.loads((self.dir / "summary.json").read_text(encoding="utf-8"))
        self.assertEqual(code, 0)
        self.assertTrue(summary["ok"])
        self.assertEqual(summary["artifacts"]["items"][0]["name"], "config.json")

    def test_package_creates_zip_with_tool_sources(self):
        tool_dir = Path(cli.__file__).resolve().parent
        code = self.run_cli("package", "--dir", str(tool_dir), "--out", str(self.dir / "tool.zip"))
        self.assertEqual(code, 0)
        import zipfile

        with zipfile.ZipFile(self.dir / "tool.zip") as bundle:
            names = bundle.namelist()
        self.assertIn("cli.py", names)
        self.assertIn("task-ctl", names)
        self.assertIn("tests/test_cli.py", names)
        self.assertFalse(any("__pycache__" in name or name.endswith(".pyc") for name in names))

    def test_readme_command_shapes(self):
        """The four commands documented in README.md run exactly as documented."""
        self.run_cli("init", "--schema", "schema.json", "--out", "config.json")
        self.run_cli("set", "--config", "config.json", "--key", "max_records", "--value", "100")
        code = self.run_cli("validate", "--schema", "schema.json", "--config", "config.json")
        self.assertEqual(code, 0)
        config = json.loads((self.dir / "config.json").read_text(encoding="utf-8"))
        self.assertEqual(config["max_records"], 100)
        code = self.run_cli("export-report", "--schema", "schema.json", "--config", "config.json",
                            "--out", "report.json")
        self.assertEqual(code, 0)


if __name__ == "__main__":
    unittest.main()
