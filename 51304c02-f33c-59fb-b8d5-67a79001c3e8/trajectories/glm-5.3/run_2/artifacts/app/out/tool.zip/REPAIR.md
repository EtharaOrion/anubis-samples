# Repair notes

Faults found in the original `tool.zip` sources, and how each was fixed.
"Marked" faults carried a `# BUG` comment; the rest were found by reading the
tool against the contract in `config_schema.json` / `validation_rules.json`.

## Marked faults

1. **`cmd_init` read the wrong argument** — `load_json(args.config)` on a parser
   that only defines `--schema`/`--out`, so `init` crashed with
   `AttributeError: 'Namespace' object has no attribute 'config'` before writing
   anything. Now reads `args.schema`.
2. **`cmd_init` emitted nested data** — it wrote a `settings` object, violating
   `scalar_only`; and it emitted only 4 of the 9 required keys because it never
   consulted `defaults.json`. `init` now merges schema → defaults →
   `env_overrides[profile]` → `sample_config_<profile>.json`, applies
   `*_delta` adjustments, orders keys as `required_keys` and refuses to write a
   config that fails validation.
3. **`cmd_set` mangled keys and values** — `data[args.key.upper()] = args.value`
   stored `MAX_RECORDS` (a key outside the contract) and left `"100"` as a
   string, so numeric fields silently became strings. Keys are now matched
   case-insensitively against the existing key and values are coerced to
   bool/int/float/str; forbidden keys are refused.
4. **`cmd_report` wrote an unusable transcript** — `{"commands": "unknown"}`,
   and it asserted `ok: true` without validating anything. Reports now contain
   the real run journal, validation results, input/output digests and notes.
5. **`subparsers` were optional** — running the CLI with no command crashed on
   `args.func` (`AttributeError`). Subcommands are now required and the parser
   prints real usage.

## Unmarked faults

6. **`cmd_validate` assumed `required_keys` is a comma-separated string** —
   `.split(",")` raised `AttributeError: 'list' object has no attribute 'split'`
   against the actual contract, where `required_keys` is a JSON array. Both
   shapes (array and legacy string) are accepted.
7. **`validation_rules.json` was ignored entirely** — no `forbidden_keys`, no
   known-profile check, no `required_artifacts`/`max_artifact_bytes` check, and
   no way to record validation output. `validate` gained all of these plus
   `--out` for a machine-readable report and a non-zero exit status on failure.
8. **No profile support** — the tool could not consume `env_overrides.json` or
   the `sample_config_<profile>.json` files, so it could not produce the dev/prod
   environment profiles at all. Added `init --profile` (+ `--sample`,
   `--no-sample`).
9. **No `task-ctl` entry point** — the README calls the tool task-ctl, but only
   `cli.py` existed. Added the `task-ctl` executable, plus bundled copies of the
   contract inputs (`schema.json`, `defaults.json`, `env_overrides.json`,
   `validation_rules.json`) so the tool also runs standalone.
10. **Stale bundled schema** — `schema.json` shipped the legacy string form of
    `required_keys` and lacked `scalar_only`; realigned with the contract.
11. **Weak error handling and unreadable output** — `json.dumps` with no
    indentation, no encoding, and bare tracebacks instead of messages. Writes
    are now deterministic (2-space indent, sorted-by-contract key order, UTF-8)
    and failures exit with a one-line message.

## Verification

`python3 -m unittest discover -s tests` (14 tests) covers every fixed fault:
README command shapes, profile deltas, legacy `required_keys`, key case and
value coercion, forbidden keys, nested/missing keys, unknown profiles, artifact
checks, report transcripts, summaries and packaging.
