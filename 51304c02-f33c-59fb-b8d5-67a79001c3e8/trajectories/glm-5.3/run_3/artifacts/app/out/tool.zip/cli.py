#!/usr/bin/env python3
"""task-ctl -- create, update, validate and report flat JSON configurations.

Standard library only.  See README.md for the full command reference.

A configuration is a flat JSON object of scalar values.  The contract for a
valid configuration comes from a schema document (required keys, scalar-only
flag, checksum algorithm, seed identity) and, optionally, a rules document
(allowed profiles, forbidden keys, required artifacts, size budget).
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

TOOL_NAME = "task-ctl"
TOOL_VERSION = "1.1.0"
DELTA_SUFFIX = "_delta"
SCALARS = (str, int, float, bool, type(None))
NUMERIC_KEYS = ("max_records", "retry_limit", "timeout_ms")


def fail(message):
    raise SystemExit("%s: error: %s" % (TOOL_NAME, message))


# --------------------------------------------------------------------------
# json helpers
# --------------------------------------------------------------------------


def load_json(path, label=None):
    p = Path(path)
    if not p.is_file():
        fail("%s not found: %s" % (label or "file", path))
    try:
        return json.loads(p.read_text())
    except json.JSONDecodeError as exc:
        fail("%s is not valid JSON: %s" % (label or path, exc))


def write_json(path, data):
    p = Path(path)
    if p.parent and str(p.parent) not in ("", "."):
        p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")
    return p


def is_scalar(value):
    return isinstance(value, SCALARS) and not isinstance(value, (dict, list))


# --------------------------------------------------------------------------
# schema helpers
# --------------------------------------------------------------------------


def required_keys(schema):
    """Accept the contract's list form and the legacy comma-separated form."""
    raw = schema.get("required_keys")
    if isinstance(raw, str):
        keys = [k.strip() for k in raw.split(",") if k.strip()]
    elif isinstance(raw, list):
        keys = [str(k) for k in raw]
    else:
        fail("schema field 'required_keys' must be a list or a comma separated string")
    if not keys:
        fail("schema field 'required_keys' is empty")
    return keys


def coerce_value(raw, type_hint=None):
    """Turn a command line string into the scalar the configuration expects."""
    if type_hint:
        hint = type_hint.strip().lower()
        if hint in ("str", "string"):
            return raw
        if hint in ("int", "integer"):
            try:
                return int(raw)
            except ValueError:
                fail("--value %r is not an integer" % raw)
        if hint in ("float", "number"):
            try:
                return float(raw)
            except ValueError:
                fail("--value %r is not a number" % raw)
        if hint in ("bool", "boolean"):
            return raw.strip().lower() in ("1", "true", "yes", "on")
        fail("unknown --type %r (use str, int, float or bool)" % type_hint)

    text = raw.strip()
    try:
        return int(text)
    except ValueError:
        pass
    try:
        return float(text)
    except ValueError:
        pass
    if text.lower() in ("true", "false"):
        return text.lower() == "true"
    if text[:1] in ("[", "{"):
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            pass
    return raw


# --------------------------------------------------------------------------
# configuration composition
# --------------------------------------------------------------------------


def apply_overlay(config, overlay, source):
    """Overlay scalars and apply ``<key>_delta`` additions onto ``config``."""
    for key, value in overlay.items():
        if key.endswith(DELTA_SUFFIX):
            target = key[: -len(DELTA_SUFFIX)]
            if target not in config:
                fail("%s: %s adjusts unknown key %r" % (source, key, target))
            base = config[target]
            if isinstance(base, bool) or not isinstance(base, (int, float)):
                fail("%s: %s needs a numeric %r, got %r" % (source, key, target, base))
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                fail("%s: %s must be numeric, got %r" % (source, key, value))
            config[target] = base + value
        elif is_scalar(value):
            config[key] = value
        else:
            fail("%s: %r is not a scalar value" % (source, key))
    return config


def build_config(schema, defaults=None, env=None, sample=None, profile=None):
    config = {}

    # 1. identity and algorithm seed from the schema
    config["profile"] = schema.get("profile", profile or "TASK")
    for key in ("producer", "container", "checksum", "mode"):
        if key in schema and is_scalar(schema[key]):
            config[key] = schema[key]

    # 2. defaults: top level scalars, then the flattened base_config block
    if defaults:
        for key, value in defaults.items():
            if key == "base_config":
                if not isinstance(value, dict):
                    fail("defaults: 'base_config' must be an object")
                for inner, inner_value in value.items():
                    if not is_scalar(inner_value):
                        fail("defaults: base_config.%s is not a scalar" % inner)
                    config[inner] = inner_value
            elif is_scalar(value):
                config[key] = value

    # 3. profile selection, then the sample profile and environment overrides
    if profile:
        config["profile"] = profile
        if env is not None and profile not in env:
            known = ", ".join(sorted(env))
            fail("environment overrides have no entry for profile %r (have: %s)" % (profile, known))

    if sample:
        apply_overlay(config, sample, "sample profile")

    if env is not None and profile:
        apply_overlay(config, env[profile], "environment overrides[%s]" % profile)

    # 4. the result must stay a flat object of scalars
    nested = [k for k, v in config.items() if not is_scalar(v)]
    if nested:
        fail("composed configuration is not flat at: %s" % ", ".join(nested))
    return config


# --------------------------------------------------------------------------
# validation
# --------------------------------------------------------------------------


def validate_config(schema, rules, config, path):
    checks = []

    def add(name, ok, detail, warn_only=False):
        status = "pass" if ok else ("warn" if warn_only else "fail")
        checks.append({"name": name, "status": status, "detail": detail})

    keys = required_keys(schema)

    missing = [k for k in keys if k not in config]
    add(
        "required_keys_present",
        not missing,
        "all %d required keys present (%s)" % (len(keys), ", ".join(keys))
        if not missing
        else "missing keys: " + ", ".join(missing),
    )

    nested = [k for k, v in config.items() if not is_scalar(v)]
    scalar_only = bool(schema.get("scalar_only", True))
    add(
        "scalar_only",
        nested == [] or not scalar_only,
        "every value is a scalar" if not nested else "nested values at: " + ", ".join(nested),
    )

    forbidden = list(rules.get("forbidden_keys", [])) if rules else []
    hit = [k for k in forbidden if k in config]
    add(
        "forbidden_keys_absent",
        not hit,
        "forbidden keys present: " + ", ".join(hit)
        if hit
        else ("none of [%s] appear in the configuration" % ", ".join(forbidden))
        if forbidden
        else "no forbidden keys declared",
    )

    allowed = set(rules.get("profiles", [])) if rules else set()
    allowed.add(schema.get("profile"))
    allowed.discard(None)
    profile = config.get("profile")
    add(
        "profile_allowed",
        profile in allowed,
        "profile %r is permitted (%s)" % (profile, ", ".join(sorted(str(a) for a in allowed))),
    )

    wanted = schema.get("checksum")
    add(
        "checksum_algorithm",
        (not wanted) or config.get("checksum") == wanted,
        "checksum algorithm is %r" % config.get("checksum") if not wanted or config.get("checksum") == wanted
        else "checksum algorithm is %r, schema requires %r" % (config.get("checksum"), wanted),
    )

    extra = [k for k in sorted(config) if k not in keys]
    add(
        "unknown_keys",
        not extra,
        "configuration holds exactly the required key set"
        if not extra
        else "keys outside the required set: " + ", ".join(extra),
        warn_only=True,
    )

    non_integer = [
        k
        for k in NUMERIC_KEYS
        if k in config and (isinstance(config[k], bool) or not isinstance(config[k], int))
    ]
    add(
        "numeric_keys_integer",
        not non_integer,
        "%s are integers" % ", ".join(k for k in NUMERIC_KEYS if k in config)
        if not non_integer
        else "not integers: " + ", ".join(non_integer),
    )

    errors = [c["detail"] for c in checks if c["status"] == "fail"]
    warnings = [c["detail"] for c in checks if c["status"] == "warn"]
    return {
        "path": str(path),
        "profile": config.get("profile"),
        "key_count": len(config),
        "keys": sorted(config),
        "checks": checks,
        "errors": errors,
        "warnings": warnings,
        "ok": not errors,
    }


def check_artifacts(rules, directory):
    required = list(rules.get("required_artifacts", []))
    limit = rules.get("max_artifact_bytes")
    present, missing, oversize, sizes = [], [], [], {}
    for name in required:
        p = Path(directory) / name
        if not p.is_file():
            missing.append(name)
            continue
        size = p.stat().st_size
        sizes[name] = size
        present.append(name)
        if limit is not None and size > limit:
            oversize.append({"artifact": name, "bytes": size, "limit": limit})
    return {
        "directory": str(directory),
        "required": required,
        "present": present,
        "missing": missing,
        "sizes_bytes": sizes,
        "oversize": oversize,
        "max_artifact_bytes": limit,
        "ok": not missing and not oversize,
    }


# --------------------------------------------------------------------------
# transcript
# --------------------------------------------------------------------------


def read_transcript(path):
    if not path:
        return []
    p = Path(path)
    if not p.is_file():
        return []
    entries = []
    for line in p.read_text().splitlines():
        line = line.strip()
        if line:
            entries.append(json.loads(line))
    return entries


def record_invocation(args):
    path = getattr(args, "transcript", None)
    if not path:
        return
    entries = read_transcript(path)
    entries.append(
        {
            "step": len(entries) + 1,
            "command": args.command,
            "argv": sys.argv[1:],
            "tool": TOOL_NAME,
            "tool_version": TOOL_VERSION,
        }
    )
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text("".join(json.dumps(e, sort_keys=True) + "\n" for e in entries))


# --------------------------------------------------------------------------
# commands
# --------------------------------------------------------------------------


def cmd_init(args):
    schema = load_json(args.schema, "schema")
    defaults = load_json(args.defaults, "defaults") if args.defaults else None
    env = load_json(args.env, "environment overrides") if args.env else None
    sample = load_json(args.sample, "sample profile") if args.sample else None

    if env is not None and not isinstance(env, dict):
        fail("environment overrides must be an object keyed by profile")

    # --profile selects the env entry; without an explicit --sample the
    # conventional sample_config_<profile>.json next to the env file is used.
    if args.profile and sample is None and env is not None and args.env:
        candidate = Path(args.env).resolve().parent / ("sample_config_%s.json" % args.profile)
        if candidate.is_file():
            sample = load_json(candidate, "sample profile")

    config = build_config(
        schema,
        defaults=defaults,
        env=env,
        sample=sample,
        profile=args.profile,
    )

    rules = load_json(args.rules, "rules") if args.rules else None
    result = validate_config(schema, rules, config, args.out)
    if not result["ok"]:
        fail("composed configuration is invalid: " + "; ".join(result["errors"]))

    write_json(args.out, config)
    if not args.quiet:
        print(
            "wrote %s (profile=%s, %d keys)"
            % (args.out, config.get("profile"), len(config))
        )


def cmd_set(args):
    config = load_json(args.config, "config")
    key = args.key.strip()
    if not key:
        fail("--key must not be empty")

    schema = load_json(args.schema, "schema") if args.schema else None
    if schema is not None and key not in required_keys(schema):
        fail("key %r is not one of the required keys" % key)

    config[key] = coerce_value(args.value, args.type)
    nested = [k for k, v in config.items() if not is_scalar(v)]
    if nested:
        fail("value for %r would make the configuration non-scalar" % key)
    write_json(args.config, config)
    if not args.quiet:
        shown = json.dumps(config[key])
        print("set %s = %s (%s)" % (key, shown, type(config[key]).__name__))


def cmd_validate(args):
    schema = load_json(args.schema, "schema")
    rules = load_json(args.rules, "rules") if args.rules else None
    results = []
    for path in args.config:
        config = load_json(path, "config")
        results.append(validate_config(schema, rules, config, path))

    artifacts = None
    if args.artifacts:
        if rules is None:
            fail("--artifacts needs --rules to supply required_artifacts")
        artifacts = check_artifacts(rules, args.artifacts)

    ok = all(r["ok"] for r in results) and (artifacts is None or artifacts["ok"])
    errors = [e for r in results for e in r["errors"]]
    warnings = [w for r in results for w in r["warnings"]]
    if artifacts and not artifacts["ok"]:
        if artifacts["missing"]:
            errors.append("missing artifacts: " + ", ".join(artifacts["missing"]))
        if artifacts["oversize"]:
            errors.append(
                "oversize artifacts: "
                + ", ".join("%s (%d bytes)" % (o["artifact"], o["bytes"]) for o in artifacts["oversize"])
            )

    report = {
        "tool": TOOL_NAME,
        "tool_version": TOOL_VERSION,
        "command": "validate",
        "ok": ok,
        "schema": str(Path(args.schema).resolve()),
        "rules": str(Path(args.rules).resolve()) if args.rules else None,
        "configs": results,
        "artifacts": artifacts,
        "summary": {
            "configs_checked": len(results),
            "configs_ok": sum(1 for r in results if r["ok"]),
            "checks_run": sum(len(r["checks"]) for r in results),
            "errors": len(errors),
            "warnings": len(warnings),
        },
    }

    if args.out:
        write_json(args.out, report)
    print(json.dumps(report, indent=2, sort_keys=True) if args.json else _render_validation(report))
    if not ok:
        raise SystemExit(1)


def _render_validation(report):
    lines = []
    for result in report["configs"]:
        status = "ok" if result["ok"] else "FAILED"
        lines.append(
            "[%s] %s (profile=%s, %d keys)"
            % (status, result["path"], result["profile"], result["key_count"])
        )
        for check in result["checks"]:
            lines.append("  %-24s %-4s %s" % (check["name"], check["status"], check["detail"]))
    artifacts = report.get("artifacts")
    if artifacts:
        status = "ok" if artifacts["ok"] else "FAILED"
        lines.append(
            "[%s] artifacts in %s (%d/%d present)"
            % (status, artifacts["directory"], len(artifacts["present"]), len(artifacts["required"]))
        )
        for name in artifacts["missing"]:
            lines.append("  %-24s fail missing artifact" % name)
        for item in artifacts["oversize"]:
            lines.append("  %-24s fail %d bytes > %d" % (item["artifact"], item["bytes"], item["limit"]))
    lines.append(
        "summary: %d/%d configs ok, %d error(s), %d warning(s)"
        % (
            report["summary"]["configs_ok"],
            report["summary"]["configs_checked"],
            report["summary"]["errors"],
            report["summary"]["warnings"],
        )
    )
    return "\n".join(lines)


def cmd_report(args):
    config = load_json(args.config, "config")
    schema = load_json(args.schema, "schema") if args.schema else None
    rules = load_json(args.rules, "rules") if args.rules else None

    if schema is None:
        fail("export-report needs --schema to validate the configuration it reports on")

    result = validate_config(schema, rules, config, args.config)
    artifacts = check_artifacts(rules, args.artifacts) if (rules and args.artifacts) else None

    commands = read_transcript(args.transcript)
    notes = load_json(args.notes, "notes") if args.notes else {}

    report = {
        "tool": TOOL_NAME,
        "tool_version": TOOL_VERSION,
        "command": "export-report",
        "ok": result["ok"] and (artifacts is None or artifacts["ok"]),
        "config_path": str(Path(args.config).resolve()),
        "config": config,
        "validation": result,
        "artifacts": artifacts,
        "commands": commands,
        "command_count": len(commands),
        "notes": notes,
    }
    write_json(args.out, report)
    if not args.quiet:
        print(
            "wrote %s (config ok=%s, %d recorded command(s))"
            % (args.out, result["ok"], len(commands))
        )
    if not result["ok"]:
        raise SystemExit(1)


# --------------------------------------------------------------------------
# cli
# --------------------------------------------------------------------------


def add_transcript_flag(sub_parser):
    # SUPPRESS keeps the value given before the sub-command when the flag is
    # not repeated after it, so both positions work.
    sub_parser.add_argument(
        "--transcript", dest="transcript", default=argparse.SUPPRESS, help=argparse.SUPPRESS
    )


def build_parser():
    parser = argparse.ArgumentParser(
        prog=TOOL_NAME,
        description="Create, update, validate and report flat JSON configurations.",
    )
    parser.add_argument("--version", action="version", version="%s %s" % (TOOL_NAME, TOOL_VERSION))
    parser.add_argument(
        "--transcript",
        default=None,
        metavar="PATH",
        help="record every invocation as a JSON Lines log at PATH",
    )
    sub = parser.add_subparsers(dest="command", required=True, metavar="COMMAND")

    p = sub.add_parser("init", help="compose a flat configuration")
    p.add_argument("--schema", required=True, help="schema document (contract)")
    p.add_argument("--out", required=True, help="configuration file to write")
    p.add_argument("--defaults", default=None, help="defaults document with base_config")
    p.add_argument("--env", default=None, help="environment overrides keyed by profile")
    p.add_argument("--sample", default=None, help="sample profile document (else sample_config_<profile>.json)")
    p.add_argument("--rules", default=None, help="validation rules document")
    p.add_argument("--profile", default=None, help="profile to build (e.g. dev, prod)")
    p.add_argument("-q", "--quiet", action="store_true", help="suppress the status line")
    add_transcript_flag(p)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set", help="set one scalar value on a configuration")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.add_argument("--type", default=None, help="force str, int, float or bool")
    p.add_argument("--schema", default=None, help="reject keys outside the schema")
    p.add_argument("-q", "--quiet", action="store_true", help="suppress the status line")
    add_transcript_flag(p)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate", help="validate configurations against schema and rules")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True, action="append", metavar="PATH")
    p.add_argument("--rules", default=None)
    p.add_argument("--artifacts", default=None, metavar="DIR", help="also check required artifacts in DIR")
    p.add_argument("--out", default=None, help="also write the JSON report here")
    p.add_argument("--json", action="store_true", help="print the JSON report instead of text")
    add_transcript_flag(p)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("export-report", help="write a report describing a configuration and the run")
    p.add_argument("--config", required=True)
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--rules", default=None)
    p.add_argument("--artifacts", default=None, metavar="DIR")
    p.add_argument("--notes", default=None, help="JSON notes to embed (repair description, run details)")
    p.add_argument("--transcript-file", default=None, help="read the command log from here")
    p.add_argument("-q", "--quiet", action="store_true", help="suppress the status line")
    add_transcript_flag(p)
    p.set_defaults(func=cmd_report)

    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    record_invocation(args)
    args.func(args)


if __name__ == "__main__":
    main()
