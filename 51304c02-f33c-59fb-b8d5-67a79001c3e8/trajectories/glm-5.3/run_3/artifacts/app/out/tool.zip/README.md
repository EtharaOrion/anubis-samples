# task-ctl

A standard-library-only CLI that creates, updates, validates and reports a
flat JSON configuration for TASK processing.

A configuration is a **flat JSON object of scalar values**. The contract for a
valid configuration is split across two documents:

* a **schema** (`required_keys`, `scalar_only`, `checksum`, `profile`) — the
  shape every configuration must satisfy;
* optional **rules** (`profiles`, `forbidden_keys`, `required_artifacts`,
  `max_artifact_bytes`) — the policy applied on top of the shape.

`required_keys` is accepted either as a list (the contract form) or as the
legacy comma-separated string.

## Install and run

```bash
./task-ctl --help          # or: python3 cli.py --help
```

## Commands

### init — compose a configuration

```bash
task-ctl init --schema schema.json --defaults defaults.json --out config.json
```

`init` seeds identity and algorithm fields from the schema, layers the scalar
defaults and the flattened `base_config` block on top, and — when `--profile`
is given — applies a sample profile document and the matching environment
override entry. Composition order is:

```
schema  ->  defaults (scalars, then base_config)  ->  sample profile  ->  env overrides
```

Documents may carry `<key>_delta` entries (for example `max_records_delta`),
which are added to the corresponding base value. `--sample` defaults to
`sample_config_<profile>.json` looked up next to the `--env` file. The composed
document is validated before it is written, so an invalid configuration never
reaches disk.

```bash
task-ctl init --schema config_schema.json --defaults defaults.json \
              --env env_overrides.json --profile dev --out profile_dev.json
```

### set — update one scalar

```bash
task-ctl set --config config.json --key max_records --value 100
```

Keys are matched verbatim (no case folding) and values are coerced to the
obvious scalar type — `100` becomes an integer, `strict-local` stays a string.
Pass `--type str|int|float|bool` to force a type, and `--schema` to reject keys
outside the contract.

### validate — check configurations against the contract

```bash
task-ctl validate --schema config_schema.json --config config.json \
                  --rules validation_rules.json --artifacts /path/to/out \
                  --out validation_report.json
```

`--config` may be repeated. Checks per configuration: required keys present,
scalar-only flatness, forbidden keys absent, profile permitted, checksum
algorithm, integer-valued numeric keys, and (as a warning) keys outside the
required set. With `--artifacts`, the required artifact set and the byte budget
from the rules document are checked too. Prints a text summary, writes the full
JSON report to `--out`, and exits non-zero when anything fails.

### export-report — describe a configuration and the run

```bash
task-ctl --transcript run.jsonl export-report --config config.json \
         --schema config_schema.json --rules validation_rules.json \
         --notes repair_notes.json --out report.json
```

The report embeds the configuration, a fresh validation of it, the recorded
command transcript, and any structured notes (for example the repair
description).

## Transcript

Pass `--transcript PATH` (before or after the sub-command) to append one JSON
object per invocation to a JSON Lines log; `export-report` reads it back as the
`commands` section. Entries carry a step counter and the argument vector — no
clocks or random identifiers, so runs stay reproducible.
