# task-ctl

A stdlib-only local CLI that creates, updates, validates and reports a **flat**
JSON configuration for TASK processing. No network, no timestamps, no
randomness: every document is written as canonical JSON (sorted keys, two-space
indent) so a run is byte-for-byte reproducible.

## Commands

```bash
python3 cli.py init --schema schema.json --out config.json            # base profile
python3 cli.py init --schema schema.json --out profile_dev.json --profile dev
python3 cli.py set --config config.json --key max_records --value 100
python3 cli.py validate --schema schema.json --config config.json
python3 cli.py export-report --config config.json --schema schema.json --out report.json
python3 cli.py export-summary --dir out/ --schema schema.json --out out/summary.json \
    --configs out/config.json out/profile_dev.json --validation out/validation_report.json
```

`--log FILE` (any command) appends a record to a run-log JSON list, which
`export-report`/`export-summary` embed as the command transcript.
`--notes FILE` merges a JSON object of authored sections into the report.

## Contract files

Discovered next to `--schema` unless an explicit flag overrides them:

| file | provides |
| --- | --- |
| `schema.json` | `profile`, `producer`, `container`, `checksum`, `required_keys` |
| `defaults.json` | `mode`, and `base_config` numbers plus the `trailer` template |
| `env_overrides.json` | per-profile `mode` and `*_delta` adjustments |
| `sample_config_<profile>.json` | profile name, `checksum`, `*_delta` adjustments |
| `validation_rules.json` | `profiles`, `forbidden_keys`, `required_artifacts`, `max_artifact_bytes` |

`required_keys` is accepted as a list (the contract form) or as a
comma-separated string.

## Validation checks

`validate` passes only when a configuration: carries every required key;
contains none of the forbidden keys (`timestamp`, `generated_at`, `uuid`,
`random_seed`); is flat and scalar-only (no nested objects or arrays); carries a
permitted `profile` (a rules profile or the schema profile); names a supported
`checksum` algorithm (`crc32`); carries a `trailer` of the form
`harbor:cli-config:<profile>:<16-digit sequence>` whose profile segment matches
`profile`; and is at most `max_artifact_bytes` on disk.
It exits `0` when every `--config` passes and `1` otherwise; `--out` writes a
structured report.

`<key>_delta` overrides adjust the corresponding numeric key; any other key is
assigned directly. The `trailer` profile segment is always re-stamped from the
profile being built, so a `dev` configuration carries
`harbor:cli-config:dev:<sequence>`.
