#!/usr/bin/env python3
"""task-ctl: create, update, validate and report flat JSON task configurations.

Stdlib only, no network, fully deterministic: no timestamps and no randomness
ever enter an emitted document, and every document is written as canonical JSON
(sorted keys, two-space indent) so runs are byte-for-byte reproducible.

Contract files consumed next to --schema (all auto-discovered, all overridable):
  schema.json         profile/producer/container/checksum + required_keys
  defaults.json       base values (mode, base_config numbers, trailer template)
  env_overrides.json  per-profile mode and *_delta adjustments
  sample_config_*.json  per-profile profile/checksum and *_delta adjustments
  validation_rules.json  profiles, forbidden_keys, required_artifacts, size cap
"""
from __future__ import annotations

import argparse
import json
import sys
import zlib
from pathlib import Path

TOOL_NAME = "task-ctl"
TOOL_VERSION = "1.1.0"

CHECKSUM_ALGORITHMS = ("crc32",)
DEFAULT_FORBIDDEN_KEYS = ("timestamp", "generated_at", "uuid", "random_seed")

TRAILER_SEGMENTS = 4
TRAILER_PROFILE_SEGMENT = 2
TRAILER_SEQUENCE_SEGMENT = 3
TRAILER_SEQUENCE_DIGITS = 16

SCALAR_TYPES = (str, int, float, bool)


# ---------------------------------------------------------------- io helpers


def fail(message: str) -> None:
    """Abort with a diagnostic; SystemExit(str) exits 1 and prints to stderr."""
    raise SystemExit(f"{TOOL_NAME}: error: {message}")


def load_json(path: str, what: str):
    file = Path(path)
    if not file.is_file():
        fail(f"{what} file not found: {path}")
    try:
        return json.loads(file.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        fail(f"{what} file {path} is not valid JSON: {exc}")


def write_json(path: str, data) -> str:
    file = Path(path)
    file.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(data, indent=2, sort_keys=True) + "\n"
    file.write_text(payload, encoding="utf-8")
    return payload


def canonical_text(data) -> str:
    """Compact, key-sorted rendering; the basis for any content checksum."""
    return json.dumps(data, sort_keys=True, separators=(",", ":"))


def content_checksum(data, algorithm: str) -> int:
    if algorithm not in CHECKSUM_ALGORITHMS:
        fail(f"unsupported checksum algorithm {algorithm!r} (expected one of {CHECKSUM_ALGORITHMS})")
    return zlib.crc32(canonical_text(data).encode("utf-8")) & 0xFFFFFFFF


# ------------------------------------------------------------- value coercion


def coerce_scalar(raw):
    """argparse delivers every --value as a string; store the JSON scalar it denotes."""
    if raw is None or isinstance(raw, (int, float, bool)):
        return raw
    text = str(raw).strip()
    lowered = text.lower()
    if lowered in ("true", "yes", "on"):
        return True
    if lowered in ("false", "no", "off"):
        return False
    if lowered in ("null", "none"):
        return None
    if "e" in lowered or "." in text or "_" in text:
        # floats keep their literal form; underscores are not numeric JSON
        try:
            value = float(text)
        except ValueError:
            return text
        if value != value or value in (float("inf"), float("-inf")):
            return text  # NaN/Infinity are not representable in JSON
        return value
    try:
        return int(text, 10)
    except ValueError:
        return text


def is_scalar(value) -> bool:
    return isinstance(value, SCALAR_TYPES) or value is None


def resolve_key(key: str, existing) -> str:
    """Fold the requested key onto an existing key, else use contract lower-case."""
    wanted = key.strip().lower()
    for known in existing:
        if known.lower() == wanted:
            return known
    return wanted


# --------------------------------------------------------- contract discovery


def sidecar(explicit, anchor, filename: str, required: bool = True):
    """An explicit --flag wins; otherwise look for the file next to the anchor path."""
    if explicit:
        file = Path(explicit)
        if not file.is_file():
            fail(f"{filename} not found at {explicit}")
        return file
    if not anchor:
        if required:
            fail(f"{filename} was not given and there is no anchor path to search beside")
        return None
    candidate = Path(anchor).resolve().parent / filename
    if candidate.is_file():
        return candidate
    if required:
        fail(f"{filename} was not found next to {anchor}; pass an explicit path")
    return None


def rules_for(explicit, anchor: str) -> dict:
    """Load validation rules from an explicit path or from beside another file."""
    path = sidecar(explicit, anchor, "validation_rules.json", required=False)
    return load_json(path, "rules") if path else {}


def required_keys_from(schema) -> list:
    """The contract schema lists required_keys; the bundled one uses a comma string."""
    raw = schema.get("required_keys", [])
    if isinstance(raw, str):
        keys = [part.strip() for part in raw.split(",")]
    elif isinstance(raw, list):
        keys = [str(part).strip() for part in raw]
    else:
        fail("schema field 'required_keys' must be a list or a comma-separated string")
    keys = [key for key in keys if key]
    if not keys:
        fail("schema field 'required_keys' is empty")
    return keys


def forbidden_keys_from(rules) -> list:
    keys = rules.get("forbidden_keys", list(DEFAULT_FORBIDDEN_KEYS))
    return list(keys) or list(DEFAULT_FORBIDDEN_KEYS)


def guard_key(key: str, rules) -> None:
    if key in forbidden_keys_from(rules):
        fail(f"{key!r} is a forbidden configuration key")


# ------------------------------------------------------------------ build


def apply_overrides(config: dict, overrides: dict, source: str, rules) -> list:
    """Apply plain keys and <key>_delta adjustments; return what was applied."""
    applied = []
    for key in sorted(overrides):
        value = overrides[key]
        if key.endswith("_delta"):
            target = key[: -len("_delta")]
            if target not in config:
                fail(f"{source}: {key} targets unknown key {target!r}")
            current = config[target]
            if not isinstance(current, (int, float)) or isinstance(current, bool):
                fail(f"{source}: {key} needs a numeric {target}, got {current!r}")
            config[target] = current + value
            applied.append({"key": target, "from": current, "to": config[target], "via": key, "source": source})
        else:
            guard_key(key, rules)
            config[key] = value
            applied.append({"key": key, "value": value, "source": source})
    return applied


def build_trailer(template: str, profile: str) -> str:
    """harbour:cli-config:<profile>:<16-digit sequence> — stamp the owning profile."""
    parts = template.split(":")
    if len(parts) != TRAILER_SEGMENTS:
        return template
    parts[TRAILER_PROFILE_SEGMENT] = profile
    return ":".join(parts)


def build_config(schema, defaults, rules, profile=None, env_overrides=None, sample=None):
    """schema identity fields + defaults + optional profile deltas, flat and scalar."""
    base = defaults.get("base_config")
    if not isinstance(base, dict):
        fail("defaults file needs a 'base_config' object")

    config = {"profile": schema.get("profile", "")}
    for field in ("producer", "container", "checksum"):
        config[field] = schema.get(field, defaults.get(field, ""))
    config["mode"] = defaults.get("mode", "")
    for key in sorted(base):
        guard_key(key, rules)
        config[key] = base[key]
    config["trailer"] = build_trailer(str(base.get("trailer", "")), config["profile"])

    applied = []
    if profile:
        if sample:
            applied += apply_overrides(config, sample, f"sample:{profile}", rules)
        if env_overrides:
            applied += apply_overrides(config, env_overrides, f"env:{profile}", rules)
        # The sample names the profile it describes; it wins over the schema default.
        config["profile"] = profile
        config["trailer"] = build_trailer(str(base.get("trailer", "")), profile)

    for key, value in list(config.items()):
        if not is_scalar(value):
            fail(f"assembled config has a non-scalar value for {key!r}")

    order = {key: index for index, key in enumerate(required_keys_from(schema))}
    config = dict(sorted(config.items(), key=lambda item: (order.get(item[0], len(order)), item[0])))
    return config, applied


# ------------------------------------------------------------------ validate


def trailer_problems(trailer, profile) -> list:
    problems = []
    parts = str(trailer).split(":")
    if len(parts) != TRAILER_SEGMENTS:
        return [f"trailer {trailer!r} is not 'harbor:cli-config:<profile>:<16-digit sequence>'"]
    if parts[TRAILER_PROFILE_SEGMENT] != str(profile):
        problems.append(f"trailer names profile {parts[TRAILER_PROFILE_SEGMENT]!r}, config says {profile!r}")
    sequence = parts[TRAILER_SEQUENCE_SEGMENT]
    if not (sequence.isdigit() and len(sequence) == TRAILER_SEQUENCE_DIGITS):
        problems.append(f"trailer sequence {sequence!r} is not {TRAILER_SEQUENCE_DIGITS} digits")
    return problems


def validate_config(config, config_path: str, schema, rules, byte_size=None) -> dict:
    checks = []

    def check(name: str, ok: bool, detail: str):
        checks.append({"name": name, "ok": bool(ok), "detail": detail})

    required = required_keys_from(schema)
    forbidden = forbidden_keys_from(rules)

    missing = [key for key in required if key not in config]
    check(
        "required_keys",
        not missing,
        f"{len(required) - len(missing)}/{len(required)} present"
        + (f"; missing: {', '.join(missing)}" if missing else ""),
    )

    present = [key for key in forbidden if key in config]
    check(
        "forbidden_keys",
        not present,
        f"{len(forbidden)} forbidden keys checked"
        + (f"; found: {', '.join(present)}" if present else "; none present"),
    )

    nested = [key for key, value in config.items() if isinstance(value, (dict, list))]
    non_scalar = [key for key, value in config.items() if not is_scalar(value)]
    scalar_only = bool(schema.get("scalar_only", True))
    violations = sorted(set(nested) | (set(non_scalar) if scalar_only else set()))
    detail = (
        f"nested values at: {', '.join(violations)}"
        if violations
        else f"{len(config)} keys, all scalar; configuration is flat"
    )
    check("flat_scalar_only", not violations, detail)

    allowed = list(rules.get("profiles", [])) + [schema.get("profile")]
    profile = config.get("profile")
    check(
        "profile",
        profile in allowed,
        f"profile {profile!r}"
        + (" is permitted" if profile in allowed else f" is not in {allowed}"),
    )

    algorithm = config.get("checksum")
    check(
        "checksum_algorithm",
        algorithm in CHECKSUM_ALGORITHMS,
        f"checksum {algorithm!r}"
        + ("" if algorithm in CHECKSUM_ALGORITHMS else f" not in {CHECKSUM_ALGORITHMS}"),
    )

    problems = trailer_problems(config.get("trailer", ""), profile)
    check("trailer_consistency", not problems, "; ".join(problems) or "trailer matches profile and sequence format")

    limit = int(rules.get("max_artifact_bytes", 0)) or None
    size = byte_size if byte_size is not None else (
        Path(config_path).stat().st_size if Path(config_path).is_file() else -1
    )
    check(
        "artifact_size",
        size >= 0 and (limit is None or size <= limit),
        f"{size} bytes" + (f" (limit {limit})" if limit else ""),
    )

    errors = [f"{c['name']}: {c['detail']}" for c in checks if not c["ok"]]
    return {
        "config": str(config_path),
        "profile": profile,
        "keys": sorted(config),
        "byte_size": size if size >= 0 else None,
        "checksum": content_checksum(config, algorithm) if algorithm in CHECKSUM_ALGORITHMS else None,
        "checks": checks,
        "errors": errors,
        "ok": not errors,
    }


# ------------------------------------------------------------------ run log


def load_log(log_path):
    if not log_path:
        return []
    file = Path(log_path)
    if not file.is_file():
        return []
    log = load_json(log_path, "run log")
    if not isinstance(log, list):
        fail(f"run log {log_path} must hold a JSON list")
    return log


def record_run(log_path, command: str, arguments: dict, ok: bool, detail: str) -> None:
    if not log_path:
        return
    log = load_log(log_path)
    log.append(
        {
            "seq": len(log) + 1,
            "command": command,
            "command_line": TOOL_NAME + " " + " ".join(sys.argv[1:]),
            "arguments": arguments,
            "ok": ok,
            "detail": detail,
        }
    )
    write_json(log_path, log)


# ------------------------------------------------------------------ commands


def cmd_init(args):
    schema_path = Path(args.schema)
    schema = load_json(schema_path, "schema")
    defaults_path = sidecar(args.defaults, args.schema, "defaults.json")
    rules = rules_for(args.rules, args.schema)
    defaults = load_json(defaults_path, "defaults")

    env_path = None
    sample_path = None
    env_overrides = None
    sample = None
    if args.profile:
        if rules.get("profiles") and args.profile not in rules["profiles"]:
            fail(f"unknown profile {args.profile!r}; rules allow {rules['profiles']}")
        env_path = sidecar(args.env_overrides, args.schema, "env_overrides.json")
        sample_path = sidecar(args.sample, args.schema, f"sample_config_{args.profile}.json")
        env_overrides = load_json(env_path, "env overrides").get(args.profile)
        if env_overrides is None:
            fail(f"env overrides have no entry for profile {args.profile!r}")
        sample = load_json(sample_path, "sample profile")

    config, applied = build_config(schema, defaults, rules, args.profile, env_overrides, sample)

    # Validate the payload in memory first, so a bad contract never reaches disk.
    payload = json.dumps(config, indent=2, sort_keys=True) + "\n"
    report = validate_config(config, args.out, schema, rules, byte_size=len(payload.encode("utf-8")))
    if not report["ok"]:
        fail(f"assembled config is invalid: {'; '.join(report['errors'])}")
    write_json(args.out, config)

    record_run(
        args.log,
        "init",
        {"schema": str(schema_path), "out": args.out, "profile": args.profile,
         "defaults": str(defaults_path) if defaults_path else None,
         "env_overrides": str(env_path) if env_path else None,
         "sample": str(sample_path) if sample_path else None},
        True,
        f"wrote {args.out} ({report['byte_size']} bytes, profile {config['profile']!r}, "
        f"{len(applied)} profile adjustments applied)",
    )
    print(f"wrote {args.out} ({report['byte_size']} bytes, profile {config['profile']})")


def cmd_set(args):
    rules = rules_for(args.rules, args.config)
    config = load_json(args.config, "config")
    if not isinstance(config, dict):
        fail(f"{args.config} does not hold a JSON object")

    key = resolve_key(args.key, config)
    guard_key(key, rules)
    value = coerce_scalar(args.value)
    if not is_scalar(value):
        fail(f"refusing to store a non-scalar value for {key!r}")

    previous = config.get(key)
    config[key] = value
    write_json(args.config, config)
    record_run(
        args.log,
        "set",
        {"config": args.config, "key": key, "value": value},
        True,
        f"set {key}: {previous!r} -> {value!r} ({type(value).__name__})",
    )
    print(f"set {key} = {value!r} (was {previous!r})")


def cmd_validate(args):
    schema = load_json(args.schema, "schema")
    rules = rules_for(args.rules, args.schema)
    paths = args.config
    results = [validate_config(load_json(path, "config"), path, schema, rules) for path in paths]
    passed = sum(1 for result in results if result["ok"])
    report = {
        "ok": passed == len(results),
        "tool": TOOL_NAME,
        "version": TOOL_VERSION,
        "schema": str(Path(args.schema)),
        "rules": str(Path(args.rules)) if args.rules else None,
        "results": results,
        "summary": {"configs": len(results), "passed": passed, "failed": len(results) - passed},
    }
    if args.out:
        write_json(args.out, report)
    for result in results:
        status = "ok" if result["ok"] else "FAILED"
        print(f"{status} {result['config']} (profile {result['profile']})")
        for error in result["errors"]:
            print(f"  - {error}", file=sys.stderr)
    record_run(
        args.log,
        "validate",
        {"schema": str(Path(args.schema)), "configs": list(paths), "out": args.out},
        report["ok"],
        f"validated {len(results)} config(s): {passed} passed, {len(results) - passed} failed",
    )
    if not report["ok"]:
        raise SystemExit(1)


def cmd_report(args):
    schema_path = Path(args.schema)
    schema = load_json(schema_path, "schema")
    rules = rules_for(args.rules, args.schema)
    config = load_json(args.config, "config")
    result = validate_config(config, args.config, schema, rules)
    transcript = load_log(args.log)
    report = {
        "ok": result["ok"],
        "tool": TOOL_NAME,
        "version": TOOL_VERSION,
        "schema": str(schema_path) if schema_path else None,
        "config": {
            "path": str(Path(args.config)),
            "profile": config.get("profile"),
            "keys": sorted(config),
            "byte_size": result["byte_size"],
            "crc32": result["checksum"],
            "body": config,
        },
        "validation": result,
        "commands": transcript,
        "command_count": len(transcript),
    }
    if args.notes:
        notes = load_json(args.notes, "notes")
        if not isinstance(notes, dict):
            fail("notes file must hold a JSON object")
        for section, payload in notes.items():
            report[section] = payload
    write_json(args.out, report)
    record_run(
        args.log,
        "export-report",
        {"config": args.config, "out": args.out, "notes": args.notes},
        report["ok"],
        f"wrote {args.out} from {args.config} with {len(transcript)} recorded command(s)",
    )
    print(f"wrote {args.out} (ok={report['ok']}, {len(transcript)} commands recorded)")


def cmd_summary(args):
    schema = load_json(args.schema, "schema")
    rules_path = sidecar(args.rules, args.schema, "validation_rules.json", required=False)
    rules = load_json(rules_path, "rules") if rules_path else {}
    out_dir = Path(args.dir)

    required = list(rules.get("required_artifacts", []))
    limit = int(rules.get("max_artifact_bytes", 0)) or None
    artifacts = []
    for name in sorted(set(required) | {Path(args.out).name}):
        file = out_dir / name
        size = file.stat().st_size if file.is_file() else None
        artifacts.append(
            {
                "name": name,
                "path": str(file),
                "exists": file.is_file(),
                "bytes": size,
                "within_limit": size is not None and (limit is None or size <= limit),
            }
        )

    configs = {}
    for path in args.configs:
        file = Path(path)
        if not file.is_file():
            configs[file.name] = {"path": str(file), "exists": False, "ok": False, "errors": ["file not found"]}
            continue
        body = load_json(path, "config")
        result = validate_config(body, path, schema, rules)
        configs[file.name] = {
            "path": str(file),
            "exists": True,
            "profile": body.get("profile"),
            "byte_size": result["byte_size"],
            "crc32": result["checksum"],
            "ok": result["ok"],
            "errors": result["errors"],
            "body": body,
        }

    validation = load_json(args.validation, "validation report") if args.validation else None
    missing = [item["name"] for item in artifacts if not item["exists"]]
    oversize = [item["name"] for item in artifacts if item["exists"] and not item["within_limit"]]
    configs_ok = all(entry.get("ok") for entry in configs.values())
    summary = {
        "ok": not missing and not oversize and configs_ok and bool(validation) and validation.get("ok", False),
        "tool": TOOL_NAME,
        "version": TOOL_VERSION,
        "schema": str(Path(args.schema)),
        "rules": str(rules_path) if rules_path else None,
        "deliverables": {
            "directory": str(out_dir),
            "required_artifacts": required,
            "artifacts": artifacts,
            "missing": missing,
            "oversize": oversize,
            "byte_limit": limit,
            "extra_files": sorted(
                p.name for p in out_dir.iterdir() if p.is_file() and p.name not in required
            ),
        },
        "configs": configs,
        "validation_report": {
            "path": str(Path(args.validation)) if args.validation else None,
            "ok": validation.get("ok") if validation else None,
            "summary": validation.get("summary") if validation else None,
        },
        "command_count": len(load_log(args.log)),
        "commands": load_log(args.log),
    }
    if args.notes:
        notes = load_json(args.notes, "notes")
        if not isinstance(notes, dict):
            fail("notes file must hold a JSON object")
        for section, payload in notes.items():
            summary[section] = payload
    write_json(args.out, summary)
    record_run(
        args.log,
        "export-summary",
        {"dir": args.dir, "out": args.out, "rules": str(rules_path) if rules_path else None,
         "configs": list(args.configs), "validation": args.validation},
        summary["ok"],
        f"wrote {args.out}: {len(artifacts)} artifact(s) checked, {len(missing)} missing, "
        f"{len(oversize)} oversize, {len(configs)} config(s) validated",
    )
    print(f"wrote {args.out} (ok={summary['ok']})")
    if not summary["ok"]:
        raise SystemExit(1)


# ------------------------------------------------------------------ cli


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog=TOOL_NAME, description=__doc__.splitlines()[0])
    sub = parser.add_subparsers(dest="command", required=True, metavar="COMMAND")

    p = sub.add_parser("init", help="build a configuration from schema, defaults and profile deltas")
    p.add_argument("--schema", required=True, help="contract schema (JSON)")
    p.add_argument("--out", required=True, help="configuration file to write")
    p.add_argument("--defaults", help="defaults file (default: defaults.json beside the schema)")
    p.add_argument("--rules", help="validation rules file (default: validation_rules.json beside the schema)")
    p.add_argument("--env-overrides", help="per-profile overrides (default: env_overrides.json beside the schema)")
    p.add_argument("--sample", help="sample profile file (default: sample_config_<profile>.json beside the schema)")
    p.add_argument("--profile", help="environment profile to build (e.g. dev, prod)")
    p.add_argument("--log", help="append a record of this command to a run-log JSON file")
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set", help="set one scalar key on an existing configuration")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.add_argument("--rules", help="validation rules file, for the forbidden-key list")
    p.add_argument("--log")
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate", help="validate configuration file(s) against the contract")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", action="append", required=True, metavar="PATH")
    p.add_argument("--rules", help="validation rules file (default: validation_rules.json beside the schema)")
    p.add_argument("--out", help="write the structured validation report here")
    p.add_argument("--log")
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("export-report", help="write a report describing a configuration and the run")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--schema", required=True)
    p.add_argument("--rules", help="validation rules file")
    p.add_argument("--log", help="run log to embed as the command transcript")
    p.add_argument("--notes", help="JSON object merged into the report (repair notes, decisions)")
    p.set_defaults(func=cmd_report)

    p = sub.add_parser("export-summary", help="check required artifacts and summarise the whole run")
    p.add_argument("--dir", required=True, help="deliverables directory")
    p.add_argument("--out", required=True)
    p.add_argument("--schema", required=True)
    p.add_argument("--rules")
    p.add_argument("--configs", nargs="*", default=[], help="configuration files to revalidate")
    p.add_argument("--validation", help="validation report written by 'validate --out'")
    p.add_argument("--log")
    p.add_argument("--notes")
    p.set_defaults(func=cmd_summary)

    return parser


def main(argv=None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)
    # Subparsers are required, so func is always present; guard anyway for API callers.
    func = getattr(args, "func", None)
    if func is None:
        parser.print_usage(sys.stderr)
        raise SystemExit(f"{TOOL_NAME}: error: a command is required")
    func(args)


if __name__ == "__main__":
    main()
