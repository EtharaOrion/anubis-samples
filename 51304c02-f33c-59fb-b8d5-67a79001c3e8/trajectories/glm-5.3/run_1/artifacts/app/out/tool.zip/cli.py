#!/usr/bin/env python3
"""task-ctl: create, update, validate and report flat JSON configurations.

The tool is stdlib-only.  A configuration is a flat map of scalar values whose
shape is described by a schema document; optional defaults, environment
override and sample profile documents supply the values.  Everything the tool
writes is deterministic: no clocks, counters based on run length, or random
values are involved, so the same inputs always produce the same bytes.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path

TOOL_NAME = "task-ctl"
TOOL_VERSION = "1.1.0"

SCALAR_TYPES = (str, int, float, bool)
DELTA_SUFFIX = "_delta"
VALUE_TYPES = ("auto", "str", "bool", "int", "float")


class ToolError(Exception):
    """A fatal, user facing error."""


# ---------------------------------------------------------------- io helpers

def load_json(path, what="document"):
    """Load a JSON document or fail with a one line diagnostic."""
    try:
        text = Path(path).read_text(encoding="utf-8")
    except OSError as exc:
        raise ToolError("cannot read %s %s: %s" % (what, path, exc.strerror or exc)) from None
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        raise ToolError("%s %s is not valid JSON: %s" % (what, path, exc)) from None


def write_json(path, data):
    """Write pretty JSON atomically so a failure cannot leave a half file."""
    target = Path(path)
    tmp = target.with_name(target.name + ".tmp")
    with tmp.open("w", encoding="utf-8") as handle:
        handle.write(json.dumps(data, indent=2) + "\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, target)


def is_scalar(value):
    return isinstance(value, SCALAR_TYPES) and value is not None


def required_keys(schema):
    """Read required_keys from a schema, accepting list or comma string form."""
    raw = schema.get("required_keys")
    if raw is None:
        return []
    if isinstance(raw, str):
        return [key.strip() for key in raw.split(",") if key.strip()]
    if isinstance(raw, list):
        return [str(key) for key in raw]
    raise ToolError("schema field 'required_keys' must be a list or a comma separated string")


def forbidden_keys(rules):
    raw = rules.get("forbidden_keys", [])
    if isinstance(raw, str):
        return [key.strip() for key in raw.split(",") if key.strip()]
    return [str(key) for key in raw]


# -------------------------------------------------------------- run transcript

def read_transcript(path):
    """Read a transcript, treating a not yet created file as empty."""
    if not path:
        return {"steps": []}
    target = Path(path)
    if not target.exists():
        return {"steps": []}
    document = load_json(path, "transcript")
    if not isinstance(document, dict) or not isinstance(document.get("steps"), list):
        raise ToolError("transcript %s must be an object with a 'steps' list" % path)
    return document


def record_step(path, args, result):
    """Append one step to the transcript.  Steps are numbered by position so
    that the transcript stays deterministic (no clock or random identifiers)."""
    if not path:
        return
    try:
        transcript = read_transcript(path)
    except ToolError as exc:
        # a broken log must never cost the user the command that just ran
        print("%s: warning: step not recorded: %s" % (TOOL_NAME, exc), file=sys.stderr)
        return
    fields = {key: value for key, value in vars(args).items() if key not in ("func", "transcript")}
    step = {
        "step": len(transcript["steps"]) + 1,
        "command": args.command,
        "argv": sys.argv[1:],
        "args": fields,
        "result": result,
    }
    transcript["steps"].append(step)
    write_json(path, transcript)


# ------------------------------------------------------------ value coercion

def kind_of(value):
    """Name of the scalar type of an existing config value."""
    if isinstance(value, bool):  # bool is a subclass of int: test it first
        return "bool"
    if isinstance(value, int):
        return "int"
    if isinstance(value, float):
        return "float"
    return "str"


def coerce_value(raw, kind="auto"):
    """Turn a command line string into the scalar value stored in the config."""
    text = str(raw).strip()
    if kind == "auto":
        lowered = text.lower()
        if lowered in ("true", "false"):
            return lowered == "true"
        try:
            return int(text, 10)
        except ValueError:
            pass
        try:
            return float(text)
        except ValueError:
            pass
        return str(raw)
    if kind == "str":
        return str(raw)
    if kind == "bool":
        lowered = text.lower()
        if lowered in ("true", "1", "yes", "on"):
            return True
        if lowered in ("false", "0", "no", "off"):
            return False
        raise ToolError("cannot read %r as a boolean" % raw)
    if kind == "int":
        try:
            return int(text, 10)
        except ValueError:
            raise ToolError("cannot read %r as an integer" % raw) from None
    if kind == "float":
        try:
            return float(text)
        except ValueError:
            raise ToolError("cannot read %r as a number" % raw) from None
    raise ToolError("unknown value type %r (choose from %s)" % (kind, ", ".join(VALUE_TYPES)))


# ------------------------------------------------------------- configuration

def order_keys(data, keys):
    """Emit required keys first in schema order, then any extras sorted."""
    ordered = {key: data[key] for key in keys if key in data}
    for key in sorted(set(data) - set(keys)):
        ordered[key] = data[key]
    return ordered


def apply_layer(data, source, label):
    """Copy direct (non delta) scalar keys from an override layer."""
    for key, value in source.items():
        if key.endswith(DELTA_SUFFIX):
            continue
        if not is_scalar(value):
            raise ToolError("%s field %r must be a scalar value" % (label, key))
        data[key] = value


def apply_deltas(data, source, label):
    """Apply <key>_delta offsets to the current numeric value of <key>."""
    for key, value in source.items():
        if not key.endswith(DELTA_SUFFIX):
            continue
        target = key[: -len(DELTA_SUFFIX)]
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ToolError("%s field %r must be a number" % (label, key))
        current = data.get(target)
        if isinstance(current, bool) or not isinstance(current, (int, float)):
            raise ToolError(
                "cannot apply %s field %r: %r is %r" % (label, key, target, current))
        data[target] = current + value


def compose_config(schema, defaults, env_overrides, sample, profile):
    """Build a flat configuration from a schema and the override documents.

    Precedence, weakest to strongest: schema, defaults, defaults.base_config,
    sample profile, environment overrides.  Delta fields are applied after all
    direct layers, sample deltas before environment deltas.
    """
    data = {}
    for key in ("profile", "producer", "container", "checksum"):
        if key in schema:
            data[key] = schema[key]
    for key, value in defaults.items():
        if key != "base_config" and is_scalar(value):
            data[key] = value
    for key, value in (defaults.get("base_config") or {}).items():
        if is_scalar(value):
            data[key] = value
    apply_layer(data, sample, "sample")
    apply_layer(data, env_overrides, "env overrides")
    if profile:
        data["profile"] = profile
    apply_deltas(data, sample, "sample")
    apply_deltas(data, env_overrides, "env overrides")
    return data


# ---------------------------------------------------------------- validation

def declared_types(defaults):
    """Key to declared value map taken from a defaults document."""
    if not isinstance(defaults, dict):
        return {}
    declared = {key: value for key, value in defaults.items()
                if key != "base_config" and is_scalar(value)}
    declared.update({key: value for key, value in (defaults.get("base_config") or {}).items()
                     if is_scalar(value)})
    return declared


def same_type(expected, actual):
    """Compare two scalars by JSON type; numbers count as one family."""
    if isinstance(expected, bool) or isinstance(actual, bool):
        return isinstance(expected, bool) and isinstance(actual, bool)
    if isinstance(expected, (int, float)) and isinstance(actual, (int, float)):
        return True
    return kind_of(expected) == kind_of(actual)


def validate_config(path, data, schema, rules, defaults=None):
    """Check one configuration against the schema and the validation rules."""
    errors = []
    warnings = []
    keys = required_keys(schema)
    forbidden = forbidden_keys(rules)

    missing = [key for key in keys if key not in data]
    if missing:
        errors.append("missing required keys: " + ", ".join(missing))

    present_forbidden = sorted(set(data) & set(forbidden))
    if present_forbidden:
        errors.append("forbidden keys present: " + ", ".join(present_forbidden))

    non_scalar = sorted(key for key, value in data.items() if not is_scalar(value))
    if non_scalar:
        errors.append("configuration must be flat: " + ", ".join(non_scalar))

    declared = declared_types(defaults)
    type_mismatches = ["%s is %s, expected %s" % (key, kind_of(data[key]), kind_of(expected))
                       for key, expected in sorted(declared.items())
                       if key in data and not same_type(expected, data[key])]
    if type_mismatches:
        errors.append("value types disagree with the defaults: "
                      + "; ".join(type_mismatches))

    unknown = sorted(set(data) - set(keys))
    if unknown:
        warnings.append("keys outside the schema: " + ", ".join(unknown))

    expected_checksum = schema.get("checksum")
    if expected_checksum is not None and "checksum" in data:
        if data["checksum"] != expected_checksum:
            errors.append(
                "checksum %r does not match the schema algorithm %r"
                % (data["checksum"], expected_checksum))

    allowed_profiles = [p for p in rules.get("profiles", []) if isinstance(p, str)]
    if schema.get("profile") is not None:
        allowed_profiles.append(schema["profile"])
    profile = data.get("profile")
    profile_state = "unchecked"
    if profile is not None and allowed_profiles:
        if profile in allowed_profiles:
            profile_state = "allowed"
        else:
            profile_state = "rejected"
            errors.append(
                "profile %r is not one of: %s" % (profile, ", ".join(map(str, allowed_profiles))))

    empty_required = [key for key in keys
                      if isinstance(data.get(key), str) and data[key] == ""]
    if empty_required:
        warnings.append("required keys left empty: " + ", ".join(empty_required))

    config_bytes = None
    if path is not None:
        try:
            config_bytes = Path(path).stat().st_size
        except OSError as exc:
            errors.append("cannot stat %s: %s" % (path, exc.strerror or exc))
    max_bytes = rules.get("max_artifact_bytes")
    if config_bytes is not None and isinstance(max_bytes, int) and config_bytes > max_bytes:
        errors.append("config is %d bytes, over the %d byte limit" % (config_bytes, max_bytes))

    return {
        "config": str(path) if path else None,
        "ok": not errors,
        "errors": errors,
        "warnings": warnings,
        "checks": {
            "required_keys": keys,
            "missing_keys": missing,
            "forbidden_keys": forbidden,
            "forbidden_present": present_forbidden,
            "non_scalar_keys": non_scalar,
            "type_mismatches": type_mismatches,
            "declared_types": sorted(declared),
            "unknown_keys": unknown,
            "scalar_only": bool(schema.get("scalar_only", True)),
            "profile": profile,
            "allowed_profiles": allowed_profiles,
            "profile_state": profile_state,
            "checksum": data.get("checksum"),
            "expected_checksum": expected_checksum,
            "config_bytes": config_bytes,
            "max_artifact_bytes": max_bytes,
        },
    }


# ------------------------------------------------------------------ commands

def cmd_init(args):
    schema = load_json(args.schema, "schema")
    defaults = load_json(args.defaults, "defaults") if args.defaults else {}
    sample = load_json(args.sample, "sample") if args.sample else {}
    all_overrides = load_json(args.env_overrides, "env overrides") if args.env_overrides else {}
    if not isinstance(defaults, dict) or not isinstance(sample, dict) or not isinstance(all_overrides, dict):
        raise ToolError("defaults, sample and env override documents must be objects")

    profile = args.profile or sample.get("profile")
    env_overrides = {}
    if profile is not None:
        env_overrides = all_overrides.get(profile)
        if env_overrides is None:
            if args.env_overrides:
                raise ToolError("env overrides %s have no entry for profile %r"
                                % (args.env_overrides, profile))
            env_overrides = {}
        elif not isinstance(env_overrides, dict):
            raise ToolError("env overrides for profile %r must be an object" % profile)

    data = compose_config(schema, defaults, env_overrides, sample, profile)
    keys = required_keys(schema)
    missing = [key for key in keys if key not in data]
    if missing:
        raise ToolError("cannot build a complete configuration, missing: "
                        + ", ".join(missing)
                        + " (supply --defaults / --sample / --env-overrides)")
    data = order_keys(data, keys)
    rules = load_json(args.rules, "rules") if args.rules else {}
    composed_forbidden = sorted(set(data) & set(forbidden_keys(rules)))
    if composed_forbidden:
        raise ToolError("refusing to write forbidden keys: " + ", ".join(composed_forbidden))
    write_json(args.out, data)
    summary = "wrote %s (%d keys, profile=%s)" % (args.out, len(data), data.get("profile"))
    print(summary)
    return summary


def cmd_set(args):
    rules = load_json(args.rules, "rules") if args.rules else {}
    data = load_json(args.config, "config")
    if not isinstance(data, dict):
        raise ToolError("config %s must be a JSON object" % args.config)

    key = args.key.strip().lower()
    if not key:
        raise ToolError("key must not be empty")
    if not re.fullmatch(r"[A-Za-z0-9_.-]+", key):
        raise ToolError("key %r may only contain letters, digits, '_', '-' and '.'" % args.key)
    if key in forbidden_keys(rules):
        raise ToolError("key %r is forbidden by the validation rules" % key)

    kind = args.type
    if kind is None and is_scalar(data.get(key)):
        # keep the type the key already carries so values stay scalars
        kind = kind_of(data[key])
    value = coerce_value(args.value, kind)
    if not is_scalar(value):
        raise ToolError("value for %r must be a scalar" % key)

    previous = data.get(key, None)
    data[key] = value
    write_json(args.config, data)
    summary = "set %s=%r (%s, was %r)" % (key, value, kind_of(value), previous)
    print(summary)
    return summary


def cmd_validate(args):
    schema = load_json(args.schema, "schema")
    rules = load_json(args.rules, "rules") if args.rules else {}
    defaults = load_json(args.defaults, "defaults") if args.defaults else {}
    results = [validate_config(path, load_json(path, "config"), schema, rules, defaults)
               for path in args.config]
    ok = all(result["ok"] for result in results)
    report = {
        "tool": TOOL_NAME,
        "version": TOOL_VERSION,
        "command": "validate",
        "schema": str(Path(args.schema)),
        "rules": str(Path(args.rules)) if args.rules else None,
        "defaults": str(Path(args.defaults)) if args.defaults else None,
        "ok": ok,
        "valid_count": sum(1 for result in results if result["ok"]),
        "config_count": len(results),
        "results": results,
    }
    if args.out:
        write_json(args.out, report)

    for result in results:
        if result["ok"]:
            print("valid: %s" % result["config"])
        else:
            print("invalid: %s" % result["config"])
            for error in result["errors"]:
                print("  error: %s" % error, file=sys.stderr)
        for warning in result["warnings"]:
            print("  warning: %s" % warning, file=sys.stderr)
    if not ok:
        raise ToolError("validation failed for %d of %d config(s)"
                        % (len(results) - report["valid_count"], len(results)))
    print("ok")
    return "validated %d config(s) against %s: ok" % (len(results), args.schema)


def cmd_report(args):
    data = load_json(args.config, "config")
    schema = load_json(args.schema, "schema") if args.schema else {}
    rules = load_json(args.rules, "rules") if args.rules else {}
    if not isinstance(data, dict):
        raise ToolError("config %s must be a JSON object" % args.config)

    result = (validate_config(args.config, data, schema, rules,
                              load_json(args.defaults, "defaults") if args.defaults else {})
              if args.schema else None)
    repairs = load_json(args.repair_log, "repair log") if args.repair_log else []
    if not isinstance(repairs, list):
        raise ToolError("repair log %s must be a list of entries" % args.repair_log)

    # this command is recorded first so that the report contains its own step
    summary = "wrote %s" % args.out
    record_step(args.transcript, args, summary)
    transcript = read_transcript(args.transcript)

    report = {
        "tool": TOOL_NAME,
        "version": TOOL_VERSION,
        "command": "export-report",
        "config_path": str(Path(args.config)),
        "schema_path": str(Path(args.schema)) if args.schema else None,
        "rules_path": str(Path(args.rules)) if args.rules else None,
        "ok": bool(result["ok"]) if result else None,
        "validation": result,
        "config": data,
        "commands": [step["argv"] for step in transcript["steps"]],
        "transcript": transcript,
        "repairs": repairs,
        "repair_count": len(repairs),
    }
    write_json(args.out, report)
    print(summary)
    return None  # already recorded above


# ---------------------------------------------------------------------- main

def build_parser():
    parser = argparse.ArgumentParser(prog=TOOL_NAME,
                                     description="Create, update, validate and report "
                                                 "flat JSON configurations.")
    parser.add_argument("--version", action="version", version="%s %s" % (TOOL_NAME, TOOL_VERSION))
    sub = parser.add_subparsers(dest="command", required=True)

    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--transcript", metavar="PATH", default=None,
                        help="append a record of this command to this JSON transcript")

    p = sub.add_parser("init", parents=[common], help="build a configuration from a schema")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--defaults", default=None, help="defaults document (defaults.json)")
    p.add_argument("--env-overrides", default=None, help="per profile override document")
    p.add_argument("--sample", default=None, help="sample profile document with deltas")
    p.add_argument("--profile", default=None, help="profile name, defaults to the sample one")
    p.add_argument("--rules", default=None, help="validation rules used to reject forbidden keys")
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set", parents=[common], help="set one scalar key in a configuration")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.add_argument("--type", choices=VALUE_TYPES, default=None,
                   help="force a type; by default the key keeps its current type")
    p.add_argument("--rules", default=None, help="validation rules used to reject forbidden keys")
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate", parents=[common], help="validate configurations")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", action="append", required=True,
                   help="configuration to validate; repeat for several")
    p.add_argument("--rules", default=None, help="validation rules document")
    p.add_argument("--defaults", default=None,
                   help="defaults document used to check declared value types")
    p.add_argument("--out", default=None, help="write the full validation report here")
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("export-report", parents=[common], help="export a run report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--schema", default=None, help="validate the config with this schema")
    p.add_argument("--rules", default=None, help="validation rules document")
    p.add_argument("--defaults", default=None,
                   help="defaults document used to check declared value types")
    p.add_argument("--repair-log", default=None, help="list of repair entries to embed")
    p.set_defaults(func=cmd_report)

    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)
    try:
        result = args.func(args)
    except ToolError as exc:
        record_step(args.transcript, args, "failed: %s" % exc)
        print("%s: error: %s" % (TOOL_NAME, exc), file=sys.stderr)
        return 1
    if result is not None:
        record_step(args.transcript, args, result)
    return 0


if __name__ == "__main__":
    sys.exit(main())
