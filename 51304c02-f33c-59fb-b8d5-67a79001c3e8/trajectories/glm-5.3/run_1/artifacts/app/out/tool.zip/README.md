# task-ctl

A stdlib-only CLI that creates, updates, validates and reports flat JSON
configurations. It reads four kinds of document:

| document | role |
| --- | --- |
| schema | required keys (list or comma-separated string), `scalar_only`, `checksum`, default `profile`/`producer`/`container` |
| defaults | top-level values plus a `base_config` block with the numeric and string base values |
| env overrides / sample profile | per-profile direct values and `<key>_delta` offsets |
| validation rules | allowed `profiles`, `forbidden_keys`, `max_artifact_bytes` |

Everything it writes is deterministic: no clocks, counters or random values,
so the same inputs always produce the same bytes. No key named `timestamp`,
`generated_at`, `uuid` or `random_seed` is ever written.

## Running

```sh
./task-ctl <command> [options]        # or: python3 cli.py <command> [options]
```

## Commands

```bash
# build the base configuration
task-ctl init --schema schema.json --defaults defaults.json \
              --rules validation_rules.json --out config.json

# build a profile configuration from a sample plus environment overrides
task-ctl init --schema schema.json --defaults defaults.json \
              --sample sample_config_dev.json --env-overrides env_overrides.json \
              --rules validation_rules.json --out profile_dev.json

# set one key: the key is lowercased and the value keeps the key's type
task-ctl set --config config.json --key max_records --value 100
task-ctl set --config config.json --key max_records --value 100 --type str

# validate one or more configurations, optionally writing a JSON report
task-ctl validate --schema schema.json --rules validation_rules.json \
                  --defaults defaults.json --config config.json \
                  [--config more.json] [--out validation_report.json]

# export a run report: config, validation verdict, transcript and repairs
task-ctl export-report --config config.json --out report.json \
                       --schema schema.json --rules validation_rules.json \
                       --defaults defaults.json [--repair-log repairs.json]
```

Every command also takes `--transcript PATH` to append a record of itself to a
JSON run log; `export-report` embeds that log as its transcript.

## Semantics

* `init` composes values weakest to strongest: schema, defaults,
  `defaults.base_config`, sample, environment overrides, then applies
  `<key>_delta` offsets (sample deltas first, environment deltas second).
  It refuses to write a configuration that would be missing required keys or
  that carries a forbidden key.
* `set` normalises the key to lower case, rejects forbidden keys, coerces the
  command line string to the type the key already carries (`--type` overrides)
  and never writes a non-scalar value.
* `validate` exits non-zero with one diagnostic per problem and checks:
  required keys present, no forbidden keys, values are scalars (flat config),
  value types agree with the defaults document, the `checksum` field matches
  the schema's algorithm, the `profile` is one of the rules' `profiles` or the
  schema's own, and the file is within `max_artifact_bytes`. Keys outside the
  schema and empty required strings are reported as warnings, not errors.
* `export-report` computes its verdict by validating instead of asserting it,
  and records the actual command transcript.

Exit codes: `0` success, `1` runtime or validation failure (message on stderr,
no traceback), `2` usage error.

## Self test

```sh
python3 selftest.py
```
