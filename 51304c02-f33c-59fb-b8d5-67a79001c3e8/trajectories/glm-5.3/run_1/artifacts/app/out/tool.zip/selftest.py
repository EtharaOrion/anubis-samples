#!/usr/bin/env python3
"""Self test for task-ctl: exercises the behaviours that were repaired.

Runs the CLI as a real subprocess against throwaway documents written into a
temporary directory, so it needs no network access and leaves nothing behind.
Usage: python3 selftest.py
"""
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path

CLI = str(Path(__file__).with_name("cli.py"))

SCHEMA_LIST = {
    "profile": "TASK",
    "producer": "",
    "container": "",
    "required_keys": ["profile", "producer", "container", "max_records",
                      "retry_limit", "timeout_ms", "checksum", "mode", "trailer"],
    "scalar_only": True,
    "checksum": "crc32",
}
SCHEMA_STRING = dict(SCHEMA_LIST, required_keys=",".join(SCHEMA_LIST["required_keys"]))
DEFAULTS = {
    "checksum": "crc32",
    "mode": "strict-local",
    "producer": "",
    "container": "",
    "base_config": {
        "max_records": 145,
        "retry_limit": 3,
        "timeout_ms": 1771,
        "trailer": "harbor:cli-config:TASK:0000000000016384",
    },
}
ENV_OVERRIDES = {"dev": {"mode": "strict-local", "retry_limit_delta": 1, "timeout_ms_delta": -125}}
SAMPLE = {"profile": "dev", "max_records_delta": -10, "checksum": "crc32"}
RULES = {
    "profiles": ["dev", "prod"],
    "forbidden_keys": ["timestamp", "generated_at", "uuid", "random_seed"],
    "required_artifacts": ["config.json"],
    "max_artifact_bytes": 1048576,
}


class Failure(AssertionError):
    pass


def run(*argv, expect=0):
    proc = subprocess.run([sys.executable, CLI, *argv], capture_output=True, text=True)
    if expect == 0 and proc.returncode != 0:
        raise Failure("command failed: %s\n%s%s" % (" ".join(argv), proc.stdout, proc.stderr))
    if expect != 0 and proc.returncode == 0:
        raise Failure("command unexpectedly succeeded: %s" % " ".join(argv))
    return proc


def check(condition, label):
    if not condition:
        raise Failure("check failed: %s" % label)


def write(path, document):
    Path(path).write_text(json.dumps(document, indent=2) + "\n", encoding="utf-8")


def main():
    failures = 0
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        write(root / "schema_list.json", SCHEMA_LIST)
        write(root / "schema_string.json", SCHEMA_STRING)
        write(root / "defaults.json", DEFAULTS)
        write(root / "env.json", ENV_OVERRIDES)
        write(root / "sample.json", SAMPLE)
        write(root / "rules.json", RULES)

        tests = [
            (test_usage, "bare invocation prints usage instead of a traceback"),
            (test_init_complete, "init builds a complete flat configuration"),
            (test_init_schema_forms, "init accepts list and comma string required_keys"),
            (test_init_incomplete, "init refuses to emit an incomplete configuration"),
            (test_init_deltas, "init applies sample and env deltas in order"),
            (test_init_forbidden, "init refuses to write forbidden keys"),
            (test_set_scalar, "set lowercases keys and coerces scalars"),
            (test_set_types, "set honours an explicit type"),
            (test_set_forbidden, "set rejects forbidden keys"),
            (test_validate_ok, "validate accepts a good configuration"),
            (test_validate_rejects, "validate rejects each contract violation"),
            (test_report, "export-report carries a real transcript and verdict"),
            (test_deterministic, "repeated runs produce identical bytes"),
        ]
        for func, label in tests:
            try:
                func(root)
                print("pass: %s" % label)
            except Failure as exc:
                failures += 1
                print("FAIL: %s\n  %s" % (label, exc))
    print("%d/%d passed" % (len(tests) - failures, len(tests)))
    return 1 if failures else 0


def test_usage(root):
    proc = subprocess.run([sys.executable, CLI], capture_output=True, text=True)
    check(proc.returncode == 2, "exit code %r" % proc.returncode)
    check("Traceback" not in proc.stderr, "traceback on bare invocation")
    check("required: command" in proc.stderr or "required" in proc.stderr, "usage hint missing")


def test_init_complete(root):
    run("init", "--schema", str(root / "schema_list.json"), "--defaults", str(root / "defaults.json"),
        "--rules", str(root / "rules.json"), "--out", str(root / "config.json"))
    data = json.loads((root / "config.json").read_text())
    check(list(data) == SCHEMA_LIST["required_keys"], "key order %r" % list(data))
    check(all(not isinstance(v, (dict, list)) for v in data.values()), "config is not flat")


def test_init_schema_forms(root):
    for name in ("schema_list.json", "schema_string.json"):
        run("init", "--schema", str(root / name), "--defaults", str(root / "defaults.json"),
            "--out", str(root / ("from_" + name)))
    first = (root / "from_schema_list.json").read_text()
    second = (root / "from_schema_string.json").read_text()
    check(first == second, "schema forms disagree")


def test_init_incomplete(root):
    proc = run("init", "--schema", str(root / "schema_list.json"), "--out", str(root / "bad.json"),
               expect=1)
    check("Traceback" not in proc.stderr, "traceback on incomplete config")
    check("missing" in proc.stderr, "no missing key report")
    check(not (root / "bad.json").exists(), "incomplete config was written anyway")


def test_init_deltas(root):
    run("init", "--schema", str(root / "schema_list.json"), "--defaults", str(root / "defaults.json"),
        "--sample", str(root / "sample.json"), "--env-overrides", str(root / "env.json"),
        "--out", str(root / "profile.json"))
    data = json.loads((root / "profile.json").read_text())
    check(data["profile"] == "dev", "profile %r" % data["profile"])
    check(data["max_records"] == 135, "max_records %r" % data["max_records"])
    check(data["retry_limit"] == 4, "retry_limit %r" % data["retry_limit"])
    check(data["timeout_ms"] == 1646, "timeout_ms %r" % data["timeout_ms"])
    check(isinstance(data["max_records"], int), "delta result is not an int")


def test_init_forbidden(root):
    write(root / "bad_sample.json", dict(SAMPLE, timestamp="now"))
    run("init", "--schema", str(root / "schema_list.json"), "--defaults", str(root / "defaults.json"),
        "--sample", str(root / "bad_sample.json"), "--rules", str(root / "rules.json"),
        "--out", str(root / "never.json"), expect=1)


def test_set_scalar(root):
    run("init", "--schema", str(root / "schema_list.json"), "--defaults", str(root / "defaults.json"),
        "--out", str(root / "config.json"))
    run("set", "--config", str(root / "config.json"), "--key", "MAX_RECORDS", "--value", "100")
    data = json.loads((root / "config.json").read_text())
    check("MAX_RECORDS" not in data, "key was not lowercased")
    check(data["max_records"] == 100, "max_records %r" % data["max_records"])
    check(isinstance(data["max_records"], int), "value is a %r" % type(data["max_records"]).__name__)


def test_set_types(root):
    config = root / "typed.json"
    run("init", "--schema", str(root / "schema_list.json"), "--defaults", str(root / "defaults.json"),
        "--out", str(config))
    run("set", "--config", str(config), "--key", "max_records", "--value", "100", "--type", "str")
    data = json.loads(config.read_text())
    check(data["max_records"] == "100", "forced string value %r" % data["max_records"])
    # without --type a key keeps the type it carries, so this stays a string
    run("set", "--config", str(config), "--key", "max_records", "--value", "100")
    check(json.loads(config.read_text())["max_records"] == "100", "type was not kept")
    run("set", "--config", str(config), "--key", "max_records", "--value", "100", "--type", "int")
    check(json.loads(config.read_text())["max_records"] == 100, "int not restored")
    run("set", "--config", str(config), "--key", "mode", "--value", "strict-local")
    check(json.loads(config.read_text())["mode"] == "strict-local", "string value damaged")


def test_set_forbidden(root):
    run("set", "--config", str(root / "config.json"), "--key", "uuid", "--value", "x",
        "--rules", str(root / "rules.json"), expect=1)


def test_validate_ok(root):
    config = root / "clean.json"
    run("init", "--schema", str(root / "schema_list.json"), "--defaults", str(root / "defaults.json"),
        "--sample", str(root / "sample.json"), "--env-overrides", str(root / "env.json"),
        "--out", str(config))
    for name in ("schema_list.json", "schema_string.json"):
        proc = run("validate", "--schema", str(root / name), "--rules", str(root / "rules.json"),
                   "--defaults", str(root / "defaults.json"), "--config", str(config))
        check("ok" in proc.stdout, "stdout %r" % proc.stdout)


def test_validate_rejects(root):
    base = json.loads((root / "config.json").read_text())
    cases = {
        "missing": {k: v for k, v in base.items() if k != "trailer"},
        "forbidden": dict(base, timestamp="now"),
        "nested": dict(base, settings={"a": 1}),
        "checksum": dict(base, checksum="md5"),
        "profile": dict(base, profile="staging"),
        "type": dict(base, max_records="145"),
    }
    for label, document in cases.items():
        path = root / ("case_%s.json" % label)
        write(path, document)
        proc = run("validate", "--schema", str(root / "schema_list.json"),
                   "--rules", str(root / "rules.json"), "--defaults", str(root / "defaults.json"),
                   "--config", str(path), expect=1)
        check("Traceback" not in proc.stderr, "%s produced a traceback" % label)
    # a config over the byte limit must also be rejected
    write(root / "case_bytes.json", dict(base, filler="x" * (RULES["max_artifact_bytes"] + 1)))
    run("validate", "--schema", str(root / "schema_list.json"), "--rules", str(root / "rules.json"),
        "--config", str(root / "case_bytes.json"), expect=1)


def test_report(root):
    log = root / "repair_log.json"
    write(log, [{"id": "R1", "fault": "f", "repair": "r"}])
    transcript = root / "transcript.json"
    run("init", "--schema", str(root / "schema_list.json"), "--defaults", str(root / "defaults.json"),
        "--out", str(root / "config.json"), "--transcript", str(transcript))
    run("set", "--config", str(root / "config.json"), "--key", "max_records", "--value", "100",
        "--transcript", str(transcript))
    run("export-report", "--config", str(root / "config.json"), "--out", str(root / "report.json"),
        "--schema", str(root / "schema_list.json"), "--rules", str(root / "rules.json"),
        "--defaults", str(root / "defaults.json"), "--repair-log", str(log),
        "--transcript", str(transcript))
    report = json.loads((root / "report.json").read_text())
    check(report["ok"] is True, "report verdict %r" % report["ok"])
    check(isinstance(report["commands"], list) and len(report["commands"]) == 3,
          "commands %r" % report["commands"])
    check(all(isinstance(item, list) for item in report["commands"]), "commands are not argv lists")
    check(report["repair_count"] == 1, "repair count %r" % report["repair_count"])
    check(report["validation"]["ok"] is True, "embedded validation is not ok")


def test_deterministic(root):
    outputs = []
    for index in range(2):
        target = root / ("det%d.json" % index)
        run("init", "--schema", str(root / "schema_list.json"), "--defaults", str(root / "defaults.json"),
            "--sample", str(root / "sample.json"), "--env-overrides", str(root / "env.json"),
            "--out", str(target))
        outputs.append(target.read_text())
    check(outputs[0] == outputs[1], "repeated runs differ")


if __name__ == "__main__":
    sys.exit(main())
