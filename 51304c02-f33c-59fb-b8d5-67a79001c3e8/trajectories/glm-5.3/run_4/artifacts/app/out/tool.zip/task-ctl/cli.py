#!/usr/bin/env python3
"""task-ctl - create, update, validate and report flat JSON configurations.

The contract for a valid configuration is written in a schema file (see
schema.json) and, optionally, a validation-rules file.  A valid configuration
is a flat JSON object whose values are all scalars, that carries every key
listed in the schema's ``required_keys`` and none of the keys forbidden by the
rules file.

Commands
--------
  init         build a configuration from schema + defaults (+ overrides)
  set          set one scalar key in an existing configuration
  validate     check one or more configurations against the contract
  export-report write a machine readable report about a configuration
  summarize    summarise a directory of artifacts against the rules file
  selftest     regression checks for the repaired behaviour

Every command accepts ``--log FILE`` to append a JSON-lines transcript record
of its own invocation, which ``export-report`` and ``summarize`` can fold in.
"""
from __future__ import annotations

import argparse
import contextlib
import hashlib
import io
import json
import re
import sys
import tempfile
from pathlib import Path

TOOL_NAME = "task-ctl"
TOOL_VERSION = "1.1.0"

DELTA_SUFFIX = "_delta"
SCALARS = (str, int, float, bool, type(None))
NUMERIC_HINTS = ("max_records", "retry_limit", "timeout_ms")
TRAILER_RE = re.compile(r"^[A-Za-z0-9._-]+:[A-Za-z0-9._-]+:[A-Za-z0-9._-]+:[0-9]{16}$")
JSON_MAX_BYTES = 1048576


class ConfigError(Exception):
    """A recoverable task-ctl failure: bad input, bad contract, bad config."""


# --------------------------------------------------------------------------
# JSON helpers
# --------------------------------------------------------------------------
def load_json(path, what="file"):
    """Load a JSON document, reporting the offending path on failure."""
    source = Path(path)
    try:
        text = source.read_text(encoding="utf-8")
    except OSError as exc:
        raise ConfigError("cannot read {} {}: {}".format(what, path, exc.strerror or exc)) from exc
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        raise ConfigError("{} {} is not valid JSON: {}".format(what, path, exc)) from exc


def dump_json(data):
    """Deterministic JSON text: sorted keys, two-space indent, newline tail."""
    return json.dumps(data, indent=2, sort_keys=True) + "\n"


def write_json(path, data):
    target = Path(path)
    try:
        if target.parent and str(target.parent):
            target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(dump_json(data), encoding="utf-8")
    except OSError as exc:
        raise ConfigError("cannot write {}: {}".format(path, exc.strerror or exc)) from exc
    return target


def is_scalar(value):
    return isinstance(value, SCALARS) and not isinstance(value, (dict, list))


def coerce_scalar(raw):
    """Turn command-line text into the JSON scalar it denotes.

    Literals are preserved: ``007`` and ``0000000000016384`` stay strings,
    ``100`` becomes an int, ``1.5`` a float, ``true``/``false``/``null`` the
    matching JSON constants.
    """
    if not isinstance(raw, str):
        return raw
    text = raw.strip()
    lowered = text.lower()
    if lowered == "true":
        return True
    if lowered == "false":
        return False
    if lowered in ("null", "none"):
        return None
    try:
        number = int(text)
    except ValueError:
        number = None
    if number is not None and str(number) == text:
        return number
    try:
        number = float(text)
    except ValueError:
        number = None
    if number is not None and repr(number) == text:
        return number
    return raw


# --------------------------------------------------------------------------
# contract helpers
# --------------------------------------------------------------------------
def required_keys_from(schema):
    """Normalise schema.required_keys, which may be a list or a CSV string."""
    raw = schema.get("required_keys", [])
    if isinstance(raw, str):
        keys = [part.strip() for part in raw.split(",") if part.strip()]
    elif isinstance(raw, list):
        keys = [str(part).strip() for part in raw if str(part).strip()]
    else:
        raise ConfigError("schema.required_keys must be a list or a comma separated string")
    if len(set(keys)) != len(keys):
        duplicates = sorted({key for key in keys if keys.count(key) > 1})
        raise ConfigError("schema.required_keys contains duplicates: " + ",".join(duplicates))
    if not keys:
        raise ConfigError("schema.required_keys is empty")
    return keys


def known_profiles(schema, rules):
    """Profile names a configuration may declare: the schema base profile plus
    every environment profile named in the rules file."""
    profiles = []
    base = schema.get("profile")
    if isinstance(base, str) and base:
        profiles.append(base)
    for profile in (rules or {}).get("profiles", []):
        if profile not in profiles:
            profiles.append(profile)
    return profiles


def apply_overrides(config, overrides, source):
    """Apply ``key``/``key_delta`` overrides onto a flat configuration."""
    if not isinstance(overrides, dict):
        raise ConfigError("{} must be a JSON object".format(source))
    for key in sorted(overrides):
        value = overrides[key]
        if key == "profile":
            if not isinstance(value, str) or not value:
                raise ConfigError("{}: profile override must be a non-empty string".format(source))
            config["profile"] = value
        elif key.endswith(DELTA_SUFFIX):
            base_key = key[: -len(DELTA_SUFFIX)]
            if base_key not in config:
                raise ConfigError("{}: delta '{}' targets unknown key '{}'".format(source, key, base_key))
            current = config[base_key]
            if isinstance(current, bool) or not isinstance(current, (int, float)):
                raise ConfigError("{}: key '{}' is not numeric, cannot apply '{}'".format(source, base_key, key))
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise ConfigError("{}: value of '{}' must be numeric".format(source, key))
            config[base_key] = current + value
        elif isinstance(value, (dict, list)):
            raise ConfigError("{}: value of '{}' must be a scalar (configuration stays flat)".format(source, key))
        else:
            config[key] = value
    return config


def seed_value(key):
    """Type-appropriate placeholder for a required key that has no default."""
    if key in NUMERIC_HINTS or key.endswith("_ms") or key.endswith("_limit") or key.endswith("_records"):
        return 0
    return ""


def build_config(args):
    """Assemble a flat configuration from schema, defaults and overrides."""
    schema = load_json(args.schema, "schema")
    if not isinstance(schema, dict):
        raise ConfigError("schema {} must be a JSON object".format(args.schema))

    rules = None
    if getattr(args, "rules", None):
        rules = load_json(args.rules, "validation rules")
        if not isinstance(rules, dict):
            raise ConfigError("validation rules {} must be a JSON object".format(args.rules))

    defaults = {}
    if getattr(args, "defaults", None):
        defaults = load_json(args.defaults, "defaults")
        if not isinstance(defaults, dict):
            raise ConfigError("defaults {} must be a JSON object".format(args.defaults))

    # 1. identity keys from the schema
    config = {"profile": schema.get("profile", "")}
    for key in ("producer", "container", "checksum", "mode"):
        if key in schema:
            config[key] = schema[key]

    # 2. defaults file: top level scalars, then the base_config block
    for key, value in defaults.items():
        if key == "base_config":
            if not isinstance(value, dict):
                raise ConfigError("defaults.base_config must be a JSON object")
            for inner, inner_value in value.items():
                if isinstance(inner_value, (dict, list)):
                    raise ConfigError("defaults.base_config.{} must be a scalar".format(inner))
                config[inner] = inner_value
        elif isinstance(value, (dict, list)):
            raise ConfigError("defaults.{} must be a scalar (configuration stays flat)".format(key))
        else:
            config[key] = value

    # 3. environment profile overrides, then an explicit profile file
    profile_file = None
    if getattr(args, "profile_file", None):
        profile_file = load_json(args.profile_file, "profile file")
        if not isinstance(profile_file, dict):
            raise ConfigError("profile file {} must be a JSON object".format(args.profile_file))

    profile = getattr(args, "profile", None) or (profile_file or {}).get("profile")
    if profile and profile_file:
        if profile_file.get("profile") not in (None, profile):
            raise ConfigError("profile '{}' does not match profile file '{}'".format(profile, profile_file.get("profile")))

    if profile:
        allowed = known_profiles(schema, rules)
        if rules is not None and allowed and profile not in allowed:
            raise ConfigError("unknown profile '{}' (known: {})".format(profile, ",".join(sorted(allowed))))
        config["profile"] = profile

    if profile and getattr(args, "env_overrides", None):
        overrides = load_json(args.env_overrides, "env overrides")
        if not isinstance(overrides, dict):
            raise ConfigError("env overrides {} must be a JSON object".format(args.env_overrides))
        if profile not in overrides:
            raise ConfigError("env overrides {} have no entry for profile '{}'".format(args.env_overrides, profile))
        apply_overrides(config, overrides[profile], "{}#{}".format(args.env_overrides, profile))

    if profile_file:
        apply_overrides(config, profile_file, args.profile_file)

    # 4. every required key must exist, flat and scalar
    required = required_keys_from(schema)
    filled = []
    for key in required:
        if key not in config:
            config[key] = seed_value(key)
            filled.append(key)
    config = {key: config[key] for key in sorted(config)}

    for key, value in config.items():
        if not is_scalar(value):
            raise ConfigError("generated key '{}' is not a scalar".format(key))

    return config, schema, rules, filled


# --------------------------------------------------------------------------
# validation
# --------------------------------------------------------------------------
def validate_config(schema, data, rules, label):
    """Return a per-configuration validation report.

    Checks that the schema and rules files actually state (required keys,
    scalar-only shape, forbidden keys, declared profile, checksum algorithm)
    are blocking.  Sanity checks that go beyond the written contract (numeric
    ranges, trailer shape) are advisory: they are reported as warnings but do
    not fail a configuration.
    """
    checks = []
    errors = []
    warnings = []

    def record(name, ok, detail, blocking=True):
        result = "pass" if ok else ("fail" if blocking else "warn")
        checks.append({"check": name, "result": result, "detail": detail,
                       "severity": "contract" if blocking else "advisory"})
        if not ok:
            (errors if blocking else warnings).append("{}: {}".format(name, detail))
        return ok

    if not record("config_is_object", isinstance(data, dict),
                  "configuration is a JSON object" if isinstance(data, dict)
                  else "configuration is not a JSON object"):
        return {
            "config": label,
            "ok": False,
            "checks": checks,
            "errors": errors,
            "warnings": warnings,
            "values": None,
        }

    required = required_keys_from(schema)
    missing = [key for key in required if key not in data]
    record("required_keys_present", not missing,
           "all {} required keys present".format(len(required)) if not missing
           else "missing required keys: " + ",".join(missing))

    nested = sorted(key for key, value in data.items() if isinstance(value, (dict, list)))
    if bool(schema.get("scalar_only", True)):
        record("scalar_only", not nested,
               "flat configuration, every value is a scalar" if not nested
               else "non-scalar values: " + ",".join(nested))
    else:
        record("scalar_only", not nested, "schema does not require scalar-only values", blocking=False)

    forbidden = [key for key in (rules or {}).get("forbidden_keys", []) if key in data]
    record("no_forbidden_keys", not forbidden,
           "none of the forbidden keys present" if not forbidden
           else "forbidden keys present: " + ",".join(forbidden))

    profiles = known_profiles(schema, rules)
    profile = data.get("profile")
    if profiles:
        record("profile_declared", profile in profiles,
               "profile '{}' is declared by the schema or the rules".format(profile) if profile in profiles
               else "profile '{}' is not one of: {}".format(profile, ",".join(profiles)))
    else:
        record("profile_declared", isinstance(profile, str) and bool(profile),
               "profile is a non-empty string")

    expected_checksum = schema.get("checksum")
    checksum = data.get("checksum")
    if expected_checksum:
        record("checksum_algorithm", checksum == expected_checksum,
               "checksum algorithm is '{}'".format(expected_checksum) if checksum == expected_checksum
               else "checksum is {!r}, schema requires {!r}".format(checksum, expected_checksum))
    else:
        record("checksum_algorithm", isinstance(checksum, str) and bool(checksum),
               "checksum is a non-empty string")

    numeric_problems = []
    for key in ("max_records", "retry_limit"):
        value = data.get(key)
        if key in data and (isinstance(value, bool) or not isinstance(value, int)):
            numeric_problems.append("{} must be an integer, got {!r}".format(key, value))
        elif key in data and value < 0:
            numeric_problems.append("{} must not be negative, got {!r}".format(key, value))
    timeout = data.get("timeout_ms")
    if "timeout_ms" in data and (isinstance(timeout, bool) or not isinstance(timeout, int)):
        numeric_problems.append("timeout_ms must be an integer, got {!r}".format(timeout))
    elif "timeout_ms" in data and timeout <= 0:
        numeric_problems.append("timeout_ms must be positive, got {!r}".format(timeout))
    record("numeric_values", not numeric_problems,
           "max_records, retry_limit and timeout_ms are sane integers" if not numeric_problems
           else "; ".join(numeric_problems), blocking=False)

    trailer = data.get("trailer")
    trailer_ok = isinstance(trailer, str) and bool(TRAILER_RE.match(trailer))
    record("trailer_format", trailer_ok,
           "trailer matches id:kind:profile:16-digit counter" if trailer_ok
           else "trailer {!r} does not match <id>:<kind>:<profile>:<16 digits>".format(trailer), blocking=False)

    return {
        "config": label,
        "ok": not errors,
        "checks": checks,
        "errors": errors,
        "warnings": warnings,
        "values": {key: data[key] for key in sorted(data)} if isinstance(data, dict) else None,
    }


def validate_paths(args):
    schema = load_json(args.schema, "schema")
    rules = load_json(args.rules, "validation rules") if getattr(args, "rules", None) else None
    results = []
    for path in args.config:
        data = load_json(path, "configuration")
        results.append(validate_config(schema, data, rules, path))
    return schema, rules, results


# --------------------------------------------------------------------------
# commands
# --------------------------------------------------------------------------
def cmd_init(args):
    config, schema, rules, filled = build_config(args)
    report = validate_config(schema, config, rules, str(args.out))
    if not report["ok"]:
        raise ConfigError("generated configuration would be invalid: " + "; ".join(report["errors"]))
    write_json(args.out, config)
    message = "wrote {} ({} keys, profile '{}')".format(args.out, len(config), config.get("profile"))
    if filled:
        message += "; filled required keys without a default: " + ",".join(filled)
    print(message)
    return 0


def cmd_set(args):
    data = load_json(args.config, "configuration")
    if not isinstance(data, dict):
        raise ConfigError("configuration {} must be a JSON object".format(args.config))
    key = args.key.strip()
    if not key or key.lower() != key:
        raise ConfigError("keys are lower case and non-empty (got {!r})".format(args.key))
    value = coerce_scalar(args.value)
    if not is_scalar(value):
        raise ConfigError("value for '{}' must be a scalar".format(key))
    if getattr(args, "rules", None):
        rules = load_json(args.rules, "validation rules")
        if key in rules.get("forbidden_keys", []):
            raise ConfigError("key '{}' is forbidden by {}".format(key, args.rules))
    previous = data.get(key, None)
    data[key] = value
    write_json(args.config, data)
    print("set {} = {!r} (was {!r})".format(key, value, previous))
    return 0


def cmd_validate(args):
    schema, rules, results = validate_paths(args)
    report = {
        "tool": TOOL_NAME,
        "tool_version": TOOL_VERSION,
        "command": "validate",
        "schema": str(args.schema),
        "rules": str(args.rules) if getattr(args, "rules", None) else None,
        "ok": all(result["ok"] for result in results),
        "config_count": len(results),
        "results": results,
    }
    if getattr(args, "out", None):
        write_json(args.out, report)
    for result in results:
        status = "ok" if result["ok"] else "FAILED"
        print("{}: {} ({} checks)".format(result["config"], status, len(result["checks"])))
        for error in result["errors"]:
            print("  error: {}".format(error), file=sys.stderr)
        for warning in result["warnings"]:
            print("  warning: {}".format(warning))
    if report["ok"]:
        print("ok")
    if getattr(args, "json", False):
        print(dump_json(report))
    return 0 if report["ok"] else 1


def cmd_report(args):
    schema = load_json(args.schema, "schema")
    data = load_json(args.config, "configuration")
    rules = load_json(args.rules, "validation rules") if getattr(args, "rules", None) else None
    validation = validate_config(schema, data, rules, str(args.config))
    report = {
        "tool": TOOL_NAME,
        "tool_version": TOOL_VERSION,
        "command": "export-report",
        "config": str(args.config),
        "schema": str(args.schema),
        "rules": str(args.rules) if getattr(args, "rules", None) else None,
        "ok": validation["ok"],
        "validation": validation,
        "config_values": {key: data[key] for key in sorted(data)} if isinstance(data, dict) else {},
        "transcript": read_transcript(args.transcript) if getattr(args, "transcript", None) else [],
        "transcript_note": "invocations are appended after they run, so this report's own entry "
                           "appears in the transcript of any command that runs later",
        "notes": load_json(args.notes, "notes") if getattr(args, "notes", None) else {},
    }
    write_json(args.out, report)
    print("wrote {} (config {}, {})".format(args.out, args.config, "valid" if validation["ok"] else "INVALID"))
    return 0 if validation["ok"] else 1


def cmd_summarize(args):
    rules = load_json(args.rules, "validation rules")
    directory = Path(args.dir)
    if not directory.is_dir():
        raise ConfigError("{} is not a directory".format(args.dir))

    def artifact(name):
        path = directory / name
        output_name = Path(args.out).name
        entry = {"name": name, "present": path.exists() or name == output_name}
        if path.exists():
            payload = path.read_bytes()
            entry["bytes"] = len(payload)
            entry["sha256"] = hashlib.sha256(payload).hexdigest()
            entry["within_size_limit"] = len(payload) <= int(rules.get("max_artifact_bytes", JSON_MAX_BYTES))
        elif name == output_name:
            entry["pending_write"] = True
        return entry

    required = [artifact(name) for name in rules.get("required_artifacts", [])]
    extra = sorted(
        entry.name for entry in directory.iterdir()
        if entry.is_file() and entry.name not in rules.get("required_artifacts", [])
    )
    configs = {}
    for path in args.config:
        configs[path] = validate_config(
            load_json(args.schema, "schema"),
            load_json(path, "configuration"),
            rules,
            path,
        )
    summary = {
        "tool": TOOL_NAME,
        "tool_version": TOOL_VERSION,
        "command": "summarize",
        "directory": str(args.dir),
        "rules": {
            "profiles": rules.get("profiles", []),
            "forbidden_keys": rules.get("forbidden_keys", []),
            "required_artifacts": rules.get("required_artifacts", []),
            "max_artifact_bytes": rules.get("max_artifact_bytes", JSON_MAX_BYTES),
        },
        "ok": all(entry["present"] for entry in required)
        and all(entry.get("within_size_limit", True) for entry in required)
        and all(report["ok"] for report in configs.values()),
        "required_artifacts": required,
        "missing_artifacts": [entry["name"] for entry in required if not entry["present"]],
        "other_files": extra,
        "configurations": configs,
        "transcript": read_transcript(args.transcript) if getattr(args, "transcript", None) else [],
        "transcript_note": "invocations are appended after they run, so this summary is the last "
                           "entry the transcript can hold",
        "notes": load_json(args.notes, "notes") if getattr(args, "notes", None) else {},
    }
    write_json(args.out, summary)
    print("wrote {} ({}/{} required artifacts present)".format(
        args.out, sum(1 for entry in required if entry["present"]), len(required)))
    return 0 if summary["ok"] else 1


def cmd_selftest(args):
    """Regression checks for the repaired behaviour."""
    checks = []

    def check(name, ok, detail):
        checks.append({"check": name, "result": "pass" if ok else "fail", "detail": detail})
        return ok

    with tempfile.TemporaryDirectory() as tmp:
        work = Path(tmp)
        schema_path = work / "schema.json"
        schema_path.write_text(json.dumps({
            "profile": "TASK",
            "producer": "",
            "container": "",
            "required_keys": ["profile", "producer", "container", "max_records", "retry_limit",
                              "timeout_ms", "checksum", "mode", "trailer"],
            "scalar_only": True,
            "checksum": "crc32",
        }), encoding="utf-8")
        defaults_path = work / "defaults.json"
        defaults_path.write_text(json.dumps({
            "checksum": "crc32", "mode": "strict-local", "producer": "", "container": "",
            "base_config": {"max_records": 145, "retry_limit": 3, "timeout_ms": 1771,
                            "trailer": "harbor:cli-config:TASK:0000000000016384"},
        }), encoding="utf-8")
        rules_path = work / "rules.json"
        rules_path.write_text(json.dumps({
            "profiles": ["dev", "prod"],
            "forbidden_keys": ["timestamp", "generated_at", "uuid", "random_seed"],
            "required_artifacts": ["config.json"],
            "max_artifact_bytes": 1048576,
        }), encoding="utf-8")
        env_path = work / "env_overrides.json"
        env_path.write_text(json.dumps({
            "dev": {"mode": "strict-local", "retry_limit_delta": 1, "timeout_ms_delta": -125},
            "prod": {"mode": "strict-local", "retry_limit_delta": 0, "timeout_ms_delta": 250},
        }), encoding="utf-8")
        sample_path = work / "sample_dev.json"
        sample_path.write_text(json.dumps({"profile": "dev", "max_records_delta": -10, "checksum": "crc32"}),
                               encoding="utf-8")
        csv_schema_path = work / "schema_csv.json"
        csv_schema_path.write_text(json.dumps({
            "profile": "TASK", "producer": "", "container": "",
            "required_keys": "profile,producer,container,max_records,retry_limit,timeout_ms,checksum,mode,trailer",
            "checksum": "crc32",
        }), encoding="utf-8")

        class Args(object):
            pass

        def init_args(out, **kw):
            item = Args()
            item.schema = str(schema_path)
            item.out = str(out)
            item.defaults = kw.get("defaults")
            item.env_overrides = kw.get("env_overrides")
            item.profile_file = kw.get("profile_file")
            item.profile = kw.get("profile")
            item.rules = kw.get("rules")
            return item

        # 1. init reads --schema and honours defaults
        out = work / "config.json"
        try:
            config, schema, rules, filled = build_config(init_args(out, defaults=str(defaults_path)))
            check("init_reads_schema_not_config", True, "init built a configuration from --schema")
        except Exception as exc:  # noqa: BLE001 - selftest reports, never raises
            check("init_reads_schema_not_config", False, "init raised: {}".format(exc))
            config = {}
        check("init_output_is_flat", all(is_scalar(value) for value in config.values()),
              "no nested 'settings' object; every value is a scalar")
        check("init_has_required_keys",
              all(key in config for key in ("profile", "producer", "container", "max_records",
                                            "retry_limit", "timeout_ms", "checksum", "mode", "trailer")),
              "all nine required keys generated")
        check("init_matches_defaults",
              config.get("max_records") == 145 and config.get("retry_limit") == 3
              and config.get("timeout_ms") == 1771,
              "defaults.base_config values applied: max_records=145 retry_limit=3 timeout_ms=1771")

        # 2. set keeps key case and coerces scalars
        config_path = work / "set.json"
        write_json(config_path, config)
        set_args = Args()
        set_args.config = str(config_path)
        set_args.key = "max_records"
        set_args.value = "100"
        set_args.rules = None
        try:
            cmd_set(set_args)
            after = load_json(config_path)
            check("set_key_case", "max_records" in after and "MAX_RECORDS" not in after,
                  "keys stay lower case")
            check("set_scalar_coercion", after.get("max_records") == 100 and isinstance(after.get("max_records"), int),
                  "value coerced from text to int")
        except Exception as exc:  # noqa: BLE001
            check("set_key_case", False, "set raised: {}".format(exc))
            check("set_scalar_coercion", False, "set raised: {}".format(exc))
        padded = coerce_scalar("0000000000016384")
        check("set_preserves_literals", isinstance(padded, str) and padded == "0000000000016384",
              "zero padded values are not coerced to integers")

        # 3. validate accepts both required_keys forms
        try:
            keys_list = required_keys_from(load_json(schema_path, "schema"))
            keys_csv = required_keys_from(load_json(csv_schema_path, "schema"))
            check("validate_required_keys_forms", keys_list == keys_csv and len(keys_list) == 9,
                  "list and comma separated schema forms normalise identically")
        except Exception as exc:  # noqa: BLE001
            check("validate_required_keys_forms", False, "raised: {}".format(exc))

        report = validate_config(load_json(schema_path, "schema"), config, load_json(rules_path, "rules"), "selftest")
        check("validate_accepts_flat_config", report["ok"], "flat configuration with all keys passes")
        broken = dict(config)
        broken["timestamp"] = 1
        broken_report = validate_config(load_json(schema_path, "schema"), broken,
                                        load_json(rules_path, "rules"), "selftest")
        check("validate_rejects_forbidden_key",
              not broken_report["ok"] and any("forbidden" in error for error in broken_report["errors"]),
              "forbidden keys are rejected")

        # 4. profile deltas
        try:
            dev, _, _, _ = build_config(init_args(work / "dev.json", defaults=str(defaults_path),
                                                  env_overrides=str(env_path), profile="dev",
                                                  profile_file=str(sample_path), rules=str(rules_path)))
            check("profile_deltas_applied",
                  dev.get("profile") == "dev" and dev.get("max_records") == 135
                  and dev.get("retry_limit") == 4 and dev.get("timeout_ms") == 1646,
                  "dev: 145-10=135, 3+1=4, 1771-125=1646")
        except Exception as exc:  # noqa: BLE001
            check("profile_deltas_applied", False, "raised: {}".format(exc))

        # 5. a command is required, and --help must not crash
        captured = io.StringIO()
        try:
            with contextlib.redirect_stdout(captured), contextlib.redirect_stderr(captured):
                code = main(["--help"])
            check("help_exits_cleanly", code == 0, "--help exits with status 0")
        except SystemExit as exc:
            check("help_exits_cleanly", exc.code == 0, "--help exits with status {}".format(exc.code))
        except Exception as exc:  # noqa: BLE001
            check("help_exits_cleanly", False, "raised: {}".format(exc))
        try:
            with contextlib.redirect_stdout(captured), contextlib.redirect_stderr(captured):
                main([])
            check("subcommand_required", False, "no subcommand should exit 0")
        except SystemExit as exc:
            check("subcommand_required", exc.code not in (0, None),
                  "no subcommand is a usage error (exit {}), not a crash".format(exc.code))
        except Exception as exc:  # noqa: BLE001
            check("subcommand_required", False, "raised: {}".format(exc))

    failed = [entry for entry in checks if entry["result"] == "fail"]
    print("selftest: {} checks, {} failed".format(len(checks), len(failed)))
    for entry in checks:
        print("  [{}] {}: {}".format(entry["result"], entry["check"], entry["detail"]))
    if getattr(args, "out", None):
        write_json(args.out, {"tool": TOOL_NAME, "tool_version": TOOL_VERSION, "command": "selftest",
                              "ok": not failed, "checks": checks})
    return 1 if failed else 0


# --------------------------------------------------------------------------
# transcript
# --------------------------------------------------------------------------
def read_transcript(path):
    source = Path(path)
    if not source.exists():
        raise ConfigError("transcript {} does not exist".format(path))
    records = []
    for number, line in enumerate(source.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        try:
            records.append(json.loads(line))
        except json.JSONDecodeError as exc:
            raise ConfigError("transcript {} line {} is not valid JSON: {}".format(path, number, exc)) from exc
    return records


def append_transcript(path, record):
    if not path:
        return
    with Path(path).open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, sort_keys=True) + "\n")


# --------------------------------------------------------------------------
# entry point
# --------------------------------------------------------------------------
def build_parser():
    parser = argparse.ArgumentParser(prog=TOOL_NAME, description=__doc__.splitlines()[0])
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--log", metavar="FILE", help="append a JSON-lines transcript record to FILE")

    sub = parser.add_subparsers(dest="command", required=True, metavar="COMMAND")

    p = sub.add_parser("init", parents=[common], help="build a configuration from schema and defaults")
    p.add_argument("--schema", required=True, help="schema file describing the contract")
    p.add_argument("--defaults", help="defaults file with top level keys and a base_config block")
    p.add_argument("--env-overrides", help="per-profile override/delta file")
    p.add_argument("--profile", help="environment profile to build (e.g. dev, prod)")
    p.add_argument("--profile-file", help="profile file carrying a profile name and *_delta overrides")
    p.add_argument("--rules", help="validation rules file")
    p.add_argument("--out", required=True, help="configuration file to write")
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set", parents=[common], help="set one scalar key in a configuration")
    p.add_argument("--config", required=True, help="configuration file to update in place")
    p.add_argument("--key", required=True, help="lower case key to set")
    p.add_argument("--value", required=True, help="scalar value (int, float, bool, null or text)")
    p.add_argument("--rules", help="validation rules file (rejects forbidden keys)")
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate", parents=[common], help="validate configurations against the contract")
    p.add_argument("--schema", required=True, help="schema file describing the contract")
    p.add_argument("--rules", help="validation rules file")
    p.add_argument("--config", action="append", required=True, metavar="FILE",
                   help="configuration file to validate (repeatable)")
    p.add_argument("--out", help="write the full validation report to this JSON file")
    p.add_argument("--json", action="store_true", help="also print the JSON report to stdout")
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("export-report", parents=[common], help="write a report about a configuration")
    p.add_argument("--config", required=True, help="configuration file to report on")
    p.add_argument("--schema", required=True, help="schema file describing the contract")
    p.add_argument("--rules", help="validation rules file")
    p.add_argument("--transcript", help="JSON-lines transcript produced by --log")
    p.add_argument("--notes", help="JSON file with author notes to embed in the report")
    p.add_argument("--out", required=True, help="report file to write")
    p.set_defaults(func=cmd_report)

    p = sub.add_parser("summarize", parents=[common], help="summarise a directory of artifacts")
    p.add_argument("--dir", required=True, help="directory holding the artifacts")
    p.add_argument("--rules", required=True, help="validation rules file")
    p.add_argument("--schema", required=True, help="schema file describing the contract")
    p.add_argument("--config", action="append", default=[], metavar="FILE",
                   help="configuration file to re-validate inside the summary")
    p.add_argument("--transcript", help="JSON-lines transcript produced by --log")
    p.add_argument("--notes", help="JSON file with author notes to embed in the summary")
    p.add_argument("--out", required=True, help="summary file to write")
    p.set_defaults(func=cmd_summarize)

    p = sub.add_parser("selftest", parents=[common], help="run regression checks for the repaired behaviour")
    p.add_argument("--out", help="write the selftest report to this JSON file")
    p.set_defaults(func=cmd_selftest)

    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        code = args.func(args)
    except ConfigError as exc:
        append_transcript(getattr(args, "log", None), {
            "command": getattr(args, "command", None),
            "argv": list(sys.argv),
            "result": "error",
            "exit_code": 1,
            "message": str(exc),
        })
        print("{}: error: {}".format(TOOL_NAME, exc), file=sys.stderr)
        return 1
    code = 0 if code is None else int(code)
    append_transcript(getattr(args, "log", None), {
        "command": getattr(args, "command", None),
        "argv": list(sys.argv),
        "result": "ok" if code == 0 else "failed",
        "exit_code": code,
    })
    return code


if __name__ == "__main__":
    sys.exit(main())
