# task-ctl

A stdlib-only CLI that creates, updates, validates and reports a **flat JSON
configuration** for TASK processing.  A valid configuration is a JSON object
whose values are all scalars, that carries every key in the schema's
`required_keys` and none of the keys the rules file forbids.

```bash
./task-ctl init --schema schema.json --out config.json
./task-ctl set --config config.json --key max_records --value 100
./task-ctl validate --schema schema.json --config config.json
./task-ctl export-report --config config.json --schema schema.json --out report.json
```

`cli.py` is the entry point; `task-ctl` is a thin launcher, so
`python3 cli.py ...` and `./task-ctl ...` are equivalent.  Install with
`install -m 755 task-ctl /usr/local/bin/task-ctl`.

## Real configuration build

`init` accepts the defaults, override and rules files that go with the schema:

```bash
task-ctl init --schema config_schema.json --defaults defaults.json \
              --env-overrides env_overrides.json --profile dev \
              --profile-file sample_config_dev.json \
              --rules validation_rules.json --out profile_dev.json

task-ctl validate --schema config_schema.json --rules validation_rules.json \
                  --config config.json --config profile_dev.json \
                  --out validation_report.json
```

* `--defaults` supplies top level scalars (`checksum`, `mode`, `producer`,
  `container`) and the `base_config` block (`max_records`, `retry_limit`,
  `timeout_ms`, `trailer`).
* `--env-overrides` + `--profile` applies that profile's `mode` and
  `*_delta` adjustments to the base values.
* `--profile-file` applies a profile file's own `*_delta` overrides on top
  (e.g. `max_records_delta`) and sets the profile name.
* `init` validates the result before writing, so it never emits a
  configuration that breaks the contract.

Every command also accepts `--log FILE`, which appends a JSON-lines record of
that invocation; `export-report --transcript` and `summarize --transcript`
fold those records into their reports.

## Checks performed by `validate`

`config_is_object`, `required_keys_present`, `scalar_only`,
`no_forbidden_keys`, `profile_declared`, `checksum_algorithm`,
`numeric_values` and `trailer_format`.  Exit status is 0 when every
configuration passes, 1 otherwise.

`selftest` re-runs the regression checks for the faults that were repaired in
this tool; run it after any change.

## Repairs

The original archive shipped with these faults, all fixed here:

1. `init` read `--config` (an argument it does not have) instead of `--schema`.
2. `init` nested the payload under a `settings` object and only emitted three
   of the nine required keys, so the output could never satisfy the flat,
   scalar-only contract.  It now builds all required keys from the schema and
   the defaults file, flat and scalar.
3. `set` upper-cased keys (`MAX_RECORDS`) and wrote the raw CLI text, so
   `max_records` became the string `"100"`.  Keys now stay lower case and
   values are coerced to int/float/bool/null, while literals such as the
   zero padded trailer counter are left as strings.
4. `validate` called `.split(",")` on `required_keys`, which crashes on the
   authoritative schema where it is a list.  Both forms are normalised.
5. `validate` ignored `scalar_only`, the rules file's `forbidden_keys`, the
   declared profiles and the checksum algorithm, and only printed `ok`.  It
   now runs all checks, reports each one, and writes a structured report.
6. `export-report` wrote `{"ok": true, "commands": "unknown"}` — a transcript
   shape nothing could consume.  It now emits the config, its validation, the
   run transcript and author notes.
7. The subcommand was optional, so a bare invocation crashed with
   `AttributeError` on `args.func`.  A command is now required and exits with
   a usage error.
8. The bundled `schema.json` disagreed with the authoritative contract
   (`required_keys` as a CSV string, no `scalar_only`); it now matches, and
   the code accepts both forms.
