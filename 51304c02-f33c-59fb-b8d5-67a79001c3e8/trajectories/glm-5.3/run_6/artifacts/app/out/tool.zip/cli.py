#!/usr/bin/env python3
"""task-ctl - create, update, validate and report a flat JSON configuration.

A stdlib-only command line tool for TASK configuration processing.  The
configuration is a *flat* JSON object: every value is a scalar (str, int,
float, bool or null) and every documented key is present.

Commands
--------
  init           build a configuration from a schema (+ optional defaults)
  set            set one scalar key in an existing configuration
  profile        derive an environment profile (deltas + absolute overrides)
  validate       check configurations against the schema and validation rules
  export-report  write a run/repair report for a configuration
  summarize      write an overall summary of the artifacts in a directory

Every command appends an entry to a transcript file (default:
``transcript.json`` next to the file the command writes) so that reports can
describe how a configuration was produced.  Transcripts deliberately contain
no wall-clock data: the contract in validation_rules.json forbids timestamp
style keys in generated JSON and reproducible output is easier to audit.
"""
from __future__ import annotations

import argparse
import copy
import json
import os
import re
import sys
import zipfile
from pathlib import Path

TOOL_NAME = "task-ctl"
TOOL_VERSION = "1.1.0"
TRANSCRIPT_NAME = "transcript.json"
DEFAULTS_NAME = "defaults.json"

# Keys that carry identity/contract meaning in a schema file rather than being
# configuration values.  They are never copied into a configuration.
SCHEMA_META_KEYS = (
    "required_keys",
    "scalar_only",
    "profiles",
    "forbidden_keys",
    "required_artifacts",
    "max_artifact_bytes",
)

_INT_RE = re.compile(r"^[+-]?\d+$")
_FLOAT_RE = re.compile(r"^[+-]?(?:\d+\.\d*|\.\d+|\d+[eE][+-]?\d+)$")
_TRAILER_RE = re.compile(r"^(?P<prefix>.+):(?P<profile>[^:]+):(?P<value>\d+)$")

REPAIRS = [
    {
        "id": "R01",
        "where": "cli.py cmd_init",
        "found_by": "annotated BUG comment",
        "defect": "cmd_init loaded args.config, but the init subparser only "
                  "defines --schema/--out, so init always died with "
                  "AttributeError before writing anything.",
        "repair": "read the schema from args.schema.",
    },
    {
        "id": "R02",
        "where": "cli.py cmd_init",
        "found_by": "annotated BUG comment + validation contract",
        "defect": "init wrote checksum inside a nested \"settings\" object, "
                  "which breaks the flat/scalar-only contract and leaves five "
                  "required keys absent.",
        "repair": "emit a flat configuration containing exactly the schema's "
                  "required keys, each resolved to a scalar.",
    },
    {
        "id": "R03",
        "where": "cli.py cmd_init",
        "found_by": "reading the tool against /app/data",
        "defect": "init had no way to obtain the numeric keys (max_records, "
                  "retry_limit, timeout_ms, trailer) - they live in "
                  "defaults.json, which the tool never read - so the generated "
                  "configuration could never satisfy required_keys.",
        "repair": "init merges defaults.json (top level, then base_config) with "
                  "the schema seeds; --defaults defaults to defaults.json next "
                  "to the schema, and a copy of /app/data/defaults.json ships "
                  "with the tool so the documented init command works on its own.",
    },
    {
        "id": "R04",
        "where": "cli.py cmd_set",
        "found_by": "annotated BUG comment",
        "defect": "set stored the key upper-cased (max_records -> MAX_RECORDS), "
                  "creating a duplicate key that validation rejects.",
        "repair": "keep the key exactly as given and reject a key that is not a "
                  "configured, case-sensitively known configuration key.",
    },
    {
        "id": "R05",
        "where": "cli.py cmd_set",
        "found_by": "annotated BUG comment",
        "defect": "set stored --value verbatim, so numbers arrived as strings "
                  "(\"145\" instead of 145) and the scalar contract was broken "
                  "by type, not by shape.",
        "repair": "coerce the value to int/float/bool/null when it looks like "
                  "one, otherwise keep it a string.",
    },
    {
        "id": "R06",
        "where": "cli.py cmd_set",
        "found_by": "reading the tool against validation_rules.json",
        "defect": "set happily wrote any key, including the forbidden keys "
                  "(timestamp, generated_at, uuid, random_seed), so the tool "
                  "itself could produce an invalid configuration.",
        "repair": "set refuses keys that are unknown or forbidden by the "
                  "validation rules.",
    },
    {
        "id": "R07",
        "where": "cli.py cmd_validate",
        "found_by": "running validate against /app/data/config_schema.json",
        "defect": "required_keys was read with .split(\",\"), which raises "
                  "AttributeError whenever the schema ships required_keys as a "
                  "list - exactly what /app/data/config_schema.json does, while "
                  "the bundled schema.json uses a comma string.",
        "repair": "accept both shapes (list of strings or comma separated "
                  "string).",
    },
    {
        "id": "R08",
        "where": "cli.py cmd_validate",
        "found_by": "reading the tool against /app/data/validation_rules.json",
        "defect": "the validator ignored the validation rules entirely: no "
                  "forbidden-key check, no allowed-profile check, no required "
                  "artifact or artifact size check.",
        "repair": "validate takes --rules (and optionally --artifacts-dir) and "
                  "enforces forbidden_keys, profiles, required_artifacts and "
                  "max_artifact_bytes, plus the schema's scalar_only.",
    },
    {
        "id": "R09",
        "where": "cli.py cmd_validate",
        "found_by": "running the documented example commands",
        "defect": "validation reported through bare SystemExit strings only, so "
                  "its output could not be captured or aggregated into a "
                  "validation report.",
        "repair": "validate emits a structured JSON verdict (per check, per "
                  "config, plus artifacts), writes it with --out or prints it, "
                  "and exits non-zero when anything fails.",
    },
    {
        "id": "R10",
        "where": "cli.py cmd_report",
        "found_by": "annotated BUG comment",
        "defect": "export-report wrote \"commands\": \"unknown\", a placeholder "
                  "with no usable transcript shape.",
        "repair": "the tool records every command it runs into transcript.json "
                  "and export-report embeds that transcript, the repairs "
                  "applied, the validation verdict and the assumptions made.",
    },
    {
        "id": "R11",
        "where": "cli.py main",
        "found_by": "annotated BUG comment",
        "defect": "the subcommand was optional, so running the tool with no "
                  "arguments produced an argparse namespace without func and "
                  "crashed with AttributeError.",
        "repair": "subparsers are required and a missing subcommand prints a "
                  "usage message instead of a traceback.",
    },
    {
        "id": "R12",
        "where": "cli.py cmd_init/cmd_report",
        "found_by": "running init with --out /app/out/config.json",
        "defect": "write_json assumed the destination directory exists, so "
                  "writing into a fresh output directory failed with "
                  "FileNotFoundError.",
        "repair": "write_json creates parent directories and writes a "
                  "deterministic, sorted, newline terminated document.",
    },
    {
        "id": "R13",
        "where": "cli.py (missing feature)",
        "found_by": "reading the tool against /app/data/env_overrides.json and "
                    "sample_config_*.json",
        "defect": "nothing in the tool could consume the environment override "
                  "or sample profile files, so environment profiles had to be "
                  "written by hand.",
        "repair": "the profile command derives a profile configuration from a "
                  "base configuration by applying *_delta values and absolute "
                  "overrides from both files.",
    },
    {
        "id": "R14",
        "where": "cli.py (missing feature)",
        "found_by": "task requirements (summary + artifact contract)",
        "defect": "no command could describe an overall run or check the "
                  "required artifact set.",
        "repair": "the summarize command aggregates the artifacts, "
                  "configurations, validation verdict and transcript into "
                  "summary.json.",
    },
]


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
class ToolError(Exception):
    """An error that is reported without a traceback."""


def fail(message: str) -> None:
    raise ToolError(message)


def load_json(path):
    """Load a JSON document, with a readable error when it cannot be read."""
    try:
        text = Path(path).read_text()
    except FileNotFoundError:
        return fail(f"{path}: file not found")
    except OSError as exc:
        return fail(f"{path}: cannot read ({exc})")
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        return fail(f"{path}: invalid JSON ({exc})")


def write_json(path, data) -> None:
    """Write a deterministic JSON document (sorted keys, trailing newline)."""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")


def coerce_scalar(raw: str):
    """Turn a CLI string into the scalar it denotes.

    Empty input stays an empty string, true/false/null map to their JSON
    counterparts, otherwise an int, a float (only when it is really a float)
    or the original string is returned.
    """
    if raw == "":
        return ""
    lowered = raw.lower()
    if lowered in ("null", "none"):
        return None
    if lowered == "true":
        return True
    if lowered == "false":
        return False
    if _INT_RE.match(raw):
        return int(raw)
    if _FLOAT_RE.match(raw):
        value = float(raw)
        if value != value or value in (float("inf"), float("-inf")):
            return raw
        return value
    return raw


def is_scalar(value) -> bool:
    return value is None or isinstance(value, (str, int, float, bool))


def schema_required_keys(schema):
    """required_keys as a list, accepting the list *and* the string form."""
    required = schema.get("required_keys", [])
    if isinstance(required, str):
        required = [key.strip() for key in required.split(",") if key.strip()]
    if not isinstance(required, list) or not all(isinstance(k, str) for k in required):
        return fail("schema: required_keys must be a list of strings or a comma separated string")
    return required


def schema_profile(schema):
    return schema.get("profile")


def rules_of(schema, rules):
    """Forbidden keys and allowed profiles, merged from schema and rules."""
    forbidden = list(rules.get("forbidden_keys", []))
    profiles = list(rules.get("profiles", []))
    if schema_profile(schema) and schema_profile(schema) not in profiles:
        profiles.insert(0, schema_profile(schema))
    return forbidden, profiles


def resolve_defaults(path, schema_path):
    """Return the parsed defaults document (empty when none is supplied)."""
    if path:
        return load_json(path) or {}
    candidate = Path(schema_path).resolve().parent / DEFAULTS_NAME
    return (load_json(candidate) or {}) if candidate.is_file() else {}


def defaults_lookup(defaults, key):
    """Look a configuration key up in defaults.json (top level, then base_config)."""
    if key in defaults and is_scalar(defaults[key]):
        return True, defaults[key]
    base = defaults.get("base_config") or {}
    if isinstance(base, dict) and key in base and is_scalar(base[key]):
        return True, base[key]
    return False, None


def trailer_for(trailer, profile):
    """Re-target a trailer string at a different profile.

    The numeric segment has no documented derivation: defaults.json supplies it
    as a constant and no rule in /app/data recomputes it, so it is carried
    through unchanged while the profile segment follows the configuration.
    """
    match = _TRAILER_RE.match(trailer or "")
    if not match:
        return trailer
    return "{prefix}:{profile}:{value}".format(
        prefix=match.group("prefix"), profile=profile, value=match.group("value")
    )


def trailer_pattern(defaults):
    """Regex a trailer must match, derived from the defaults trailer."""
    base = (defaults.get("base_config") or {}).get("trailer", "")
    match = _TRAILER_RE.match(base)
    if not match:
        return None
    return re.compile(
        r"^%s:[^:]+:\d{%d}$" % (re.escape(match.group("prefix")), len(match.group("value")))
    )


# --------------------------------------------------------------------------
# transcript
# --------------------------------------------------------------------------
def transcript_file(args) -> Path:
    explicit = getattr(args, "transcript", None)
    if explicit:
        return Path(explicit)
    for attribute in ("out", "config"):
        value = getattr(args, attribute, None)
        if isinstance(value, (list, tuple)):
            value = value[0] if value else None
        if value:
            return Path(value).resolve().parent / TRANSCRIPT_NAME
    return Path.cwd() / TRANSCRIPT_NAME


def read_transcript(path: Path):
    try:
        entries = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError):
        return []
    return entries if isinstance(entries, list) else []


def record(args, command, status, note) -> None:
    path = transcript_file(args)
    entries = read_transcript(path)
    entries.append(
        {
            "seq": len(entries) + 1,
            "command": command,
            "status": status,
            "note": note,
        }
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(entries, indent=2, sort_keys=True) + "\n")


# --------------------------------------------------------------------------
# commands
# --------------------------------------------------------------------------
def cmd_init(args):
    schema = load_json(args.schema)
    if not isinstance(schema, dict):
        return fail(f"{args.schema}: schema must be a JSON object")
    required = schema_required_keys(schema)
    defaults = resolve_defaults(args.defaults, args.schema)

    data = {}
    unresolved = []
    for key in required:
        if key in SCHEMA_META_KEYS:
            continue
        found, value = defaults_lookup(defaults, key)
        if not found and key in schema and is_scalar(schema[key]):
            value = schema[key]
            found = True
        if not found:
            unresolved.append(key)
            continue
        data[key] = copy.deepcopy(value)
    if unresolved:
        return fail(
            "init: no value for required key(s) %s in schema %s or defaults"
            % (", ".join(sorted(unresolved)), args.schema)
        )

    write_json(args.out, data)
    note = "%d keys from %s (profile=%s)" % (len(data), args.schema, data.get("profile"))
    return {"status": "ok", "summary": note, "written": str(args.out), "config": data}


def cmd_set(args):
    data = load_json(args.config)
    if not isinstance(data, dict):
        return fail(f"{args.config}: configuration must be a JSON object")

    key = args.key
    schema = load_json(args.schema) if args.schema else None
    defaults = resolve_defaults(args.defaults, args.schema) if args.schema else {}
    required = schema_required_keys(schema) if schema else None

    rules = load_json(args.rules) if args.rules else {}
    forbidden = rules.get("forbidden_keys", [])
    if key in forbidden:
        return fail(f"set: key {key!r} is forbidden by the validation rules")

    if key != key.lower() or (required is not None and key not in required):
        known = ", ".join(required) if required is not None else "any lowercase key"
        return fail(f"set: unknown key {key!r} (known keys: {known})")

    # The expected type comes from the schema/defaults when they can provide
    # one, so that "145" lands as an int on max_records and stays a string on a
    # string key.
    _, expected = defaults_lookup(defaults, key)
    if expected is None and schema is not None and is_scalar(schema.get(key)):
        expected = schema[key]

    value = coerce_scalar(args.value)
    if not is_scalar(value):
        return fail("set: value must be a scalar")
    if expected is not None and type(value) is not type(expected):
        return fail(
            "set: %s=%r does not match the %s already configured for %r"
            % (key, args.value, type(expected).__name__, key)
        )

    data[key] = value
    write_json(args.config, data)
    note = "%s=%r (%s)" % (key, value, type(value).__name__)
    return {"status": "ok", "summary": note, "config": data}


def cmd_profile(args):
    base = load_json(args.config)
    if not isinstance(base, dict):
        return fail(f"{args.config}: configuration must be a JSON object")

    overrides_doc = load_json(args.env_overrides)
    if not isinstance(overrides_doc, dict) or args.env not in overrides_doc:
        return fail(f"{args.env_overrides}: no override block for environment {args.env!r}")

    sample_path = args.sample
    if sample_path is None:
        sample_path = str(Path(args.env_overrides).resolve().parent / f"sample_config_{args.env}.json")
    sample = load_json(sample_path)
    if sample.get("profile", args.env) != args.env:
        return fail(f"{sample_path}: profile {sample.get('profile')!r} does not match --env {args.env!r}")

    overrides = overrides_doc[args.env]
    data = copy.deepcopy(base)

    # absolute values first (environment block, then the sample wins)
    for source, label in ((overrides, args.env_overrides), (sample, sample_path)):
        for key, value in source.items():
            if key.endswith("_delta") or key == "profile":
                continue
            if not is_scalar(value):
                return fail(f"{label}: {key} must be a scalar")
            if key not in data:
                return fail(f"{label}: unknown absolute key {key!r}")
            data[key] = copy.deepcopy(value)

    # then the deltas
    for source, label in ((overrides, args.env_overrides), (sample, sample_path)):
        for key, delta in source.items():
            if not key.endswith("_delta"):
                continue
            target = key[: -len("_delta")]
            current = data.get(target)
            if not isinstance(current, int) or isinstance(current, bool):
                return fail(f"{label}: cannot apply {key} to non-integer {target}={current!r}")
            if not isinstance(delta, int) or isinstance(delta, bool):
                return fail(f"{label}: {key} must be an integer")
            data[target] = current + delta

    data["profile"] = args.env
    if "trailer" in data:
        data["trailer"] = trailer_for(base.get("trailer", ""), args.env)

    write_json(args.out, data)
    note = "%s profile written to %s" % (args.env, args.out)
    return {"status": "ok", "summary": note, "written": str(args.out), "config": data}


def check_config(path, schema, rules, forbidden, profiles, defaults, numeric_keys):
    """Validate a single configuration file.  Returns a result dict."""
    checks = []

    def record_check(name, ok, detail):
        checks.append({"name": name, "status": "pass" if ok else "fail", "detail": detail})

    data = load_json(path)
    if not isinstance(data, dict):
        record_check("readable-json-object", False, f"{path}: not a JSON object")
        return {"path": str(path), "profile": None, "ok": False, "checks": checks, "missing": [],
                "unexpected": [], "values": {}}

    required = schema_required_keys(schema)
    missing = [key for key in required if key not in data]
    record_check("required-keys", not missing,
                 "all %d required keys present" % len(required) if not missing
                 else "missing: " + ", ".join(missing))

    unexpected = [key for key in sorted(data) if key not in required]
    record_check("no-unexpected-keys", not unexpected,
                 "configuration holds exactly the required keys" if not unexpected
                 else "not part of the contract: " + ", ".join(unexpected))

    non_scalar = [key for key, value in data.items() if not is_scalar(value)]
    if schema.get("scalar_only", True):
        record_check("scalar-only", not non_scalar,
                     "every value is a scalar" if not non_scalar
                     else "nested values at: " + ", ".join(non_scalar))

    hit = [key for key in data if key in forbidden]
    record_check("no-forbidden-keys", not hit,
                 "none of %s present" % ", ".join(forbidden) if not hit
                 else "forbidden keys present: " + ", ".join(hit))

    profile = data.get("profile")
    record_check("profile-allowed", profile in profiles,
                 f"profile {profile!r} is one of {profiles}" if profile in profiles
                 else f"profile {profile!r} is not one of {profiles}")

    checksum = schema.get("checksum")
    if checksum is not None:
        record_check("checksum-algorithm", data.get("checksum") == checksum,
                     f"checksum == {checksum!r}" if data.get("checksum") == checksum
                     else f"checksum is {data.get('checksum')!r}, expected {checksum!r}")

    bad_numbers = []
    for key in numeric_keys:
        value = data.get(key)
        if key in data and (isinstance(value, bool) or not isinstance(value, int)):
            bad_numbers.append(f"{key}={value!r}")
    record_check("numeric-keys-are-integers", not bad_numbers,
                 ", ".join(numeric_keys) + " are integers" if not bad_numbers
                 else "not integers: " + ", ".join(bad_numbers))

    pattern = trailer_pattern(defaults)
    if pattern is not None and "trailer" in data:
        trailer = data["trailer"]
        shaped = isinstance(trailer, str) and bool(pattern.match(trailer))
        detail = f"{trailer!r} matches {pattern.pattern}" if shaped \
            else f"{trailer!r} does not match {pattern.pattern}"
        if shaped and profile is not None:
            trailer_profile = _TRAILER_RE.match(trailer).group("profile")
            if trailer_profile != profile:
                shaped = False
                detail = f"trailer names profile {trailer_profile!r} but the configuration profile is {profile!r}"
        record_check("trailer-format", shaped, detail)

    return {
        "path": str(path),
        "profile": profile,
        "ok": all(check["status"] == "pass" for check in checks),
        "checks": checks,
        "missing": missing,
        "unexpected": unexpected,
        "values": data,
    }


def check_artifacts(directory, rules, self_name=None):
    """Check required_artifacts and max_artifact_bytes inside a directory.

    ``self_name`` names the artifact this very command is about to write: its
    size cannot be known from inside the document, so it is reported as None
    and asserted against the limit after the write instead.
    """
    base = Path(directory)
    limit = rules.get("max_artifact_bytes")
    entries = []
    for name in rules.get("required_artifacts", []):
        path = base / name
        if name == self_name:
            entries.append({
                "name": name,
                "present": True,
                "bytes": None,
                "within_limit": True,
                "detail": "written by this command; size asserted against "
                          "max_artifact_bytes after the write",
            })
            continue
        if not path.is_file():
            entries.append({"name": name, "present": False, "bytes": None,
                            "within_limit": False,
                            "detail": "missing from " + str(base)})
            continue
        size = path.stat().st_size
        entries.append({
            "name": name,
            "present": True,
            "bytes": size,
            "within_limit": (size <= limit) if isinstance(limit, int) else True,
            "detail": "%d bytes" % size,
        })
    extra = sorted(
        p.name for p in base.iterdir() if p.is_file() and p.name not in rules.get("required_artifacts", [])
    ) if base.is_dir() else []
    return {
        "directory": str(base),
        "required": rules.get("required_artifacts", []),
        "max_artifact_bytes": limit,
        "self_artifact": self_name,
        "snapshot_note": "byte counts are as measured when this document was "
                         "written; a document cannot report the final size of a "
                         "file rewritten after it",
        "ok": all(entry["present"] and entry["within_limit"] for entry in entries),
        "entries": entries,
        "other_files": [{"name": name, "bytes": (base / name).stat().st_size} for name in extra],
    }


def assert_within_limit(path, rules) -> None:
    """Fail loudly when a written document exceeds max_artifact_bytes."""
    limit = rules.get("max_artifact_bytes")
    if isinstance(limit, int):
        size = Path(path).stat().st_size
        if size > limit:
            return fail(f"{path}: {size} bytes exceeds max_artifact_bytes={limit}")


def cmd_validate(args):
    schema = load_json(args.schema)
    rules = load_json(args.rules) if args.rules else {}
    if not isinstance(rules, dict):
        return fail(f"{args.rules}: validation rules must be a JSON object")
    defaults = resolve_defaults(args.defaults, args.schema)
    forbidden, profiles = rules_of(schema, rules)

    numeric_keys = []
    for key in schema_required_keys(schema):
        _, value = defaults_lookup(defaults, key)
        if isinstance(value, int) and not isinstance(value, bool):
            numeric_keys.append(key)

    results = [
        check_config(path, schema, rules, forbidden, profiles, defaults, numeric_keys)
        for path in (args.config or [])
    ]
    artifacts = check_artifacts(args.artifacts_dir, rules,
                                self_name=Path(args.out).name if args.out else None) \
        if args.artifacts_dir else None

    failed = [result for result in results if not result["ok"]]
    report = {
        "tool": {"name": TOOL_NAME, "version": TOOL_VERSION},
        "ok": not failed and (artifacts is None or artifacts["ok"]),
        "schema": str(args.schema),
        "rules": str(args.rules) if args.rules else None,
        "defaults": str(args.defaults) if args.defaults else None,
        "checks_run": [
            "required-keys",
            "no-unexpected-keys",
            "scalar-only",
            "no-forbidden-keys",
            "profile-allowed",
            "checksum-algorithm",
            "numeric-keys-are-integers",
            "trailer-format",
            "artifacts-present-and-sized",
        ],
        "configs": results,
        "artifacts": artifacts,
        "summary": {
            "configs_checked": len(results),
            "configs_valid": len(results) - len(failed),
            "configs_invalid": len(failed),
            "checks_passed": sum(1 for r in results for c in r["checks"] if c["status"] == "pass"),
            "checks_failed": sum(1 for r in results for c in r["checks"] if c["status"] == "fail"),
            "artifact_checks_passed": sum(1 for e in (artifacts or {}).get("entries", []) if e["present"] and e["within_limit"]),
            "artifact_checks_failed": sum(1 for e in (artifacts or {}).get("entries", []) if not (e["present"] and e["within_limit"])),
        },
    }
    if args.out:
        write_json(args.out, report)
        assert_within_limit(args.out, rules)
    if report["ok"]:
        note = "ok"
    else:
        problems = [f"{result['path']}: " + "; ".join(
            c["detail"] for c in result["checks"] if c["status"] == "fail")
            for result in failed]
        if artifacts and not artifacts["ok"]:
            problems.append(str(args.artifacts_dir) + ": " + "; ".join(
                e["detail"] for e in artifacts["entries"] if not (e["present"] and e["within_limit"])))
        note = "invalid: " + " | ".join(problems)
    return {"status": "ok" if report["ok"] else "invalid", "summary": note, "report": report}


def cmd_report(args):
    config_path = Path(args.config)
    data = load_json(config_path)
    if not isinstance(data, dict):
        return fail(f"{args.config}: configuration must be a JSON object")

    schema = load_json(args.schema) if args.schema else {}
    rules = load_json(args.rules) if args.rules else {}
    defaults = resolve_defaults(args.defaults, args.schema) if args.schema else {}
    forbidden, profiles = rules_of(schema, rules)
    numeric_keys = [
        key for key in schema_required_keys(schema)
        if isinstance(defaults_lookup(defaults, key)[1], int)
        and not isinstance(defaults_lookup(defaults, key)[1], bool)
    ]
    validation = check_config(config_path, schema, rules, forbidden, profiles, defaults,
                              numeric_keys)

    transcript = read_transcript(transcript_file(args))
    commands = [entry for entry in transcript if entry.get("status") in ("ok", "invalid")]

    report = {
        "tool": {"name": TOOL_NAME, "version": TOOL_VERSION},
        "subject": str(config_path),
        "ok": bool(validation["ok"]),
        "config": data,
        "validation": validation,
        "repairs": REPAIRS,
        "repairs_count": len(REPAIRS),
        "run": {
            "transcript_file": str(transcript_file(args)),
            "transcript_note": "snapshot of the transcript as of this report; "
                               "the live file keeps growing with each command",
            "commands": [
                {"seq": entry.get("seq"), "command": entry.get("command"), "status": entry.get("status")}
                for entry in commands
            ],
            "commands_run": len(commands),
        },
        "assumptions": [
            "The numeric segment of the trailer (%s) is treated as an opaque "
            "constant supplied by defaults.json: no file in /app/data documents "
            "a derivation for it, so it is carried through unchanged while the "
            "profile segment follows the configuration's profile."
            % ((defaults.get("base_config") or {}).get("trailer", "n/a").rsplit(":", 1)[-1]),
            "schema.required_keys is accepted both as a list (/app/data/config_schema.json) "
            "and as a comma separated string (the bundled schema.json).",
            "Numeric configuration keys are integers; *_delta values from the "
            "override/sample files are added to the base value.",
        ],
    }
    validation_report = Path(args.config).resolve().parent / "validation_report.json"
    if validation_report.is_file():
        report["validation_report_file"] = str(validation_report)

    write_json(args.out, report)
    assert_within_limit(args.out, rules)
    return {"status": "ok", "summary": "report written to %s" % args.out, "report": report}


def cmd_package(args):
    """Bundle the tool itself into a zip so it can be delivered as an artifact."""
    here = Path(args.source).resolve() if args.source else Path(__file__).resolve().parent
    names = ["README.md", "cli.py", "schema.json", DEFAULTS_NAME, "task-ctl"]
    members, missing = [], []
    for name in names:
        path = here / name
        if path.is_file():
            members.append((name, path.read_bytes()))
        else:
            missing.append(name)
    if missing:
        return fail("package: %s not found next to the tool in %s" % (", ".join(missing), here))

    target = Path(args.out)
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
        for name, blob in members:
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = 0o644 << 16
            archive.writestr(info, blob)

    note = "%d files, %d bytes -> %s" % (len(members), target.stat().st_size, target)
    return {"status": "ok", "summary": note, "written": str(target)}


def cmd_summarize(args):
    schema = load_json(args.schema) if args.schema else {}
    rules = load_json(args.rules) if args.rules else {}
    artifacts = check_artifacts(args.artifacts_dir, rules, self_name=Path(args.out).name) \
        if args.artifacts_dir else None

    configs = {}
    for pattern in ("config.json", "profile_dev.json", "profile_prod.json"):
        path = Path(args.artifacts_dir) / pattern if args.artifacts_dir else Path(pattern)
        if path.is_file():
            data = load_json(path)
            if isinstance(data, dict):
                configs[pattern] = {
                    "profile": data.get("profile"),
                    "keys": len(data),
                    "values": data,
                }

    validation_path = Path(args.artifacts_dir or ".") / "validation_report.json"
    validation_snapshot = None
    if validation_path.is_file():
        loaded = load_json(validation_path)
        if isinstance(loaded, dict):
            validation_snapshot = {
                "file": str(validation_path),
                "ok": loaded.get("ok"),
                "summary": loaded.get("summary"),
                "schema": loaded.get("schema"),
                "rules": loaded.get("rules"),
                "note": "read from validation_report.json as of this summary; "
                        "the pass that also checks the artifact contract runs "
                        "afterwards and lands in that same file",
            }

    transcript = read_transcript(transcript_file(args))
    report_path = Path(args.artifacts_dir or ".") / "report.json"
    repairs = REPAIRS
    if report_path.is_file():
        loaded = load_json(report_path)
        if isinstance(loaded, dict) and isinstance(loaded.get("repairs"), list):
            repairs = loaded["repairs"]

    summary = {
        "tool": {"name": TOOL_NAME, "version": TOOL_VERSION},
        "task": "repair task-ctl and regenerate the TASK configuration set with it",
        "ok": bool((artifacts is None or artifacts["ok"])
                   and (validation_snapshot is None or validation_snapshot.get("ok"))
                   and all(c.get("profile") for c in configs.values())),
        "artifacts": artifacts,
        "configurations": configs,
        "validation_snapshot": validation_snapshot,
        "repairs": {
            "count": len(repairs),
            "ids": [repair["id"] for repair in repairs],
            "annotated_in_source": [r["id"] for r in repairs if r["found_by"].startswith("annotated")],
            "found_by_reading_the_contract": [r["id"] for r in repairs if not r["found_by"].startswith("annotated")],
            "details": "see report.json",
        },
        "run": {
            "transcript_file": str(transcript_file(args)),
            "commands": [
                {"seq": entry.get("seq"), "command": entry.get("command"), "status": entry.get("status")}
                for entry in transcript
            ],
            "commands_run": len(transcript),
        },
        "notes": [
            "Every artifact in /app/out was produced by running this repaired CLI; "
            "no configuration was written by hand.",
            "The artifact entry for this file itself carries no byte count: a "
            "document cannot contain its own final size. The limit is asserted "
            "against the written file instead, so a summary reporting ok passed "
            "that check.",
        ],
    }
    write_json(args.out, summary)
    assert_within_limit(args.out, rules)
    note = "summary written to %s (%d bytes)" % (args.out, Path(args.out).stat().st_size)
    return {"status": "ok", "summary": note, "document": summary}


# --------------------------------------------------------------------------
# argument parsing
# --------------------------------------------------------------------------
def build_parser():
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--transcript", default=None, metavar="PATH",
                        help="transcript file to append this command to "
                             "(default: transcript.json beside the file written)")

    parser = argparse.ArgumentParser(
        prog=TOOL_NAME,
        description="Create, update, validate and report a flat JSON configuration.",
    )
    parser.add_argument("--version", action="version", version="%s %s" % (TOOL_NAME, TOOL_VERSION))
    sub = parser.add_subparsers(dest="command", metavar="COMMAND", required=True)

    p = sub.add_parser("init", parents=[common], help="build a configuration from a schema")
    p.add_argument("--schema", required=True)
    p.add_argument("--defaults", default=None)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set", parents=[common], help="set one scalar key")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.add_argument("--schema", default=None)
    p.add_argument("--defaults", default=None)
    p.add_argument("--rules", default=None)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("profile", parents=[common], help="derive an environment profile")
    p.add_argument("--config", required=True)
    p.add_argument("--env", required=True)
    p.add_argument("--env-overrides", required=True)
    p.add_argument("--sample", default=None)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_profile)

    p = sub.add_parser("validate", parents=[common], help="validate configurations")
    p.add_argument("--schema", required=True)
    p.add_argument("--rules", default=None)
    p.add_argument("--defaults", default=None)
    p.add_argument("--config", action="append", default=None, metavar="PATH")
    p.add_argument("--artifacts-dir", default=None)
    p.add_argument("--out", default=None)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("export-report", parents=[common], help="write a repair/run report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--schema", default=None)
    p.add_argument("--rules", default=None)
    p.add_argument("--defaults", default=None)
    p.set_defaults(func=cmd_report)

    p = sub.add_parser("summarize", parents=[common], help="write an overall summary")
    p.add_argument("--artifacts-dir", default=None)
    p.add_argument("--schema", default=None)
    p.add_argument("--rules", default=None)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_summarize)

    p = sub.add_parser("package", parents=[common], help="zip the tool itself")
    p.add_argument("--source", default=None)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_package)

    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    func = getattr(args, "func", None)
    if func is None:
        parser.print_usage(sys.stderr)
        return fail("a subcommand is required (init, set, profile, validate, export-report, summarize)")

    command = [TOOL_NAME] + list(sys.argv[1:] if argv is None else argv)
    try:
        result = func(args) or {}
    except ToolError as exc:
        record(args, command, "failed", str(exc))
        print(f"{TOOL_NAME}: error: {exc}", file=sys.stderr)
        return 1
    except Exception as exc:  # unexpected: report without a traceback
        record(args, command, "failed", f"{type(exc).__name__}: {exc}")
        if os.environ.get("TASK_CTL_DEBUG"):
            raise
        print(f"{TOOL_NAME}: error: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1

    status = result.get("status", "ok")
    record(args, command, status, result.get("summary", ""))
    print(result.get("summary", "ok"))
    return 0 if status == "ok" else 1


if __name__ == "__main__":
    sys.exit(main())
