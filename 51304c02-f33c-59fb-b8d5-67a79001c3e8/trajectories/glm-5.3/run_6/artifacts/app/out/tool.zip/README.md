# task-ctl

This local stdlib-only CLI creates, updates, validates, and reports a flat
JSON configuration for TASK processing.

A configuration is a *flat* JSON object: every value is a scalar and every key
listed in the schema's `required_keys` is present. The contract lives in the
schema (`required_keys`, `scalar_only`, `checksum`, `profile`) and in the
validation rules (`profiles`, `forbidden_keys`, `required_artifacts`,
`max_artifact_bytes`).

## Install

```bash
./task-ctl --version          # or: python3 cli.py --version
```

`task-ctl` is a two-line launcher around `cli.py`; both invoke the same tool.

## Commands

```bash
python3 cli.py init --schema schema.json --out config.json
python3 cli.py set --config config.json --key max_records --value 100
python3 cli.py validate --schema schema.json --config config.json
python3 cli.py export-report --config config.json --out report.json
```

`init` seeds every required key from the schema and from `defaults.json`
(--defaults, or `defaults.json` next to the schema), so the generated
configuration is complete and valid straight away.

Additional commands used to build a full artifact set:

```bash
python3 cli.py profile --config config.json --env dev \
    --env-overrides env_overrides.json --out profile_dev.json
python3 cli.py validate --schema schema.json --rules validation_rules.json \
    --config config.json --config profile_dev.json --artifacts-dir out \
    --out validation_report.json
python3 cli.py export-report --config config.json --schema schema.json \
    --rules validation_rules.json --out report.json
python3 cli.py summarize --artifacts-dir out --schema schema.json \
    --rules validation_rules.json --out summary.json
python3 cli.py package --out tool.zip
```

`profile` derives an environment configuration: `*_delta` values from
`env_overrides.json` and `sample_config_<env>.json` are added to the base
value, absolute values are copied over, and the trailer's profile segment
follows the new profile.

Every invocation appends an entry to `transcript.json` (next to the file the
command writes, or set explicitly with `--transcript`), which `export-report`
and `summarize` embed. No timestamps are recorded, keeping output reproducible
and clear of the keys forbidden by the validation rules.

Exit status is `0` on success and `1` on any error or failed validation.
