# task-ctl

A stdlib-only CLI that creates, updates, validates and reports the flat JSON
configuration used for TASK processing. The configuration is a single JSON
object of scalar values; its shape is fixed by a schema file and by the rules
in `validation_rules.json`, and its values are composed from `defaults.json`
plus, for an environment profile, a sample profile file and the per-profile
overrides in `env_overrides.json`.

## Commands

```bash
# base configuration (profile comes from the schema)
python3 cli.py init --schema schema.json --out config.json

# environment profile: sample file + env_overrides.json deltas
python3 cli.py init --schema schema.json --out profile_dev.json \
    --profile dev --profile-file sample_config_dev.json

# update one scalar (values are coerced: "100" -> 100)
python3 cli.py set --config config.json --key max_records --value 100

# validate one or more configurations, optionally as a JSON report
python3 cli.py validate --schema schema.json --config config.json
python3 cli.py validate --schema schema.json --config config.json \
    --config profile_dev.json --config profile_prod.json \
    --profile TASK --profile dev --profile prod \
    --rules validation_rules.json --out validation_report.json

# report on a configuration, optionally folding in the run log and notes
python3 cli.py export-report --config config.json --out report.json

# check a deliverables directory against the rules
python3 cli.py summarize --dir out --rules validation_rules.json --out out/summary.json

# archive the tool itself (fixed timestamps, so the zip is reproducible)
python3 cli.py pack --source . --out tool.zip
```

Inputs that are not passed explicitly are looked up next to the schema file:
`init` probes for `defaults.json` (required) and `env_overrides.json` (needed
only when `--profile` is given).

Pass `--log run.jsonl` (before the subcommand) to append one JSON line per
invocation; `export-report --transcript run.jsonl` folds that log into the
report. Every command exits non-zero and prints a diagnostic on failure.

## Validation checks

`validate` reports an error for a missing required key, a forbidden key, a
non-scalar or null value, a `checksum` other than the schema's, a `profile`
outside the schema profile and the rules' `profiles`, a `trailer` that does not
match `harbor:cli-config:<name>:<16 digits>`, or a non-integer/negative
`max_records`, `retry_limit`, `timeout_ms`. Keys outside `required_keys` are
reported as warnings rather than errors.
