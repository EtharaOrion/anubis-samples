#!/usr/bin/env python3
"""task-ctl: create, update, validate and report a flat JSON configuration.

The configuration is a single flat JSON object of scalar values. Its shape is
described by a schema file (``config_schema.json``) and the companion rules in
``validation_rules.json``; the values are composed from ``defaults.json`` and,
for an environment profile, from a sample profile file plus the per-profile
overrides in ``env_overrides.json``. Only the Python standard library is used.

Commands: init, set, validate, export-report, pack, summarize.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import zipfile
from pathlib import Path

TOOL_NAME = "task-ctl"
TOOL_VERSION = "1.1.0"

#: Keys the tool knows how to derive from the base configuration.
NUMERIC_KEYS = ("max_records", "retry_limit", "timeout_ms")

#: Shape of the trailer token shipped in ``defaults.json``.
TRAILER_PATTERN = re.compile(r"^harbor:cli-config:[^:\s]+:[0-9]{16}$")

#: Checks performed by ``validate``; also reported in ``export-report``.
VALIDATION_CHECKS = (
    "required_keys",
    "scalar_only",
    "forbidden_keys",
    "checksum",
    "profile",
    "trailer",
    "numeric_types",
)


class ToolError(Exception):
    """Fatal, user-facing error; printed to stderr and turned into exit code 1."""


# --------------------------------------------------------------------------- io


def load_json(path):
    """Parse a JSON document, reporting problems as :class:`ToolError`."""
    try:
        text = Path(path).read_text(encoding="utf-8")
    except OSError as exc:
        raise ToolError(f"cannot read {path}: {exc.strerror or exc}") from exc
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        raise ToolError(f"{path} is not valid JSON: {exc.msg}") from exc


def write_json(path, data):
    """Write stable JSON: UTF-8, sorted keys, two-space indent, newline."""
    target = Path(path)
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(
            json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
    except OSError as exc:
        raise ToolError(f"cannot write {path}: {exc.strerror or exc}") from exc


def canonical_bytes(data):
    """Deterministic byte form of a document, used for digests."""
    return json.dumps(
        data, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode("utf-8")


def digest(data):
    return "sha256:" + hashlib.sha256(canonical_bytes(data)).hexdigest()


def file_digest(path):
    hasher = hashlib.sha256()
    try:
        hasher.update(Path(path).read_bytes())
    except OSError as exc:
        raise ToolError(f"cannot read {path}: {exc.strerror or exc}") from exc
    return "sha256:" + hasher.hexdigest()


# ------------------------------------------------------------------ contracts


def normalize_schema(raw):
    """Accept the schema in either shipped form (list or comma-joined keys)."""
    if not isinstance(raw, dict):
        raise ToolError("schema must be a JSON object")
    keys = raw.get("required_keys")
    if isinstance(keys, str):
        keys = [part.strip() for part in keys.split(",") if part.strip()]
    elif isinstance(keys, list):
        keys = [str(part) for part in keys]
    else:
        raise ToolError("schema is missing required_keys")
    if not keys:
        raise ToolError("schema declares no required_keys")
    return {
        "profile": raw.get("profile", ""),
        "producer": raw.get("producer", ""),
        "container": raw.get("container", ""),
        "checksum": raw.get("checksum", ""),
        "required_keys": keys,
        "scalar_only": bool(raw.get("scalar_only", True)),
    }


def load_schema(path):
    return normalize_schema(load_json(path))


def load_rules(path):
    raw = load_json(path) if path else {}
    if not isinstance(raw, dict):
        raise ToolError("rules must be a JSON object")
    return {
        "profiles": [str(p) for p in raw.get("profiles", [])],
        "forbidden_keys": [str(k) for k in raw.get("forbidden_keys", [])],
        "required_artifacts": [str(a) for a in raw.get("required_artifacts", [])],
        "max_artifact_bytes": int(raw.get("max_artifact_bytes", 0)),
        "source": str(path) if path else "",
    }


#: Used when no rules file is reachable, so that the safety checks (notably the
#: forbidden keys) still apply to a bare `set` or `validate`.
BUILTIN_RULES = {
    "profiles": [],
    "forbidden_keys": ["timestamp", "generated_at", "uuid", "random_seed"],
    "required_artifacts": [],
    "max_artifact_bytes": 0,
    "source": "builtin",
}


def resolve_rules(explicit, *near):
    """Explicit path, else validation_rules.json beside one of ``near`` paths."""
    if explicit:
        return load_rules(explicit)
    for neighbour in near:
        if not neighbour:
            continue
        candidate = Path(neighbour).resolve().parent / "validation_rules.json"
        if candidate.exists():
            return load_rules(str(candidate))
    return dict(BUILTIN_RULES)


def companion(schema_path, name, explicit):
    """Resolve an optional input next to the schema when not given explicitly."""
    if explicit:
        return explicit
    candidate = Path(schema_path).resolve().parent / name
    return str(candidate) if candidate.exists() else None


# -------------------------------------------------------------- configuration


def coerce_scalar(raw):
    """Turn a CLI ``--value`` string into a JSON scalar (never a container)."""
    text = str(raw)
    lowered = text.lower()
    if lowered in ("true", "false"):
        return lowered == "true"
    if lowered in ("null", "none", ""):
        raise ToolError(f"{raw!r} is not a usable scalar value")
    try:
        return int(text)
    except ValueError:
        pass
    try:
        return float(text)
    except ValueError:
        return text


def build_base_config(schema, defaults):
    """Flat base configuration: schema identity fields + default settings."""
    base = defaults.get("base_config", {})
    if not isinstance(base, dict):
        raise ToolError("defaults.base_config must be an object")
    config = {
        "profile": schema["profile"],
        "producer": defaults.get("producer", schema["producer"]),
        "container": defaults.get("container", schema["container"]),
        "checksum": schema["checksum"] or defaults.get("checksum", ""),
        "mode": defaults.get("mode", ""),
        "trailer": "",
    }
    for key in NUMERIC_KEYS:
        value = base.get(key)
        if not isinstance(value, int) or isinstance(value, bool):
            raise ToolError(f"defaults.base_config.{key} must be an integer")
        config[key] = value
    config["trailer"] = str(base.get("trailer", ""))
    return config


def apply_profile(config, profile, sample, env_overrides, schema):
    """Fold a sample profile file and the environment overrides into a copy."""
    merged = dict(config)
    sample = sample or {}
    if profile is None:
        profile = sample.get("profile")
    if profile is None:
        return merged, None
    profile = str(profile)
    merged["profile"] = profile

    if sample.get("profile") not in (None, profile):
        raise ToolError(
            f"profile file declares {sample.get('profile')!r}, not {profile!r}"
        )

    overrides = {}
    if env_overrides is not None:
        if profile not in env_overrides:
            known = ", ".join(sorted(env_overrides)) or "none"
            raise ToolError(f"unknown profile {profile!r} (known: {known})")
        overrides = env_overrides[profile] or {}
        if "mode" in overrides:
            merged["mode"] = str(overrides["mode"])

    for key in NUMERIC_KEYS:
        merged[key] = config[key] + int(sample.get(f"{key}_delta", 0)) + int(
            overrides.get(f"{key}_delta", 0)
        )

    # Absolute scalar settings from the sample file (e.g. "checksum").
    for key, value in sample.items():
        if key == "profile" or key.endswith("_delta"):
            continue
        if key not in config:
            raise ToolError(f"sample profile sets unknown key {key!r}")
        if isinstance(value, (dict, list)):
            raise ToolError(f"sample profile key {key!r} must be a scalar")
        merged[key] = value

    if merged["checksum"] != schema["checksum"]:
        raise ToolError(
            f"profile {profile!r} wants checksum {merged['checksum']!r}, "
            f"schema requires {schema['checksum']!r}"
        )
    return merged, profile


# ---------------------------------------------------------------- validation


def validate_config(config, schema, rules, expected_profile=None):
    """Return (errors, warnings) for one configuration document."""
    errors, warnings = [], []

    def err(code, message, key=None):
        item = {"code": code, "message": message}
        if key is not None:
            item["key"] = key
        errors.append(item)

    if not isinstance(config, dict):
        return (
            [{"code": "not_an_object", "message": "configuration must be a JSON object"}],
            [],
        )

    required = schema["required_keys"]
    for key in [k for k in required if k not in config]:
        err("missing_key", f"required key {key!r} is missing", key)
    for key in [k for k in config if k not in required]:
        warnings.append(
            {"code": "unexpected_key", "message": f"key {key!r} is not in required_keys", "key": key}
        )

    for key in sorted(rules["forbidden_keys"]):
        if key in config:
            err("forbidden_key", f"key {key!r} is forbidden by the validation rules", key)

    for key, value in sorted(config.items()):
        if schema["scalar_only"] and isinstance(value, (dict, list)):
            err("non_scalar_value", f"value for {key!r} must be a scalar", key)
        elif value is None:
            err("non_scalar_value", f"value for {key!r} must not be null", key)

    if config.get("checksum") != schema["checksum"]:
        err(
            "checksum_mismatch",
            f"checksum must be {schema['checksum']!r}, found {config.get('checksum')!r}",
            "checksum",
        )

    allowed = set(rules["profiles"]) | {schema["profile"]}
    profile = config.get("profile")
    if profile not in allowed:
        err(
            "unknown_profile",
            f"profile {profile!r} is not one of: " + ", ".join(sorted(allowed)),
            "profile",
        )
    if expected_profile is not None and profile != expected_profile:
        err(
            "profile_mismatch",
            f"expected profile {expected_profile!r}, found {profile!r}",
            "profile",
        )

    trailer = config.get("trailer")
    if not isinstance(trailer, str) or not TRAILER_PATTERN.match(trailer):
        err(
            "bad_trailer",
            "trailer must match " + TRAILER_PATTERN.pattern,
            "trailer",
        )

    for key in NUMERIC_KEYS:
        value = config.get(key)
        if isinstance(value, bool) or not isinstance(value, int):
            err("bad_type", f"{key} must be an integer, found {type(value).__name__}", key)
        elif value < 0:
            err("bad_type", f"{key} must not be negative", key)
    if config.get("timeout_ms") == 0:
        err("bad_type", "timeout_ms must be greater than zero", "timeout_ms")

    mode = config.get("mode")
    if not isinstance(mode, str) or not mode:
        err("bad_type", "mode must be a non-empty string", "mode")

    return errors, warnings


# ------------------------------------------------------------------ run log


def append_run_log(path, command, argv, status, exit_code):
    entry = {
        "command": command,
        "argv": [str(part) for part in argv],
        "status": status,
        "exit_code": exit_code,
    }
    try:
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(entry, sort_keys=True) + "\n")
    except OSError as exc:
        raise ToolError(f"cannot write log {path}: {exc.strerror or exc}") from exc


def schema_from_config(config):
    """Schema fallback when ``export-report`` runs without ``--schema``."""
    return {
        "profile": config.get("profile", ""),
        "producer": config.get("producer", ""),
        "container": config.get("container", ""),
        "checksum": config.get("checksum", ""),
        "required_keys": sorted(config),
        "scalar_only": True,
    }


def read_run_log(path):
    return load_json_lines(path) if path else []


def load_json_lines(path):
    try:
        text = Path(path).read_text(encoding="utf-8")
    except OSError as exc:
        raise ToolError(f"cannot read {path}: {exc.strerror or exc}") from exc
    lines = [line for line in text.splitlines() if line.strip()]
    out = []
    for number, line in enumerate(lines, start=1):
        try:
            out.append(json.loads(line))
        except json.JSONDecodeError as exc:
            raise ToolError(f"{path}:{number} is not valid JSON: {exc.msg}") from exc
    return out


# ------------------------------------------------------------------ commands


def cmd_init(args):
    schema = load_schema(args.schema)
    defaults_path = companion(args.schema, "defaults.json", args.defaults)
    if not defaults_path:
        raise ToolError(
            "no defaults file found; pass --defaults (expected defaults.json "
            f"next to {args.schema})"
        )
    defaults = load_json(defaults_path)
    if not isinstance(defaults, dict):
        raise ToolError(f"{defaults_path} must be a JSON object")

    env_path = companion(args.schema, "env_overrides.json", args.env)
    env_overrides = None
    if env_path:
        env_overrides = load_json(env_path)
        if not isinstance(env_overrides, dict):
            raise ToolError(f"{env_path} must be a JSON object")

    sample = load_json(args.profile_file) if args.profile_file else None
    if sample is not None and not isinstance(sample, dict):
        raise ToolError(f"{args.profile_file} must be a JSON object")

    config = build_base_config(schema, defaults)
    config, profile = apply_profile(config, args.profile, sample, env_overrides, schema)
    if args.profile and profile != args.profile:
        raise ToolError(f"could not apply profile {args.profile!r}")

    write_json(args.out, config)
    label = profile if profile else schema["profile"]
    print(
        f"wrote {args.out}: profile={label} keys={len(config)} "
        f"sha256={digest(config).split(':', 1)[1][:12]}"
    )


def cmd_set(args):
    config = load_json(args.config)
    if not isinstance(config, dict):
        raise ToolError(f"{args.config} must be a JSON object")

    schema = load_schema(args.schema) if args.schema else None
    rules = resolve_rules(args.rules, args.config, args.schema)

    key = str(args.key)
    if key != key.strip() or not key:
        raise ToolError(f"{key!r} is not a usable key")
    if key in rules["forbidden_keys"]:
        raise ToolError(f"key {key!r} is forbidden by the validation rules")
    if schema and key not in schema["required_keys"]:
        raise ToolError(f"key {key!r} is not one of the configured keys")

    value = coerce_scalar(args.value)
    config[key] = value
    write_json(args.config, config)
    print(f"set {key}={json.dumps(value, sort_keys=True)} in {args.config}")


def cmd_validate(args):
    schema = load_schema(args.schema)
    rules = resolve_rules(args.rules, *[c for c in args.config], args.schema)

    profiles = args.profile or []
    if profiles and len(profiles) != len(args.config):
        raise ToolError(
            f"--profile was given {len(profiles)} time(s) for "
            f"{len(args.config)} --config file(s): give one per --config, in order"
        )

    results, all_ok = [], True
    for path, expected in zip(args.config, profiles or [None] * len(args.config)):
        config = load_json(path)
        errors, warnings = validate_config(config, schema, rules, expected)
        ok = not errors
        all_ok = all_ok and ok
        entry = {
            "path": str(path),
            "ok": ok,
            "error_count": len(errors),
            "warning_count": len(warnings),
            "errors": errors,
            "warnings": warnings,
        }
        if expected is not None:
            entry["expected_profile"] = expected
        if isinstance(config, dict):
            entry["keys"] = sorted(config)
        results.append(entry)
        if not args.quiet:
            print(f"{path}: {'ok' if ok else 'FAILED'}")
            for item in errors:
                print(f"  error [{item['code']}] {item['message']}")
            for item in warnings:
                print(f"  warning [{item['code']}] {item['message']}")

    if args.out:
        write_json(
            args.out,
            {
                "tool": TOOL_NAME,
                "version": TOOL_VERSION,
                "schema": str(args.schema),
                "rules": rules["source"],
                "checks": list(VALIDATION_CHECKS),
                "ok": all_ok,
                "config_count": len(results),
                "configs": results,
            },
        )
    if not all_ok:
        raise ToolError(f"{sum(r['error_count'] for r in results)} validation error(s)")
    print(f"validated {len(results)} configuration(s): ok")


def cmd_report(args):
    config = load_json(args.config)
    if not isinstance(config, dict):
        raise ToolError(f"{args.config} must be a JSON object")
    schema = load_schema(args.schema) if args.schema else schema_from_config(config)
    rules = resolve_rules(args.rules, args.config, args.schema, args.rules)
    errors, warnings = validate_config(config, schema, rules, args.profile)
    notes = load_json(args.notes) if args.notes else {}

    sources = {}
    for role, path in (
        ("schema", args.schema),
        ("rules", args.rules),
        ("defaults", args.defaults),
        ("env_overrides", args.env),
        ("profile_sample", args.profile_file),
    ):
        if path:
            sources[role] = {"path": str(path), "sha256": file_digest(path)}

    report = {
        "tool": TOOL_NAME,
        "version": TOOL_VERSION,
        "config_path": str(args.config),
        "config_sha256": digest(config),
        "config": config,
        "key_count": len(config),
        "validation": {
            "ok": not errors,
            "checks": list(VALIDATION_CHECKS),
            "errors": errors,
            "warnings": warnings,
        },
        "sources": sources,
        "commands": read_run_log(args.transcript),
        "notes": notes,
    }
    write_json(args.out, report)
    print(
        f"wrote {args.out}: ok={not errors} keys={len(config)} "
        f"commands={len(report['commands'])}"
    )


def cmd_summarize(args):
    rules = resolve_rules(args.rules, args.dir)
    if not rules["required_artifacts"]:
        raise ToolError("rules declare no required_artifacts; pass --rules")
    directory = Path(args.dir)
    if not directory.is_dir():
        raise ToolError(f"{directory} is not a directory")

    forbidden = set(rules["forbidden_keys"])
    expected = set(rules["required_artifacts"])
    # The file this command writes cannot hold its own digest or size.
    self_name = Path(args.out).name if args.out else None
    artifacts, ok = [], True
    for name in rules["required_artifacts"]:
        path = directory / name
        if name == self_name:
            artifacts.append(
                {
                    "name": name,
                    "present": True,
                    "self": True,
                    "note": "written by this command",
                }
            )
            continue
        entry = {"name": name, "present": path.exists()}
        if entry["present"]:
            size = path.stat().st_size
            entry["bytes"] = size
            entry["sha256"] = file_digest(path)
            entry["within_size_limit"] = size <= rules["max_artifact_bytes"]
            ok = ok and entry["within_size_limit"]
            if name.endswith(".json"):
                document = load_json(path)
                entry["forbidden_keys_present"] = sorted(
                    forbidden & set(_walk_keys(document))
                )
                if entry["forbidden_keys_present"]:
                    ok = False
        else:
            entry["within_size_limit"] = False
            ok = False
        artifacts.append(entry)

    unexpected = sorted(
        p.name for p in directory.iterdir() if p.is_file() and p.name not in expected
    )

    summary = {
        "tool": TOOL_NAME,
        "version": TOOL_VERSION,
        "directory": str(directory),
        "ok": ok,
        "checks": [
            "required_artifacts_present",
            "artifact_size_limit",
            "forbidden_keys_absent",
        ],
        "max_artifact_bytes": rules["max_artifact_bytes"],
        "artifact_count": len(artifacts),
        "artifacts": artifacts,
        "unexpected_files": unexpected,
    }
    if args.out:
        write_json(args.out, summary)
    if not args.quiet:
        print(f"{directory}: {'ok' if ok else 'FAILED'} ({len(artifacts)} artifacts)")
        for entry in artifacts:
            if entry.get("self"):
                continue
            if not entry["present"]:
                print(f"  missing {entry['name']}")
            elif not entry.get("within_size_limit"):
                print(f"  oversized {entry['name']} ({entry.get('bytes')} bytes)")
            elif entry.get("forbidden_keys_present"):
                print(f"  forbidden keys in {entry['name']}: "
                      + ", ".join(entry["forbidden_keys_present"]))
    if not ok:
        raise ToolError("artifact set is not complete/valid")
    print(f"summarized {len(artifacts)} artifact(s): ok")


def cmd_pack(args):
    """Archive the tool itself with reproducible metadata (no __pycache__)."""
    source = Path(args.source)
    if not source.is_dir():
        raise ToolError(f"{source} is not a directory")
    names = sorted(
        entry.relative_to(source).as_posix()
        for entry in source.rglob("*")
        if entry.is_file()
        and "__pycache__" not in entry.parts
        and not entry.name.startswith(".")
    )
    if not names:
        raise ToolError(f"{source} contains no files to archive")

    target = Path(args.out)
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
            for name in names:
                info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o644 << 16
                archive.writestr(info, (source / name).read_bytes())
    except OSError as exc:
        raise ToolError(f"cannot write {args.out}: {exc.strerror or exc}") from exc

    with zipfile.ZipFile(target) as archive:
        broken = archive.testzip()
        if broken:
            raise ToolError(f"{args.out}: corrupt member {broken}")
        written = sorted(archive.namelist())
    if written != names:
        raise ToolError(f"{args.out}: archive contents do not match {source}")
    print(f"wrote {target}: {len(names)} file(s) ({target.stat().st_size} bytes)")


def _walk_keys(node):
    """Yield every object key in a nested JSON document."""
    if isinstance(node, dict):
        for key, value in node.items():
            yield key
            yield from _walk_keys(value)
    elif isinstance(node, list):
        for item in node:
            yield from _walk_keys(item)


# ---------------------------------------------------------------------- main


def build_parser():
    parser = argparse.ArgumentParser(
        prog=TOOL_NAME,
        description="Create, update, validate and report a flat JSON configuration.",
    )
    parser.add_argument(
        "--version", action="version", version=f"{TOOL_NAME} {TOOL_VERSION}"
    )
    parser.add_argument(
        "--log",
        metavar="PATH",
        help="append one JSON line describing this invocation to PATH",
    )
    sub = parser.add_subparsers(dest="command", required=True, metavar="COMMAND")

    p = sub.add_parser("init", help="build a configuration from schema and defaults")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--defaults", help="defaults.json (default: next to the schema)")
    p.add_argument("--env", help="env_overrides.json (default: next to the schema)")
    p.add_argument("--profile", help="environment profile to apply, e.g. dev or prod")
    p.add_argument("--profile-file", help="sample profile file for that profile")
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set", help="set one scalar key in an existing configuration")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.add_argument("--schema", help="restrict keys to the schema's required_keys")
    p.add_argument("--rules", help="validation_rules.json for forbidden keys")
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate", help="validate configuration file(s)")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", action="append", required=True)
    p.add_argument("--rules", help="validation_rules.json")
    p.add_argument(
        "--profile",
        action="append",
        help="profile a configuration must declare (repeat: one per --config, in order)",
    )
    p.add_argument("--out", help="write a JSON validation report here")
    p.add_argument("--quiet", action="store_true", help="only print the verdict")
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("export-report", help="write a report about a configuration")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--schema", help="schema used to validate the configuration")
    p.add_argument("--rules", help="validation_rules.json")
    p.add_argument("--profile", help="profile the configuration must declare")
    p.add_argument("--transcript", help="run log produced with --log")
    p.add_argument("--notes", help="JSON object merged into the report")
    p.add_argument("--defaults", help="record this input's digest")
    p.add_argument("--env", help="record this input's digest")
    p.add_argument("--profile-file", help="record this input's digest")
    p.set_defaults(func=cmd_report)

    p = sub.add_parser("pack", help="archive the tool itself, reproducibly")
    p.add_argument("--source", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_pack)

    p = sub.add_parser("summarize", help="check a deliverable directory")
    p.add_argument("--dir", required=True)
    p.add_argument("--rules", required=True)
    p.add_argument("--out", help="write the summary JSON here")
    p.add_argument("--quiet", action="store_true", help="only print the verdict")
    p.set_defaults(func=cmd_summarize)

    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    log_path = getattr(args, "log", None)
    try:
        args.func(args)
        status, code = "ok", 0
    except ToolError as exc:
        print(f"{TOOL_NAME}: error: {exc}", file=sys.stderr)
        status, code = "error", 1
    if log_path:
        append_run_log(log_path, getattr(args, "command", "?"), sys.argv, status, code)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
