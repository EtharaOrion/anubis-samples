# task-ctl

This local stdlib-only CLI creates, updates, validates, and reports a flat JSON
configuration. A configuration is a single JSON object of scalar values whose
contract is described by a schema file (required keys, scalar-only, checksum
algorithm, base profile) and a rules file (allowed environment profiles,
forbidden keys, required artifacts and their byte limit).

Commands after repair:

```bash
python3 cli.py init --schema /app/data/config_schema.json --out config.json
python3 cli.py set --config config.json --key max_records --value 100 --schema /app/data/config_schema.json
python3 cli.py validate --schema /app/data/config_schema.json --config config.json
python3 cli.py export-report --config config.json --out report.json
```

`--schema` points at the contract schema, because that is where
`defaults.json`, `validation_rules.json` and `env_overrides.json` live. The
`schema.json` shipped beside this file is a minimal skeleton: it has no
defaults beside it, so `init` fills the keys it cannot source with empty
strings and warns. Both `required_keys` spellings — the JSON array used by the
contract and the comma-separated string used here — are accepted.

`--schema` is explicit; `defaults.json`, `validation_rules.json` and
`env_overrides.json` are picked up automatically from the schema's directory
when present (each can be overridden with `--defaults`, `--rules` or
`--env-overrides`).

Environment profiles are built from those same data files, so the sample
profile specs in the data directory drive the whole computation:

```bash
python3 cli.py init --schema schema.json --out profile_dev.json \
    --profile dev --spec sample_config_dev.json
```

`init` lays down the defaults (top level plus `base_config`), then applies the
environment overrides (`mode`, `*_delta`) and finally the spec overrides, so
every number in the output is computed by the tool from the data files.

## Other commands

```bash
# validate several configurations at once and check the deliverable directory
python3 cli.py validate --schema schema.json \
    --config config.json profile_dev.json profile_prod.json \
    --artifacts-dir out --out validation_report.json

# set a literal value, or apply an adjustment to the current one
python3 cli.py set --config config.json --key timeout_ms --value 2000
python3 cli.py set --config config.json --key timeout_ms --value -125 --delta

# a report with a real transcript, the validation verdict and the repair diff
python3 cli.py export-report --config config.json --out report.json \
    --baseline original/cli.py --repair-notes repair_notes.json

# an overall summary of configs and artifacts
python3 cli.py summarize --schema schema.json \
    --configs config.json profile_dev.json profile_prod.json \
    --artifacts-dir out --out summary.json
```

## Behaviour notes

- Every mutating command appends a JSONL journal entry (beside the output file,
  or wherever `--journal` points) and `export-report` replays it as the
  transcript, so reports describe the commands that actually ran.
- Journal entries and reports contain no timestamps, uuids or random seeds:
  re-running the same commands reproduces byte-identical artifacts, which is
  what `forbidden_keys` in the rules file is guarding.
- `set` coerces CLI strings to scalars (`100` -> int, `true` -> bool,
  `null` -> None, a quoted value stays a string), keeps the contract's key
  casing, rejects unknown and forbidden keys, and refuses non-scalar results.
- `validate` accepts `required_keys` as a JSON array or as a comma-separated
  string, prints its report as JSON on stdout, and exits non-zero when any
  check fails.
- Allowed profiles are `validation_rules.json`'s `profiles` plus the schema's
  own `profile` (the base configuration).
