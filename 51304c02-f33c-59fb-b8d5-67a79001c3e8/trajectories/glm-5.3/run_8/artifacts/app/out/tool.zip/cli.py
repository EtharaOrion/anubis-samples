#!/usr/bin/env python3
"""task-ctl: create, update, validate and report a flat JSON configuration.

The tool is standard-library only and works entirely on local files.  A
configuration is a single flat JSON object of scalar values whose contract is
described by a schema file (required keys, scalar-only, checksum algorithm, the
base profile name) plus an optional rules file (allowed environment profiles,
forbidden keys, required artifacts and their size limit).

Input files and how they are discovered
---------------------------------------
``--schema`` is always explicit.  The remaining data files are looked up next
to the schema unless given explicitly:

    defaults.json         top-level defaults (checksum, mode, producer, ...) and
                          base_config values (max_records, retry_limit, ...)
    validation_rules.json profiles, forbidden_keys, required_artifacts,
                          max_artifact_bytes
    env_overrides.json    per-environment mode overrides and *_delta adjustments
    <sample config>       a profile spec (profile, max_records_delta, ...),
                          passed explicitly with ``--spec``

Every mutating command appends a journal entry, so ``export-report`` can emit a
real transcript of the commands that produced a configuration.  Journal entries
deliberately contain no timestamps, uuids or random seeds: re-running the same
commands reproduces byte-identical artifacts.
"""
from __future__ import annotations

import argparse
import difflib
import hashlib
import json
import re
import sys
from pathlib import Path

TOOL_NAME = "task-ctl"
TOOL_VERSION = "1.1.0"

DEFAULTS_FILENAME = "defaults.json"
RULES_FILENAME = "validation_rules.json"
ENV_OVERRIDES_FILENAME = "env_overrides.json"

DELTA_SUFFIX = "_delta"


# --------------------------------------------------------------------------
# file helpers
# --------------------------------------------------------------------------
def load_json(path):
    """Load a JSON document, failing with a message that names the file."""
    target = Path(path)
    if not target.is_file():
        raise SystemExit(f"{TOOL_NAME}: file not found: {target}")
    try:
        return json.loads(target.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise SystemExit(f"{TOOL_NAME}: invalid JSON in {target}: {exc}") from exc


def dump_json(data):
    """Canonical text form: two-space indent, trailing newline."""
    return json.dumps(data, indent=2, ensure_ascii=False) + "\n"


def write_json(path, data):
    target = Path(path)
    if target.parent and not target.parent.exists():
        target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(dump_json(data), encoding="utf-8")
    return target


def optional_json(path):
    """Load a JSON document that may legitimately be absent."""
    if path is None or not Path(path).is_file():
        return None
    return load_json(path)


def discover(explicit, schema_path, filename):
    """Return `explicit`, or `filename` sitting next to the schema."""
    if explicit:
        return Path(explicit)
    if schema_path:
        return Path(schema_path).resolve().parent / filename
    return None


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha256_text(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def file_stats(path):
    target = Path(path)
    if not target.is_file():
        return {"path": str(target), "exists": False}
    content = target.read_bytes()
    return {
        "path": str(target),
        "exists": True,
        "bytes": len(content),
        "sha256": sha256_bytes(content),
    }


# --------------------------------------------------------------------------
# schema / rules helpers
# --------------------------------------------------------------------------
def required_keys(schema):
    """Required keys as a list.

    The contract ships `required_keys` as a JSON array; older/inline schemas
    spell it as a comma-separated string.  Both are accepted.
    """
    raw = schema.get("required_keys", [])
    if isinstance(raw, str):
        keys = [part.strip() for part in raw.split(",")]
    elif isinstance(raw, list):
        keys = [str(part).strip() for part in raw]
    else:
        raise SystemExit(f"{TOOL_NAME}: unsupported required_keys type in schema")
    return [key for key in keys if key]


def allowed_profiles(schema, rules):
    """Profiles a configuration may declare.

    `validation_rules.profiles` lists the environment profiles; the schema's own
    `profile` value is the base profile and is always permitted.
    """
    profiles = []
    if rules:
        for name in rules.get("profiles", []) or []:
            if name not in profiles:
                profiles.append(name)
    base = schema.get("profile")
    if base and base not in profiles:
        profiles.append(base)
    return profiles


def forbidden_keys(rules):
    return list((rules or {}).get("forbidden_keys", []) or [])


def flat_defaults(defaults):
    """Defaults as one flat mapping: top level minus base_config, plus base_config."""
    if not defaults:
        return {}
    merged = {}
    for key, value in defaults.items():
        if key == "base_config":
            continue
        merged[key] = value
    for key, value in (defaults.get("base_config") or {}).items():
        merged[key] = value
    return merged


# --------------------------------------------------------------------------
# value helpers
# --------------------------------------------------------------------------
def type_name(value):
    if isinstance(value, bool):
        return "bool"
    if isinstance(value, int):
        return "int"
    if isinstance(value, float):
        return "float"
    if isinstance(value, str):
        return "str"
    if value is None:
        return "null"
    if isinstance(value, list):
        return "list"
    if isinstance(value, dict):
        return "dict"
    return type(value).__name__


def is_scalar(value):
    return not isinstance(value, (dict, list))


def is_number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool)


_INT_RE = re.compile(r"-?\d+$")
_FLOAT_RE = re.compile(r"-?(\d+\.\d*|\.\d+|\d+[eE][+-]?\d+|\d+\.\d*[eE][+-]?\d+)$")


def coerce_value(raw):
    """Coerce a CLI string into the scalar the configuration should hold.

    "100" -> int, "-12.5" -> float, "true"/"false" -> bool, "null" -> None,
    a quoted string stays a string, anything else is a plain string.
    """
    text = str(raw)
    if len(text) >= 2 and text[0] == text[-1] and text[0] in "\"'":
        return text[1:-1]
    lowered = text.strip().lower()
    if lowered == "true":
        return True
    if lowered == "false":
        return False
    if lowered in ("null", "none"):
        return None
    if _INT_RE.match(text):
        return int(text)
    if _FLOAT_RE.match(text):
        return float(text)
    return text


def apply_delta(current, delta, key):
    """Add `delta` to `current`, refusing non-numeric operands."""
    if not is_number(current) or not is_number(delta):
        raise SystemExit(
            f"{TOOL_NAME}: cannot apply {DELTA_SUFFIX} to {key}: "
            f"{type_name(current)} + {type_name(delta)}"
        )
    return current + delta


def canonical_key(key, known):
    """Map a CLI key to its canonical casing from the known keys."""
    for candidate in known:
        if candidate.lower() == str(key).lower():
            return candidate
    return key


def order_keys(data, schema):
    """Emit required keys in contract order, then any extras alphabetically."""
    ordered = [key for key in required_keys(schema) if key in data]
    ordered += sorted(key for key in data if key not in ordered)
    return {key: data[key] for key in ordered}


# --------------------------------------------------------------------------
# journal
# --------------------------------------------------------------------------
def journal_path_for(config_path):
    """Default journal lives beside its configuration file."""
    target = Path(config_path)
    return target.with_name(target.stem + ".journal.jsonl")


def journal_read(path):
    if path is None or not Path(path).is_file():
        return []
    entries = []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if line.strip():
            entries.append(json.loads(line))
    return entries


def journal_append(path, entry):
    entries = journal_read(path)
    record = {"seq": len(entries) + 1}
    record.update(entry)
    target = Path(path)
    if target.parent and not target.parent.exists():
        target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, ensure_ascii=False) + "\n")
    return record


def locate_journal(config_path, journal_dir=None):
    """Find a configuration's journal: explicit dir first, then beside the file."""
    target = Path(config_path)
    if journal_dir:
        candidate = Path(journal_dir) / (target.stem + ".journal.jsonl")
        if candidate.is_file():
            return candidate
    sibling = journal_path_for(target)
    return sibling if sibling.is_file() else None


# --------------------------------------------------------------------------
# configuration assembly
# --------------------------------------------------------------------------
def apply_overrides(data, overrides, applied, label):
    """Apply literal values and `*_delta` adjustments from an override mapping."""
    for key, value in overrides.items():
        if isinstance(value, (dict, list)):
            raise SystemExit(f"{TOOL_NAME}: {label} value for {key} is not a scalar")
        if key.endswith(DELTA_SUFFIX):
            target_key = key[: -len(DELTA_SUFFIX)]
            if target_key not in data:
                raise SystemExit(f"{TOOL_NAME}: {label} adjusts unknown key {target_key}")
            old = data[target_key]
            new = apply_delta(old, value, target_key)
            data[target_key] = new
            applied.append({"source": label, "key": target_key, "via": key,
                            "before": old, "delta": value, "after": new})
        else:
            old = data.get(key)
            data[key] = value
            applied.append({"source": label, "key": key, "via": key,
                            "before": old, "delta": None, "after": value})
    return data


def build_config(schema, defaults, env_overrides, profile, spec):
    """Assemble a flat configuration from the contract's data files."""
    keys = required_keys(schema)
    flat = flat_defaults(defaults)
    profile = profile or (spec or {}).get("profile") or schema.get("profile", "")

    data = {}
    for key in keys:
        if key == "profile":
            data[key] = profile
        elif key in flat:
            data[key] = flat[key]
        else:
            data[key] = ""

    applied = []
    if profile and env_overrides and profile in env_overrides:
        apply_overrides(data, env_overrides[profile], applied,
                        f"env_overrides[{profile}]")
    if spec:
        overrides = {key: value for key, value in spec.items() if key != "profile"}
        apply_overrides(data, overrides, applied, f"spec:{spec.get('profile')}")

    return order_keys(data, schema), profile, applied


# --------------------------------------------------------------------------
# validation
# --------------------------------------------------------------------------
def check(check_id, ok, detail):
    return {"id": check_id, "status": "pass" if ok else "fail", "detail": detail}


def validate_config(data, schema, rules, defaults, config_path):
    """Validate one configuration against the schema and rules contracts."""
    errors, warnings, checks = [], [], []
    keys = required_keys(schema)

    missing = [key for key in keys if key not in data]
    checks.append(check(
        "required_keys",
        not missing,
        "missing: " + ",".join(missing) if missing
        else f"{len(keys)} required keys present",
    ))
    if missing:
        errors.append("missing required keys: " + ",".join(missing))

    non_scalars = [key for key, value in data.items() if not is_scalar(value)]
    scalar_only = bool(schema.get("scalar_only", True))
    checks.append(check(
        "scalar_only",
        scalar_only and not non_scalars,
        "non-scalar values: " + ",".join(non_scalars) if non_scalars
        else f"all {len(data)} values are scalars (scalar_only={scalar_only})",
    ))
    if non_scalars:
        errors.append("configuration must be flat; non-scalar: "
                      + ",".join(f"{key}:{type_name(data[key])}" for key in non_scalars))

    forbidden = forbidden_keys(rules)
    present_forbidden = [key for key in data if key in forbidden]
    checks.append(check(
        "forbidden_keys",
        not present_forbidden,
        "forbidden keys present: " + ",".join(present_forbidden) if present_forbidden
        else f"none of {len(forbidden)} forbidden keys present",
    ))
    if present_forbidden:
        errors.append("forbidden keys present: " + ",".join(present_forbidden))

    profiles = allowed_profiles(schema, rules)
    declared = data.get("profile")
    profile_ok = declared in profiles if profiles else True
    checks.append(check(
        "profile_allowed",
        profile_ok,
        f"profile {declared!r} in {profiles}" if profile_ok
        else f"profile {declared!r} not in {profiles}",
    ))
    if not profile_ok:
        errors.append(f"profile {declared!r} not allowed (allowed: {profiles})")

    expected_checksum = schema.get("checksum")
    if expected_checksum is not None and "checksum" in data:
        match = data["checksum"] == expected_checksum
        checks.append(check(
            "checksum_algorithm",
            match,
            f"checksum={data['checksum']!r} matches schema" if match
            else f"checksum {data['checksum']!r} != schema {expected_checksum!r}",
        ))
        if not match:
            errors.append(f"checksum must be {expected_checksum!r}, "
                          f"found {data['checksum']!r}")

    reference = flat_defaults(defaults)
    if reference:
        mismatched = [f"{key}:{type_name(data[key])}!={type_name(reference[key])}"
                      for key, value in reference.items()
                      if key in data and type_name(data[key]) != type_name(value)]
        checks.append(check(
            "value_types",
            not mismatched,
            "all typed values match defaults" if not mismatched
            else "type mismatches: " + ",".join(mismatched),
        ))
        if mismatched:
            errors.append("value types diverge from defaults: " + ",".join(mismatched))

    extras = sorted(key for key in data if keys and key not in keys)
    checks.append(check(
        "no_extra_keys",
        True,
        "no keys outside the contract" if not extras
        else "keys outside required_keys: " + ",".join(extras),
    ))
    if extras:
        warnings.append("keys outside required_keys: " + ",".join(extras))

    return {
        "config": str(config_path),
        "ok": not errors,
        "key_count": len(data),
        "keys": sorted(data),
        "checks": checks,
        "errors": errors,
        "warnings": warnings,
    }


def check_artifacts(rules, artifacts_dir, pending=()):
    """Check required_artifacts / max_artifact_bytes for a deliverable directory.

    `pending` names artifacts that the current run writes after this check (the
    file this command is writing, and anything produced later); they count as
    present but carry no size or digest yet.
    """
    result = {"directory": str(artifacts_dir), "ok": True, "missing": [],
              "oversized": [], "artifacts": []}
    if not rules or not artifacts_dir:
        return None
    directory = Path(artifacts_dir)
    required = list(rules.get("required_artifacts", []) or [])
    limit = rules.get("max_artifact_bytes")
    expected = {Path(item).name for item in pending}
    names = {entry.name for entry in directory.iterdir()} if directory.is_dir() else set()
    names |= expected

    for name in required:
        target = directory / name
        stats = {"artifact": name, "present": name in names, "expected": name in expected,
                 "bytes": None, "sha256": None, "within_limit": None}
        if target.is_file():
            content = target.read_bytes()
            stats.update({"bytes": len(content), "sha256": sha256_bytes(content)})
            if isinstance(limit, int):
                stats["within_limit"] = stats["bytes"] <= limit
                if not stats["within_limit"]:
                    result["oversized"].append({"artifact": name,
                                                "bytes": stats["bytes"],
                                                "limit": limit})
        result["artifacts"].append(stats)

    result["missing"] = [name for name in required if name not in names]
    result["ok"] = not result["missing"] and not result["oversized"]
    return result


# --------------------------------------------------------------------------
# commands
# --------------------------------------------------------------------------
def cmd_init(args):
    schema = load_json(args.schema)
    defaults_path = discover(args.defaults, args.schema, DEFAULTS_FILENAME)
    rules_path = discover(args.rules, args.schema, RULES_FILENAME)
    env_path = discover(args.env_overrides, args.schema, ENV_OVERRIDES_FILENAME)
    spec = load_json(args.spec) if args.spec else None

    defaults = optional_json(defaults_path) or {}
    rules = optional_json(rules_path)
    env_overrides = optional_json(env_path) or {}
    if not defaults:
        print(f"{TOOL_NAME}: warning: no defaults file beside {args.schema} "
              f"({DEFAULTS_FILENAME}); keys the schema does not supply are left empty",
              file=sys.stderr)

    if args.profile and args.profile not in env_overrides:
        raise SystemExit(f"{TOOL_NAME}: unknown profile {args.profile!r}; "
                         f"known: {sorted(env_overrides)}")
    if spec and args.profile and spec.get("profile") not in (None, args.profile):
        raise SystemExit(f"{TOOL_NAME}: spec profile {spec.get('profile')!r} "
                         f"does not match --profile {args.profile!r}")

    data, profile, applied = build_config(schema, defaults, env_overrides,
                                          args.profile, spec)
    for key, value in data.items():
        if not is_scalar(value):
            raise SystemExit(f"{TOOL_NAME}: init produced a non-scalar for {key}")
    write_json(args.out, data)

    journal = args.journal or journal_path_for(args.out)
    journal_append(journal, {
        "command": "init",
        "argv": list(sys.argv),
        "options": {"schema": str(args.schema), "out": str(args.out),
                    "profile": profile, "spec": str(args.spec) if args.spec else None,
                    "defaults": str(defaults_path) if defaults_path else None,
                    "env_overrides": str(env_path) if env_path else None,
                    "rules": str(rules_path) if rules_path else None},
        "result": {"profile": profile, "required_keys": required_keys(schema),
                   "base_values": flat_defaults(defaults),
                   "overrides_applied": applied, "final": data},
        "ok": True,
    })

    verdict = validate_config(data, schema, rules, defaults, args.out)
    print(f"initialized {args.out} (profile={profile}, keys={len(data)}, "
          f"validation={'ok' if verdict['ok'] else 'failed'})")
    return verdict


def cmd_set(args):
    data = load_json(args.config)
    schema_path = args.schema
    if not schema_path:
        prior = [entry for entry in journal_read(args.journal or journal_path_for(args.config))
                 if entry.get("options", {}).get("schema")]
        if prior:
            schema_path = prior[-1]["options"]["schema"]
    schema = load_json(schema_path) if schema_path else {}
    rules_path = discover(args.rules, schema_path, RULES_FILENAME)
    rules = optional_json(rules_path) or {}
    defaults_path = discover(args.defaults, schema_path, DEFAULTS_FILENAME)
    reference = flat_defaults(optional_json(defaults_path) or {})

    known = list(dict.fromkeys(required_keys(schema) + sorted(data)))
    key = canonical_key(args.key, known)
    if key in forbidden_keys(rules):
        raise SystemExit(f"{TOOL_NAME}: key {key!r} is forbidden by the rules")
    if key not in known and not args.allow_new:
        raise SystemExit(f"{TOOL_NAME}: unknown key {key!r}; known: {known} "
                         f"(use --allow-new to add it)")

    value = coerce_value(args.value)
    old = data.get(key)
    if args.delta:
        if key not in data:
            raise SystemExit(f"{TOOL_NAME}: cannot apply a delta to missing key {key!r}")
        value = apply_delta(old, value, key)
    if not is_scalar(value):
        raise SystemExit(f"{TOOL_NAME}: value for {key} must be a scalar")
    if key in reference and type_name(value) != type_name(reference[key]):
        raise SystemExit(
            f"{TOOL_NAME}: {key} must be {type_name(reference[key])} "
            f"(as declared in defaults), got {type_name(value)}: {value!r}")
    data[key] = value
    write_json(args.config, data)

    journal = args.journal or journal_path_for(args.config)
    journal_append(journal, {
        "command": "set",
        "argv": list(sys.argv),
        "options": {"config": str(args.config), "key": key,
                    "value": args.value, "delta": bool(args.delta),
                    "schema": str(schema_path) if schema_path else None},
        "result": {"key": key, "before": old, "after": value,
                   "delta_applied": bool(args.delta)},
        "ok": True,
    })

    print(f"set {key}: {old!r} -> {value!r} in {args.config}")


def cmd_validate(args):
    schema = load_json(args.schema)
    rules_path = discover(args.rules, args.schema, RULES_FILENAME)
    rules = optional_json(rules_path) or {}
    defaults_path = discover(args.defaults, args.schema, DEFAULTS_FILENAME)
    defaults = optional_json(defaults_path) or {}

    results = []
    for config_path in args.config:
        data = load_json(config_path)
        result = validate_config(data, schema, rules, defaults, config_path)
        result["stats"] = file_stats(config_path)
        results.append(result)

    pending = ([args.out] if args.out else []) + list(args.expect_artifact or [])
    artifacts = check_artifacts(rules, args.artifacts_dir, pending=pending)

    overall = all(result["ok"] for result in results) and (artifacts is None or artifacts["ok"])
    report = {
        "tool": {"name": TOOL_NAME, "version": TOOL_VERSION, "command": "validate"},
        "ok": overall,
        "schema": str(args.schema),
        "rules": str(rules_path) if rules_path else None,
        "defaults": str(defaults_path) if defaults_path else None,
        "contract": {
            "required_keys": required_keys(schema),
            "scalar_only": bool(schema.get("scalar_only", True)),
            "checksum": schema.get("checksum"),
            "allowed_profiles": allowed_profiles(schema, rules),
            "forbidden_keys": forbidden_keys(rules),
            "max_artifact_bytes": rules.get("max_artifact_bytes"),
            "required_artifacts": rules.get("required_artifacts"),
        },
        "results": results,
        "artifacts": artifacts,
        "summary": {
            "configs_checked": len(results),
            "configs_passed": sum(1 for result in results if result["ok"]),
            "configs_failed": [result["config"] for result in results if not result["ok"]],
            "errors": sum(len(result["errors"]) for result in results),
            "warnings": sum(len(result["warnings"]) for result in results),
        },
    }
    text = dump_json(report)
    if args.out:
        write_json(args.out, report)
    print(text, end="")
    if not overall:
        raise SystemExit(1)


def cmd_report(args):
    config_path = Path(args.config)
    data = load_json(config_path)

    journal = args.journal or journal_path_for(config_path)
    entries = journal_read(journal)
    schema_path = args.schema
    if not schema_path:
        prior = [entry for entry in entries if entry.get("options", {}).get("schema")]
        if prior:
            schema_path = prior[-1]["options"]["schema"]
    if not schema_path:
        raise SystemExit(f"{TOOL_NAME}: export-report needs --schema "
                         f"(directly, or recorded in {journal})")
    schema = load_json(schema_path)
    rules_path = discover(args.rules, schema_path, RULES_FILENAME)
    rules = optional_json(rules_path) or {}
    defaults_path = discover(args.defaults, schema_path, DEFAULTS_FILENAME)
    defaults = optional_json(defaults_path) or {}

    verdict = validate_config(data, schema, rules, defaults, config_path)

    diff = None
    if args.baseline:
        baseline = Path(args.baseline)
        if not baseline.is_file():
            raise SystemExit(f"{TOOL_NAME}: baseline not found: {baseline}")
        diff = list(difflib.unified_diff(
            baseline.read_text(encoding="utf-8").splitlines(keepends=True),
            Path(__file__).read_text(encoding="utf-8").splitlines(keepends=True),
            fromfile=f"original/{baseline.name}",
            tofile=f"repaired/{Path(__file__).name}",
            n=3,
        ))
        diff = [line.rstrip("\n") for line in diff]

    report = {
        "tool": {"name": TOOL_NAME, "version": TOOL_VERSION,
                 "entrypoint": str(Path(__file__).name),
                 "command": "export-report"},
        "config_path": str(config_path),
        "config": data,
        "config_stats": file_stats(config_path),
        "schema_path": str(schema_path),
        "rules_path": str(rules_path) if rules_path else None,
        "defaults_path": str(defaults_path) if defaults_path else None,
        "validation": verdict,
        "commands": entries,
        "repair": {
            "notes": load_json(args.repair_notes) if args.repair_notes else None,
            "baseline": str(args.baseline) if args.baseline else None,
            "diff": diff,
            "diff_lines": len(diff) if diff else 0,
        },
        "summary": {
            "command_count": len(entries),
            "commands": [entry.get("command") for entry in entries],
            "valid": verdict["ok"],
            "errors": verdict["errors"],
            "warnings": verdict["warnings"],
        },
    }
    write_json(args.out, report)
    print(f"wrote {args.out} ({len(entries)} commands, "
          f"validation={'ok' if verdict['ok'] else 'failed'})")


def cmd_summarize(args):
    schema = load_json(args.schema)
    rules_path = discover(args.rules, args.schema, RULES_FILENAME)
    rules = optional_json(rules_path) or {}
    defaults_path = discover(args.defaults, args.schema, DEFAULTS_FILENAME)
    defaults = optional_json(defaults_path) or {}
    env_path = discover(args.env_overrides, args.schema, ENV_OVERRIDES_FILENAME)
    env_overrides = optional_json(env_path) or {}

    configs = {}
    for config_path in args.configs:
        data = load_json(config_path)
        verdict = validate_config(data, schema, rules, defaults, config_path)
        journal = locate_journal(config_path, args.journal_dir)
        entries = journal_read(journal) if journal else []
        init_entries = [entry for entry in entries if entry.get("command") == "init"]
        configs[str(config_path)] = {
            "data": data,
            "valid": verdict["ok"],
            "errors": verdict["errors"],
            "warnings": verdict["warnings"],
            "stats": file_stats(config_path),
            "journal": str(journal) if journal else None,
            "commands": [entry.get("command") for entry in entries],
            "overrides_applied": (init_entries[-1]["result"]["overrides_applied"]
                                  if init_entries else []),
        }

    artifacts = check_artifacts(rules, args.artifacts_dir,
                                pending=[args.out] + list(args.expect_artifact or []))

    transcripts = []
    if args.journal_dir and Path(args.journal_dir).is_dir():
        for journal in sorted(Path(args.journal_dir).glob("*.jsonl")):
            entries = journal_read(journal)
            transcripts.append({
                "journal": str(journal),
                "commands": [f"{entry.get('command')}:{entry.get('seq')}"
                             for entry in entries],
            })

    summary = {
        "tool": {"name": TOOL_NAME, "version": TOOL_VERSION,
                 "entrypoint": str(Path(__file__).name),
                 "stdlib_only": True, "network": "none"},
        "contract": {
            "schema": str(args.schema),
            "rules": str(rules_path) if rules_path else None,
            "defaults": str(defaults_path) if defaults_path else None,
            "env_overrides": str(env_path) if env_path else None,
            "required_keys": required_keys(schema),
            "allowed_profiles": allowed_profiles(schema, rules),
            "forbidden_keys": forbidden_keys(rules),
            "required_artifacts": rules.get("required_artifacts"),
            "max_artifact_bytes": rules.get("max_artifact_bytes"),
        },
        "configs": configs,
        "transcripts": transcripts,
        "artifacts": artifacts,
        "repair": {"notes": load_json(args.repair_notes) if args.repair_notes else None},
        "reproduce": [
            "python3 cli.py init --schema schema.json --out config.json",
            "python3 cli.py init --schema schema.json --out profile_dev.json "
            "--profile dev --spec sample_config_dev.json",
            "python3 cli.py init --schema schema.json --out profile_prod.json "
            "--profile prod --spec sample_config_prod.json",
            "python3 cli.py validate --schema schema.json --config config.json "
            "profile_dev.json profile_prod.json --artifacts-dir out --out "
            "validation_report.json",
            "python3 cli.py export-report --config config.json --out report.json "
            "--baseline original/cli.py --repair-notes repair_notes.json",
            "python3 cli.py summarize --schema schema.json --configs config.json "
            "profile_dev.json profile_prod.json --artifacts-dir out --out summary.json",
        ],
        "status": "ok" if all(item["valid"] for item in configs.values()) and (
            artifacts is None or artifacts["ok"]) else "failed",
    }
    write_json(args.out, summary)
    print(f"wrote {args.out} (status={summary['status']}, "
          f"configs={len(configs)}, artifacts_ok={artifacts['ok'] if artifacts else None})")
    if summary["status"] != "ok":
        raise SystemExit(1)


# --------------------------------------------------------------------------
# cli
# --------------------------------------------------------------------------
def build_parser():
    parser = argparse.ArgumentParser(
        prog=TOOL_NAME,
        description="Create, update, validate and report a flat JSON configuration.",
    )
    sub = parser.add_subparsers(dest="command", required=True,
                                metavar="{init,set,validate,export-report,summarize}")

    p = sub.add_parser("init", help="build a configuration from schema + defaults")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--defaults", default=None,
                   help=f"defaults file (default: {DEFAULTS_FILENAME} beside the schema)")
    p.add_argument("--rules", default=None,
                   help=f"rules file (default: {RULES_FILENAME} beside the schema)")
    p.add_argument("--env-overrides", default=None,
                   help=f"env overrides (default: {ENV_OVERRIDES_FILENAME} beside the schema)")
    p.add_argument("--profile", default=None,
                   help="environment profile to apply (e.g. dev, prod)")
    p.add_argument("--spec", default=None,
                   help="sample profile spec file (profile + *_delta overrides)")
    p.add_argument("--journal", default=None,
                   help="transcript file (default: beside --out)")
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set", help="set one key to a coerced scalar value")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.add_argument("--delta", action="store_true",
                   help="treat VALUE as an adjustment to add to the current value")
    p.add_argument("--allow-new", action="store_true",
                   help="permit a key that is neither in the schema nor in the config")
    p.add_argument("--schema", default=None,
                   help="schema used for key checks (default: from the journal)")
    p.add_argument("--rules", default=None)
    p.add_argument("--defaults", default=None,
                   help=f"defaults used for type checks (default: {DEFAULTS_FILENAME} "
                        f"beside the schema)")
    p.add_argument("--journal", default=None)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate", help="validate configurations and artifacts")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True, nargs="+")
    p.add_argument("--rules", default=None)
    p.add_argument("--defaults", default=None)
    p.add_argument("--artifacts-dir", default=None,
                   help="check required_artifacts/max_artifact_bytes in this directory")
    p.add_argument("--expect-artifact", action="append", default=None, metavar="NAME",
                   help="artifact written later in the same run; count it as present")
    p.add_argument("--out", default=None, help="also write the report to this file")
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("export-report", help="write a run report with transcript")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--schema", default=None)
    p.add_argument("--rules", default=None)
    p.add_argument("--defaults", default=None)
    p.add_argument("--journal", default=None)
    p.add_argument("--baseline", default=None,
                   help="original cli.py to diff against the repaired one")
    p.add_argument("--repair-notes", default=None,
                   help="JSON file of repair notes embedded verbatim")
    p.set_defaults(func=cmd_report)

    p = sub.add_parser("summarize", help="write an overall run summary")
    p.add_argument("--schema", required=True)
    p.add_argument("--configs", required=True, nargs="+")
    p.add_argument("--out", required=True)
    p.add_argument("--rules", default=None)
    p.add_argument("--defaults", default=None)
    p.add_argument("--env-overrides", default=None)
    p.add_argument("--artifacts-dir", default=None)
    p.add_argument("--journal-dir", default=None,
                   help="directory holding <config>.journal.jsonl transcripts")
    p.add_argument("--expect-artifact", action="append", default=None, metavar="NAME",
                   help="artifact written later in the same run; count it as present")
    p.add_argument("--repair-notes", default=None)
    p.set_defaults(func=cmd_summarize)

    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    if not hasattr(args, "func"):
        parser.error("a command is required (init, set, validate, export-report, summarize)")
    args.func(args)
    return 0


if __name__ == "__main__":
    sys.exit(main() or 0)
