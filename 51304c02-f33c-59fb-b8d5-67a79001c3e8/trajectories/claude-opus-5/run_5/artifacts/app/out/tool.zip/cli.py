#!/usr/bin/env python3
"""task-ctl -- create, update, validate and report a flat JSON configuration.

Stdlib only.  No network access, no wall-clock or random values anywhere in
the artifacts it writes (the validation rules forbid such keys and the output
is required to be reproducible).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

TOOL_NAME = "task-ctl"
TOOL_VERSION = "1.0.0-repaired"

# Faults that were present in the shipped archive and repaired here.  Emitted
# by `export-report` so the run report describes the repair itself.
REPAIRS = [
    {
        "id": "init-reads-missing-arg",
        "location": "cmd_init",
        "fault": "init loaded args.config, an option the init subparser never defines, "
                 "so every invocation died with AttributeError.",
        "fix": "init now loads the schema from args.schema, as documented in README.md.",
    },
    {
        "id": "init-emits-nested-config",
        "location": "cmd_init",
        "fault": "init nested the checksum under a 'settings' object and emitted only 4 of "
                 "the 9 required keys; the schema demands a flat, scalar-only document.",
        "fix": "init emits a flat document containing every required key, seeded from the "
               "schema and (when --defaults is given) from defaults.json.",
    },
    {
        "id": "set-uppercases-key",
        "location": "cmd_set",
        "fault": "set wrote args.key.upper(), producing keys like MAX_RECORDS that no "
                 "required key matches, and left every value as a string.",
        "fix": "set preserves the key exactly and coerces the value to int/float/bool/null "
               "when the literal is one, so numeric keys stay numeric.",
    },
    {
        "id": "set-accepts-nonscalar",
        "location": "cmd_set",
        "fault": "set never rejected structured or forbidden keys, so it could silently "
                 "break the scalar-only and forbidden-key rules.",
        "fix": "set rejects non-scalar values and forbidden keys before writing.",
    },
    {
        "id": "validate-assumes-string-required-keys",
        "location": "cmd_validate",
        "fault": "validate called schema['required_keys'].split(','), which raises "
                 "AttributeError against config_schema.json where required_keys is a list.",
        "fix": "the schema loader normalises required_keys from either a JSON list or a "
               "comma-separated string, so both schema spellings validate.",
    },
    {
        "id": "validate-too-thin",
        "location": "cmd_validate",
        "fault": "validate only checked key presence and flatness; it ignored the declared "
                 "checksum, the forbidden-key list and the allowed profiles, and it could "
                 "not emit a machine-readable result.",
        "fix": "validate checks required keys, scalar-only shape, forbidden keys, the "
               "declared checksum and the allowed profile set, accepts repeated --config, "
               "and can write its findings with --report-out.",
    },
    {
        "id": "report-transcript-unusable",
        "location": "cmd_report",
        "fault": "export-report hard-coded 'commands': 'unknown', so the report carried no "
                 "record of what was actually run.",
        "fix": "every command appends a structured entry to a transcript file next to the "
               "config (override with --log) and export-report emits that transcript as a "
               "list, together with the repair notes.",
    },
    {
        "id": "subcommand-not-required",
        "location": "main",
        "fault": "the subparsers were not required, so a bare `task-ctl` crashed with "
                 "AttributeError: 'Namespace' object has no attribute 'func'.",
        "fix": "a subcommand is required and a bare invocation prints usage and exits 2.",
    },
    {
        "id": "no-profile-support",
        "location": "main",
        "fault": "the tool had no way to combine defaults.json, env_overrides.json and a "
                 "sample profile, so the per-environment configurations it is meant to "
                 "produce could not be generated at all.",
        "fix": "added build-profile, which applies base defaults, then environment "
               "overrides, then the profile document, resolving '<key>_delta' additively.",
    },
]

SCALARS = (str, int, float, bool, type(None))
DELTA_SUFFIX = "_delta"
TRANSCRIPT_NAME = ".task-ctl-transcript.json"


# --------------------------------------------------------------------------- io


def load_json(path):
    return json.loads(Path(path).read_text())


def write_json(path, data):
    path = Path(path)
    if path.parent != Path(""):
        path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=False) + "\n")


def load_schema(path):
    """Normalise a schema document.

    required_keys may be a JSON list (config_schema.json) or a comma separated
    string (the schema.json bundled with the tool); both are accepted.
    """
    schema = load_json(path)
    required = schema.get("required_keys", [])
    if isinstance(required, str):
        required = [k.strip() for k in required.split(",") if k.strip()]
    schema["required_keys"] = list(required)
    return schema


def coerce(value):
    """Turn a command-line literal into the scalar it denotes."""
    if isinstance(value, bool) or not isinstance(value, str):
        return value
    text = value.strip()
    lowered = text.lower()
    if lowered == "true":
        return True
    if lowered == "false":
        return False
    if lowered == "null":
        return None
    try:
        return int(text)
    except ValueError:
        pass
    try:
        return float(text)
    except ValueError:
        pass
    return value


# -------------------------------------------------------------------- transcript


def transcript_path(args, anchor):
    if getattr(args, "log", None):
        return Path(args.log)
    return Path(anchor).resolve().parent / TRANSCRIPT_NAME


def record(path, entry):
    path = Path(path)
    entries = []
    if path.exists():
        try:
            entries = json.loads(path.read_text())
        except json.JSONDecodeError:
            entries = []
    if not isinstance(entries, list):
        entries = []
    entries.append(entry)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(entries, indent=2) + "\n")


def entry(command, options, status="ok", detail=None):
    item = {"command": command, "options": options, "status": status}
    if detail is not None:
        item["detail"] = detail
    return item


# ---------------------------------------------------------------------- commands


def placeholder_for(key):
    """Neutral scalar seed for a required key that no input supplies."""
    return 0 if key.endswith(("_records", "_limit", "_ms", "_count", "_bytes")) else ""


def cmd_init(args):
    schema = load_schema(args.schema)
    defaults = load_json(args.defaults) if args.defaults else {}
    base = defaults.get("base_config", {}) if isinstance(defaults, dict) else {}

    data = {}
    for key in schema["required_keys"]:
        if key in base:
            value = base[key]
        elif key in defaults and key != "base_config":
            value = defaults[key]
        elif key in schema:
            value = schema[key]
        else:
            value = placeholder_for(key)
        if not isinstance(value, SCALARS):
            raise SystemExit(f"init: value for {key!r} is not a scalar")
        data[key] = value

    write_json(args.out, data)
    record(
        transcript_path(args, args.out),
        entry("init", {"schema": args.schema, "defaults": args.defaults, "out": args.out},
              detail={"keys": list(data)}),
    )
    print(f"initialised {args.out} with {len(data)} keys")


def cmd_set(args):
    data = load_json(args.config)
    if not isinstance(data, dict):
        raise SystemExit("set: configuration must be a JSON object")
    key = args.key
    value = coerce(args.value)
    if not isinstance(value, SCALARS):
        raise SystemExit(f"set: value for {key!r} must be a scalar")
    forbidden = set(load_json(args.rules).get("forbidden_keys", [])) if args.rules else set()
    if key in forbidden:
        raise SystemExit(f"set: {key!r} is a forbidden key")
    previous = data.get(key, None)
    data[key] = value
    write_json(args.config, data)
    record(
        transcript_path(args, args.config),
        entry("set", {"config": args.config, "key": key, "value": args.value},
              detail={"from": previous, "to": value, "type": type(value).__name__}),
    )
    print(f"set {key}={json.dumps(value)}")


def cmd_build_profile(args):
    """defaults.base_config  ->  env override  ->  profile document."""
    schema = load_schema(args.schema)
    defaults = load_json(args.defaults)
    profile_doc = load_json(args.profile_input)
    name = args.profile or profile_doc.get("profile")
    if not name:
        raise SystemExit("build-profile: no profile name in --profile-input or --profile")

    data = {}
    for key in schema["required_keys"]:
        if key in defaults.get("base_config", {}):
            data[key] = defaults["base_config"][key]
        elif key in defaults and key != "base_config":
            data[key] = defaults[key]
        elif key in schema:
            data[key] = schema[key]
        else:
            data[key] = placeholder_for(key)

    applied = []
    layers = []
    if args.overrides:
        overrides = load_json(args.overrides)
        if name not in overrides:
            raise SystemExit(f"build-profile: no override block for profile {name!r}")
        layers.append(("env_overrides", overrides[name]))
    layers.append(("profile", profile_doc))

    for source, layer in layers:
        for key, value in layer.items():
            if key.endswith(DELTA_SUFFIX):
                target = key[: -len(DELTA_SUFFIX)]
                if target not in data:
                    raise SystemExit(f"build-profile: delta for unknown key {target!r}")
                if not isinstance(data[target], (int, float)) or isinstance(data[target], bool):
                    raise SystemExit(f"build-profile: {target!r} is not numeric")
                before = data[target]
                data[target] = before + value
                applied.append({"source": source, "key": target, "delta": value,
                                "from": before, "to": data[target]})
            else:
                if not isinstance(value, SCALARS):
                    raise SystemExit(f"build-profile: value for {key!r} is not a scalar")
                before = data.get(key)
                data[key] = value
                applied.append({"source": source, "key": key, "from": before, "to": value})

    data["profile"] = name
    ordered = {k: data[k] for k in schema["required_keys"] if k in data}
    for key, value in data.items():
        ordered.setdefault(key, value)

    write_json(args.out, ordered)
    record(
        transcript_path(args, args.out),
        entry("build-profile",
              {"schema": args.schema, "defaults": args.defaults, "overrides": args.overrides,
               "profile_input": args.profile_input, "out": args.out},
              detail={"profile": name, "applied": applied}),
    )
    print(f"built profile {name} -> {args.out}")


def check_config(data, schema, rules):
    """Return the per-configuration validation result."""
    missing = [k for k in schema["required_keys"] if k not in data]
    nonscalar = sorted(k for k, v in data.items() if not isinstance(v, SCALARS))
    forbidden_keys = list(rules.get("forbidden_keys", []))
    forbidden = sorted(k for k in data if k in set(forbidden_keys))

    checksum_ok = True
    checksum_detail = None
    if "checksum" in schema and "checksum" in data:
        checksum_ok = data["checksum"] == schema["checksum"]
        checksum_detail = {"expected": schema["checksum"], "actual": data.get("checksum")}

    allowed = list(rules.get("profiles", []))
    if schema.get("profile") is not None and schema["profile"] not in allowed:
        # the schema's own profile value is the template default for the main
        # configuration; the rules list constrains the per-environment ones.
        allowed = allowed + [schema["profile"]]
    profile_ok = (not allowed) or data.get("profile") in allowed

    checks = [
        {"check": "required_keys_present", "ok": not missing, "missing": missing},
        {"check": "scalar_only", "ok": not nonscalar, "non_scalar_keys": nonscalar},
        {"check": "no_forbidden_keys", "ok": not forbidden, "forbidden_present": forbidden},
        {"check": "checksum_matches_schema", "ok": checksum_ok, "detail": checksum_detail},
        {"check": "profile_allowed", "ok": profile_ok,
         "detail": {"profile": data.get("profile"), "allowed": allowed}},
    ]
    return {"ok": all(c["ok"] for c in checks), "key_count": len(data), "checks": checks}


def cmd_validate(args):
    schema = load_schema(args.schema)
    rules = load_json(args.rules) if args.rules else {}
    results = []
    for config_path in args.config:
        data = load_json(config_path)
        if not isinstance(data, dict):
            raise SystemExit(f"validate: {config_path} is not a JSON object")
        result = {"config": config_path}
        result.update(check_config(data, schema, rules))
        results.append(result)

    report = {
        "tool": TOOL_NAME,
        "tool_version": TOOL_VERSION,
        "schema": args.schema,
        "rules": args.rules,
        "ok": all(r["ok"] for r in results),
        "configs_validated": len(results),
        "results": results,
    }
    if args.report_out:
        write_json(args.report_out, report)

    record(
        transcript_path(args, args.config[0]),
        entry("validate",
              {"schema": args.schema, "config": list(args.config), "rules": args.rules,
               "report_out": args.report_out},
              status="ok" if report["ok"] else "error",
              detail={"ok": report["ok"], "configs_validated": len(results)}),
    )

    for result in results:
        if result["ok"]:
            print(f"ok {result['config']}")
        else:
            for check in result["checks"]:
                if not check["ok"]:
                    print(f"FAIL {result['config']}: {check['check']} {json.dumps(check)}",
                          file=sys.stderr)
    if not report["ok"]:
        raise SystemExit("validation failed")
    print("ok")


def cmd_report(args):
    data = load_json(args.config)
    log = transcript_path(args, args.config)
    record(log, entry("export-report", {"config": args.config, "out": args.out}))
    commands = json.loads(log.read_text()) if log.exists() else []
    report = {
        "tool": TOOL_NAME,
        "tool_version": TOOL_VERSION,
        "ok": True,
        "config_path": str(args.config),
        "config": data,
        "config_key_count": len(data) if isinstance(data, dict) else None,
        "repairs": REPAIRS,
        "repair_count": len(REPAIRS),
        "commands": commands,
        "command_count": len(commands),
    }
    for item in args.meta or []:
        key, _, value = item.partition("=")
        report.setdefault("run", {})[key] = value
    write_json(args.out, report)
    print(f"wrote {args.out} ({len(commands)} commands, {len(REPAIRS)} repairs)")


def cmd_summarize(args):
    rules = load_json(args.rules) if args.rules else {}
    required = list(rules.get("required_artifacts", []))
    limit = rules.get("max_artifact_bytes")
    directory = Path(args.dir)
    out = Path(args.out).resolve()

    artifacts = []
    for name in required:
        path = directory / name
        item = {"name": name, "present": path.exists()}
        if path.resolve() == out:
            # the summary is being written by this very call: it exists by
            # definition, and it cannot contain its own hash.
            item["self"] = True
            item["present"] = True
            item["bytes"] = None
            item["sha256"] = None
        elif path.exists():
            blob = path.read_bytes()
            item["bytes"] = len(blob)
            item["sha256"] = hashlib.sha256(blob).hexdigest()
            if limit:
                item["within_size_limit"] = len(blob) <= limit
        artifacts.append(item)

    missing = [a["name"] for a in artifacts if not a["present"]]
    oversize = [a["name"] for a in artifacts if a.get("within_size_limit") is False]
    summary = {
        "tool": TOOL_NAME,
        "tool_version": TOOL_VERSION,
        "artifact_dir": str(directory),
        "required_artifacts": required,
        "artifacts": artifacts,
        "missing_artifacts": missing,
        "oversize_artifacts": oversize,
        "max_artifact_bytes": limit,
        "ok": not missing and not oversize,
    }
    if args.merge:
        for path in args.merge:
            key = Path(path).stem
            summary.setdefault("inputs", {})[key] = load_json(path)
    write_json(args.out, summary)
    print(f"wrote {args.out} ({len(artifacts) - len(missing)}/{len(artifacts)} artifacts present)")


# -------------------------------------------------------------------------- main


def build_parser():
    parser = argparse.ArgumentParser(prog=TOOL_NAME)
    parser.add_argument("--version", action="version",
                        version=f"{TOOL_NAME} {TOOL_VERSION}")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("init", help="create a flat configuration from a schema")
    p.add_argument("--schema", required=True)
    p.add_argument("--defaults", help="defaults.json supplying base_config values")
    p.add_argument("--out", required=True)
    p.add_argument("--log")
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set", help="set one scalar key in a configuration")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.add_argument("--rules", help="validation_rules.json, to reject forbidden keys")
    p.add_argument("--log")
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("build-profile", help="apply defaults, env overrides and a profile")
    p.add_argument("--schema", required=True)
    p.add_argument("--defaults", required=True)
    p.add_argument("--overrides")
    p.add_argument("--profile-input", required=True, dest="profile_input")
    p.add_argument("--profile")
    p.add_argument("--out", required=True)
    p.add_argument("--log")
    p.set_defaults(func=cmd_build_profile)

    p = sub.add_parser("validate", help="validate one or more configurations")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True, action="append")
    p.add_argument("--rules")
    p.add_argument("--report-out", dest="report_out")
    p.add_argument("--log")
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("export-report", help="write a run report with the command transcript")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--meta", action="append", metavar="KEY=VALUE",
                   help="extra run context to record under the report's 'run' key")
    p.add_argument("--log")
    p.set_defaults(func=cmd_report)

    p = sub.add_parser("summarize", help="summarise the produced artifacts")
    p.add_argument("--dir", required=True)
    p.add_argument("--rules")
    p.add_argument("--merge", action="append")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_summarize)
    return parser


def main(argv=None):
    parser = build_parser()
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv:
        parser.print_usage(sys.stderr)
        raise SystemExit(2)
    args = parser.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()
