# task-ctl

A local, stdlib-only CLI that creates, updates, validates and reports a flat
JSON configuration for TASK processing. The archived version was broken in
several places; this copy is repaired. `python3 cli.py export-report ...`
embeds the full list of faults and fixes under the `repairs` key.

Everything it writes is deterministic: no clock, no randomness, and none of the
keys forbidden by `validation_rules.json`.

## Contract

A valid configuration is a **flat, scalar-only** JSON object that contains every
key in the schema's `required_keys`, whose `checksum` equals the schema's
`checksum`, that contains none of the forbidden keys, and whose `profile` is one
of the allowed profiles (or the schema's own template profile).

`required_keys` may be a JSON list or a comma-separated string; both spellings
load.

## Commands

```bash
# create a flat configuration containing every required key
python3 cli.py init --schema schema.json --out config.json
python3 cli.py init --schema config_schema.json --defaults defaults.json --out config.json

# set one scalar key (key case preserved, value coerced to int/float/bool/null)
python3 cli.py set --config config.json --key max_records --value 100

# base defaults -> env override block -> profile document; "<key>_delta" adds
python3 cli.py build-profile --schema config_schema.json --defaults defaults.json \
    --overrides env_overrides.json --profile-input sample_config_dev.json \
    --out profile_dev.json

# validate one or more configurations; --report-out writes the findings as JSON
python3 cli.py validate --schema config_schema.json --config config.json \
    --rules validation_rules.json --report-out validation_report.json

# run report: the configuration, the repair notes and the command transcript
python3 cli.py export-report --config config.json --out report.json

# artifact summary against the rules' required_artifacts / max_artifact_bytes
python3 cli.py summarize --dir . --rules validation_rules.json --out summary.json
```

Every mutating command appends a structured entry to a transcript file
(`.task-ctl-transcript.json`, next to the config or wherever `--log` points);
`export-report` emits that transcript as the report's `commands` list.

Exit status is non-zero on validation failure or on a bad invocation; a bare
`task-ctl` prints usage and exits 2.
