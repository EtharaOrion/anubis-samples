#!/usr/bin/env python3
"""Package the repaired tool into a deterministic zip archive.

Fixed timestamps and a sorted member list so repeated runs are byte-identical.
"""
from __future__ import annotations

import sys
import zipfile
from pathlib import Path

MEMBERS = ["README.md", "cli.py", "package.py", "schema.json"]
FIXED_DATE = (1980, 1, 1, 0, 0, 0)


def main():
    source = Path(sys.argv[1] if len(sys.argv) > 1 else Path(__file__).parent)
    target = Path(sys.argv[2] if len(sys.argv) > 2 else source / "tool.zip")
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
        for name in sorted(MEMBERS):
            info = zipfile.ZipInfo(name, date_time=FIXED_DATE)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (0o644 if name != "cli.py" else 0o755) << 16
            archive.writestr(info, (source / name).read_bytes())
    print(f"wrote {target} ({target.stat().st_size} bytes)")


if __name__ == "__main__":
    main()
