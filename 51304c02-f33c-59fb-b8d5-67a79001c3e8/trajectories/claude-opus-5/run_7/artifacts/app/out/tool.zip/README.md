# task-ctl

A local, stdlib-only CLI that creates, updates, validates and reports a **flat**
JSON configuration. The written contract is `config_schema.json` (required keys,
`scalar_only`) plus `validation_rules.json` (forbidden keys, required artifacts,
size limit); `defaults.json`, `sample_config_*.json` and `env_overrides.json`
supply the base values and the per-environment layers.

## Commands

```bash
python3 cli.py init --schema schema.json --defaults defaults.json --out config.json
python3 cli.py set --config config.json --key max_records --value 100
python3 cli.py profile --config config.json --profile-file sample_config_dev.json \
                       --overrides env_overrides.json --schema schema.json \
                       --out profile_dev.json
python3 cli.py validate --schema schema.json --config config.json \
                        --rules validation_rules.json --format json \
                        --report-out validation_report.json --label config.json
python3 cli.py export-report --config config.json --out report.json
python3 cli.py summarize --dir out --rules validation_rules.json --out summary.json
```

`init` copies the scalar schema fields, fills placeholders from `defaults.json`
and flattens `base_config` into the top level. `profile` applies a layer: a
`<key>_delta` entry adds to a numeric key, any other entry assigns a scalar.
`set` keeps the key exactly as given and coerces the value to int/float/bool/
null/string. `validate` exits non-zero on any error and can append a
machine-readable result to a shared report file.

Setting `TASK_CTL_LOG=<path>` records every invocation, so `export-report`
emits a real command transcript. Output is deterministic: no timestamps,
UUIDs or random seeds are ever written (they are forbidden keys).

## Faults repaired

1. `init` read `args.config`, an option it never defines — every run crashed
   with `AttributeError`.
2. `init` emitted a nested `settings` object, violating the `scalar_only`
   contract; it also emitted only 4 of the 9 required keys and had no way to
   read `defaults.json`.
3. `set` upper-cased the key (`MAX_RECORDS`), so it could never satisfy a
   required key, and stored every value as a string instead of a scalar.
4. `validate` did `schema["required_keys"].split(",")`, which raises
   `AttributeError` on the contract's list form; it also ignored
   `scalar_only`, the forbidden-key rules and pinned schema values, and it
   reported nothing machine-readable.
5. `export-report` wrote `"commands": "unknown"` — an unusable transcript
   shape; it is now a list of the commands actually run.
6. The subparser was optional, so a bare `task-ctl` died with
   `AttributeError: 'Namespace' object has no attribute 'func'` instead of
   printing usage.
7. The bundled `schema.json` disagreed with `config_schema.json`
   (comma-separated string, no `scalar_only`); it now matches the contract and
   the loader still accepts the legacy string form.
8. No command could apply the sample profiles or `env_overrides.json`, and
   nothing could summarise artifacts against `validation_rules.json`; the
   `profile` and `summarize` commands close those gaps.
