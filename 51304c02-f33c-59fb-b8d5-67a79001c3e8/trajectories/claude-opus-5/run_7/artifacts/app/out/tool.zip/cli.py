#!/usr/bin/env python3
"""task-ctl: a stdlib-only CLI that creates, updates, validates and reports a
flat JSON configuration.

Every command appends a line to the run log named by the TASK_CTL_LOG
environment variable (when set), so `export-report` can emit a real command
transcript instead of a placeholder.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import zlib
from pathlib import Path

SCHEMA_META_KEYS = {"required_keys", "scalar_only"}
SCALAR_TYPES = (str, int, float, bool, type(None))


def load_json(path):
    return json.loads(Path(path).read_text())


def write_json(path, data):
    Path(path).write_text(json.dumps(data, indent=2, sort_keys=False) + "\n")


def log_command(argv):
    """Append this invocation to the run log (deterministic, no timestamps)."""
    log_path = os.environ.get("TASK_CTL_LOG")
    if not log_path:
        return
    entries = []
    path = Path(log_path)
    if path.exists():
        try:
            entries = json.loads(path.read_text())
        except json.JSONDecodeError:
            entries = []
    entries.append(["task-ctl"] + list(argv))
    path.write_text(json.dumps(entries, indent=2) + "\n")


def required_keys(schema):
    """The contract writes required_keys as a list; older copies used a
    comma-separated string. Accept both."""
    keys = schema.get("required_keys", [])
    if isinstance(keys, str):
        keys = [k.strip() for k in keys.split(",")]
    return [k for k in keys if k]


def order_keys(data, schema):
    """Emit required keys first, in contract order, then any extras."""
    ordered = {}
    for key in required_keys(schema):
        if key in data:
            ordered[key] = data[key]
    for key, value in data.items():
        if key not in ordered:
            ordered[key] = value
    return ordered


def coerce(text):
    """Turn a command-line string into the scalar it denotes."""
    lowered = text.strip().lower()
    if lowered in ("true", "false"):
        return lowered == "true"
    if lowered in ("null", "none"):
        return None
    try:
        return int(text)
    except ValueError:
        pass
    try:
        return float(text)
    except ValueError:
        pass
    return text


def apply_layer(data, layer):
    """Apply a profile/override layer: `<key>_delta` adds to a numeric key,
    anything else is a straight scalar assignment."""
    for key, value in layer.items():
        if key.endswith("_delta"):
            target = key[: -len("_delta")]
            base = data.get(target)
            if not isinstance(base, (int, float)) or isinstance(base, bool):
                raise SystemExit(
                    "cannot apply %s: %r is not numeric" % (key, target)
                )
            data[target] = base + value
        elif isinstance(value, SCALAR_TYPES):
            data[key] = value
        else:
            raise SystemExit("override %s must be scalar" % key)
    return data


def cmd_init(args):
    schema = load_json(args.schema)
    data = {}
    for key, value in schema.items():
        if key in SCHEMA_META_KEYS:
            continue
        if not isinstance(value, SCALAR_TYPES):
            raise SystemExit("schema value %s must be scalar" % key)
        data[key] = value
    if args.defaults:
        defaults = load_json(args.defaults)
        for key, value in defaults.items():
            if key == "base_config" or not isinstance(value, SCALAR_TYPES):
                continue
            if data.get(key) in (None, ""):
                data[key] = value
        for key, value in defaults.get("base_config", {}).items():
            if not isinstance(value, SCALAR_TYPES):
                raise SystemExit("base_config value %s must be scalar" % key)
            data[key] = value
    data = order_keys(data, schema)
    missing = [k for k in required_keys(schema) if k not in data]
    if missing:
        print("warning: not yet set: " + ",".join(missing), file=sys.stderr)
    write_json(args.out, data)
    print("wrote %s (%d keys)" % (args.out, len(data)))


def cmd_set(args):
    data = load_json(args.config)
    data[args.key] = coerce(args.value)
    write_json(args.config, data)
    print("set %s=%r" % (args.key, data[args.key]))


def cmd_profile(args):
    data = load_json(args.config)
    layers = []
    if args.profile_file:
        layers.append(load_json(args.profile_file))
    name = args.name
    for layer in layers:
        if not name and isinstance(layer.get("profile"), str):
            name = layer["profile"]
    if args.overrides:
        overrides = load_json(args.overrides)
        if name not in overrides:
            raise SystemExit("no overrides for profile %r" % name)
        layers.append(overrides[name])
    if name:
        data["profile"] = name
    for layer in layers:
        apply_layer(data, layer)
    if args.schema:
        data = order_keys(data, load_json(args.schema))
    write_json(args.out, data)
    print("wrote %s (profile %s)" % (args.out, name))


def validate_config(schema, data, rules=None):
    errors = []
    missing = [key for key in required_keys(schema) if key not in data]
    if missing:
        errors.append("missing required keys: " + ",".join(missing))
    if schema.get("scalar_only", True):
        nested = sorted(
            k for k, v in data.items() if isinstance(v, (dict, list))
        )
        if nested:
            errors.append("configuration must be flat; nested: " + ",".join(nested))
    for key in ("producer", "container", "checksum"):
        # An empty schema value is a placeholder, not a pinned value.
        if schema.get(key) not in (None, "") and key in data:
            if data[key] != schema[key]:
                errors.append(
                    "%s must be %r, got %r" % (key, schema[key], data[key])
                )
    if rules:
        forbidden = sorted(set(rules.get("forbidden_keys", [])) & set(data))
        if forbidden:
            errors.append("forbidden keys present: " + ",".join(forbidden))
    return errors


def cmd_validate(args):
    schema = load_json(args.schema)
    data = load_json(args.config)
    rules = load_json(args.rules) if args.rules else None
    errors = validate_config(schema, data, rules)
    result = {
        "target": args.config,
        "label": args.label or Path(args.config).name,
        "schema": args.schema,
        "rules": args.rules,
        "checked_keys": sorted(data) if isinstance(data, dict) else [],
        "required_keys": required_keys(schema),
        "errors": errors,
        "ok": not errors,
    }
    if args.report_out:
        path = Path(args.report_out)
        report = {"tool": "task-ctl", "check": "config-validation", "results": []}
        if path.exists():
            try:
                existing = json.loads(path.read_text())
                if isinstance(existing, dict) and isinstance(
                    existing.get("results"), list
                ):
                    report = existing
            except json.JSONDecodeError:
                pass
        report["results"] = [
            r for r in report["results"] if r.get("label") != result["label"]
        ]
        report["results"].append(result)
        report["results"].sort(key=lambda r: r.get("label", ""))
        report["ok"] = all(r.get("ok") for r in report["results"])
        report["checked"] = len(report["results"])
        write_json(path, report)
    if args.format == "json":
        print(json.dumps(result, indent=2))
    else:
        print("ok" if not errors else "FAILED")
        for err in errors:
            print("  - " + err)
    if errors:
        raise SystemExit(1)


def cmd_report(args):
    data = load_json(args.config)
    commands = []
    log_path = args.log or os.environ.get("TASK_CTL_LOG")
    if log_path and Path(log_path).exists():
        commands = json.loads(Path(log_path).read_text())
    report = {
        "tool": "task-ctl",
        "ok": True,
        "config_path": str(args.config),
        "config": data,
        "config_keys": sorted(data),
        "commands": [" ".join(str(part) for part in c) for c in commands],
        "command_count": len(commands),
    }
    if args.notes:
        notes = load_json(args.notes)
        if isinstance(notes, dict):
            report.update(notes)
    write_json(args.out, report)
    print("wrote %s (%d commands)" % (args.out, len(commands)))


def cmd_summarize(args):
    rules = load_json(args.rules) if args.rules else {}
    directory = Path(args.dir)
    out_name = Path(args.out).name
    limit = rules.get("max_artifact_bytes")
    artifacts = []
    problems = []
    for name in rules.get("required_artifacts", []):
        path = directory / name
        entry = {"name": name, "present": path.exists()}
        if name == out_name and not path.exists():
            entry["present"] = True
            entry["note"] = "written by this command"
        elif path.exists():
            raw = path.read_bytes()
            entry["bytes"] = len(raw)
            entry["crc32"] = "%08x" % (zlib.crc32(raw) & 0xFFFFFFFF)
            if limit and len(raw) > limit:
                problems.append("%s exceeds max_artifact_bytes" % name)
        if not entry["present"]:
            problems.append("missing artifact: %s" % name)
        artifacts.append(entry)
    summary = {
        "tool": "task-ctl",
        "directory": str(directory),
        "artifacts": artifacts,
        "artifact_count": len(artifacts),
        "problems": problems,
        "ok": not problems,
    }
    if args.notes:
        notes = load_json(args.notes)
        if isinstance(notes, dict):
            summary.update(notes)
    write_json(args.out, summary)
    print("wrote %s (%d artifacts, ok=%s)" % (args.out, len(artifacts), summary["ok"]))


def build_parser():
    parser = argparse.ArgumentParser(prog="task-ctl")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("init", help="create a flat config from schema/defaults")
    p.add_argument("--schema", required=True)
    p.add_argument("--defaults")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set", help="set one scalar key")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("profile", help="apply a profile and env overrides")
    p.add_argument("--config", required=True)
    p.add_argument("--profile-file")
    p.add_argument("--overrides")
    p.add_argument("--name")
    p.add_argument("--schema")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_profile)

    p = sub.add_parser("validate", help="check a config against the schema")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--rules")
    p.add_argument("--label")
    p.add_argument("--report-out")
    p.add_argument("--format", choices=["text", "json"], default="text")
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("export-report", help="emit a run report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--log")
    p.add_argument("--notes")
    p.set_defaults(func=cmd_report)

    p = sub.add_parser("summarize", help="summarise produced artifacts")
    p.add_argument("--dir", required=True)
    p.add_argument("--rules")
    p.add_argument("--notes")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_summarize)

    return parser


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    args = build_parser().parse_args(argv)
    log_command(argv)
    args.func(args)


if __name__ == "__main__":
    main()
