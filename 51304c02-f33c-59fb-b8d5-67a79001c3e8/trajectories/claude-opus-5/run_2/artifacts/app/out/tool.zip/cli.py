#!/usr/bin/env python3
"""task-ctl: build, update, derive, validate and report a flat JSON configuration.

Standard library only. All output is deterministic: no timestamps, no random
values, no network access.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

SCALAR_TYPES = (str, int, float, bool, type(None))


# --------------------------------------------------------------------------
# io helpers
# --------------------------------------------------------------------------
def load_json(path):
    p = Path(path)
    if not p.is_file():
        raise SystemExit("error: no such file: %s" % path)
    try:
        return json.loads(p.read_text())
    except json.JSONDecodeError as exc:
        raise SystemExit("error: %s is not valid JSON: %s" % (path, exc))


def write_json(path, data):
    p = Path(path)
    if p.parent and str(p.parent):
        p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")


# --------------------------------------------------------------------------
# transcript sidecar
#
# Every mutating command records what it did next to the config it produced,
# so `export-report` can emit a real command transcript instead of a placeholder.
# --------------------------------------------------------------------------
def transcript_path(config_path, explicit=None):
    if explicit:
        return Path(explicit)
    p = Path(config_path)
    return p.with_name(p.name + ".transcript.json")


def load_transcript(config_path, explicit=None):
    p = transcript_path(config_path, explicit)
    if not p.is_file():
        return {"tool": "task-ctl", "config": str(Path(config_path)), "commands": []}
    try:
        data = json.loads(p.read_text())
    except json.JSONDecodeError:
        return {"tool": "task-ctl", "config": str(Path(config_path)), "commands": []}
    data.setdefault("commands", [])
    return data


def record(config_path, entry, explicit=None, seed=None):
    doc = seed if seed is not None else load_transcript(config_path, explicit)
    doc["tool"] = "task-ctl"
    doc["config"] = str(Path(config_path))
    doc.setdefault("commands", []).append(entry)
    write_json(transcript_path(config_path, explicit), doc)
    return doc


# --------------------------------------------------------------------------
# schema helpers
# --------------------------------------------------------------------------
def required_keys(schema):
    """Accept the contract form (list) and the legacy form (comma string)."""
    keys = schema.get("required_keys", [])
    if isinstance(keys, str):
        keys = [k.strip() for k in keys.split(",")]
    return [k for k in keys if k]


def coerce(raw, kind="auto"):
    """Turn a command-line string into the scalar it denotes."""
    if kind == "str":
        return raw
    if kind == "int":
        return int(raw)
    if kind == "float":
        return float(raw)
    if kind == "bool":
        if raw.lower() in ("true", "1", "yes"):
            return True
        if raw.lower() in ("false", "0", "no"):
            return False
        raise SystemExit("error: not a boolean: %s" % raw)
    if kind == "null":
        return None
    # auto
    try:
        value = json.loads(raw)
    except json.JSONDecodeError:
        return raw
    if isinstance(value, (dict, list)):
        raise SystemExit(
            "error: value must be a scalar (configuration is flat), got: %s" % raw
        )
    return value


def nonscalar_keys(data):
    return sorted(k for k, v in data.items() if not isinstance(v, SCALAR_TYPES))


# --------------------------------------------------------------------------
# commands
# --------------------------------------------------------------------------
def cmd_init(args):
    schema = load_json(args.schema)
    data = {}
    for key in ("profile", "producer", "container", "checksum"):
        if key in schema:
            data[key] = schema[key]

    if args.defaults:
        defaults = load_json(args.defaults)
        base = defaults.get("base_config", {})
        for key, value in defaults.items():
            if key == "base_config":
                continue
            if not isinstance(value, SCALAR_TYPES):
                continue
            # schema-declared identity fields win over defaults
            if key in data and data[key] not in ("", None):
                continue
            data[key] = value
        for key, value in base.items():
            data[key] = value

    bad = nonscalar_keys(data)
    if bad:
        raise SystemExit("error: non-scalar values are not allowed: %s" % ",".join(bad))

    write_json(args.out, data)
    entry = {"command": "init", "schema": args.schema, "out": args.out}
    if args.defaults:
        entry["defaults"] = args.defaults
    entry["keys"] = sorted(data)
    record(args.out, entry, args.transcript,
           seed={"tool": "task-ctl", "config": str(Path(args.out)), "commands": []})
    print("wrote %s (%d keys)" % (args.out, len(data)))


def cmd_set(args):
    data = load_json(args.config)
    if not isinstance(data, dict):
        raise SystemExit("error: configuration must be a JSON object")
    key = args.key  # keys are case sensitive and used verbatim
    value = coerce(args.value, args.type)
    data[key] = value
    write_json(args.config, data)
    record(args.config, {"command": "set", "config": args.config,
                         "key": key, "value": value}, args.transcript)
    print("set %s=%s" % (key, json.dumps(value)))


def cmd_apply_profile(args):
    """Derive an environment configuration from a base config.

    Overlay files may carry `<key>_delta` entries; those are applied as numeric
    deltas to the base value and never survive into the output, which stays flat.
    """
    data = load_json(args.config)
    if not isinstance(data, dict):
        raise SystemExit("error: configuration must be a JSON object")

    layers = []
    if args.profile:
        layers.append(("profile-file", args.profile, load_json(args.profile)))
    if args.overrides:
        overrides = load_json(args.overrides)
        if args.env is None:
            raise SystemExit("error: --overrides requires --env")
        if args.env not in overrides:
            raise SystemExit("error: --overrides has no section for env %r" % args.env)
        layers.append(("overrides:" + args.env, args.overrides, overrides[args.env]))

    applied = []
    for label, source, layer in layers:
        if not isinstance(layer, dict):
            raise SystemExit("error: overlay %s is not a JSON object" % source)
        for key, value in sorted(layer.items()):
            if key.endswith("_delta"):
                target = key[: -len("_delta")]
                if target not in data:
                    raise SystemExit(
                        "error: %s targets unknown key %r" % (key, target))
                base = data[target]
                if not isinstance(base, (int, float)) or isinstance(base, bool):
                    raise SystemExit(
                        "error: cannot apply a delta to non-numeric key %r" % target)
                if not isinstance(value, (int, float)) or isinstance(value, bool):
                    raise SystemExit("error: delta %r is not numeric" % key)
                data[target] = base + value
                applied.append({"layer": label, "key": target, "op": "delta",
                                "delta": value, "from": base, "to": data[target]})
            else:
                if not isinstance(value, SCALAR_TYPES):
                    raise SystemExit(
                        "error: overlay value for %r is not a scalar" % key)
                before = data.get(key)
                data[key] = value
                applied.append({"layer": label, "key": key, "op": "set",
                                "from": before, "to": value})

    bad = nonscalar_keys(data)
    if bad:
        raise SystemExit("error: non-scalar values are not allowed: %s" % ",".join(bad))
    leftover = sorted(k for k in data if k.endswith("_delta"))
    if leftover:
        raise SystemExit("error: unresolved delta keys: %s" % ",".join(leftover))

    write_json(args.out, data)

    lineage = load_transcript(args.config, None)
    seed = {"tool": "task-ctl", "config": str(Path(args.out)),
            "derived_from": str(Path(args.config)),
            "commands": list(lineage.get("commands", []))}
    entry = {"command": "apply-profile", "config": args.config, "out": args.out,
             "env": args.env, "changes": applied}
    if args.profile:
        entry["profile"] = args.profile
    if args.overrides:
        entry["overrides"] = args.overrides
    record(args.out, entry, args.transcript, seed=seed)
    print("wrote %s (%d changes)" % (args.out, len(applied)))


def cmd_validate(args):
    schema = load_json(args.schema)
    data = load_json(args.config)
    rules = load_json(args.rules) if args.rules else {}

    checks = []
    errors = []
    warnings = []

    def check(name, ok, detail, level="error"):
        status = "pass" if ok else ("warn" if level == "warn" else "fail")
        checks.append({"check": name, "status": status, "detail": detail})
        if not ok:
            (warnings if level == "warn" else errors).append(
                "%s: %s" % (name, detail))

    if not isinstance(data, dict):
        raise SystemExit("error: configuration must be a JSON object")

    need = required_keys(schema)
    missing = [k for k in need if k not in data]
    check("required_keys", not missing,
          "all %d required keys present" % len(need) if not missing
          else "missing: " + ",".join(missing))

    if schema.get("scalar_only", True):
        bad = nonscalar_keys(data)
        check("scalar_only", not bad,
              "configuration is flat" if not bad
              else "non-scalar values: " + ",".join(bad))

    empty = sorted(k for k in need if k in data and data[k] == "")
    check("non_empty_values", not empty,
          "no empty required values" if not empty
          else "declared empty by the schema: " + ",".join(empty), level="warn")

    for key in ("checksum", "profile", "producer", "container"):
        if key in schema and isinstance(schema[key], SCALAR_TYPES) and key in data:
            if key == "profile":
                continue  # profile is environment specific, checked against rules
            check("schema_value:" + key, data[key] == schema[key],
                  "%s == %r" % (key, schema[key]) if data[key] == schema[key]
                  else "expected %r, found %r" % (schema[key], data[key]))

    forbidden = [k for k in rules.get("forbidden_keys", []) if k in data]
    if rules.get("forbidden_keys") is not None:
        check("forbidden_keys", not forbidden,
              "no forbidden keys" if not forbidden
              else "present: " + ",".join(forbidden))

    profiles = rules.get("profiles")
    if profiles is not None and "profile" in data:
        ok = data["profile"] in profiles
        check("profile_allowed", ok,
              "profile %r is an allowed environment profile" % data["profile"] if ok
              else "profile %r is not one of %s (schema placeholder, not an "
                   "environment profile)" % (data["profile"], profiles),
              level="warn")

    limit = rules.get("max_artifact_bytes")
    if limit is not None:
        size = Path(args.config).stat().st_size
        check("max_artifact_bytes", size <= limit,
              "%d bytes <= %d" % (size, limit) if size <= limit
              else "%d bytes exceeds %d" % (size, limit))

    report = {
        "tool": "task-ctl",
        "command": "validate",
        "schema": args.schema,
        "config": args.config,
        "rules": args.rules,
        "checks": checks,
        "errors": errors,
        "warnings": warnings,
        "ok": not errors,
    }
    if args.report:
        write_json(args.report, report)
    if args.json:
        print(json.dumps(report, indent=2, sort_keys=True))

    record(args.config, {"command": "validate", "schema": args.schema,
                         "config": args.config, "rules": args.rules,
                         "ok": not errors,
                         "errors": errors, "warnings": warnings},
           args.transcript)

    if errors:
        if not args.json:
            for line in errors:
                print(line, file=sys.stderr)
        raise SystemExit(1)
    if not args.json:
        print("ok")


def cmd_report(args):
    data = load_json(args.config)
    doc = load_transcript(args.config, args.transcript)
    commands = doc.get("commands", [])
    validations = [c for c in commands if c.get("command") == "validate"]
    report = {
        "tool": "task-ctl",
        "config_path": args.config,
        "config": data,
        "key_count": len(data) if isinstance(data, dict) else None,
        "commands": commands,
        "command_count": len(commands),
        "derived_from": doc.get("derived_from"),
        "validated": bool(validations),
        "ok": all(c.get("ok") for c in validations) if validations else False,
    }
    write_json(args.out, report)
    print("wrote %s (%d commands)" % (args.out, len(commands)))


# --------------------------------------------------------------------------
def main(argv=None):
    parser = argparse.ArgumentParser(prog="task-ctl")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("init", help="create a flat config from the schema")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--defaults", help="defaults file supplying base_config values")
    p.add_argument("--transcript")
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set", help="set a single scalar key")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.add_argument("--type", default="auto",
                   choices=["auto", "str", "int", "float", "bool", "null"])
    p.add_argument("--transcript")
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("apply-profile",
                       help="derive an environment config using overlays/deltas")
    p.add_argument("--config", required=True)
    p.add_argument("--profile", help="profile overlay file")
    p.add_argument("--overrides", help="environment overrides file")
    p.add_argument("--env", help="section to read from --overrides")
    p.add_argument("--out", required=True)
    p.add_argument("--transcript")
    p.set_defaults(func=cmd_apply_profile)

    p = sub.add_parser("validate", help="validate a config against schema and rules")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--rules", help="validation rules file")
    p.add_argument("--report", help="write a machine readable validation report")
    p.add_argument("--json", action="store_true", help="print the report as JSON")
    p.add_argument("--transcript")
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("export-report", help="export the run transcript and config")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--transcript")
    p.set_defaults(func=cmd_report)

    args = parser.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()
