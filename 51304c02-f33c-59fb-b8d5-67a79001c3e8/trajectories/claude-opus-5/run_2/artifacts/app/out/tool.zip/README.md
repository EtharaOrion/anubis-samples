# task-ctl

A local, standard-library-only CLI that creates, updates, derives, validates and
reports a **flat** JSON configuration for TASK processing.

The configuration is always a single-level JSON object of scalar values. The
schema (`schema.json`, matching `config_schema.json` in the data set) declares
the required keys; the validation rules file declares forbidden keys, the
allowed environment profiles and the artifact size limit.

## Commands

```bash
# create the base configuration (schema identity fields + defaults/base_config)
python3 cli.py init --schema schema.json --defaults defaults.json --out config.json

# set a single scalar key (keys are case sensitive, values keep their JSON type)
python3 cli.py set --config config.json --key max_records --value 100
python3 cli.py set --config config.json --key mode --value strict-local --type str

# derive an environment configuration; `<key>_delta` entries in an overlay are
# applied as numeric deltas to the base value and are removed from the output
python3 cli.py apply-profile --config config.json \
    --profile sample_config_dev.json \
    --overrides env_overrides.json --env dev \
    --out profile_dev.json

# validate against the schema (and optionally the validation rules)
python3 cli.py validate --schema schema.json --config config.json \
    --rules validation_rules.json --report validation_report.json

# export the run transcript together with the configuration
python3 cli.py export-report --config config.json --out report.json
```

## Transcript

Every mutating command appends a record to a sidecar transcript next to the
config it wrote (`<config>.transcript.json`, overridable with `--transcript`).
`export-report` reads that sidecar, so the exported report contains the real
sequence of commands. `apply-profile` copies the base config's transcript into
the derived config's transcript so lineage is preserved.

Output is deterministic: no timestamps, no random values, no network access.

## Repairs applied

1. `init` read a non-existent `--config` argument and crashed; it now reads
   `--schema`.
2. `init` emitted a nested `settings` object, which violates the flat/scalar
   contract; all values are now written at the top level.
3. `init` could not seed the required numeric keys at all; it accepts
   `--defaults` and merges `base_config`.
4. `set` upper-cased the key, producing keys the schema never declares; the key
   is now used verbatim.
5. `set` stored every value as a string, so numeric keys failed their contract;
   values are now coerced to the scalar they denote (with an explicit `--type`
   escape hatch), and object/array values are rejected.
6. `validate` assumed `required_keys` was a comma-separated string and crashed
   on the list form used by the contract; both forms are accepted.
7. `validate` ignored `scalar_only`, the schema's declared values, and the
   validation rules; it now checks all of them and can emit a machine readable
   report.
8. `export-report` wrote `"commands": "unknown"`; a real transcript is recorded
   and exported.
9. The subcommand was optional, so running the tool with no arguments raised an
   `AttributeError` instead of printing usage; the subcommand is now required.
10. Overlay/delta handling (`*_delta` keys in the profile and override files)
    was missing entirely; `apply-profile` implements it.
11. The bundled `schema.json` had drifted from the contract (`required_keys` as
    a string, no `scalar_only`); it now matches `config_schema.json`.
