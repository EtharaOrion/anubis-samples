#!/usr/bin/env python3
"""task-ctl: create, update, validate and report a flat JSON configuration.

Standard library only. No network access.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

TOOL_NAME = "task-ctl"
TOOL_VERSION = "1.0.0"
DELTA_SUFFIX = "_delta"


def load_json(path):
    return json.loads(Path(path).read_text())


def write_json(path, data):
    Path(path).write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")


def coerce_scalar(text):
    """Turn a command-line string into the scalar it denotes.

    Numbers, booleans and null are decoded; anything else stays a string.
    Containers are rejected because the configuration must stay flat.
    """
    try:
        value = json.loads(text)
    except (ValueError, TypeError):
        return text
    if isinstance(value, (dict, list)):
        raise SystemExit("value must be a scalar, not a container: " + text)
    return value


def schema_required_keys(schema):
    """required_keys may be a JSON list or a comma-separated string."""
    keys = schema.get("required_keys", [])
    if isinstance(keys, str):
        keys = [part.strip() for part in keys.split(",")]
    return [key for key in keys if key]


def is_scalar(value):
    return not isinstance(value, (dict, list))


def history_path(config_path):
    path = Path(config_path)
    return path.parent / ("." + path.name + ".history.json")


def history_load(config_path):
    path = history_path(config_path)
    if not path.exists():
        return []
    try:
        entries = json.loads(path.read_text())
    except ValueError:
        return []
    return entries if isinstance(entries, list) else []


def history_append(config_path, entry):
    """Record one invocation so export-report can emit a real transcript."""
    entries = history_load(config_path)
    entry = dict(entry)
    entry["index"] = len(entries) + 1
    entries.append(entry)
    write_json(history_path(config_path), entries)


def defaults_to_flat(defaults):
    """Flatten defaults.json: top-level scalars plus the base_config block."""
    flat = {key: value for key, value in defaults.items() if is_scalar(value)}
    base = defaults.get("base_config", {})
    if not isinstance(base, dict):
        raise SystemExit("defaults base_config must be an object")
    for key, value in base.items():
        if not is_scalar(value):
            raise SystemExit("defaults base_config must be flat: " + key)
        flat[key] = value
    return flat


def apply_layer(data, layer):
    """Apply an override layer; `<key>_delta` adds to a numeric base key."""
    for key, value in layer.items():
        if not is_scalar(value):
            raise SystemExit("override values must be scalar: " + key)
        if key.endswith(DELTA_SUFFIX):
            target = key[: -len(DELTA_SUFFIX)]
            base = data.get(target)
            if not isinstance(base, (int, float)) or isinstance(base, bool):
                raise SystemExit("cannot apply " + key + " to non-numeric " + target)
            data[target] = base + value
        else:
            data[key] = value
    return data


# --------------------------------------------------------------------------- commands


def cmd_init(args):
    schema = load_json(args.schema)
    data = {
        "profile": schema["profile"],
        "producer": schema["producer"],
        "container": schema["container"],
        "checksum": schema["checksum"],
    }
    write_json(args.out, data)
    print("initialised " + args.out + " with " + str(len(data)) + " keys")


def cmd_merge(args):
    data = load_json(args.config)
    data.update(defaults_to_flat(load_json(args.defaults)))
    write_json(args.config, data)
    print("merged defaults into " + args.config)


def cmd_set(args):
    data = load_json(args.config)
    data[args.key] = coerce_scalar(args.value)
    write_json(args.config, data)
    print("set " + args.key + "=" + json.dumps(data[args.key]))


def cmd_derive_profile(args):
    data = defaults_to_flat(load_json(args.defaults))
    profile_input = load_json(args.profile) if args.profile else {}
    env = args.env or profile_input.get("profile")
    if not env:
        raise SystemExit("no environment given and profile input has no 'profile'")
    overrides = load_json(args.overrides)
    if env not in overrides:
        raise SystemExit("unknown environment: " + env)
    data["profile"] = env
    apply_layer(data, overrides[env])
    apply_layer(data, profile_input)
    write_json(args.out, data)
    print("derived profile " + env + " -> " + args.out)


def validate_one(schema, rules, config_path):
    data = load_json(config_path)
    checks = []
    errors = []

    def check(name, ok, detail):
        checks.append({"check": name, "ok": bool(ok), "detail": detail})
        if not ok:
            errors.append(name + ": " + detail)

    missing = [key for key in schema_required_keys(schema) if key not in data]
    check("required_keys", not missing,
          "all required keys present" if not missing else "missing " + ",".join(missing))

    if schema.get("scalar_only", True):
        nested = sorted(key for key, value in data.items() if not is_scalar(value))
        check("scalar_only", not nested,
              "configuration is flat" if not nested else "nested values: " + ",".join(nested))

    forbidden = sorted(set(rules.get("forbidden_keys", [])) & set(data))
    check("forbidden_keys", not forbidden,
          "no forbidden keys" if not forbidden else "present: " + ",".join(forbidden))

    allowed_profiles = list(rules.get("profiles", []))
    if "profile" in schema:
        allowed_profiles.append(schema["profile"])
    profile = data.get("profile")
    check("profile_value", profile in allowed_profiles,
          "profile=" + json.dumps(profile) + " allowed one of " + ",".join(sorted(set(allowed_profiles))))

    if "checksum" in schema:
        check("checksum_algorithm", data.get("checksum") == schema["checksum"],
              "checksum=" + json.dumps(data.get("checksum")) + " expected " + json.dumps(schema["checksum"]))

    for key in ("max_records", "retry_limit", "timeout_ms"):
        if key in data:
            value = data[key]
            ok = isinstance(value, int) and not isinstance(value, bool) and value >= 0
            check("numeric:" + key, ok, key + "=" + json.dumps(value) + " must be a non-negative integer")

    return {
        "config": str(config_path),
        "ok": not errors,
        "checks": checks,
        "errors": errors,
        "key_count": len(data),
    }


def cmd_validate(args):
    schema = load_json(args.schema)
    rules = load_json(args.rules) if args.rules else {}
    results = [validate_one(schema, rules, path) for path in args.config]
    ok = all(result["ok"] for result in results)
    report = {
        "tool": TOOL_NAME,
        "tool_version": TOOL_VERSION,
        "schema": str(args.schema),
        "rules": str(args.rules) if args.rules else None,
        "ok": ok,
        "targets_validated": len(results),
        "results": results,
    }
    if args.report:
        write_json(args.report, report)
    for result in results:
        options = {"schema": str(args.schema), "config": result["config"],
                   "rules": args.rules, "report": args.report}
        history_append(result["config"], {
            "command": "validate",
            "options": {key: value for key, value in options.items() if value is not None},
            "result": "ok" if result["ok"] else "failed",
        })
    for result in results:
        for error in result["errors"]:
            print("FAIL " + result["config"] + " " + error, file=sys.stderr)
        if result["ok"]:
            print("ok " + result["config"])
    if not ok:
        raise SystemExit(1)


def cmd_report(args):
    history_append(args.config, {"command": "export-report",
                                 "options": {"config": args.config, "out": args.out}})
    data = load_json(args.config)
    commands = history_load(args.config)
    report = {
        "tool": TOOL_NAME,
        "tool_version": TOOL_VERSION,
        "ok": True,
        "config_path": str(args.config),
        "config": data,
        "config_keys": sorted(data),
        "commands": commands,
        "command_count": len(commands),
    }
    if args.notes:
        notes = load_json(args.notes)
        if not isinstance(notes, dict):
            raise SystemExit("notes file must contain a JSON object")
        report.update(notes)
    write_json(args.out, report)
    print("wrote report " + args.out + " with " + str(len(commands)) + " commands")


def cmd_summarize(args):
    rules = load_json(args.rules) if args.rules else {}
    required = rules.get("required_artifacts", [])
    limit = rules.get("max_artifact_bytes")
    out_dir = Path(args.dir)
    artifacts = []
    missing = []
    oversized = []
    for name in required:
        path = out_dir / name
        if path == Path(args.out).resolve() or name == Path(args.out).name:
            # the summary itself: written by this command, so it cannot hash itself
            artifacts.append({"name": name, "present": True, "self": True,
                              "note": "written by this command"})
            continue
        if not path.exists():
            missing.append(name)
            artifacts.append({"name": name, "present": False})
            continue
        raw = path.read_bytes()
        if limit is not None and len(raw) > limit:
            oversized.append(name)
        artifacts.append({
            "name": name,
            "present": True,
            "bytes": len(raw),
            "within_size_limit": limit is None or len(raw) <= limit,
            "sha256": hashlib.sha256(raw).hexdigest(),
        })
    validation = None
    if args.validation:
        raw = load_json(args.validation)
        validation = {
            "report": str(args.validation),
            "ok": raw.get("ok"),
            "targets_validated": raw.get("targets_validated"),
            "results": [{"config": item.get("config"),
                         "ok": item.get("ok"),
                         "checks_run": len(item.get("checks", [])),
                         "errors": item.get("errors", [])}
                        for item in raw.get("results", [])],
        }
    summary = {
        "tool": TOOL_NAME,
        "tool_version": TOOL_VERSION,
        "artifact_dir": str(out_dir),
        "artifacts": artifacts,
        "missing_artifacts": missing,
        "oversized_artifacts": oversized,
        "validation": validation,
        "ok": not missing and not oversized and (validation is None or bool(validation["ok"])),
    }
    if args.extra:
        extra = load_json(args.extra)
        if not isinstance(extra, dict):
            raise SystemExit("extra file must contain a JSON object")
        summary.update(extra)
    write_json(args.out, summary)
    print("wrote summary " + args.out)


# --------------------------------------------------------------------------- cli


def build_parser():
    parser = argparse.ArgumentParser(prog=TOOL_NAME)
    parser.add_argument("--version", action="version", version=TOOL_NAME + " " + TOOL_VERSION)
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("init", help="create a flat configuration from a schema")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init, target="out")

    p = sub.add_parser("merge", help="fold defaults.json into an existing configuration")
    p.add_argument("--config", required=True)
    p.add_argument("--defaults", required=True)
    p.set_defaults(func=cmd_merge, target="config")

    p = sub.add_parser("set", help="set one scalar key")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set, target="config")

    p = sub.add_parser("derive-profile", help="build an environment profile from defaults + overrides")
    p.add_argument("--defaults", required=True)
    p.add_argument("--overrides", required=True)
    p.add_argument("--profile", help="sample profile file supplying the env name and its deltas")
    p.add_argument("--env", help="environment name (defaults to the profile file's 'profile')")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_derive_profile, target="out")

    p = sub.add_parser("validate", help="validate one or more configurations")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True, action="append",
                   help="configuration to validate; repeat for several")
    p.add_argument("--rules", help="validation_rules.json")
    p.add_argument("--report", help="write the validation report here")
    p.set_defaults(func=cmd_validate, target=None)

    p = sub.add_parser("export-report", help="write a run report for a configuration")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--notes", help="JSON object merged into the report")
    p.set_defaults(func=cmd_report, target=None)

    p = sub.add_parser("summarize", help="summarise the produced artifacts")
    p.add_argument("--dir", required=True)
    p.add_argument("--rules")
    p.add_argument("--validation", help="validation report to fold into the summary")
    p.add_argument("--extra", help="JSON object merged into the summary")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_summarize, target=None)

    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    args.func(args)
    target = getattr(args, "target", None)
    if target:
        options = {key: value for key, value in vars(args).items()
                   if key not in ("func", "command", "target") and value is not None}
        history_append(getattr(args, target), {"command": args.command, "options": options})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
