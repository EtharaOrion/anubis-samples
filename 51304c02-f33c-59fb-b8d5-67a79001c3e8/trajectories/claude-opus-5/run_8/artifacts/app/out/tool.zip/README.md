# task-ctl

A local, stdlib-only CLI that creates, updates, validates and reports a flat
JSON configuration for TASK processing. It reads no network resources.

## Contract

A valid configuration is a **flat** JSON object (scalars only) that carries every
key in the schema's `required_keys`:

    profile, producer, container, max_records, retry_limit, timeout_ms,
    checksum, mode, trailer

`validation_rules.json` additionally forbids the keys `timestamp`,
`generated_at`, `uuid` and `random_seed`, and names the environment profiles
(`dev`, `prod`) that a derived profile may use. The base configuration keeps the
schema's own profile token.

## Commands

```bash
# create the base configuration from the schema
python3 cli.py init --schema schema.json --out config.json

# fold defaults.json (top-level scalars + base_config) into it
python3 cli.py merge --config config.json --defaults defaults.json

# update a single key (the value is coerced to the scalar it denotes)
python3 cli.py set --config config.json --key max_records --value 100

# build an environment profile: defaults + env_overrides + the profile's deltas
python3 cli.py derive-profile --defaults defaults.json \
    --overrides env_overrides.json --profile sample_config_dev.json \
    --out profile_dev.json

# validate one or more configurations, optionally writing a report
python3 cli.py validate --schema schema.json --config config.json \
    [--config profile_dev.json ...] [--rules validation_rules.json] \
    [--report validation_report.json]

# write a run report (configuration + command transcript)
python3 cli.py export-report --config config.json --out report.json [--notes notes.json]

# summarise the produced artifacts against the validation rules
python3 cli.py summarize --dir out --rules validation_rules.json --out summary.json
```

Every command that writes a configuration appends a structured entry to a
sidecar transcript (`.<config-name>.history.json`) so that `export-report` can
emit the real sequence of commands rather than a placeholder. The transcript
holds no timestamps or random values, so repeated runs are byte-identical.

## Override semantics

In `env_overrides.json` and in the sample profile files, a key named
`<name>_delta` is *added* to the numeric base value of `<name>`; any other key
replaces the base value outright.

## Repairs applied

See `/app/out/report.json` (`repair` section) for the faults that were found in
the shipped version and how each one was fixed.
