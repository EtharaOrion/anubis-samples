#!/usr/bin/env python3
"""task-ctl - build, update, validate and report a flat JSON configuration.

Standard library only. No network access. Deterministic output: nothing that
this tool writes contains a timestamp, a uuid or a random seed.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

# Faults that were present in the shipped archive and repaired here. Emitted by
# `export-report` so the transcript explains itself.
REPAIRS = [
    {
        "id": "init-reads-wrong-argument",
        "where": "cmd_init",
        "fault": "init read args.config, an option the init subparser never defines, so every "
                 "invocation died with AttributeError before writing anything.",
        "fix": "init reads args.schema, the option it actually declares.",
    },
    {
        "id": "init-emits-nested-config",
        "where": "cmd_init",
        "fault": "init wrote checksum inside a nested 'settings' object, which violates the "
                 "scalar_only/flat contract and made the config fail its own validate step.",
        "fix": "every key is written at the top level as a scalar.",
    },
    {
        "id": "init-omits-required-keys",
        "where": "cmd_init",
        "fault": "init only copied profile/producer/container/checksum, so max_records, "
                 "retry_limit, timeout_ms, mode and trailer were always missing.",
        "fix": "init merges the defaults document (base_config plus top-level scalars) so all "
               "required_keys are populated; the defaults file is auto-discovered next to the "
               "schema or given with --defaults.",
    },
    {
        "id": "set-mangles-key-case",
        "where": "cmd_set",
        "fault": "set upper-cased the key, writing MAX_RECORDS beside the required lower-case "
                 "max_records instead of updating it.",
        "fix": "the key is stored exactly as supplied.",
    },
    {
        "id": "set-stores-numbers-as-strings",
        "where": "cmd_set",
        "fault": "set stored every value as the raw argv string, so numeric fields became "
                 "\"100\" instead of 100.",
        "fix": "values are coerced through a JSON scalar parse (int/float/bool/null), with a "
               "plain string kept when the text is not a JSON scalar; --type forces a kind.",
    },
    {
        "id": "validate-assumes-csv-required-keys",
        "where": "cmd_validate",
        "fault": "validate called .split(',') on required_keys, which crashes with AttributeError "
                 "on the authoritative schema where required_keys is a JSON list.",
        "fix": "required_keys is normalised from either a list or a comma separated string.",
    },
    {
        "id": "validate-ignores-rule-file",
        "where": "cmd_validate",
        "fault": "validate never honoured scalar_only, the forbidden_keys list or the empty-value "
                 "case, so a config could pass while carrying a forbidden non-deterministic key.",
        "fix": "validate enforces required keys, flatness/scalar_only, forbidden keys and "
               "non-empty required values, and can emit a machine readable result.",
    },
    {
        "id": "report-transcript-unusable",
        "where": "cmd_report",
        "fault": "export-report hard-coded \"commands\": \"unknown\", so the report proved nothing "
                 "about how the config was produced.",
        "fix": "each command appends its argv to a journal and export-report replays it as an "
               "ordered list, alongside the repair notes and the config it describes.",
    },
    {
        "id": "subcommand-not-required",
        "where": "main",
        "fault": "the subparsers group was optional, so `task-ctl` with no arguments raised "
                 "AttributeError: 'Namespace' object has no attribute 'func'.",
        "fix": "the subcommand is required and the parser exits with usage text instead.",
    },
    {
        "id": "no-profile-derivation",
        "where": "main",
        "fault": "the tool could not consume env_overrides.json or the sample profile documents, "
                 "so the per-environment configs it exists to produce were unreachable.",
        "fix": "added derive-profile, which applies environment overrides and *_delta adjustments "
               "onto the base config, and validate-many for a combined validation report.",
    },
]

SCALAR_TYPES = (str, int, float, bool)


# --------------------------------------------------------------------------- io


def load_json(path):
    return json.loads(Path(path).read_text())


def write_json(path, data):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")


def journal_path(args, anchor):
    if getattr(args, "journal", None):
        return Path(args.journal)
    return Path(anchor).resolve().parent / ".task-ctl-journal.json"


def journal_append(args, anchor, entry):
    path = journal_path(args, anchor)
    try:
        entries = load_json(path)
        if not isinstance(entries, list):
            entries = []
    except (OSError, ValueError):
        entries = []
    entries.append(entry)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(entries, indent=2) + "\n")


def record(args, anchor, command, detail):
    journal_append(args, anchor, {"command": command, "argv": sys.argv[1:], "detail": detail})


# ---------------------------------------------------------------- schema helpers


def required_keys(schema):
    """required_keys is a JSON list in the authoritative schema and a comma
    separated string in the copy bundled with the tool. Accept both."""
    raw = schema.get("required_keys", [])
    if isinstance(raw, str):
        return [k.strip() for k in raw.split(",") if k.strip()]
    return list(raw)


def find_defaults(args):
    if getattr(args, "defaults", None):
        return load_json(args.defaults)
    sibling = Path(args.schema).resolve().parent / "defaults.json"
    if sibling.is_file():
        return load_json(sibling)
    return {}


def coerce(value, kind=None):
    """Turn an argv string into the scalar it denotes."""
    if kind == "str":
        return value
    if kind == "int":
        return int(value)
    if kind == "float":
        return float(value)
    if kind == "bool":
        low = value.strip().lower()
        if low in ("true", "1", "yes"):
            return True
        if low in ("false", "0", "no"):
            return False
        raise SystemExit("not a boolean: " + value)
    try:
        parsed = json.loads(value)
    except ValueError:
        return value
    if parsed is None or isinstance(parsed, SCALAR_TYPES):
        return parsed
    return value


def build_base(schema, defaults):
    """Flat base configuration: schema identity fields plus the defaults."""
    config = {}
    for key in ("profile", "producer", "container", "checksum", "mode"):
        if key in schema and isinstance(schema[key], SCALAR_TYPES):
            config[key] = schema[key]
    for key, value in defaults.items():
        if key == "base_config":
            continue
        if isinstance(value, SCALAR_TYPES):
            config.setdefault(key, value)
            if config.get(key) in ("", None):
                config[key] = value
    for key, value in defaults.get("base_config", {}).items():
        config[key] = value
    return {k: config[k] for k in sorted(config)}


def apply_overlay(config, overlay):
    """Apply an overlay document onto a config.

    A `<key>_delta` entry adds a numeric adjustment to `<key>`; any other scalar
    entry replaces the value outright.
    """
    applied = []
    for key in sorted(overlay):
        value = overlay[key]
        if key.endswith("_delta"):
            target = key[: -len("_delta")]
            if target not in config:
                raise SystemExit("delta for unknown key: " + target)
            before = config[target]
            if not isinstance(before, (int, float)) or isinstance(before, bool):
                raise SystemExit("delta applied to non-numeric key: " + target)
            config[target] = before + value
            applied.append({"key": target, "operation": "delta", "delta": value,
                            "from": before, "to": config[target]})
        elif isinstance(value, SCALAR_TYPES):
            before = config.get(key)
            config[key] = value
            applied.append({"key": key, "operation": "set", "from": before, "to": value})
        else:
            raise SystemExit("overlay values must be scalar: " + key)
    return applied


# -------------------------------------------------------------------- validation


def validate_config(config, schema, rules):
    errors = []
    warnings = []

    for key in required_keys(schema):
        if key not in config:
            errors.append("missing required key: " + key)

    for key, value in sorted(config.items()):
        if isinstance(value, (dict, list)):
            errors.append("value must be a scalar, not a container: " + key)
        elif value is None:
            errors.append("value must not be null: " + key)

    if schema.get("scalar_only", True):
        for key, value in sorted(config.items()):
            if not isinstance(value, SCALAR_TYPES):
                errors.append("scalar_only violated by key: " + key)

    for key in rules.get("forbidden_keys", []):
        if key in config:
            errors.append("forbidden key present: " + key)

    for key in ("producer", "container"):
        if config.get(key) == "":
            warnings.append("required key is present but empty: " + key)

    profiles = rules.get("profiles")
    if profiles and config.get("profile") in profiles:
        warnings.append("profile '%s' is an environment profile" % config["profile"])

    return {"ok": not errors, "errors": errors, "warnings": warnings,
            "keys": sorted(config), "key_count": len(config)}


# ---------------------------------------------------------------------- commands


def cmd_init(args):
    schema = load_json(args.schema)
    defaults = find_defaults(args)
    config = build_base(schema, defaults)
    write_json(args.out, config)
    record(args, args.out, "init",
           {"schema": str(args.schema), "out": str(args.out), "keys": sorted(config)})
    print("wrote %s with %d keys" % (args.out, len(config)))


def cmd_set(args):
    config = load_json(args.config)
    if isinstance(config, dict) is False:
        raise SystemExit("config must be a JSON object")
    value = coerce(args.value, args.type)
    before = config.get(args.key)
    config[args.key] = value
    write_json(args.config, {k: config[k] for k in sorted(config)})
    record(args, args.config, "set",
           {"config": str(args.config), "key": args.key, "from": before, "to": value})
    print("%s = %s" % (args.key, json.dumps(value)))


def cmd_derive(args):
    schema = load_json(args.schema)
    defaults = find_defaults(args)
    config = load_json(args.base) if args.base else build_base(schema, defaults)

    profile_doc = load_json(args.profile_input)
    name = args.profile or profile_doc.get("profile")
    if not name:
        raise SystemExit("no profile name given and none present in the profile document")

    steps = []
    if args.overrides:
        overrides = load_json(args.overrides)
        if name not in overrides:
            raise SystemExit("no environment overrides for profile: " + name)
        steps.append({"source": str(args.overrides),
                      "applied": apply_overlay(config, overrides[name])})

    overlay = {k: v for k, v in profile_doc.items() if k != "profile"}
    steps.append({"source": str(args.profile_input), "applied": apply_overlay(config, overlay)})

    config["profile"] = name
    config = {k: config[k] for k in sorted(config)}
    write_json(args.out, config)
    record(args, args.out, "derive-profile",
           {"profile": name, "out": str(args.out), "steps": steps})
    print("derived profile %s -> %s" % (name, args.out))


def cmd_validate(args):
    schema = load_json(args.schema)
    rules = load_json(args.rules) if args.rules else {}
    config = load_json(args.config)
    result = validate_config(config, schema, rules)
    result["config"] = str(args.config)
    if args.json_out:
        write_json(args.json_out, result)
    record(args, args.config, "validate",
           {"config": str(args.config), "ok": result["ok"],
            "errors": result["errors"], "warnings": result["warnings"]})
    for warning in result["warnings"]:
        print("warning: " + warning)
    if not result["ok"]:
        for error in result["errors"]:
            print("error: " + error, file=sys.stderr)
        raise SystemExit("invalid: " + args.config)
    print("ok")


def cmd_validate_many(args):
    schema = load_json(args.schema)
    rules = load_json(args.rules) if args.rules else {}
    results = []
    for path in args.config:
        result = validate_config(load_json(path), schema, rules)
        result["config"] = str(path)
        results.append(result)

    artifacts = []
    if args.artifact_dir and rules.get("required_artifacts"):
        limit = rules.get("max_artifact_bytes")
        for name in rules["required_artifacts"]:
            path = Path(args.artifact_dir) / name
            exists = path.is_file()
            size = path.stat().st_size if exists else 0
            entry = {"artifact": name, "present": exists, "bytes": size}
            if limit is not None:
                entry["within_size_limit"] = exists and size <= limit
            artifacts.append(entry)

    report = {
        "tool": "task-ctl",
        "schema": str(args.schema),
        "rules": str(args.rules) if args.rules else None,
        "configs_checked": len(results),
        "all_valid": all(r["ok"] for r in results),
        "results": results,
        "artifacts": artifacts,
    }
    write_json(args.out, report)
    record(args, args.out, "validate-many",
           {"out": str(args.out), "configs": [str(p) for p in args.config],
            "all_valid": report["all_valid"]})
    print("validated %d config(s): %s" % (len(results), "ok" if report["all_valid"] else "FAILED"))
    if not report["all_valid"]:
        raise SystemExit(1)


def cmd_report(args):
    config = load_json(args.config)
    entries = []
    path = journal_path(args, args.config)
    if path.is_file():
        try:
            loaded = load_json(path)
            if isinstance(loaded, list):
                entries = loaded
        except ValueError:
            entries = []

    report = {
        "tool": "task-ctl",
        "ok": True,
        "config_path": str(args.config),
        "config": config,
        "repairs": REPAIRS,
        "repair_count": len(REPAIRS),
        "commands": [
            {"step": i + 1, "command": e.get("command"), "argv": e.get("argv", []),
             "detail": e.get("detail")}
            for i, e in enumerate(entries)
        ],
        "command_count": len(entries),
    }
    write_json(args.out, report)
    print("wrote %s (%d commands, %d repairs)" % (args.out, len(entries), len(REPAIRS)))


# ------------------------------------------------------------------------- main


def main(argv=None):
    parser = argparse.ArgumentParser(prog="task-ctl", description=__doc__)
    # The subcommand is required; without this the parser produced a Namespace
    # with no .func and crashed instead of printing usage.
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("init", help="create a flat config from a schema and defaults")
    p.add_argument("--schema", required=True)
    p.add_argument("--defaults", help="defaults document; auto-discovered next to --schema")
    p.add_argument("--out", required=True)
    p.add_argument("--journal")
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set", help="set one scalar key in a config")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.add_argument("--type", choices=["str", "int", "float", "bool"])
    p.add_argument("--journal")
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("derive-profile", help="apply environment overrides and deltas")
    p.add_argument("--schema", required=True)
    p.add_argument("--defaults")
    p.add_argument("--base", help="existing base config; built from schema+defaults if omitted")
    p.add_argument("--overrides", help="env_overrides document")
    p.add_argument("--profile-input", required=True, help="sample profile document")
    p.add_argument("--profile", help="profile name; taken from the profile document if omitted")
    p.add_argument("--out", required=True)
    p.add_argument("--journal")
    p.set_defaults(func=cmd_derive)

    p = sub.add_parser("validate", help="validate one config against schema and rules")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--rules")
    p.add_argument("--json-out", dest="json_out")
    p.add_argument("--journal")
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("validate-many", help="validate several configs into one report")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True, action="append")
    p.add_argument("--rules")
    p.add_argument("--artifact-dir")
    p.add_argument("--out", required=True)
    p.add_argument("--journal")
    p.set_defaults(func=cmd_validate_many)

    p = sub.add_parser("export-report", help="write the run transcript and repair notes")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--journal")
    p.set_defaults(func=cmd_report)

    args = parser.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()
