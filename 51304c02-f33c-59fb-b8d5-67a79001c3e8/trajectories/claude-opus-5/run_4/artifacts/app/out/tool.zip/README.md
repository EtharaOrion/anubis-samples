# task-ctl

A local, standard-library-only CLI that creates, updates, validates and reports a
**flat** JSON configuration for TASK processing. The archive as shipped was broken
in several places; this copy is repaired. Every fault and its fix is listed in
`REPAIRS` inside `cli.py` and is reproduced in the output of `export-report`.

## Contract

A valid configuration is a single flat JSON object. Every value is a scalar
(string, number or boolean) — no nested objects or arrays. It carries exactly the
keys named by `required_keys` in the schema:

    profile, producer, container, max_records, retry_limit, timeout_ms,
    checksum, mode, trailer

and none of the `forbidden_keys` from the validation rules
(`timestamp`, `generated_at`, `uuid`, `random_seed`). Output is deterministic:
the tool never writes a clock reading or a random value.

## Commands

```bash
# base configuration: schema identity fields + defaults (defaults.json is
# auto-discovered next to --schema, or pass --defaults explicitly)
python3 cli.py init --schema schema.json --out config.json

# update a single key; the value is coerced to its JSON scalar type
python3 cli.py set --config config.json --key max_records --value 100

# per-environment configuration: env overrides then the profile document,
# where a "<key>_delta" entry adds to "<key>" and any other scalar replaces it
python3 cli.py derive-profile --schema schema.json --defaults defaults.json \
    --overrides env_overrides.json --profile-input sample_config_dev.json \
    --out profile_dev.json

# validate one config (add --rules for forbidden-key checks, --json-out for a
# machine readable result)
python3 cli.py validate --schema schema.json --config config.json \
    --rules validation_rules.json

# validate several configs and audit the artifact directory in one report
python3 cli.py validate-many --schema schema.json --rules validation_rules.json \
    --config config.json --config profile_dev.json \
    --artifact-dir out --out validation_report.json

# transcript of every command run plus the repair notes
python3 cli.py export-report --config config.json --out report.json
```

Each mutating command appends its argv to a journal
(`.task-ctl-journal.json` beside the file it writes, or `--journal PATH`), which
is what makes `export-report` a real transcript rather than a placeholder.
