# task-ctl

A local, standard-library-only CLI that creates, updates, validates and reports
a **flat** JSON configuration for TASK processing. Every output is
deterministic: no clock, no randomness, no network.

## Configuration contract

* The configuration is a flat object of scalars only (no nested objects/arrays).
* It must carry every key in the schema's `required_keys`:
  `profile, producer, container, max_records, retry_limit, timeout_ms,
  checksum, mode, trailer`.
* `checksum` must equal the algorithm named by the schema (`crc32`).
* Keys named in the rules file's `forbidden_keys` (`timestamp`, `generated_at`,
  `uuid`, `random_seed`) must never appear — they would make output
  non-reproducible.
* Environment profiles must use a profile name from the rules file
  (`dev`, `prod`); the base configuration keeps the schema's profile name.
* `<key>_delta` inputs are *inputs*, not configuration: they are numeric offsets
  applied to `<key>` and must not survive into a generated configuration.

## Commands

```bash
# 1. Build the base configuration from the schema + defaults.
python3 cli.py init --schema schema.json --defaults defaults.json \
    --out config.json --log run_log.json

# 2. Adjust a single scalar (type is inferred: 100 -> int, "x" -> str).
python3 cli.py set --config config.json --key max_records --value 100

# 3. Derive an environment profile from a profile input + override layers.
python3 cli.py apply-profile --config config.json --schema schema.json \
    --profile-config sample_config_dev.json --overrides env_overrides.json \
    --out profile_dev.json

# 4. Validate one artifact (--profile-kind env for derived profiles).
python3 cli.py validate --schema schema.json --config config.json \
    --rules validation_rules.json --profile-kind main

# 5. Validate every artifact at once and write a machine-readable report.
python3 cli.py validate-all --schema schema.json --rules validation_rules.json \
    --config config.json:main --config profile_dev.json:env \
    --artifact-dir out --out validation_report.json

# 6. Export a run report (config + command transcript from --log).
python3 cli.py export-report --config config.json --log run_log.json \
    --out report.json

# 7. Summarise the produced artifacts.
python3 cli.py summarize --artifact config.json --out summary.json
```

`--log FILE` is accepted by every command and appends a transcript entry that
`export-report` turns into the `commands` list.
