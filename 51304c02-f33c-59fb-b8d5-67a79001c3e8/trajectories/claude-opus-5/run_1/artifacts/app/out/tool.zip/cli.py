#!/usr/bin/env python3
"""task-ctl -- create, update, validate and report a flat JSON configuration.

Standard library only. No network access, no wall-clock or random values, so
every artifact it writes is byte-for-byte reproducible.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

DELTA_SUFFIX = "_delta"
META_KEYS = ("required_keys", "scalar_only", "profiles", "forbidden_keys")


def load_json(path):
    return json.loads(Path(path).read_text())


def write_json(path, data):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(data, indent=2, sort_keys=False) + "\n")


def is_scalar(value):
    return value is None or isinstance(value, (str, int, float, bool))


def required_keys(schema):
    """Accept both the list form and the legacy comma-separated string form."""
    keys = schema.get("required_keys", [])
    if isinstance(keys, str):
        keys = [part.strip() for part in keys.split(",") if part.strip()]
    return list(keys)


def order_keys(data, schema):
    """Emit required keys in schema order first, then any remaining keys."""
    ordered = {}
    for key in required_keys(schema):
        if key in data:
            ordered[key] = data[key]
    for key in data:
        if key not in ordered:
            ordered[key] = data[key]
    return ordered


def coerce_scalar(text):
    """Turn a command-line string into the scalar it denotes."""
    try:
        value = json.loads(text)
    except (TypeError, ValueError):
        return text
    if not is_scalar(value):
        raise SystemExit("value must be a scalar, got: " + type(value).__name__)
    return value


def log_run(args, detail):
    if not getattr(args, "log", None):
        return
    path = Path(args.log)
    entries = load_json(path) if path.exists() else []
    entry = {"command": args.command, "status": "ok"}
    entry.update(detail)
    entries.append(entry)
    write_json(path, entries)


def cmd_init(args):
    schema = load_json(args.schema)
    wanted = required_keys(schema)
    data = {}
    sources = [(schema, args.schema)]
    if args.defaults:
        defaults = load_json(args.defaults)
        sources.append((defaults, args.defaults))
        base = defaults.get("base_config", {})
        if not isinstance(base, dict):
            raise SystemExit("base_config must be an object")
        sources.append((base, args.defaults + "#base_config"))
    for source, _name in sources:
        for key, value in source.items():
            if key in META_KEYS or key == "base_config":
                continue
            if key not in wanted:
                continue
            if not is_scalar(value):
                raise SystemExit("non-scalar value for key: " + key)
            data[key] = value
    data = order_keys(data, schema)
    write_json(args.out, data)
    log_run(args, {"schema": args.schema, "defaults": args.defaults,
                   "out": args.out, "keys": len(data)})
    print("init: wrote {} keys to {}".format(len(data), args.out))


def cmd_set(args):
    data = load_json(args.config)
    key = args.key
    if key.endswith(DELTA_SUFFIX):
        raise SystemExit("delta keys belong to profile inputs, not the config")
    data[key] = coerce_scalar(args.value)
    write_json(args.config, data)
    log_run(args, {"config": args.config, "key": key, "value": data[key]})
    print("set: {}={}".format(key, json.dumps(data[key])))


def apply_layer(data, layer, origin):
    """Merge one override layer: `x_delta` adds to x, plain keys replace."""
    applied = []
    for key, value in layer.items():
        if key.endswith(DELTA_SUFFIX):
            target = key[: -len(DELTA_SUFFIX)]
            if target not in data:
                raise SystemExit("delta for unknown key: " + target)
            if not isinstance(data[target], (int, float)) or isinstance(data[target], bool):
                raise SystemExit("delta applied to non-numeric key: " + target)
            if not isinstance(value, (int, float)) or isinstance(value, bool):
                raise SystemExit("delta value is not numeric: " + key)
            data[target] = data[target] + value
            applied.append({"key": target, "op": "delta", "delta": value,
                            "result": data[target], "from": origin})
        else:
            if not is_scalar(value):
                raise SystemExit("non-scalar override for key: " + key)
            data[key] = value
            applied.append({"key": key, "op": "set", "result": value, "from": origin})
    return applied


def cmd_apply_profile(args):
    schema = load_json(args.schema) if args.schema else {}
    data = load_json(args.config)
    applied = []

    profile_input = {}
    if args.profile_config:
        profile_input = load_json(args.profile_config)
        applied += apply_layer(data, profile_input, Path(args.profile_config).name)

    name = args.profile or profile_input.get("profile") or data.get("profile")
    if not name:
        raise SystemExit("no profile name given or discoverable")

    if args.overrides:
        overrides = load_json(args.overrides)
        if name not in overrides:
            raise SystemExit("no override section for profile: " + name)
        applied += apply_layer(data, overrides[name], Path(args.overrides).name + "#" + name)

    data["profile"] = name
    data = order_keys(data, schema) if schema else data
    write_json(args.out, data)
    log_run(args, {"config": args.config, "profile": name,
                   "profile_config": args.profile_config,
                   "overrides": args.overrides, "out": args.out,
                   "applied": len(applied)})
    print("apply-profile: {} -> {} ({} changes)".format(name, args.out, len(applied)))
    return applied


def validate_config(schema, rules, data, path, profile_kind):
    checks = []
    errors = []

    wanted = required_keys(schema)
    missing = [key for key in wanted if key not in data]
    checks.append({"check": "required_keys", "expected": wanted,
                   "missing": missing, "passed": not missing})
    if missing:
        errors.append("missing keys: " + ", ".join(missing))

    if schema.get("scalar_only", True):
        nested = sorted(k for k, v in data.items() if not is_scalar(v))
        checks.append({"check": "scalar_only", "nested_keys": nested,
                       "passed": not nested})
        if nested:
            errors.append("configuration must be flat; nested keys: " + ", ".join(nested))

    forbidden = list(rules.get("forbidden_keys", []))
    present = sorted(k for k in data if k in forbidden)
    checks.append({"check": "forbidden_keys", "forbidden": forbidden,
                   "present": present, "passed": not present})
    if present:
        errors.append("forbidden keys present: " + ", ".join(present))

    stray = sorted(k for k in data if k.endswith(DELTA_SUFFIX))
    checks.append({"check": "no_unresolved_deltas", "present": stray,
                   "passed": not stray})
    if stray:
        errors.append("unresolved delta keys: " + ", ".join(stray))

    if "checksum" in schema and "checksum" in data:
        ok = data["checksum"] == schema["checksum"]
        checks.append({"check": "checksum_algorithm", "expected": schema["checksum"],
                       "actual": data.get("checksum"), "passed": ok})
        if not ok:
            errors.append("checksum must be " + str(schema["checksum"]))

    allowed = list(rules.get("profiles", []))
    if profile_kind == "env" and allowed:
        ok = data.get("profile") in allowed
        checks.append({"check": "profile_allowed", "allowed": allowed,
                       "actual": data.get("profile"), "passed": ok})
        if not ok:
            errors.append("profile must be one of: " + ", ".join(allowed))
    elif profile_kind == "main":
        ok = data.get("profile") == schema.get("profile", data.get("profile"))
        checks.append({"check": "profile_matches_schema",
                       "expected": schema.get("profile"),
                       "actual": data.get("profile"), "passed": ok})
        if not ok:
            errors.append("profile must be " + str(schema.get("profile")))

    limit = rules.get("max_artifact_bytes")
    if limit is not None and path is not None:
        size = Path(path).stat().st_size
        checks.append({"check": "max_artifact_bytes", "limit": limit,
                       "bytes": size, "passed": size <= limit})
        if size > limit:
            errors.append("artifact exceeds max_artifact_bytes")

    return {"artifact": Path(path).name if path else None,
            "profile": data.get("profile"),
            "profile_kind": profile_kind,
            "key_count": len(data),
            "checks": checks,
            "errors": errors,
            "valid": not errors}


def cmd_validate(args):
    schema = load_json(args.schema)
    rules = load_json(args.rules) if args.rules else {}
    result = validate_config(schema, rules, load_json(args.config), args.config,
                             args.profile_kind)
    if args.out:
        write_json(args.out, result)
    log_run(args, {"schema": args.schema, "config": args.config,
                   "rules": args.rules, "profile_kind": args.profile_kind,
                   "valid": result["valid"]})
    if not result["valid"]:
        for message in result["errors"]:
            print("error: " + message, file=sys.stderr)
        raise SystemExit(1)
    print("ok")
    return result


def cmd_validate_all(args):
    schema = load_json(args.schema)
    rules = load_json(args.rules) if args.rules else {}
    results = []
    for spec in args.config:
        if ":" in spec:
            path, kind = spec.rsplit(":", 1)
        else:
            path, kind = spec, "main"
        results.append(validate_config(schema, rules, load_json(path), path, kind))

    required = list(rules.get("required_artifacts", []))
    seen = {r["artifact"] for r in results}
    if args.artifact_dir:
        seen |= {p.name for p in Path(args.artifact_dir).iterdir() if p.is_file()}
    if args.out:
        # This report is written by this very command, so it counts as present.
        seen.add(Path(args.out).name)
    missing_artifacts = [name for name in required if name not in seen]

    report = {
        "schema": Path(args.schema).name,
        "rules": Path(args.rules).name if args.rules else None,
        "results": results,
        "required_artifacts": required,
        "missing_artifacts": missing_artifacts,
        "artifacts_checked": len(results),
        "all_valid": all(r["valid"] for r in results) and not missing_artifacts,
    }
    if args.out:
        write_json(args.out, report)
    log_run(args, {"configs": list(args.config), "out": args.out,
                   "all_valid": report["all_valid"]})
    for result in results:
        print("{}: {}".format(result["artifact"], "ok" if result["valid"] else "FAILED"))
        for message in result["errors"]:
            print("  error: " + message, file=sys.stderr)
    if not report["all_valid"]:
        raise SystemExit(1)
    return report


def cmd_report(args):
    data = load_json(args.config)
    transcript = load_json(args.log) if args.log and Path(args.log).exists() else []
    report = {
        "tool": "task-ctl",
        "ok": True,
        "config": data,
        "config_key_count": len(data),
        "commands": [
            {"command": entry.get("command"),
             "status": entry.get("status"),
             "detail": {k: v for k, v in entry.items()
                        if k not in ("command", "status")}}
            for entry in transcript
        ],
        "command_count": len(transcript),
    }
    if args.notes:
        notes = load_json(args.notes)
        if not isinstance(notes, dict):
            raise SystemExit("--notes must contain a JSON object")
        report.update(notes)
    write_json(args.out, report)
    print("export-report: {} commands -> {}".format(len(transcript), args.out))


def cmd_summarize(args):
    summary = {"tool": "task-ctl", "artifacts": [], "inputs": []}
    out_path = Path(args.out).resolve()
    for spec in args.artifact:
        path = Path(spec)
        # A summary cannot record its own final size, and listing a stale one
        # would make the artifact non-reproducible; report it as self instead.
        itself = path.resolve() == out_path
        exists = itself or path.is_file()
        summary["artifacts"].append({
            "name": path.name,
            "path": str(path),
            "bytes": None if itself else (path.stat().st_size if exists else None),
            "exists": exists,
            "self": itself,
        })
    summary["artifact_count"] = len(summary["artifacts"])
    summary["missing_artifacts"] = sorted(
        a["name"] for a in summary["artifacts"] if not a["exists"]
    )
    for spec in args.input:
        path = Path(spec)
        summary["inputs"].append({"name": path.name, "bytes": path.stat().st_size})
    if args.merge:
        extra = load_json(args.merge)
        if not isinstance(extra, dict):
            raise SystemExit("--merge must contain a JSON object")
        summary.update(extra)
    write_json(args.out, summary)
    print("summarize: {} artifacts -> {}".format(len(summary["artifacts"]), args.out))


def build_parser():
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--log", help="append a transcript entry to this JSON file")

    parser = argparse.ArgumentParser(prog="task-ctl")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("init", parents=[common])
    p.add_argument("--schema", required=True)
    p.add_argument("--defaults")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set", parents=[common])
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("apply-profile", parents=[common])
    p.add_argument("--config", required=True)
    p.add_argument("--profile")
    p.add_argument("--profile-config")
    p.add_argument("--overrides")
    p.add_argument("--schema")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_apply_profile)

    p = sub.add_parser("validate", parents=[common])
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--rules")
    p.add_argument("--profile-kind", choices=["main", "env"], default="main")
    p.add_argument("--out")
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("validate-all", parents=[common])
    p.add_argument("--schema", required=True)
    p.add_argument("--config", action="append", required=True,
                   help="PATH[:main|env], repeatable")
    p.add_argument("--rules")
    p.add_argument("--artifact-dir")
    p.add_argument("--out")
    p.set_defaults(func=cmd_validate_all)

    p = sub.add_parser("export-report", parents=[common])
    p.add_argument("--config", required=True)
    p.add_argument("--notes")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_report)

    p = sub.add_parser("summarize", parents=[common])
    p.add_argument("--artifact", action="append", default=[])
    p.add_argument("--input", action="append", default=[])
    p.add_argument("--merge")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_summarize)

    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()
