# task-ctl

A local, stdlib-only CLI that creates, updates, validates and reports a flat
JSON configuration for TASK processing. Every command is a pure function of its
input files — no clock, no randomness, no network — so runs are reproducible.

## Commands

```bash
# create a flat configuration from the schema (optionally seeded from defaults)
python3 cli.py init --schema schema.json --out config.json
python3 cli.py init --schema schema.json --defaults defaults.json --out config.json

# set one scalar key (values are coerced: 100 -> int, true -> bool, text stays text)
python3 cli.py set --config config.json --key max_records --value 100

# validate one or more configurations, optionally against validation_rules.json
python3 cli.py validate --schema schema.json --config config.json
python3 cli.py validate --schema schema.json --rules validation_rules.json \
    --config config.json --config profile_dev.json --report-out validation_report.json

# build an environment profile by applying *_delta patches to the defaults
python3 cli.py derive-profile --schema schema.json --defaults defaults.json \
    --profile-config sample_config_dev.json --overrides env_overrides.json \
    --env dev --out profile_dev.json

# write a report of the configuration and the commands that produced it
python3 cli.py export-report --config config.json --out report.json --journal journal.json

# repackage the tool, and summarize the produced artifacts against the rules
python3 cli.py package --source . --out tool.zip
python3 cli.py summarize --dir out --rules validation_rules.json --out summary.json
```

Pass `--journal <path>` to any command to append it to a transcript that
`export-report` and `summarize` embed as the command list.

## Contract

A valid configuration is **flat** (scalars only) and carries every key in the
schema's `required_keys`. `validate` additionally rejects the `forbidden_keys`
from the validation rules and checks the profile and checksum algorithm.

## Repairs

The shipped version was broken; see `/app/out/report.json` (`repair` section)
for the list of faults that were found and fixed.
