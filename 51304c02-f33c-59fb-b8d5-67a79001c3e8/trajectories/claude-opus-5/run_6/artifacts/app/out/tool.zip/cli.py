#!/usr/bin/env python3
"""task-ctl: create, update, validate and report a flat JSON configuration.

Stdlib only. No network access, no clocks, no randomness: every command is a
pure function of the files it is given, so repeated runs are byte-identical.
"""
from __future__ import annotations

import argparse
import json
import sys
import zipfile
from pathlib import Path

SCALARS = (str, int, float, bool, type(None))


def load_json(path):
    p = Path(path)
    if not p.is_file():
        raise SystemExit("error: no such file: %s" % path)
    try:
        return json.loads(p.read_text())
    except json.JSONDecodeError as exc:
        raise SystemExit("error: invalid JSON in %s: %s" % (path, exc))


def write_json(path, data):
    p = Path(path)
    if p.parent != Path(""):
        p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2) + "\n")


def required_keys(schema):
    """The contract states required_keys as a list; older schemas used a
    comma-separated string. Accept either."""
    keys = schema.get("required_keys", [])
    if isinstance(keys, str):
        keys = [k.strip() for k in keys.split(",") if k.strip()]
    return list(keys)


def coerce(value):
    """Turn a command-line string into the scalar it denotes.

    "3" -> 3, "1.5" -> 1.5, "true" -> True, "null" -> None, anything that is
    not a JSON scalar literal (e.g. "strict-local") stays a string.
    """
    try:
        parsed = json.loads(value)
    except (json.JSONDecodeError, ValueError):
        return value
    if isinstance(parsed, bool) or isinstance(parsed, SCALARS):
        return parsed
    return value


def ordered(data, schema=None):
    """Emit required keys first, in contract order, then any extras."""
    order = required_keys(schema) if schema else []
    out = {k: data[k] for k in order if k in data}
    for k in data:
        if k not in out:
            out[k] = data[k]
    return out


def journal_append(args, entry):
    if not getattr(args, "journal", None):
        return
    path = Path(args.journal)
    entries = []
    if path.is_file():
        entries = json.loads(path.read_text()).get("commands", [])
    entries.append(entry)
    write_json(path, {"commands": entries})


def cmd_init(args):
    schema = load_json(args.schema)
    data = {
        "profile": schema.get("profile", ""),
        "producer": schema.get("producer", ""),
        "container": schema.get("container", ""),
        "checksum": schema.get("checksum", ""),
    }
    seeded = []
    if args.defaults:
        defaults = load_json(args.defaults)
        for key, value in defaults.items():
            if key == "base_config":
                continue
            if isinstance(value, SCALARS):
                data.setdefault(key, value)
                if key not in ("profile", "producer", "container", "checksum"):
                    seeded.append(key)
        for key, value in defaults.get("base_config", {}).items():
            data[key] = value
            seeded.append(key)
    data = ordered(data, schema)
    write_json(args.out, data)
    journal_append(args, {
        "command": "init",
        "schema": args.schema,
        "defaults": args.defaults,
        "out": args.out,
        "keys": list(data),
        "seeded_from_defaults": seeded,
    })
    print("init: wrote %s with %d key(s)" % (args.out, len(data)))


def cmd_set(args):
    data = load_json(args.config)
    if not isinstance(data, dict):
        raise SystemExit("error: %s is not a JSON object" % args.config)
    key = args.key
    value = coerce(args.value)
    if not isinstance(value, SCALARS):
        raise SystemExit("error: value for %s must be a scalar" % key)
    previous = data.get(key)
    data[key] = value
    write_json(args.config, data)
    journal_append(args, {
        "command": "set",
        "config": args.config,
        "key": key,
        "value": value,
        "previous": previous,
    })
    print("set: %s = %s" % (key, json.dumps(value)))


def check(schema, data, rules=None):
    """Return (errors, checks) for one configuration."""
    errors = []
    checks = []

    missing = [k for k in required_keys(schema) if k not in data]
    checks.append({"check": "required_keys", "ok": not missing, "missing": missing})
    if missing:
        errors.append("missing required key(s): " + ", ".join(missing))

    nested = sorted(k for k, v in data.items() if not isinstance(v, SCALARS))
    flat_ok = not nested
    checks.append({"check": "scalar_only", "ok": flat_ok, "nested_keys": nested})
    if nested:
        errors.append("configuration must be flat; nested key(s): " + ", ".join(nested))

    if schema.get("checksum"):
        ok = data.get("checksum") == schema["checksum"]
        checks.append({"check": "checksum_algorithm", "ok": ok,
                       "expected": schema["checksum"], "actual": data.get("checksum")})
        if not ok:
            errors.append("checksum must be %r" % schema["checksum"])

    if rules:
        found = sorted(k for k in rules.get("forbidden_keys", []) if k in data)
        checks.append({"check": "forbidden_keys", "ok": not found, "found": found})
        if found:
            errors.append("forbidden key(s) present: " + ", ".join(found))

        allowed = list(rules.get("profiles", []))
        if schema.get("profile") and schema["profile"] not in allowed:
            allowed.append(schema["profile"])
        if allowed:
            ok = data.get("profile") in allowed
            checks.append({"check": "profile_allowed", "ok": ok,
                           "allowed": allowed, "actual": data.get("profile")})
            if not ok:
                errors.append("profile %r not in %s" % (data.get("profile"), allowed))

    return errors, checks


def cmd_validate(args):
    schema = load_json(args.schema)
    rules = load_json(args.rules) if args.rules else None
    results = []
    failed = 0
    for config in args.config:
        data = load_json(config)
        errors, checks = check(schema, data, rules)
        if errors:
            failed += 1
        results.append({"config": config, "ok": not errors,
                        "checks": checks, "errors": errors})
        if errors:
            for err in errors:
                print("FAIL %s: %s" % (config, err), file=sys.stderr)
        else:
            print("ok %s" % config)

    if args.report_out:
        write_json(args.report_out, {
            "tool": "task-ctl",
            "schema": args.schema,
            "rules": args.rules,
            "validated": len(results),
            "failed": failed,
            "ok": failed == 0,
            "results": results,
        })
    journal_append(args, {
        "command": "validate",
        "schema": args.schema,
        "rules": args.rules,
        "configs": list(args.config),
        "report_out": args.report_out,
        "ok": failed == 0,
    })
    if failed:
        raise SystemExit(1)


def apply_deltas(base, patch):
    """Apply a patch: `<key>_delta` adds to a numeric key, anything else sets."""
    applied = []
    for key, value in patch.items():
        if key.endswith("_delta"):
            target = key[: -len("_delta")]
            if target not in base:
                raise SystemExit("error: %s has no base value for %s" % (target, key))
            if not isinstance(base[target], (int, float)) or isinstance(base[target], bool):
                raise SystemExit("error: %s is not numeric; cannot apply %s" % (target, key))
            before = base[target]
            base[target] = before + value
            applied.append({"key": target, "op": "delta", "delta": value,
                            "from": before, "to": base[target]})
        else:
            if not isinstance(value, SCALARS):
                raise SystemExit("error: override %s must be a scalar" % key)
            before = base.get(key)
            base[key] = value
            applied.append({"key": key, "op": "set", "from": before, "to": value})
    return applied


def cmd_derive(args):
    schema = load_json(args.schema)
    defaults = load_json(args.defaults)

    base = {
        "profile": schema.get("profile", ""),
        "producer": schema.get("producer", ""),
        "container": schema.get("container", ""),
        "checksum": schema.get("checksum", ""),
    }
    for key, value in defaults.items():
        if key != "base_config" and isinstance(value, SCALARS):
            base[key] = value
    base.update(defaults.get("base_config", {}))

    steps = []
    if args.profile_config:
        patch = load_json(args.profile_config)
        steps.append({"source": args.profile_config, "applied": apply_deltas(base, patch)})
    if args.overrides:
        overrides = load_json(args.overrides)
        if args.env not in overrides:
            raise SystemExit("error: no overrides for env %r in %s" % (args.env, args.overrides))
        steps.append({"source": "%s[%s]" % (args.overrides, args.env),
                      "applied": apply_deltas(base, overrides[args.env])})
    if args.env:
        base["profile"] = args.env

    base = ordered(base, schema)
    write_json(args.out, base)
    journal_append(args, {
        "command": "derive-profile",
        "env": args.env,
        "schema": args.schema,
        "defaults": args.defaults,
        "profile_config": args.profile_config,
        "overrides": args.overrides,
        "out": args.out,
        "steps": steps,
    })
    print("derive-profile: wrote %s for env %s" % (args.out, args.env))


def cmd_report(args):
    data = load_json(args.config)
    commands = []
    if args.journal and Path(args.journal).is_file():
        commands = load_json(args.journal).get("commands", [])
    report = {
        "tool": "task-ctl",
        "ok": True,
        "config_path": args.config,
        "config": data,
        "config_keys": len(data),
        "commands": commands,
        "command_count": len(commands),
    }
    if args.repair_notes:
        report["repair"] = load_json(args.repair_notes)
    write_json(args.out, report)
    journal_append(args, {"command": "export-report", "config": args.config, "out": args.out})
    print("export-report: wrote %s (%d command(s))" % (args.out, len(commands)))


def cmd_package(args):
    src = Path(args.source)
    files = sorted(p for p in src.rglob("*") if p.is_file())
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    # Fixed timestamps keep the archive byte-identical across runs.
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in files:
            info = zipfile.ZipInfo(str(path.relative_to(src)), date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            zf.writestr(info, path.read_bytes())
    journal_append(args, {"command": "package", "source": args.source, "out": args.out,
                          "files": [str(p.relative_to(src)) for p in files]})
    print("package: wrote %s with %d file(s)" % (args.out, len(files)))


def cmd_summarize(args):
    rules = load_json(args.rules)
    out_path = Path(args.out)
    directory = Path(args.dir)
    limit = rules.get("max_artifact_bytes")

    validation = None
    vpath = directory / "validation_report.json"
    if vpath.is_file():
        report = json.loads(vpath.read_text())
        validation = {"validated": report.get("validated"),
                      "failed": report.get("failed"),
                      "ok": report.get("ok")}

    commands = []
    if args.journal and Path(args.journal).is_file():
        commands = [c["command"] for c in load_json(args.journal).get("commands", [])]

    def build(self_size):
        """Assemble the summary. `self_size` is the size the summary itself will
        have once written; it is solved for by the fixed-point loop below."""
        artifacts, missing, oversize = [], [], []
        for name in rules.get("required_artifacts", []):
            path = directory / name
            # The summary is written by this command, so it counts as present.
            pending = path.resolve() == out_path.resolve()
            present = path.is_file() or pending
            size = path.stat().st_size if path.is_file() and not pending else None
            if pending:
                size = self_size
            entry = {"artifact": name, "present": present, "bytes": size}
            if pending:
                entry["written_by_this_command"] = True
            if limit is not None and size is not None:
                entry["within_size_limit"] = size <= limit
                if size > limit:
                    oversize.append(name)
            if not present:
                missing.append(name)
            artifacts.append(entry)
        ok = not missing and not oversize and (validation is None or validation.get("ok"))
        return {
            "tool": "task-ctl",
            "ok": bool(ok),
            "artifact_dir": str(directory),
            "artifacts": artifacts,
            "missing_artifacts": missing,
            "oversize_artifacts": oversize,
            "max_artifact_bytes": limit,
            "validation": validation,
            "commands_run": commands,
            "command_count": len(commands),
        }

    # The summary reports its own byte size, so iterate until the reported size
    # equals the size of the rendered document (converges in a few passes).
    size, text = None, ""
    for _ in range(8):
        text = json.dumps(build(size), indent=2) + "\n"
        actual = len(text.encode())
        if actual == size:
            break
        size = actual
    summary = build(size)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(text)
    print("summarize: wrote %s (ok=%s)" % (args.out, summary["ok"]))


def main():
    parser = argparse.ArgumentParser(prog="task-ctl")
    sub = parser.add_subparsers(dest="command", required=True)

    def add_journal(p):
        p.add_argument("--journal", help="append this command to a JSON transcript")

    p = sub.add_parser("init", help="create a flat configuration from the schema")
    p.add_argument("--schema", required=True)
    p.add_argument("--defaults", help="optional defaults.json to seed base values")
    p.add_argument("--out", required=True)
    add_journal(p)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set", help="set one scalar key in a configuration")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    add_journal(p)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate", help="validate one or more configurations")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True, action="append",
                   help="repeat to validate several configurations")
    p.add_argument("--rules", help="optional validation_rules.json")
    p.add_argument("--report-out", dest="report_out", help="write a JSON validation report")
    add_journal(p)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("derive-profile", help="build an environment profile from deltas")
    p.add_argument("--schema", required=True)
    p.add_argument("--defaults", required=True)
    p.add_argument("--profile-config", dest="profile_config")
    p.add_argument("--overrides")
    p.add_argument("--env", required=True)
    p.add_argument("--out", required=True)
    add_journal(p)
    p.set_defaults(func=cmd_derive)

    p = sub.add_parser("export-report", help="write a report of the config and the run")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--journal", help="transcript to embed as the command list")
    p.add_argument("--repair-notes", dest="repair_notes")
    p.set_defaults(func=cmd_report)

    p = sub.add_parser("package", help="repackage the tool as a zip archive")
    p.add_argument("--source", required=True)
    p.add_argument("--out", required=True)
    add_journal(p)
    p.set_defaults(func=cmd_package)

    p = sub.add_parser("summarize", help="summarize the produced artifacts")
    p.add_argument("--dir", required=True)
    p.add_argument("--rules", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--journal")
    p.set_defaults(func=cmd_summarize)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
