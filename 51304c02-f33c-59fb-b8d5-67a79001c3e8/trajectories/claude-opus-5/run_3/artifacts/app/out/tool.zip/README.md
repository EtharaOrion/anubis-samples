# task-ctl

A local, standard-library-only CLI that creates, updates, derives, validates and
reports a **flat** JSON configuration. Every value in a configuration must be a
scalar (string, number, boolean or null); nested objects and arrays are rejected.

The tool never contacts the network and never writes non-deterministic values
(timestamps, uuids, random seeds) into an artifact, so repeated runs with the
same inputs produce byte-identical output.

## Commands

```bash
# create a configuration from the schema, optionally seeded from a defaults file
python3 cli.py init --schema schema.json --defaults defaults.json --out config.json

# set a single key; the value is coerced to the scalar it denotes (145 -> int)
python3 cli.py set --config config.json --key max_records --value 100

# derive a per-environment profile: <key>_delta entries are applied as arithmetic
# against the base configuration, plain keys are assigned directly
python3 cli.py derive --config config.json --profile dev \
    --overrides env_overrides.json --spec sample_config_dev.json --out profile_dev.json

# validate one or more configurations; --rules adds the forbidden-key check
python3 cli.py validate --schema schema.json --config config.json \
    [--config profile_dev.json] [--rules validation_rules.json] [--report validation_report.json]

# write a run report (includes the transcript of commands, if one was kept)
python3 cli.py export-report --config config.json --out report.json [--notes notes.json]

# check the produced artifacts against the validation rules
python3 cli.py summarize --rules validation_rules.json --artifacts-dir out --out summary.json
```

Every subcommand accepts `--transcript PATH`. When given, the invocation is
appended to that JSON file, and `export-report` embeds the recorded commands so
a report shows exactly how its configuration was produced.

## Schema

`required_keys` may be given either as a JSON list or as a comma-separated
string. `scalar_only` (default true) enables the flatness check.
