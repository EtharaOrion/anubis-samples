#!/usr/bin/env python3
"""task-ctl: create, update, validate and report a flat JSON configuration.

Standard library only. No network access, no timestamps or other
non-deterministic values are ever written into an artifact.
"""
from __future__ import annotations

import argparse
import json
import sys
import zlib
from pathlib import Path

SCALAR_TYPES = (str, int, float, bool, type(None))
DELTA_SUFFIX = "_delta"


def load_json(path):
    return json.loads(Path(path).read_text())


def write_json(path, data):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")


def required_keys(schema):
    """The schema ships ``required_keys`` either as a list or as a CSV string."""
    keys = schema.get("required_keys", [])
    if isinstance(keys, str):
        keys = [key.strip() for key in keys.split(",") if key.strip()]
    return list(keys)


def coerce_scalar(raw):
    """Turn a command-line string into the scalar it denotes."""
    try:
        value = json.loads(raw)
    except (TypeError, ValueError):
        return raw
    if isinstance(value, (dict, list)):
        raise SystemExit("value must be a scalar, not a container: " + raw)
    return value


def flatten_defaults(defaults):
    """Defaults are given as top level scalars plus a ``base_config`` group."""
    flat = {}
    for key, value in defaults.items():
        if isinstance(value, dict):
            flat.update(value)
        else:
            flat[key] = value
    return flat


def record(args, command, detail):
    """Append one entry to the run transcript, if a transcript was requested."""
    path = getattr(args, "transcript", None)
    if not path:
        return
    path = Path(path)
    entries = []
    if path.exists():
        entries = json.loads(path.read_text()).get("commands", [])
    entry = {"command": command}
    entry.update(detail)
    entries.append(entry)
    write_json(path, {"tool": "task-ctl", "commands": entries})


def transcript_commands(path):
    if not path or not Path(path).exists():
        return []
    return json.loads(Path(path).read_text()).get("commands", [])


def check_config(schema, data, rules=None):
    """Return the list of problems found in ``data``; empty means valid."""
    problems = []
    for key in required_keys(schema):
        if key not in data:
            problems.append({"rule": "required_keys", "detail": "missing key: " + key})
    if schema.get("scalar_only", True):
        for key, value in sorted(data.items()):
            if not isinstance(value, SCALAR_TYPES):
                problems.append(
                    {
                        "rule": "scalar_only",
                        "detail": "key %s holds a %s, configuration must be flat"
                        % (key, type(value).__name__),
                    }
                )
    for key in (rules or {}).get("forbidden_keys", []):
        if key in data:
            problems.append({"rule": "forbidden_keys", "detail": "forbidden key: " + key})
    return problems


def cmd_init(args):
    schema = load_json(args.schema)
    data = {
        "profile": schema["profile"],
        "producer": schema["producer"],
        "container": schema["container"],
        "checksum": schema["checksum"],
    }
    if args.defaults:
        for key, value in flatten_defaults(load_json(args.defaults)).items():
            data.setdefault(key, value)
    write_json(args.out, data)
    record(args, "init", {"schema": args.schema, "defaults": args.defaults, "out": args.out})
    print("wrote " + str(args.out))


def cmd_set(args):
    data = load_json(args.config)
    value = coerce_scalar(args.value)
    data[args.key] = value
    write_json(args.config, data)
    record(args, "set", {"config": args.config, "key": args.key, "value": value})
    print("%s=%s" % (args.key, json.dumps(value)))


def cmd_derive(args):
    """Build a profile configuration from the base config, env overrides and a spec."""
    data = load_json(args.config)
    layers = []
    if args.overrides:
        overrides = load_json(args.overrides)
        if args.profile not in overrides:
            raise SystemExit("no overrides for profile: " + args.profile)
        layers.append(overrides[args.profile])
    if args.spec:
        layers.append(load_json(args.spec))

    applied = []
    data["profile"] = args.profile
    for layer in layers:
        for key, value in layer.items():
            if key.endswith(DELTA_SUFFIX):
                target = key[: -len(DELTA_SUFFIX)]
                if target not in data:
                    raise SystemExit("delta for unknown key: " + target)
                if not isinstance(data[target], (int, float)) or isinstance(data[target], bool):
                    raise SystemExit("delta applied to non numeric key: " + target)
                data[target] = data[target] + value
                applied.append({"key": target, "delta": value, "result": data[target]})
            else:
                if not isinstance(value, SCALAR_TYPES):
                    raise SystemExit("override must be a scalar: " + key)
                data[key] = value
                applied.append({"key": key, "set": value})
    write_json(args.out, data)
    record(
        args,
        "derive",
        {
            "config": args.config,
            "profile": args.profile,
            "overrides": args.overrides,
            "spec": args.spec,
            "out": args.out,
            "applied": applied,
        },
    )
    print("wrote " + str(args.out))


def cmd_validate(args):
    schema = load_json(args.schema)
    rules = load_json(args.rules) if args.rules else None
    results = []
    for config in args.config:
        problems = check_config(schema, load_json(config), rules)
        results.append({"config": config, "valid": not problems, "problems": problems})
        print("%s: %s" % (config, "ok" if not problems else "FAILED"))
        for problem in problems:
            print("  %s: %s" % (problem["rule"], problem["detail"]), file=sys.stderr)
    ok = all(result["valid"] for result in results)
    report = {
        "tool": "task-ctl",
        "schema": args.schema,
        "rules": args.rules,
        "checks": ["required_keys", "scalar_only"] + (["forbidden_keys"] if rules else []),
        "results": results,
        "valid": ok,
    }
    if args.report:
        write_json(args.report, report)
    record(
        args,
        "validate",
        {
            "schema": args.schema,
            "configs": list(args.config),
            "report": args.report,
            "valid": ok,
        },
    )
    if not ok:
        raise SystemExit(1)


def cmd_report(args):
    data = load_json(args.config)
    report = {
        "tool": "task-ctl",
        "ok": True,
        "config_path": args.config,
        "config": data,
        "commands": transcript_commands(args.transcript),
    }
    if args.notes:
        report.update(load_json(args.notes))
    write_json(args.out, report)
    record(args, "export-report", {"config": args.config, "out": args.out})
    print("wrote " + str(args.out))


def cmd_summarize(args):
    rules = load_json(args.rules)
    root = Path(args.artifacts_dir)
    limit = rules.get("max_artifact_bytes")
    forbidden = set(rules.get("forbidden_keys", []))
    artifacts = []
    ok = True
    for name in rules.get("required_artifacts", []):
        path = root / name
        entry = {"name": name, "present": path.exists()}
        if args.out and path == Path(args.out):
            # This command is writing that artifact right now.
            entry.update({"present": True, "self": True})
            artifacts.append(entry)
            continue
        if not path.exists():
            ok = False
            artifacts.append(entry)
            continue
        blob = path.read_bytes()
        entry["bytes"] = len(blob)
        entry["crc32"] = format(zlib.crc32(blob) & 0xFFFFFFFF, "08x")
        entry["within_size_limit"] = limit is None or len(blob) <= limit
        if not entry["within_size_limit"]:
            ok = False
        if path.suffix == ".json":
            found = sorted(forbidden & set(_all_keys(json.loads(blob.decode()))))
            entry["forbidden_keys_found"] = found
            if found:
                ok = False
        artifacts.append(entry)
    summary = {
        "tool": "task-ctl",
        "artifacts_dir": str(root),
        "rules": args.rules,
        "artifacts": artifacts,
        "ok": ok,
    }
    if args.notes:
        summary.update(load_json(args.notes))
    write_json(args.out, summary)
    record(args, "summarize", {"artifacts_dir": str(root), "out": args.out, "ok": ok})
    print("wrote " + str(args.out))
    if not ok:
        raise SystemExit(1)


def _all_keys(node):
    if isinstance(node, dict):
        for key, value in node.items():
            yield key
            yield from _all_keys(value)
    elif isinstance(node, list):
        for item in node:
            yield from _all_keys(item)


def main(argv=None):
    parser = argparse.ArgumentParser(prog="task-ctl")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("init", help="create a configuration from the schema")
    p.add_argument("--schema", required=True)
    p.add_argument("--defaults", help="optional defaults file to seed values from")
    p.add_argument("--out", required=True)
    p.add_argument("--transcript")
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set", help="set one scalar key in a configuration")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.add_argument("--transcript")
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("derive", help="derive a profile configuration")
    p.add_argument("--config", required=True)
    p.add_argument("--profile", required=True)
    p.add_argument("--overrides")
    p.add_argument("--spec", help="profile spec, may carry <key>_delta entries")
    p.add_argument("--out", required=True)
    p.add_argument("--transcript")
    p.set_defaults(func=cmd_derive)

    p = sub.add_parser("validate", help="validate one or more configurations")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True, action="append")
    p.add_argument("--rules", help="optional validation rules file")
    p.add_argument("--report", help="optional path for a JSON validation report")
    p.add_argument("--transcript")
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("export-report", help="write a run report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--notes", help="optional JSON file merged into the report")
    p.add_argument("--transcript")
    p.set_defaults(func=cmd_report)

    p = sub.add_parser("summarize", help="summarize the generated artifacts")
    p.add_argument("--rules", required=True)
    p.add_argument("--artifacts-dir", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--notes")
    p.add_argument("--transcript")
    p.set_defaults(func=cmd_summarize)

    args = parser.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()
